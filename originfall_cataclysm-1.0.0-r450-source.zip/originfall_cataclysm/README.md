# 源石天灾（OriginFall Cataclysm）模组源代码

- Minecraft 版本：**1.20.1**
- 加载器：**Forge 47.4.0**（ForgeGradle [6.0, 6.2)）
- 模组版本：**1.0.0-r450**
- 模组 ID：`originfall_cataclysm`
- Java 版本：17（toolchain 已在 `build.gradle` 中声明）

## 目录结构

```
originfall_cataclysm/
├── build.gradle              ForgeGradle 构建脚本（含多源码集接线）
├── settings.gradle
├── gradle.properties
├── libs/                     编译期依赖（第三方模组 jar，仅 compileOnly，不打开发布包）
│   ├── epic-fight-20-6.14.17-mc1.20.1-forge.jar
│   ├── l2hostility-2-14.5.19.jar
│   └── l2library-2-8.5.3.jar
└── src/
    ├── main/                 主源码集
    │   ├── java/cn/blockforge/generated/originfallcataclysm/
    │   │   ├── *.java        游戏逻辑：天灾 Boss、邪魔（Calamity）体系、坍缩效果、
    │   │   │                 邪魔之约档位、源石感染、陨石、客户端/服务端事件等
    │   │   ├── client/       渲染器、粒子、客户端事件
    │   │   └── mixin/        LivingEntity 效果免疫 Mixin
    │   └── resources/
    │       ├── META-INF/mods.toml
    │       ├── pack.mcmeta / originfall_cataclysm.mixins.json
    │       ├── assets/originfall_cataclysm/   贴图、模型、音效、粒子、语言文件
    │       └── data/                          配方、战利品表、标签等数据
    ├── epicfight/            史诗战斗（Epic Fight）兼容层，仅在装有 Epic Fight 时加载
    └── l2compat/             莱特兰-恶意（L2Hostility）兼容层，仅在装有该模组时加载
```

## 构建方法

环境要求：JDK 17、Gradle 8.x（无需 wrapper，工程未附带；也可用你 IDE 自带的 Gradle）。

```bash
cd originfall_cataclysm
gradle build
```

产物位于 `build/libs/originfall_cataclysm-<版本号>.jar`，放进 `.minecraft/mods` 即可。

说明：

1. `libs/` 下三个 jar 只参与 `epicfight` / `l2compat` 源码集的编译期类路径，
   不会打进成品 jar。运行时兼容层由主代码检测已装模组（ModList / 反射入口）后按需加载，
   没装 Epic Fight 或莱特兰-恶意也完全正常运行。
2. `gradle.properties` 里的 `org.gradle.java.installations.paths` 是构建容器的本地 JDK 路径提示，
   在你自己的机器上可以直接删掉这一行，不影响构建。
3. 构建需要能访问 Forge Maven（`maven.minecraftforge.net`）拉取 ForgeGradle 与 1.20.1 的映射。

## r450 版本要点

- 邪魔区域累计感染时间由 5 秒调整为 10 秒。
- 新增"邪魔测试"物品（仅创造模式可获得）：对生物使用可施加坍缩效果。
- 邪魔之约档位规则重写：累计层数达到 8、16、32、64……（2 的三次方及以上的 2 的幂），
  以及 100 及以后每 100 的倍数（100、200、300……）各点亮一个档位。
  实现见 `src/main/java/.../CollapseCovenant.java`。
