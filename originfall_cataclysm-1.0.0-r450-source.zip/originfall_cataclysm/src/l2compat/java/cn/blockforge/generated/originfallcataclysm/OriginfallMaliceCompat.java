package cn.blockforge.generated.originfallcataclysm;

import dev.xkmc.l2hostility.content.capability.chunk.ChunkDifficulty;
import dev.xkmc.l2hostility.content.capability.mob.MobTraitCap;
import dev.xkmc.l2hostility.content.logic.DifficultyLevel;
import dev.xkmc.l2hostility.content.logic.PlayerFinder;
import dev.xkmc.l2hostility.content.logic.TraitManager;
import dev.xkmc.l2hostility.content.traits.base.MobTrait;
import dev.xkmc.l2hostility.init.data.LHConfig;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.config.ConfigTracker;
import net.minecraftforge.fml.config.ModConfig;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 莱特兰-恶意（L2Hostility）真实接入层，位于独立的 l2compat 源码集：
 * 编译期依赖它的 jar，运行期只有在确认莱特兰-恶意在场时才会被
 * {@link MaliceCompat} 经反射装载；未安装本模组的任何路径都不会触达这里。
 *
 * <p>职责（全部直接读写莱特兰-恶意自己的 {@link MobTraitCap} 数据）：</p>
 * <ul>
 *   <li>击杀学习：模组生物（学习者）近战/远程击杀带词条的生物后，
 *       把目标的莱特兰恶意词条学给自己；学习数量上限为原有学习行动逻辑数量的两倍，
 *       且恶意等级每提升 20 级再增加 1 个上限（{@link LearnedTraitLogic#maliceLimit}）。</li>
 *   <li>击杀继承等级：学习者击杀带恶意等级的目标后，继承对方等级的 32.5%，
 *       不足整数的零头向上取整，且只升不降（{@link #onLearnerKillInheritLevel}）。</li>
 *   <li>融合升级：已拥有的词条再次获得时提升 1 级（不超过词条自身等级上限），
 *       不占用词条数量名额。</li>
 *   <li>首领附带：「女祭司」普瑞赛斯与「预言家」博士初始生成时按 boss 级别
 *       （恶意等级顶格）随机附带 2~3 条 2~3 级的词条。</li>
 *   <li>召唤生物同样学习：玩家通过刷怪蛋、道具或代码召唤的本模组生物，
 *       在被本层补初始化时其莱特兰恶意等级跟随召唤者玩家，并且会按该等级
 *       完整补一次恶意词条——即「召唤出来的同样适用学习莱特兰恶意词条」，
 *       而不是停留在 0 级、身上一条词条都没有。</li>
 *   <li>复活再随机：本模组机制（复活陨石波次）复活出的模组生物，丢弃死亡快照带回的
 *       旧等级与旧词条，按莱特兰自身的区域修正链路重新随机等级与词条
 *       （见 {@link #onRevive}）；首领重新按首领档位随机附带。</li>
 *   <li>兼容配置修正：自动把莱特兰-恶意的 {@code allowPlayerAllies} 与
 *       {@code allowTraitOnOwnable} 修正为 true 并落盘（见
 *       {@link #forceCompatConfigs()}），让玩家召唤/认主的生物在莱特兰自己的
 *       初始化与每 tick 清理路径里都被当作正常生物对待。</li>
 *   <li>自适应强化：生物按恶意等级的生命/伤害加成由莱特兰-恶意自身的
 *       {@code TraitManager.scale} 链路完成，本层不重复缩放，避免双重加成。</li>
 * </ul>
 *
 * <p>其他模组生物是否附带词条完全交给莱特兰-恶意的原版机制（区域/玩家恶意等级
 * 刷怪初始化），本层不做任何干预；击杀链对<b>本模组所有生物与本模组所有召唤生物</b>
 * （{@link LearnedTraitLogic#isKillLearningCandidate}，恶意词条通道放宽口径）生效，
 * 玩家、原版与其他模组生物的击杀既不读取、也不继承任何恶意词条或等级。</p>
 */
public final class OriginfallMaliceCompat {
    /** 首领初始词条附带的一次性标记。 */
    private static final String BOSS_GRANTED_TAG = "OriginFallMaliceBossGranted";
    /** 玩家召唤生物补词条的一次性标记：避免每个 tick 反复重掷它的恶意词条。 */
    private static final String SUMMONED_TRAITS_TAG = "OriginFallSummonedTraitsGranted";
    /** 莱特兰-恶意的模组 ID。 */
    private static final String L2_MOD_ID = "l2hostility";
    /** 莱特兰-恶意的词条注册表：l2hostility:trait。 */
    private static final ResourceKey<Registry<MobTrait>> TRAIT_REGISTRY =
            ResourceKey.createRegistryKey(ResourceLocation.fromNamespaceAndPath("l2hostility", "trait"));

    private static final int BOSS_TRAIT_COUNT_MIN = 2;
    private static final int BOSS_TRAIT_COUNT_MAX = 3;
    private static final int BOSS_TRAIT_RANK_MIN = 2;
    private static final int BOSS_TRAIT_RANK_MAX = 3;

    /** 莱特兰 {@code MobTraitCap.pending} 字段：把尚未落表的词条写入并入本地视图。 */
    private static final java.lang.reflect.Field PENDING_FIELD = resolvePendingField();

    private static java.lang.reflect.Field resolvePendingField() {
        try {
            var field = MobTraitCap.class.getDeclaredField("pending");
            field.setAccessible(true);
            return field;
        } catch (ReflectiveOperationException | RuntimeException | LinkageError e) {
            return null; // 字段结构变化时退化为 traits 表视图。
        }
    }

    private OriginfallMaliceCompat() {}

    /**
     * 自动检测并把莱特兰-恶意的两个「玩家生物」配置修正为 {@code true}，并同步落盘。
     *
     * <ul>
     *   <li>{@code allowTraitOnOwnable}（Keep traits on mobs tamed by player）：为
     *       {@code false}（默认值）时，莱特兰会在自己的 {@code MobTraitCap.tick} 里每个 tick
     *       清空所有 {@code OwnableEntity} 且认主玩家的生物身上的 {@code traits}——本模组的学习者
     *       （终焉行者/天灾信使/特蕾西娅/傀儡等）只要被玩家驯服或认主，刚学到的词条就会在
     *       下一 tick 被抹掉，表现为「部分生物的词条学了却留不住」。</li>
     *   <li>{@code allowPlayerAllies}（Allow mobs allied to player to have levels）：为
     *       {@code false}（默认值）时，莱特兰的 {@code MobTraitCap.init} 会对「与玩家结盟」的
     *       生物直接 {@code skip}，把它定成 0 级且不生成任何词条。玩家通过刷怪蛋、道具或驯服
     *       得到的生物因此永远学不到（也带不上）莱特兰恶意词条。</li>
     * </ul>
     *
     * <p>两者一起修正后，玩家召唤/认主的生物在莱特兰自己的初始化与每 tick 清理路径里都和
     * 普通生物一视同仁；本层随后还会为它们补召唤者等级与词条（见
     * {@link #applySummonedLearning}），保证「召唤出来的同样适用学习」。</p>
     *
     * <p>幂等且容错：配置尚未完成加载时 {@code get/set} 会抛异常（开发环境还会断言失败），
     * 此时直接跳过，由配置事件或每 tick 的兜底再次尝试，绝不因兼容层报错中断游戏。</p>
     */
    public static void forceCompatConfigs() {
        try {
            boolean traitOnOwnable = isFalse(LHConfig.COMMON.allowTraitOnOwnable);
            boolean playerAllies = isFalse(LHConfig.COMMON.allowPlayerAllies);
            if (!traitOnOwnable && !playerAllies) return;
            if (traitOnOwnable) {
                LHConfig.COMMON.allowTraitOnOwnable.set(true);
                log().info("[源石天灾] 检测到莱特兰-恶意 allowTraitOnOwnable=false，已自动修正为 true："
                        + "避免玩家驯服/召唤的学习者词条被每 tick 清空");
            }
            if (playerAllies) {
                LHConfig.COMMON.allowPlayerAllies.set(true);
                log().info("[源石天灾] 检测到莱特兰-恶意 allowPlayerAllies=false，已自动修正为 true："
                        + "让玩家通过刷怪蛋/道具召唤或驯服的生物同样能获得恶意等级与词条");
            }
            // 写回配置文件：否则本次会话虽然生效，重启后仍会从文件读回 false。
            for (ModConfig config : ConfigTracker.INSTANCE.fileMap().values()) {
                if (L2_MOD_ID.equals(config.getModId()) && config.getType() == ModConfig.Type.COMMON) {
                    config.save();
                    break;
                }
            }
        } catch (RuntimeException | LinkageError ignored) {
            // 配置尚未加载完成（或已处于异常状态）：留待配置加载事件与运行期兜底重试。
        }
    }

    /** 配置项当前是否为显式的 {@code false}；配置未加载完成时抛出的异常由调用方兜底。 */
    private static boolean isFalse(ForgeConfigSpec.BooleanValue value) {
        return value != null && !value.get();
    }

    private static org.slf4j.Logger log() {
        return com.mojang.logging.LogUtils.getLogger();
    }

    /** 兼容层 tick 入口：兜底初始化，首领按 boss 级别附带词条（幂等重试直到它的 cap 就绪）。 */
    public static void onLearnerTick(LivingEntity entity) {
        if (entity == null || entity.level().isClientSide || !(entity instanceof Mob mob)) return;
        MobTraitCap cap = capOf(mob);
        if (cap == null) {
            // 极端环境（被它的黑名单排除等）下拿不到恶意能力：
            // 首领退回模组独立形态的首领附带流程，保证 boss 初始词条永不落空。
            if (MaliceLevelSystem.isBoss(mob)) {
                MaliceLevelSystem.ensureAssigned(mob);
            }
            return;
        }
        if (!cap.isInitialized()) {
            // 代码召唤的生物不经 L2 的 FinalizeSpawn，恶意能力从未被 init；
            // 这里按原版同源规则补一次 init（取得区域难度下的词条与等级兜底），
            // 随后让它按召唤者补上等级与恶意词条（召唤出来的同样适用学习）。
            ensureInit(mob, cap);
            if (!cap.isInitialized()) return;
            applySummonedLearning(mob, cap, false);
        } else if (!MaliceLevelSystem.isBoss(mob) && isPlayerSummoned(mob)) {
            // 莱特兰自己的 cap tick 往往先于本模组 tick 完成初始化：它的 allowPlayerAllies=false
            // 会把「与玩家结盟」的认主生物初始化成 0 级，之后本层再没有补跟随的时机。
            // 玩家通过刷怪蛋、道具（表里之间/南瓜仪式）召唤的生物同理，这里同样给它们
            // 补上召唤者的等级与恶意词条；野生/自然生成的生物不受影响。
            applySummonedLearning(mob, cap, true);
        }
        // 首领（博士/女祭司）保持 boss 顶格级别并附带高级词条；不跟随召唤者等级。
        if (!MaliceLevelSystem.isBoss(mob)) return;
        if (mob.getPersistentData().getBoolean(BOSS_GRANTED_TAG)) return;
        grantBossTraits(mob, cap);
        mob.getPersistentData().putBoolean(BOSS_GRANTED_TAG, true);
    }

    /**
     * 模组机制复活后的莱特兰再随机入口。
     *
     * <p>复活体是从死亡瞬间的实体快照重建并复活的，莱特兰的能力数据
     * （{@code lv}、{@code traits} 与已序列化到快照里的 {@code stage}）会随快照一并带回，
     * 于是复活后仍挂着死亡前的旧等级与旧词条，表现为「复活还是原来的恶意等级与词条」。
     * 按本轮需求「复活后按照莱特兰机制随机等级和莱特兰词条」，这里：</p>
     * <ol>
     *   <li>先清掉跨死亡遗留在实体数据里的一次性标记（召唤补词条标记、首领附带标记），
     *       否则复活体的补词条与首领附带会被误判为已完成而跳过。</li>
     *   <li>调用莱特兰自身的 {@link MobTraitCap#deinit()} 丢弃快照带回的旧等级与旧词条，
     *       再用与它自然刷怪完全相同的 {@link ChunkDifficulty} 区域修正调用
     *       {@link MobTraitCap#init}，由 {@code TraitManager.fill} 重新随机出等级与词条。</li>
     *   <li>首领仍按首领档位附带随机高级词条（与初始生成同一规则）。</li>
     * </ol>
     *
     * <p>只对模组生物（{@link LearnedTraitLogic#isLearner} 判定的学习者）生效：
     * 原版与其他模组生物即使由本模组机制复活，其莱特兰数据也不做任何改动。</p>
     */
    public static void onRevive(LivingEntity entity) {
        if (entity == null || entity.level().isClientSide || !(entity instanceof Mob mob)) return;
        if (!LearnedTraitLogic.isLearner(mob)) return;
        mob.getPersistentData().remove(SUMMONED_TRAITS_TAG);
        mob.getPersistentData().remove(BOSS_GRANTED_TAG);
        MobTraitCap cap = capOf(mob);
        if (cap == null) {
            // 拿不到莱特兰能力（被它的黑名单排除等）：退回模组独立形态的等级与首领附带。
            MaliceLevelSystem.rerollOnRevive(mob);
            return;
        }
        // 丢弃死亡快照里带回的旧等级与旧词条，按莱特兰自身机制重掷。
        cap.deinit();
        ensureInit(mob, cap);
        if (!cap.isInitialized()) return;
        if (MaliceLevelSystem.isBoss(mob)) {
            grantBossTraits(mob, cap);
            mob.getPersistentData().putBoolean(BOSS_GRANTED_TAG, true);
        }
        cap.syncToClient(mob);
    }

    /** 该生物是否由玩家召唤/认主：认主玩家、刷怪蛋召唤，或道具（南瓜仪式）制造。 */
    private static boolean isPlayerSummoned(Mob mob) {
        if (hasPlayerOwner(mob)) return true;
        if (mob instanceof CalamityMob calamity && calamity.isSpawnEggSummoned()) return true;
        return mob instanceof SourceOreGolem golem && golem.getManufacturerUUID() != null;
    }

    /**
     * 玩家召唤生物的「同样学习」：让刷怪蛋、道具或代码召唤出来的学习者照样取得
     * 莱特兰恶意等级与恶意词条。
     *
     * <p>本模组的学习者大量由代码、道具或刷怪蛋召唤，它们要么不经莱特兰的
     * {@code FinalizeSpawn}，要么因 {@code allowPlayerAllies=false} 被它的 {@code init}
     * 直接跳过成 0 级、身上一条词条都没有。因此这里在补初始化（或莱特兰抢先初始化）之后：</p>
     * <ul>
     *   <li><b>没有词条</b>的：按召唤者玩家的当前恶意等级完整重掷一次词条
     *       （{@link MobTraitCap#reinit} 且必然出词条），使它像自然生成的同等级生物一样
     *       「学到」莱特兰恶意词条；每个实体只尝试一次，不反复重掷。</li>
     *   <li><b>已有词条</b>的：只把等级<b>只升不降</b>地跟到召唤者，不重掷已有词条，
     *       也不覆盖击杀继承来的等级。</li>
     * </ul>
     *
     * <p>找不到可引用玩家（远离玩家的个体、玩家恶意能力尚未就绪）时保持原样。</p>
     *
     * @param requirePlayerSummoned 为 true 时只处理可确认由玩家召唤/认主的生物
     *                              （用于莱特兰抢先初始化的刷怪蛋/道具召唤）；
     *                              为 false 时用于本层补初始化的代码召唤生物。
     */
    private static void applySummonedLearning(Mob mob, MobTraitCap cap, boolean requirePlayerSummoned) {
        if (MaliceLevelSystem.isBoss(mob)) return;
        if (requirePlayerSummoned) {
            if (!isPlayerSummoned(mob)) return;
            // 已被莱特兰初始化过的召唤生物：只有「等级仍为 0」或「身上没有词条」才需要补，
            // 已经正常的个体直接返回，避免每 tick 为它做一次「最近的玩家」检索。
            if (cap.getLevel() > 0 && !cap.traits.isEmpty()) return;
        }
        Player summoner = findSummoner(mob);
        if (summoner == null) return;
        int playerLevel;
        try {
            playerLevel = DifficultyLevel.ofAny(summoner);
        } catch (RuntimeException | LinkageError e) {
            return; // 玩家恶意能力尚未就绪：保持区域兜底等级。
        }
        if (playerLevel < 0) return;
        if (cap.traits.isEmpty() && playerLevel > 0
                && !mob.getPersistentData().getBoolean(SUMMONED_TRAITS_TAG)) {
            // 召唤生物同样适用学习：按召唤者等级完整生成一次恶意词条。
            cap.reinit(mob, playerLevel, true);
            mob.getPersistentData().putBoolean(SUMMONED_TRAITS_TAG, true);
            cap.syncToClient(mob);
            return;
        }
        // 已有词条（或补词条已尝试过）：等级只升不降地跟随召唤者。
        if (playerLevel > cap.getLevel()) {
            cap.setLevel(mob, playerLevel);
            cap.syncToClient(mob);
        }
    }

    /** 该生物是否认主于一名玩家（玩家驯服/召唤的本模组学习者）。 */
    private static boolean hasPlayerOwner(Mob mob) {
        return mob instanceof net.minecraft.world.entity.OwnableEntity ownable
                && ownable.getOwner() instanceof Player;
    }

    /** 召唤者玩家：优先认主/已绑定的玩家，否则就近取在线玩家（召唤环境里召唤者通常就在附近）。 */
    private static Player findSummoner(Mob mob) {
        if (mob instanceof net.minecraft.world.entity.OwnableEntity ownable) {
            LivingEntity owner = ownable.getOwner();
            if (owner instanceof ServerPlayer serverPlayer) return serverPlayer;
        }
        if (mob.level() instanceof ServerLevel serverLevel) {
            Player nearest = PlayerFinder.getNearestPlayer(serverLevel, mob);
            if (nearest != null) return nearest;
        }
        return null;
    }

    /**
     * 击杀学习入口：学习者击杀带词条的生物后，可学习对方的所有词条。
     *
     * <p>规则与本轮需求逐条对应：</p>
     * <ol>
     *   <li>相同词条优先融合升级：我方已有、且未到该词条自身等级上限的，逐条提升 1 级。
     *       融合只改等级、不新增条目，因此<b>不占用词条数量上限</b>。</li>
     *   <li>新词条按剩余名额学入：名额 = 恶意词条数量上限 − 我方当前已有词条数。
     *       上限取 {@link LearnedTraitLogic#maliceLimit}（原有学习生物行动逻辑数量的两倍，
     *       外加恶意等级每提升 20 级增加的 1 个上限）。等级取值经
     *       {@link MaliceCompat#maliceLevelOf} 直接读莱特兰-恶意自身的当前等级。</li>
     *   <li>当对方可学的词条数量大于我方剩余名额时，把对方词条<b>随机抽取</b>到名额数量
     *       再学入（用实体自带随机源，保证同一对局可复现、不引入额外随机流）。</li>
     *   <li>被恶意模组封禁（{@code isBanned}）或按它自身规则不允许挂到该生物身上的词条
     *       （{@code allow}）不学，避免破坏莱特兰-恶意自己的约束。</li>
     *   <li><b>模组生物击杀模组生物</b>同样可学：本模组由代码召唤（仪式/技能/龙陨等）的
     *       生物不经它的 {@code FinalizeSpawn}，L2 能力从未被 init、{@code traits} 恒为空。
     *       因此在取目标词条前，先按它自身的区域难度规则为受害者补一次 {@code init}
     *       （{@link #ensureInit}），受害者便有了可被学习的词条；无需初始化的天然/已初始化
     *       目标不受影响。</li>
     * </ol>
     */
    public static void onLearnerKill(LivingEntity learner, LivingEntity victim) {
        if (learner == null || victim == null || learner.level().isClientSide) return;
        if (!(learner instanceof Mob mob)) return;
        // 硬闸门：只有本模组生物与本模组召唤生物（恶意词条通道口径，含备用学习机制）
        // 才读取并继承被击杀者的莱特兰恶意词条。原版与其他模组生物即使击杀了带词条的目标，
        // 也不会被“感染”到任何词条。
        if (!LearnedTraitLogic.isKillLearningCandidate(mob)) return;
        MobTraitCap learnerCap = capOf(learner);
        if (learnerCap == null) return;
        if (!learnerCap.isInitialized()) {
            ensureInit(mob, learnerCap); // 代码召唤的学习者同样补初始化，保证击杀学习不缺位。
            if (!learnerCap.isInitialized()) return;
        }
        // 直接读取被击杀者身上莱特兰-恶意自己的词条表；本模组生物被代码召唤时
        // 不经它的 FinalizeSpawn，故先按它自身的区域难度规则补一次 init。
        Map<MobTrait, Integer> source = victimTraits(victim);
        if (source.isEmpty()) return;

        // 以「既有词条 + 尚未落表的 pending 写入」的本地视图计算名额与融合：
        // setTrait 只把写入排进 pending，直到下一次 cap tick 才落到 traits 表里；
        // 同一 tick 内的多次击杀（例如溅射连杀）若不并入 pending，会把同一词条重复算作新词条，
        // 既可能撑破名额，也可能用更低的等级覆盖掉已经融合升级过的写入。
        Map<MobTrait, Integer> owned = ownedView(learnerCap);
        // 先分组，防止“先学新词条占满名额”导致融合机会被挤掉。
        List<MobTrait> mergeable = new ArrayList<>();
        List<MobTrait> fresh = new ArrayList<>();
        for (MobTrait trait : source.keySet()) {
            if (trait == null || trait.isBanned() || !trait.allow(learner)) continue;
            if (owned.getOrDefault(trait, 0) > 0) {
                mergeable.add(trait);
            } else {
                fresh.add(trait);
            }
        }

        int gained = 0;
        // ① 相同词条融合升级：只提升等级，不占用词条数量。
        for (MobTrait trait : mergeable) {
            int current = owned.getOrDefault(trait, 0);
            int maxRank = Math.max(1, trait.getMaxLevel());
            if (current < maxRank) {
                learnerCap.setTrait(trait, current + 1);
                owned.put(trait, current + 1);
                gained++;
            }
        }
        // ②③ 新词条按剩余名额学入；对方词条多于名额时随机抽取到名额数量。
        int limit = LearnedTraitLogic.maliceKillLimit(learner);
        int slots = limit - owned.size();
        if (slots > 0 && !fresh.isEmpty()) {
            if (fresh.size() > slots) shuffleWithMobRandom(fresh, mob);
            int take = Math.min(slots, fresh.size());
            for (int i = 0; i < take; i++) {
                MobTrait trait = fresh.get(i);
                int maxRank = Math.max(1, trait.getMaxLevel());
                Integer rank = source.get(trait);
                int applied = Math.max(1, Math.min(rank == null ? 1 : rank, maxRank));
                learnerCap.setTrait(trait, applied);
                owned.put(trait, applied);
                gained++;
            }
        }
        if (gained == 0) return;
        learnerCap.syncToClient(learner);
    }

    /**
     * 击杀等级继承：学习者击杀带恶意等级的目标后，继承对方等级的
     * {@link MaliceLevelSystem#KILL_INHERIT_RATIO}（32.5%），<b>不足整数的零头向上取整</b>，
     * 且只升不降；首领固定停在首领档位，不参与继承。
     *
     * <p>等级直接写回莱特兰-恶意自身的 {@link MobTraitCap#setLevel}，
     * 由它按等级同步缩放属性并下发客户端。原版与其他模组生物不是学习者，
     * 这里直接返回，等级不会外溢到击杀链之外。</p>
     */
    public static void onLearnerKillInheritLevel(LivingEntity learner, LivingEntity victim) {
        if (learner == null || victim == null || learner.level().isClientSide) return;
        // 等级继承与恶意词条学习共用同一放宽口径：本模组生物 + 本模组召唤生物。
        if (!(learner instanceof Mob mob) || !LearnedTraitLogic.isKillLearningCandidate(mob)) return;
        if (MaliceLevelSystem.isBoss(mob)) return;
        // 先补齐被击杀者的恶意能力初始化，再读它的等级：本模组大量生物由代码召唤，
        // 不经莱特兰的 FinalizeSpawn，cap 处于 PRE_INIT 时 currentMaliceLevel 只会返回 -1，
        // 导致「带等级的召唤生物被击杀时不继承等级」。补初始化后读到的是它与词条同源的区域等级。
        ensureInitialized(victim);
        int victimLevel = currentMaliceLevel(victim);
        if (victimLevel <= 0) return;
        int inherited = MaliceLevelSystem.inheritedLevel(victimLevel);
        if (inherited <= 0) return;
        MobTraitCap learnerCap = capOf(learner);
        if (learnerCap == null) return;
        if (!learnerCap.isInitialized()) {
            ensureInit(mob, learnerCap);
            if (!learnerCap.isInitialized()) return;
        }
        if (learnerCap.getLevel() >= inherited) return;
        learnerCap.setLevel(mob, inherited);
        learnerCap.syncToClient(mob);
    }

    /** 读取被击杀者身上的莱特兰恶意词条快照；未被它接管或尚未初始化时返回空表。 */
    private static Map<MobTrait, Integer> victimTraits(LivingEntity victim) {
        MobTraitCap victimCap = capOf(victim);
        if (victimCap == null) return Map.of();
        if (!victimCap.isInitialized()) {
            if (victim instanceof Mob victimMob) {
                ensureInit(victimMob, victimCap);
            }
            if (!victimCap.isInitialized()) return Map.of();
        }
        return ownedView(victimCap);
    }

    /** 用实体自带的随机源做 Fisher–Yates 洗牌，保持与它自身刷怪逻辑一致的随机流。 */
    private static void shuffleWithMobRandom(List<MobTrait> list, Mob mob) {
        for (int i = list.size() - 1; i > 0; i--) {
            int j = mob.getRandom().nextInt(i + 1);
            MobTrait tmp = list.get(i);
            list.set(i, list.get(j));
            list.set(j, tmp);
        }
    }

    /**
     * 学习者当前真正拥有的词条视图：{@code traits} 表中已落表的，加上 {@code pending} 里
     * 尚未落表的写入（后者在下次 cap tick 之前不可见）。这样同一 tick 内的连续击杀
     * （溅射连杀）也能正确判断融合与剩余名额。
     *
     * <p>{@code pending} 是莱特兰的私有字段，取不到时退化为只读 {@code traits} 表，
     * 兼容层绝不因此报错。</p>
     */
    private static Map<MobTrait, Integer> ownedView(MobTraitCap cap) {
        Map<MobTrait, Integer> owned = new LinkedHashMap<>(cap.traits);
        if (PENDING_FIELD == null) return owned;
        try {
            Object raw = PENDING_FIELD.get(cap);
            if (!(raw instanceof Iterable<?> list)) return owned;
            for (Object element : list) {
                if (element instanceof com.mojang.datafixers.util.Pair<?, ?> pair
                        && pair.getFirst() instanceof MobTrait trait
                        && pair.getSecond() instanceof Integer level) {
                    if (level <= 0) {
                        owned.remove(trait);
                    } else {
                        owned.merge(trait, level, Integer::max);
                    }
                }
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // 字段结构变化时退化为 traits 表视图，不影响主流程。
        }
        return owned;
    }

    /** 首领按 boss 级别附带词条：恶意等级顶格，随机 2~3 条互不重复的词条，等级 2~3（受词条上限约束）。 */
    private static void grantBossTraits(Mob mob, MobTraitCap cap) {
        int bossLevel = Math.max(1, TraitManager.getMaxLevel());
        cap.setLevel(mob, bossLevel);
        if (!(mob.level() instanceof ServerLevel level)) return;
        var registry = level.registryAccess().registry(TRAIT_REGISTRY);
        if (registry.isEmpty()) return;
        List<MobTrait> pool = new ArrayList<>();
        for (MobTrait trait : registry.get().stream().toList()) {
            if (trait == null || trait.isBanned()) continue;
            if (trait.getMaxLevel() < BOSS_TRAIT_RANK_MIN) continue; // 封顶 1 级的词条不配当首领初始词条。
            if (!trait.allow(mob)) continue;
            if (cap.getTraitLevel(trait) > 0) continue;
            pool.add(trait);
        }
        // 用实体自带随机源做 Fisher–Yates 洗牌。
        for (int i = pool.size() - 1; i > 0; i--) {
            int j = mob.getRandom().nextInt(i + 1);
            MobTrait tmp = pool.get(i);
            pool.set(i, pool.get(j));
            pool.set(j, tmp);
        }
        int wanted = BOSS_TRAIT_COUNT_MIN
                + mob.getRandom().nextInt(BOSS_TRAIT_COUNT_MAX - BOSS_TRAIT_COUNT_MIN + 1);
        int count = Math.min(wanted, pool.size());
        for (int i = 0; i < count; i++) {
            MobTrait trait = pool.get(i);
            int capRank = Math.min(BOSS_TRAIT_RANK_MAX, trait.getMaxLevel());
            int rank = Math.min(BOSS_TRAIT_RANK_MIN, capRank)
                    + mob.getRandom().nextInt(Math.max(1, capRank - Math.min(BOSS_TRAIT_RANK_MIN, capRank) + 1));
            cap.setTrait(trait, rank);
        }
        if (count > 0) cap.syncToClient(mob);
    }

    // ===== 工具 =====

    /**
     * 门面取恶意等级的入口：直接读莱特兰-恶意挂在它自己 cap 上的当前等级
     * （词条数量上限「每 20 级 +1」加成的取值来源）。
     * 实体未被它接管或 cap 尚未初始化时返回 -1，由门面回退独立等级系统。
     */
    public static int currentMaliceLevel(LivingEntity entity) {
        if (entity == null) return -1;
        MobTraitCap cap = capOf(entity);
        if (cap == null || !cap.isInitialized()) return -1;
        return Math.max(0, cap.getLevel());
    }

    /** 读取莱特兰-恶意挂在生物身上的词条能力；未被它接管的实体返回 null。 */
    private static MobTraitCap capOf(LivingEntity entity) {
        return entity.getCapability(MobTraitCap.CAPABILITY).resolve().orElse(null);
    }

    /**
     * 恶意能力的补初始化：本模组大量生物由代码召唤（仪式、技能、龙陨降临等），
     * 不经它的 {@code MobSpawnEvent.FinalizeSpawn}；这里用与它自身完全相同的
     * {@code ChunkDifficulty} 区域修正器调用它的 {@code init}，判定与随机化
     * 全部走它的原版机制，不引入任何自定义规则。
     */
    private static void ensureInit(Mob mob, MobTraitCap cap) {
        if (cap.isInitialized() || mob.level().isClientSide) return;
        ChunkDifficulty.at(mob.level(), mob.blockPosition())
                .ifPresent(modifier -> cap.init(mob.level(), mob, modifier));
    }

    /** 目标为生物且其恶意能力尚未初始化时补一次初始化；非生物或已初始化时不做任何事。 */
    private static void ensureInitialized(LivingEntity entity) {
        if (entity == null || entity.level().isClientSide || !(entity instanceof Mob mob)) return;
        MobTraitCap cap = capOf(mob);
        if (cap == null || cap.isInitialized()) return;
        ensureInit(mob, cap);
    }

}
