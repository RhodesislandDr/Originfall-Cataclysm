package cn.blockforge.generated.originfallcataclysm;

import cn.blockforge.generated.originfallcataclysm.client.NativeApocataDanceState;
import net.minecraft.world.entity.LivingEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import yesman.epicfight.api.animation.AnimationClip;
import yesman.epicfight.api.animation.AnimationManager;
import yesman.epicfight.api.animation.Joint;
import yesman.epicfight.api.animation.JointTransform;
import yesman.epicfight.api.animation.Pose;
import yesman.epicfight.api.animation.types.DynamicAnimation;
import yesman.epicfight.api.animation.types.StaticAnimation;
import yesman.epicfight.api.model.Armature;
import yesman.epicfight.api.utils.math.Vec3f;
import yesman.epicfight.gameasset.Armatures;
import yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch;

/**
 * 「扒臀长舞」的史诗战斗版本：装了这个 mod 时，舞蹈交给史诗战斗自己的 BIPED 骨骼去演。
 *
 * <p>不读 json 关键帧文件，而是每帧按模组 {@link BossDanceKeyframes} 里那 577 tick（
 * 编排 30.3 秒 ×1.05 倍基础速度）的 Blockbench 关键帧<b>程序化</b>地算出每根关节的旋转，写进史诗战斗的
 * {@link Pose}。这样舞蹈、连段、受击用的是同一套骨架与渲染路径，武器挂点、火焰拖尾、
 * 补丁渲染器全都自然生效，也不会再出现「史诗战斗把舞蹈吞掉」的问题。</p>
 *
 * <h2>坐标系换算（本类唯一的难点，已用数值验证）</h2>
 * <p>模组模型用的是原版玩家骨架坐标（+Y 朝下、模型朝 −Z），史诗战斗的网格是另一套
 * 右手系（+Y 朝上），两者相差 {@code M = diag(-1,-1,1)}（绕 Z 轴 180°）。关节的
 * <b>静止朝向</b>又各不一样（史诗战斗的绑定矩阵里手臂、腿骨都是斜的），所以直接把
 * 欧拉角抄过去一定会错轴。</p>
 *
 * <p>正确做法是：{@code anim = W⁻¹ · (M · R_rel · M) · W}，其中 W 是该关节在史诗战斗里的
 * <b>静止世界朝向</b>（把 Root 到它的绑定旋转连乘起来），{@code R_rel} 是模组关键帧里
 * 该部件相对父级的 ZYX 欧拉角。把 M 的共轭展开正好是「x/y 取反、z 不变」：
 * {@code M·Rz(z)Ry(y)Rx(x)·M = Rz(z)·Ry(−y)·Rx(−x)}，代码里就是这么写的。</p>
 *
 * <p>这条公式用 {@code work/verify_ef_pose.py} 对着史诗战斗的真实数据（biped.json 的
 * 绑定链 + 反编译出来的 {@code JointTransform.getAnimationBoundMatrix} 合成规则）逐帧
 * 对过账：20 根关节在 17 个采样帧上的世界旋转误差 ≤ 3e-6，位置误差 ≤ 2 像素。</p>
 *
 * <h2>驱动哪些关节</h2>
 * <ul>
 *   <li>{@code Root}：位移（下蹲/蹦跳）+ 整体偏航；</li>
 *   <li>{@code Torso}：躯干；{@code Head}：头（相对躯干）；实体自身的扭头（现有方向）
 *       由史诗战斗在帧末前置叠加，见 {@link #doesHeadRotFollowEntityHead()}；</li>
 *   <li>{@code Arm_R/L}：上臂（相对躯干，史诗战斗的骨架里躯干旋转会自动带走它）；</li>
 *   <li>{@code Elbow_R/L}：小臂（屈肘）；</li>
 *   <li>{@code Thigh_R/L}：大腿；{@code Leg_R/L}：小腿（屈膝）。</li>
 * </ul>
 *
 * <p>{@code Chest}/{@code Shoulder}/{@code Hand}/{@code Tool}/{@code Knee} 一律不动：
 * 它们是骨骼里的中间节点，保持静止就等于跟着父级走，和模组骨架的层级一致。</p>
 */
public final class OriginfallDanceAnimation extends StaticAnimation {
    private static final float DEG = (float) (Math.PI / 180.0D);
    /** 关键帧按 20 tick/秒书写。 */
    private static final float TICKS_PER_SECOND = 20.0F;
    /** 每套骨架（正常只有 BIPED 一套）的「关节名 → 静止世界朝向」，懒加载一次。 */
    private static final Map<Armature, Map<String, Quaternionf>> BIND_WORLD = new ConcurrentHashMap<>();

    /** 空关键帧：真正的姿势在 {@link #modifyPose} 里现算，json 文件不存在也无所谓。 */
    private final AnimationClip proceduralClip = new AnimationClip();

    public OriginfallDanceAnimation(AnimationManager.AnimationAccessor<? extends StaticAnimation> accessor) {
        super(0.15F, true, accessor, Armatures.BIPED);
        this.proceduralClip.setClipTime(BossDanceKeyframes.TICKS / TICKS_PER_SECOND);
    }

    /** 舞蹈数据全在代码里，不需要（也没有）json 动画文件。 */
    @Override
    public void loadAnimation() {
    }

    @Override
    public AnimationClip getAnimationClip() {
        return this.proceduralClip;
    }

    /**
     * <b>保留生物原有的扭头</b>：按现有方向转，不做任何索敌。
     *
     * <p>史诗战斗会在每帧末把实体自己的头朝向（{@code yHeadRot} 相对身体朝向的偏航 +
     * 头部俯仰）作为一次「世界系绕竖轴/绕头部水平轴」的旋转<b>前置</b>乘到 {@code Head}
     * 关节当前的姿势变换上（{@code LivingEntityPatch#poseTick}）。早先为了让舞蹈里编好的
     * 头节点动作不被抹掉，这里返回过 {@code false}——代价就是原版那套「头跟着身体转向
     * 甩过去」的扭头整个消失，跳舞时头永远死死钉在身体正前方，看上去像头没装转盘，
     * 这正是「原有扭头未生效」的直接原因。</p>
     *
     * <p>现在改回 {@code true}：头先按实体<b>现有方向</b>转（服务端 {@link BossTauntLogic}
     * 每 tick 把 {@code yHeadRot} 限步长地拉向当前身体朝向，转身时头就自然甩过去），
     * 再叠加舞蹈关键帧里相对躯干的头节点角度。两者是串联合成而非互相覆盖，所以既看得见
     * 扭头，也看得见编排里的低头/侧头。头的偏航不再指向任何目标（{@code Head} 关键帧里
     * 原先那个「转头看锁定的伤害施加者」的 180° 反解已按需求去掉，见
     * {@code work/generate_boss_dance.py} 的 H2 段）。</p>
     */
    @Override
    public boolean doesHeadRotFollowEntityHead() {
        return true;
    }

    @Override
    public void modifyPose(DynamicAnimation animation, Pose pose, LivingEntityPatch<?> entitypatch, float time,
                           float partialTicks) {
        LivingEntity original = entitypatch.getOriginal();
        int remaining;
        int total;
        if (original instanceof CalamityMob mob) {
            remaining = mob.getTauntTicks();
            total = mob.getTauntTotalTicks();
        } else if (CaerulaArborCompat.isNativeApocataEntity(original)) {
            // 深蓝之树本尊（外部实体）在史诗战斗侧有它自己的补丁时，史诗战斗画的仍是
            // 它自己的骨架——舞蹈同样由这套关键帧驱动：舞程取客户端舞蹈会话表，
            // 姿势与替身同一通道（注入见 OriginfallEpicFightClientCompat 的 tick 钩子）。
            remaining = NativeApocataDanceState.remaining(original.getId());
            total = NativeApocataDanceState.total(original.getId());
        } else {
            return;
        }
        if (remaining <= 0) return;
        total = Math.max(remaining, total);
        // 相位跟舞蹈倒计时走（跟随客户端同步来的 20Hz 数据），partialTicks 负责帧间平滑，
        // 与模组自己那条 BossTauntPose 路径完全同步。
        float elapsed = (total - remaining) + partialTicks;
        float t = elapsed % BossDanceKeyframes.TICKS;
        if (t < 0.0F) t += BossDanceKeyframes.TICKS;

        float[] root = sample(BossDanceKeyframes.ROOT, t);
        float[] body = sample(BossDanceKeyframes.BODY, t);
        float[] head = sample(BossDanceKeyframes.HEAD, t);
        float[] rightArm = sample(BossDanceKeyframes.RIGHT_ARM, t);
        float[] leftArm = sample(BossDanceKeyframes.LEFT_ARM, t);
        float[] rightFore = sample(BossDanceKeyframes.RIGHT_FORE, t);
        float[] leftFore = sample(BossDanceKeyframes.LEFT_FORE, t);
        float[] rightLeg = sample(BossDanceKeyframes.RIGHT_LEG, t);
        float[] leftLeg = sample(BossDanceKeyframes.LEFT_LEG, t);
        float[] rightShin = sample(BossDanceKeyframes.RIGHT_SHIN, t);
        float[] leftShin = sample(BossDanceKeyframes.LEFT_SHIN, t);

        Armature armature = entitypatch.getArmature();
        Map<String, Quaternionf> bind = armature == null ? null
                : BIND_WORLD.computeIfAbsent(armature, OriginfallDanceAnimation::buildBindWorld);
        if (bind == null) return;

        // Root：整体位移（下蹲、蹦跳）与偏航。
        Quaternionf rootRotation = animQuat(bind, "Root", root[0], root[1], root[2]);
        if (rootRotation != null) {
            pose.putJointData("Root", JointTransform.translationRotation(
                    rootTranslation(bind, root[3], root[4], root[5]), rootRotation));
        }
        // 躯干、头、四肢都是「相对父级」的角度，父级旋转由骨骼层级自然带来。
        putRotation(pose, bind, "Torso", body);
        putRotation(pose, bind, "Head", head);
        putRotation(pose, bind, "Arm_R", rightArm);
        putRotation(pose, bind, "Arm_L", leftArm);
        putRotation(pose, bind, "Elbow_R", rightFore);
        putRotation(pose, bind, "Elbow_L", leftFore);
        putRotation(pose, bind, "Thigh_R", rightLeg);
        putRotation(pose, bind, "Thigh_L", leftLeg);
        putRotation(pose, bind, "Leg_R", rightShin);
        putRotation(pose, bind, "Leg_L", leftShin);
    }

    private static void putRotation(Pose pose, Map<String, Quaternionf> bind, String joint, float[] angles) {
        Quaternionf rotation = animQuat(bind, joint, angles[0], angles[1], angles[2]);
        if (rotation != null) {
            pose.putJointData(joint, JointTransform.rotation(rotation));
        }
    }

    /**
     * 模组角度 → 史诗战斗关节角：{@code W⁻¹ · Rz(z)·Ry(−y)·Rx(−x) · W}。
     * 关节不在骨架里时返回 null，调用方跳过。
     */
    private static Quaternionf animQuat(Map<String, Quaternionf> bind, String joint, float x, float y, float z) {
        Quaternionf world = bind.get(joint);
        if (world == null) return null;
        Quaternionf target = new Quaternionf()
                .rotateZ(z * DEG)
                .rotateY(-y * DEG)
                .rotateX(-x * DEG);
        return new Quaternionf(world).conjugate().mul(target).mul(world).normalize();
    }

    /**
     * 根位移：模组里是「1/16 格」的单位，先按 {@code M} 转成史诗战斗坐标系，再退回
     * Root 骨骼自己的本地系（Root 的静止朝向并不一定是单位阵，所以不能直接赋值）。
     */
    private static Vec3f rootTranslation(Map<String, Quaternionf> bind, float px, float py, float pz) {
        Quaternionf world = bind.get("Root");
        if (world == null) return new Vec3f();
        Vector3f local = new Vector3f(-px / 16.0F, -py / 16.0F, pz / 16.0F);
        new Quaternionf(world).conjugate().transform(local);
        return new Vec3f(local.x, local.y, local.z);
    }

    /** 把 Root→各关节的静止旋转连乘出来（与 {@code Armature.blendJoint} 的父链一致）。 */
    private static Map<String, Quaternionf> buildBindWorld(Armature armature) {
        Map<String, Quaternionf> out = new HashMap<>();
        collectBind(armature.rootJoint, new Quaternionf(), out);
        return out;
    }

    private static void collectBind(Joint joint, Quaternionf parentRotation, Map<String, Quaternionf> out) {
        Quaternionf world = new Quaternionf(parentRotation).mul(joint.getLocalTransform().toQuaternion()).normalize();
        out.put(joint.getName(), world);
        for (Joint child : joint.getSubJoints()) {
            collectBind(child, world, out);
        }
    }

    /**
     * 关键帧采样：8 个数字一组 {@code time, xRot, yRot, zRot, posX, posY, posZ, interp}，
     * 与 {@link BossTauntPose} 的采样规则一致（interp>0.5 走平滑插值）。
     */
    private static float[] sample(float[] keyframes, float t) {
        float[] out = new float[6];
        int n = keyframes.length / 8;
        if (n <= 0) return out;
        int i = 0;
        while (i < n - 1 && keyframes[(i + 1) * 8] <= t) i++;
        int j = Math.min(i + 1, n - 1);
        float t0 = keyframes[i * 8];
        float t1 = keyframes[j * 8];
        float f = t1 > t0 ? (t - t0) / (t1 - t0) : 0.0F;
        if (f < 0.0F) f = 0.0F;
        if (f > 1.0F) f = 1.0F;
        if (keyframes[i * 8 + 7] > 0.5F) f = f * f * (3.0F - 2.0F * f);
        int a = i * 8 + 1;
        int b = j * 8 + 1;
        for (int c = 0; c < 6; c++) {
            out[c] = keyframes[a + c] + (keyframes[b + c] - keyframes[a + c]) * f;
        }
        return out;
    }
}
