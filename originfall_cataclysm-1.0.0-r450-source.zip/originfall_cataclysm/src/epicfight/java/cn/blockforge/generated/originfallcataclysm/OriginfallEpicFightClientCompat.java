package cn.blockforge.generated.originfallcataclysm;

import cn.blockforge.generated.originfallcataclysm.client.BlinkState;
import cn.blockforge.generated.originfallcataclysm.client.CollapseMarkRenderer;
import cn.blockforge.generated.originfallcataclysm.client.NativeApocataDanceState;
import cn.blockforge.generated.originfallcataclysm.client.WeaponFlameEvents;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.RegistryObject;
import yesman.epicfight.api.animation.Animator;
import yesman.epicfight.api.animation.Joint;
import yesman.epicfight.api.animation.Pose;
import yesman.epicfight.api.animation.types.EntityState;
import yesman.epicfight.api.animation.types.StaticAnimation;
import yesman.epicfight.api.asset.AssetAccessor;
import yesman.epicfight.api.client.forgeevent.PatchedRenderersEvent;
import yesman.epicfight.api.client.model.Meshes;
import yesman.epicfight.api.model.Armature;
import yesman.epicfight.api.utils.math.MathUtils;
import yesman.epicfight.api.utils.math.OpenMatrix4f;
import yesman.epicfight.api.utils.math.Vec3f;
import yesman.epicfight.client.mesh.HumanoidMesh;
import yesman.epicfight.client.renderer.patched.entity.PCustomHumanoidEntityRenderer;
import yesman.epicfight.gameasset.Armatures;
import yesman.epicfight.model.armature.types.ToolHolderArmature;
import yesman.epicfight.world.capabilities.EpicFightCapabilities;
import yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * 史诗战斗兼容层的客户端部分。
 *
 * <p>为模组的七个人形天灾生物注册史诗战斗的“补丁渲染器”（PatchedEntityRenderer）：
 * 生物继续使用本模组的贴图（64×64 标准人形布局，与史诗战斗 BIPED 网格一致），
 * 但动作层整体改由史诗战斗的动画系统驱动——持剑怪物的挥剑连段、空手拳击、
 * 受击/击倒反馈，以及本模组新增的格挡姿态都会真实显示出来。
 * 未注册补丁渲染器的实体（源石傀儡等）仍由模组自己的模型渲染，不受影响。</p>
 *
 * <p>同时把「武装火焰」的武器线段计算交给本层：史诗战斗用骨架动画渲染实体，
 * 原版 {@code HumanoidModel#translateToHand} 根本拿不到它的手臂，而史诗战斗自身的
 * 渲染又是在被取消的 {@code RenderLivingEvent.Pre} 里完成的（{@code Post} 不触发），
 * 因此由 {@link #weaponPose} 从史诗战斗骨架的武器关节直接取世界线段，
 * 供 {@link WeaponFlameEvents} 喷粒子。</p>
 *
 * <p>本类只在安装了 Epic Fight 且处于客户端时被加载（由
 * {@link OriginfallEpicFightCompat#init} 在 {@code FMLEnvironment.dist} 判断后调用），
 * 服务端进程不会触达任何客户端类。</p>
 */
public final class OriginfallEpicFightClientCompat {
    private OriginfallEpicFightClientCompat() {}

    /**
     * 武器在持握关节（{@code Tool_R}/{@code Tool_L}）局部坐标系里的线段。
     * 史诗战斗自带的武器拖尾（{@code TrailInfo} 默认值）就以 {@code (0,0,0) → (0,0,-1)}
     * 锚定这根关节，这里沿同一根轴略微外扩，让火焰既裹住握把、也舔过刃尖。
     */
    private static final Vec3 TOOL_START = new Vec3(0.0D, 0.0D, 0.05D);
    private static final Vec3 TOOL_END = new Vec3(0.0D, 0.0D, -1.05D);

    /** 由 {@link OriginfallEpicFightCompat#init} 仅在客户端调用；监听史诗战斗在模组总线上广播的渲染器注册事件。 */
    public static void init(IEventBus modBus) {
        if (!FMLEnvironment.dist.isClient()) return;
        modBus.addListener(OriginfallEpicFightClientCompat::addPatchedRenderers);
        // 武装火焰自适配：史诗战斗用骨架动画渲染实体，这里提供它的武器关节世界线段。
        WeaponFlameEvents.installEpicFightPose(OriginfallEpicFightClientCompat::weaponPose);
        // 坍缩之眼自适配：史诗战斗骨架动画会让头离开躯干朝向（连段、翻滚、击倒等），
        // 这里提供动画头骨的世界坐标，标志始终钉在头上而不是浮在躯干上方。
        CollapseMarkRenderer.installHeadAnchor(OriginfallEpicFightClientCompat::collapseEyeAnchor);
        // 深蓝之树本尊：它若自带史诗战斗补丁，替身外观代画让位给史诗战斗（见
        // NativeApocataAppearanceEvents 的取消判定），舞蹈改由下面的 tick 钩子注入它自己的
        // 动画器，用本尊自身骨架演出（替身与本尊同肤同骨架，观感一致）。
        MinecraftForge.EVENT_BUS.addListener(OriginfallEpicFightClientCompat::onClientTick);
    }

    // ---------------- 深蓝之树本尊的史诗战斗侧舞蹈注入 ----------------

    /** 已把舞曲动画注入动画器的本尊客户端实体 id；舞程结束或实体离场时回收。 */
    private static final Set<Integer> NATIVE_DANCING = new HashSet<>();

    /** 账本所属的客户端世界：换存档/重进服时清账，防旧世界的 id 挡下新世界里的新舞。 */
    private static ClientLevel dancingLevel;

    /**
     * 每客户端 tick 扫描在场实体：舞程开始且本尊带有史诗战斗的 BIPED 补丁时，
     * 把模组登记的舞曲动画以纯客户端方式播进它自己的动画器（{@code modifyPose}
     * 已按实体类型分流，见 {@link OriginfallDanceAnimation}）；舞程结束播
     * {@code stopPlaying} 让它回落回自己的生活动作。未装/未登记舞曲、或本尊没有
     * 史诗战斗补丁（走本模组代跳）时本钩子完全空转。
     */
    private static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        AssetAccessor<? extends StaticAnimation> dance = OriginfallEpicFightCompat.danceAnimation();
        ClientLevel level = Minecraft.getInstance().level;
        if (dance == null || level == null) {
            NATIVE_DANCING.clear();
            return;
        }
        if (level != dancingLevel) {
            NATIVE_DANCING.clear();
            dancingLevel = level;
        }
        // 只扫渲染可见集：本尊离开视野时动画注入无意义，回到视野的那一 tick 自然补上。
        for (Entity entity : level.entitiesForRendering()) {
            if (!(entity instanceof LivingEntity living)) continue;
            if (!CaerulaArborCompat.isNativeApocataEntity(living)) continue;
            int id = living.getId();
            if (NativeApocataDanceState.remaining(id) > 0) {
                if (NATIVE_DANCING.contains(id)) continue;
                LivingEntityPatch<?> patch = EpicFightCapabilities.getEntityPatch(living, LivingEntityPatch.class);
                if (patch == null || patch.getArmature() != Armatures.BIPED.get()) continue;
                try {
                    patch.playAnimationInClientSide(dance, 0.0F);
                    NATIVE_DANCING.add(id);
                } catch (RuntimeException | LinkageError ignored) {
                    // 注入是表现层加分项：失败只意味着这一档环境看不到舞蹈，绝不能炸渲染主循环。
                }
            } else if (NATIVE_DANCING.remove(id)) {
                try {
                    LivingEntityPatch<?> patch = EpicFightCapabilities.getEntityPatch(living, LivingEntityPatch.class);
                    Animator animator = patch == null ? null : patch.getAnimator();
                    if (animator != null) animator.stopPlaying(dance);
                } catch (RuntimeException | LinkageError ignored) {
                    // 同上：停舞失败由动画自然到时兜底。
                }
            }
        }
        // 实体离场（区块卸载/死亡）后账本里的 id 会复用：按舞蹈会话清理，防陈旧条目挡下新舞。
        if (!NATIVE_DANCING.isEmpty()) {
            for (Iterator<Integer> iterator = NATIVE_DANCING.iterator(); iterator.hasNext(); ) {
                if (NativeApocataDanceState.remaining(iterator.next()) <= 0) iterator.remove();
            }
        }
    }

    /** 每次资源重载时史诗战斗都会重放该事件，注册幂等（按实体类型 put）。 */
    private static void addPatchedRenderers(PatchedRenderersEvent.Add event) {
        EntityRendererProvider.Context context = event.getContext();
        putHumanoidRenderer(event, context, GeneratedMod.PROPHET);
        putHumanoidRenderer(event, context, GeneratedMod.PRIESTESS);
        putHumanoidRenderer(event, context, GeneratedMod.THERESIA);
        putHumanoidRenderer(event, context, GeneratedMod.CALAMITY_MESSENGER);
        putHumanoidRenderer(event, context, GeneratedMod.CALAMITY_PRINCESS);
        putHumanoidRenderer(event, context, GeneratedMod.YOUNG_DEMON_LORD);
        putHumanoidRenderer(event, context, GeneratedMod.END_WALKER);
        // 哈基玖：与首领同一套补丁渲染器，贴图仍是本模组的蕾缪安皮肤。
        putHumanoidRenderer(event, context, GeneratedMod.APOCATA);
    }

    private static void putHumanoidRenderer(PatchedRenderersEvent.Add event, EntityRendererProvider.Context context,
                                            RegistryObject<? extends EntityType<?>> type) {
        EntityType<?> entityType = type.get();
        // PCustomHumanoidEntityRenderer 是 Epic Fight 为第三方人形生物准备的通用网格渲染器，
        // 这里用模组特化的子类：动作与皮肤来源不变，但去掉史诗战斗默认挂上的护甲层
        // （模组自己的渲染器本来就不显示装备护甲），并挡住幼年头部放大，详见子类说明。
        event.addPatchedEntityRenderer(entityType,
                target -> new OriginfallHumanoidRenderer(context, target));
    }

    /**
     * 模组人形首领专用的史诗战斗补丁渲染器。
     *
     * <p>网格、动画、贴图都与 {@code PCustomHumanoidEntityRenderer(Meshes.BIPED, ...)} 完全一致
     * （模组人形首领用的也是标准玩家骨架，与 BIPED 同构），只额外关掉两处不需要的默认处理：</p>
     *
     * <ul>
     *   <li><b>幼年头部放大。</b>史诗战斗在 {@code setJointTransforms} 里对
     *       {@code LivingEntity#isBaby()} 为真的实体，把当前动画帧的 {@code Head} 关节
     *       <b>就地</b>再乘 1.25 倍缩放；同一帧 {@code LivingEntityPatch#getModelMatrix}
     *       还会把整个模型缩到 0.5 倍。模组首领恒为成年个体（{@code CalamityMob#isBaby()}
     *       永远返回 false、{@code setAge} 也会把负年龄归零），这里再覆盖一层空实现：
     *       即使旧存档的年龄字段或其他模组的注入把 isBaby 重新变成 true，头部也不会被
     *       放大成脱离身体、浮在半空的巨块。</li>
     *   <li><b>护甲层。</b>史诗战斗会挂上 {@code WearableItemLayer}（原版
     *       {@code HumanoidArmorLayer}），而模组自己的渲染器本来就不显示任何附加护甲
     *       （{@code CalamityRenderer} 没有护甲层）。这里把护甲层摘掉，两边外观一致，
     *       也省掉每帧烘焙。</li>
     * </ul>
     *
     * <p>另外补一件史诗战斗不会替我们做的事：<b>眨眼</b>。非史诗战斗路径的眼睑是头部网格
     * 子部件（{@code BlinkLids}），由 {@code setupAnim} 驱动；接管渲染后这条通道不存在，
     * 于是身体画完后按头部关节矩阵直接补画同一对眼睑薄板（见 {@link #renderBlinkLids}），
     * 两种环境里的眨眼节律、几何与采样贴图完全同源。</p>
     *
     * <p>只在客户端加载史诗战斗时生效；未安装史诗战斗的进程不会触达本类。</p>
     */
    private static final class OriginfallHumanoidRenderer extends PCustomHumanoidEntityRenderer<HumanoidMesh> {
        OriginfallHumanoidRenderer(EntityRendererProvider.Context context, EntityType<?> entityType) {
            super(Meshes.BIPED, context, entityType);
            try {
                // 摘掉护甲层：模组首领不显示附加护甲，与模组自己的渲染器保持一致。
                this.patchedLayers.remove(HumanoidArmorLayer.class);
            } catch (RuntimeException | LinkageError ignored) {
                // 客户端装的史诗战斗版本与本模组编译期版本不一致时，层表结构可能不同；
                // 最坏结果只是保留史诗战斗默认的护甲层，绝不能让构造渲染器这一步炸掉。
            }
        }

        /**
         * 模组人形首领没有幼年形态，不执行史诗战斗的「baby 头部就地放大 1.25 倍」。
         *
         * <p>不做任何事即为正确行为：成年实体的关节变换本来就该是动画姿势的原值。</p>
         */
        @Override
        public void setJointTransforms(LivingEntityPatch<LivingEntity> patch, Armature armature, Pose pose,
                                       float partialTick) {
            // 有意留空，见方法说明。
        }

        /**
         * 身体画完后补画「眨眼」眼睑，让眨眼在史诗战斗接管渲染时照常生效。
         *
         * <p>本模组的非史诗战斗路径把眼睑做成头部网格的子部件（{@code BlinkLids}），由
         * {@code setupAnim} 每帧摆位；而史诗战斗路径画的是它自己的 BIPED 蒙皮骨架网格，
         * 根本不走 {@code setupAnim}，眼睑部件无处附着。这里改为直接发顶点：按头部关节的
         * 当前姿势矩阵把绘制空间搬到头件局部坐标系，复刻 {@code BlinkLids} 同一对薄板
         * （同样的眼列 u、额头采样带 v、-4.12 层距、同样的按实体 id 节律与睁闭阈值），
         * 闭眼时板面从眉线向眼下生长，观感与非史诗战斗路径逐像素同源。</p>
         *
         * <p>矩阵链照抄史诗战斗自己的 {@code RenderOriginalModelLayer}（它把原版模型部件
         * 画到任意关节上的官方做法）：先 {@code mulPoseStack} 回到实体的模型空间，再乘
         * {@code Armature#getPoseMatrices()} 里头部关节的矩阵，最后 {@code scale(-1,-1,1)}
         * 翻回原版部件坐标系。睁眼阈值、尸体/NoAi 不眨等判定与 {@code BlinkLids.apply}
         * 完全一致。</p>
         */
        @Override
        public void render(LivingEntity entity, LivingEntityPatch<LivingEntity> patch,
                           LivingEntityRenderer<LivingEntity, HumanoidModel<LivingEntity>> renderer,
                           MultiBufferSource bufferSource, PoseStack poseStack, int packedLight, float partialTick) {
            super.render(entity, patch, renderer, bufferSource, poseStack, packedLight, partialTick);
            renderBlinkLids(entity, patch, renderer, bufferSource, poseStack, packedLight, partialTick);
        }

        private void renderBlinkLids(LivingEntity entity, LivingEntityPatch<LivingEntity> patch,
                                     LivingEntityRenderer<LivingEntity, HumanoidModel<LivingEntity>> renderer,
                                     MultiBufferSource bufferSource, PoseStack poseStack,
                                     int packedLight, float partialTick) {
            try {
                // 与非史诗战斗路径同规则：尸体展示（恒 NoAi）与已倒下的生物不眨眼。
                if (!(entity instanceof Mob mob) || !mob.isAlive() || mob.isNoAi()) return;
                Player cameraEntity = Minecraft.getInstance().player;
                if (cameraEntity != null && entity.isInvisibleTo(cameraEntity)) return;
                float lid = BlinkState.lid(entity.tickCount + partialTick, entity.getId());
                if (lid < 0.02F) return;                                            // 睁眼：不发任何顶点
                Armature armature = patch.getArmature();
                if (armature == null) return;
                Joint head = armature.searchJointByName("Head");
                int headIndex = head == null ? -1 : head.getId();
                OpenMatrix4f[] matrices = armature.getPoseMatrices();
                if (headIndex < 0 || matrices == null || headIndex >= matrices.length
                        || matrices[headIndex] == null) {
                    return;
                }
                int overlay = getOverlayCoord(entity, patch, partialTick);
                VertexConsumer consumer = bufferSource.getBuffer(
                        RenderType.entityCutoutNoCull(renderer.getTextureLocation(entity)));
                poseStack.pushPose();
                mulPoseStack(poseStack, armature, entity, patch, partialTick);
                MathUtils.mulStack(poseStack, matrices[headIndex]);
                poseStack.scale(-1.0F, -1.0F, 1.0F);
                PoseStack.Pose pose = poseStack.last();
                // BlinkLids 的板框：u = texOffs + 0.12（depth），v ∈ [11.12, 13.18] 额头采样带；
                // yScale=lid 绕眉线（头件局部 y=-5）生长，UV 不动、只缩几何，与非史诗战斗路径一致。
                drawLid(consumer, pose, -3.0F, -1.0F, 9.12F, 11.12F, lid, overlay, packedLight);
                drawLid(consumer, pose, 1.0F, 3.0F, 13.12F, 15.12F, lid, overlay, packedLight);
                poseStack.popPose();
            } catch (RuntimeException | LinkageError ignored) {
                // 与武器火焰/舞蹈注入同一档兜底：眼睑是表现层加分项，画不出来就回到「不眨」，
                // 绝不能炸渲染主循环；版本差异导致的缺方法（NoSuchMethodError）一并接住。
            }
        }

        /** 画单侧眼睑：脸平面 z=-4.12 上的一块前向矩形（entityCutoutNoCull，不剔面，绕序无关）。 */
        private static void drawLid(VertexConsumer consumer, PoseStack.Pose pose,
                                    float x1, float x2, float u1, float u2,
                                    float lid, int overlay, int packedLight) {
            float z = -4.12F;
            float yTop = -5.0F - 0.02F * lid;        // 板原点是眉线，几何 y ∈ [-0.02, 2.04]
            float yBottom = -5.0F + 2.04F * lid;
            vertex(consumer, pose, x1, yTop, z, u1, 11.12F, overlay, packedLight);
            vertex(consumer, pose, x2, yTop, z, u2, 11.12F, overlay, packedLight);
            vertex(consumer, pose, x2, yBottom, z, u2, 13.18F, overlay, packedLight);
            vertex(consumer, pose, x1, yBottom, z, u1, 13.18F, overlay, packedLight);
        }

        private static void vertex(VertexConsumer consumer, PoseStack.Pose pose,
                                   float x, float y, float z, float u, float v,
                                   int overlay, int packedLight) {
            consumer.vertex(pose.pose(), x, y, z)
                    .color(255, 255, 255, 255)
                    .uv(u, v)
                    .overlayCoords(overlay)
                    .uv2(packedLight)
                    .normal(pose.normal(), 0.0F, 0.0F, -1.0F)
                    .endVertex();
        }
    }

    /**
     * 从史诗战斗骨架取武器关节的世界线段，供武装火焰喷粒子用。
     *
     * <p>变换链与史诗战斗渲染骨架 / 播放武器拖尾时完全一致：
     * 实体世界坐标 → 朝向翻转 180° → 实体的模型矩阵（含身体朝向与体型缩放）→ 武器关节矩阵。
     * 关节矩阵由当前动画姿势 ({@link Animator#getPose(float)}) 与骨架的绑定矩阵算出，
     * 因此挥剑连段、冲刺斩、后跳翻滚等史诗战斗动作都会如实反映到火焰上。</p>
     *
     * <p>手→关节的对应关系照抄史诗战斗自己的 {@code RenderItemBase#getCorrectionMatrix}：
     * <b>主手固定取 {@code Tool_R}、副手固定取 {@code Tool_L}</b>，与实体是不是左撇子无关。
     * 火焰只有用同一套映射，才会落在史诗战斗实际画出武器的那只手上。</p>
     *
     * <p>出招状态取自史诗战斗的实体状态（{@link EntityState#attacking()}）而非原版挥臂计时——
     * 史诗战斗接管近战后原版 {@code getAttackAnim} 不再是攻击判据，拖尾必须跟着它的连段走。</p>
     *
     * <p>「扒臀长舞」同样走这条路：舞蹈已登记成史诗战斗动画（{@code OriginfallDanceAnimation}），
     * 舞程内实体画的仍是史诗战斗骨架，关节姿势从同一个 {@link Animator#getPose(float)} 里取，
     * 火焰自然跟住舞动的那只手，不需要任何特例。</p>
     *
     * @return 史诗战斗不可用（该实体没有补丁、骨架缺少武器关节等）时返回 null，
     *         调用方会回落到原版姿势的火焰
     */
    private static WeaponFlameEvents.WeaponPose weaponPose(LivingEntity entity, InteractionHand hand, float partialTick) {
        try {
            LivingEntityPatch<?> patch = EpicFightCapabilities.getEntityPatch(entity, LivingEntityPatch.class);
            if (patch == null) return null;
            Armature armature = patch.getArmature();
            Animator animator = patch.getAnimator();
            if (armature == null || animator == null) return null;
            Joint joint = toolJoint(armature, hand);
            if (joint == null) return null;
            Pose pose = animator.getPose(partialTick);
            if (pose == null) return null;
            Vec3 position = entity.getPosition(partialTick);
            OpenMatrix4f world = OpenMatrix4f
                    .createTranslation((float) position.x, (float) position.y, (float) position.z)
                    .rotateDeg(180.0F, Vec3f.Y_AXIS)
                    .mulBack(patch.getModelMatrix(partialTick));
            OpenMatrix4f weapon = armature.getBoundTransformFor(pose, joint).mulFront(world);
            Vec3 start = OpenMatrix4f.transform(weapon, TOOL_START);
            Vec3 end = OpenMatrix4f.transform(weapon, TOOL_END);
            EntityState state = patch.getEntityState();
            return new WeaponFlameEvents.WeaponPose(start, end, state != null && state.attacking());
        } catch (RuntimeException | LinkageError ignored) {
            // 表现层兜底：史诗战斗处于我们尚未覆盖的状态（自定义骨架、版本差异、API 变更
            // 导致的方法解析失败）时，宁可不喷这一路火焰、回落到原版姿势，也绝不让渲染线程炸掉。
            // LinkageError 也要接住：客户端装的史诗战斗版本与本模组编译期版本不一致时，
            // 缺失的方法会在第一次调用点抛 NoSuchMethodError，那是一条 Error 而不是 Exception。
            return null;
        }
    }

    /** 持武器那根关节：主手取 Tool_R，副手取 Tool_L；骨架没实现工具持有接口时按名字兜底。 */
    private static Joint toolJoint(Armature armature, InteractionHand hand) {
        boolean mainHand = hand == InteractionHand.MAIN_HAND;
        if (armature instanceof ToolHolderArmature holder) {
            return mainHand ? holder.rightToolJoint() : holder.leftToolJoint();
        }
        return armature.searchJointByName(mainHand ? "Tool_R" : "Tool_L");
    }

    /**
     * 坍缩之眼相对头骨原点的落点（格，世界尺度）：
     * 头骨原点在颈部，眼睛约在原点上方 0.34 格（≈5.4 像素），再向脸前方 0.30 格（≈4.8 像素），
     * 于是标志（约 0.9 格见方、朝摄像机公告板）正好罩在额前。
     *
     * <p>刻意用世界尺度的偏移而不是关节局部像素坐标：不同骨架的关节局部单位（像素/格）
     * 并不统一，而「从关节原点沿关节自己的上轴/前轴偏移若干格」在任何骨架上都是对的。</p>
     */
    private static final double EYE_UP_OFFSET = 0.34D;
    private static final double EYE_FORWARD_OFFSET = 0.30D;

    /**
     * 坍缩之眼（{@code CollapseMarkRenderer}）的史诗战斗锚点：把标志钉在骨架 {@code Head}
     * 关节的额前。
     *
     * <p>史诗战斗用骨架动画渲染实体，头会随连段前倾、冲刺斩、后跳翻滚、被击倒等动作
     * 大幅离开 {@code getViewVector} 代表的躯干朝向；模组原来的「躯干朝向 + 身高 92%」
     * 推算在这种时候会把标志留在半空，看起来像脱了头。这里沿用
     * {@link #weaponPose} 验证过的变换链（世界坐标 → 朝向翻转 180° → 补丁模型矩阵 →
     * 关节矩阵），只是换成 {@code Head} 关节：先取关节原点（颈部）在世界里的位置，
     * 再沿关节自身的上轴与前轴各偏移一小段，标志因此逐帧贴在动画头骨上。</p>
     *
     * @return 该实体没有史诗战斗补丁/骨架缺少 Head 关节时返回 null，调用方回落到原版推算
     */
    private static Vec3 collapseEyeAnchor(LivingEntity entity, float partialTick) {
        try {
            LivingEntityPatch<?> patch = EpicFightCapabilities.getEntityPatch(entity, LivingEntityPatch.class);
            if (patch == null) return null;
            Armature armature = patch.getArmature();
            Animator animator = patch.getAnimator();
            if (armature == null || animator == null) return null;
            Joint head = armature.searchJointByName("Head");
            if (head == null) return null;
            Pose pose = animator.getPose(partialTick);
            if (pose == null) return null;
            Vec3 position = entity.getPosition(partialTick);
            OpenMatrix4f world = OpenMatrix4f
                    .createTranslation((float) position.x, (float) position.y, (float) position.z)
                    .rotateDeg(180.0F, Vec3f.Y_AXIS)
                    .mulBack(patch.getModelMatrix(partialTick));
            OpenMatrix4f headMatrix = armature.getBoundTransformFor(pose, head).mulFront(world);
            // 关节原点：局部 (0,0,0) 经关节链变换后的世界坐标，与骨架的像素/格单位无关。
            Vec3 neck = OpenMatrix4f.transform(headMatrix, Vec3.ZERO);
            // 关节自身的上轴（局部 +y）与前轴（局部 -z）：方向与单位无关。
            Vec3 up = jointAxis(headMatrix, neck, 0.0D, 1.0D, 0.0D);
            Vec3 forward = jointAxis(headMatrix, neck, 0.0D, 0.0D, -1.0D);
            return neck.add(up.scale(EYE_UP_OFFSET)).add(forward.scale(EYE_FORWARD_OFFSET));
        } catch (RuntimeException | LinkageError ignored) {
            // 与武器火焰同一档兜底：版本差异/自定义骨架取不到头坐标时回落到原版推算，
            // 绝不能因为一个装饰性标志炸掉整条实体渲染线程。
            return null;
        }
    }

    /** 关节自己的某根局部轴在世界里的单位方向；关节退化时返回零向量。 */
    private static Vec3 jointAxis(OpenMatrix4f jointMatrix, Vec3 origin, double x, double y, double z) {
        Vec3 axis = OpenMatrix4f.transform(jointMatrix, new Vec3(x, y, z)).subtract(origin);
        return axis.lengthSqr() < 1.0E-8D ? Vec3.ZERO : axis.normalize();
    }
}
