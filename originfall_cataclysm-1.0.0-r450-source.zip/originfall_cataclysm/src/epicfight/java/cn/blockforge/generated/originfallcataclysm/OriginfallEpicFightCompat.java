package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.MoveTowardsTargetGoal;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.EntityAttributeModificationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.RegistryObject;
import yesman.epicfight.api.animation.Animator;
import yesman.epicfight.api.animation.AnimationManager;
import yesman.epicfight.api.animation.LivingMotions;
import yesman.epicfight.api.animation.types.EntityState;
import yesman.epicfight.api.animation.types.StaticAnimation;
import yesman.epicfight.api.asset.AssetAccessor;
import yesman.epicfight.api.forgeevent.EntityPatchRegistryEvent;
import yesman.epicfight.api.utils.AttackResult;
import yesman.epicfight.gameasset.Animations;
import yesman.epicfight.gameasset.Armatures;
import yesman.epicfight.world.capabilities.EpicFightCapabilities;
import yesman.epicfight.world.capabilities.entitypatch.EntityPatch;
import yesman.epicfight.world.capabilities.entitypatch.Factions;
import yesman.epicfight.world.capabilities.entitypatch.HumanoidMobPatch;
import yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch;
import yesman.epicfight.world.capabilities.entitypatch.MobPatch;
import yesman.epicfight.world.damagesource.EpicFightDamageSource;
import yesman.epicfight.world.damagesource.StunType;
import yesman.epicfight.world.entity.ai.attribute.EpicFightAttributes;
import yesman.epicfight.world.entity.ai.goal.AnimatedAttackGoal;
import yesman.epicfight.world.entity.ai.goal.CombatBehaviors;
import yesman.epicfight.world.entity.ai.goal.TargetChasingGoal;

import java.util.EnumSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * 史诗战斗（Epic Fight）兼容层。
 *
 * <p>本类位于独立的 {@code epicfight} 源码集，编译期以 compileOnly 方式依赖
 * Epic Fight、运行期不强依赖：只有当 Epic Fight 实际存在时，模组才会通过反射
 * 入口调用 {@link #init(IEventBus)} 加载本类（见 {@code GeneratedMod} 构造器）。
 * 没有 Epic Fight 时本类永不加载，模组使用自带的 {@link AdaptiveCombatGoal}
 * 行动逻辑照常运行，可完全脱离史诗战斗工作。</p>
 *
 * <p>Epic Fight 存在时，本层为模组全部战斗生物登记实体补丁（EntityPatch）：
 * <ul>
 *   <li>七个人形天灾生物使用史诗战斗的类人攻击框架：近战武器走怪物单手剑连段、
 *       空手走拳击连段，攻击命中改为史诗战斗的伤害管线（硬直、击倒、破防，
 *       并可被玩家格挡弹反）；并通过 {@link OriginfallEpicFightClientCompat}
 *       注册史诗战斗的补丁渲染器，让挥剑连段、受击/击倒、格挡姿态等动作真实
 *       显示在生物身上——网格仍取模组自己的 64×64 人形贴图，皮肤外观不变；</li>
 *   <li>两个源石傀儡完全仿照史诗战斗对铁傀儡的处理（拍击组合），保留模组自己的
 *       模型渲染，每段拍击附带原版挥臂广播使攻击动作可见；</li>
 *   <li>持弓/弩/三叉戟的生物保留模组的玩家式远程逻辑（拉弓射击、蓄力投叉），
 *       此时不挂史诗战斗的近战目标，两套逻辑不会互相争夺移动控制；
 *       拉弓/放箭/上弩的画面动作改用史诗战斗的对应动画；</li>
 *   <li>剑气（黑色/白色月牙）作为技能，在史诗战斗接管近战后仍会释放；</li>
 *   <li>格挡（防御姿态）：人形生物被目标近战命中后，持近战武器时自动举剑进入
 *       史诗战斗的剑防姿态（{@link OriginfallMobGuardGoal}），姿态期间正面近战
 *       伤害减免为 25%（{@link OriginfallGuardEvents}），背后与远程袭击无效，
 *       而史诗战斗的破防重击（{@code NEUTRALIZE}/{@code KNOCKDOWN} 结算）会直接
 *       击碎姿态并全额命中；</li>
 *   <li>跑步、疾行、冲刺与翻滚：{@link OriginfallMobMotionGoal} 按索敌距离开合冲刺标记，
 *       史诗战斗在生物冲刺时切换到追击动作，而该动作被重映射为 {@code BIPED_RUN}
 *       双足奔跑动画（远处追击表现为奔跑，贴脸自动回落走位）；弹射物飞来或刚被近战
 *       命中时播放 {@code BIPED_ROLL_BACKWARD} 后跳翻滚闪避；敌人处于中距离时以
 *       {@code SWORD_DASH}/{@code FIST_DASH} 突进攻击接敌。全部动作只在史诗战斗
 *       存在时可用，未安装时该目标类根本不会加载；</li>
 *   <li>「扒臀长舞」：舞蹈被登记为史诗战斗动画（{@link OriginfallDanceAnimation}），
 *       舞程内所有天灾人形生物的生活动作切到 {@code CELEBRATE} 槽位，由史诗战斗的
 *       BIPED 骨骼演出模组 577 tick（编排 30.3 秒 ×1.05 倍基础速度）的 Blockbench 关键帧（躯干整体不拆、保留完整
 *       屈肘屈膝），武器挂点与火焰拖尾照常跟随；舞蹈动画没登记上时自动退回模组骨架
 *       渲染的简化版舞蹈，见 {@code OriginfallHumanoidPatch#overrideRender}；</li>
 *   <li>技能命中的打击反馈：模组的近战延伸剑气、陨石爆轰、以及未被接管的近战与
 *       直接结算的斩击，都会通过 {@link SkillCombatHooks} 转成史诗战斗的硬直结算
 *       （短硬直/长硬直/击倒 + 受击动画），使这些技能拥有和史诗战斗生物连段一致的
 *       打断感；出招中不打断、已在硬直中不叠加，傀儡等霸体单位不受影响。</li>
 * </ul></p>
 */
public final class OriginfallEpicFightCompat {
    /**
     * 「扒臀长舞」的史诗战斗动画句柄：由 {@link #registerDanceAnimation} 在史诗战斗的
     * {@code AnimationRegistryEvent} 里填好。舞蹈期间所有天灾人形生物的 {@code CELEBRATE}
     * 生活动作都指向它，因此舞蹈走的是史诗战斗自己的骨架与渲染管线。
     */
    private static AnimationManager.AnimationAccessor<OriginfallDanceAnimation> danceAnimation;

    private OriginfallEpicFightCompat() {}

    /** 舞曲动画句柄（未登记成功时为 null）：供客户端把深蓝之树本尊的舞蹈注入它自己的史诗战斗动画器。 */
    public static AnimationManager.AnimationAccessor<OriginfallDanceAnimation> danceAnimation() {
        return danceAnimation;
    }

    /**
     * 把模组的程序化舞蹈登记成史诗战斗动画。注册器发的 {@code AnimationRegistryEvent} 在
     * {@code enqueueWork} 里派发（所有模组构造完之后），所以这里只是登记一个构建回调，
     * 真正建对象发生在之后；{@link #danceAnimation} 为空时舞蹈自动回落到模组自己的骨架。
     */
    private static void registerDanceAnimation(AnimationManager.AnimationRegistryEvent event) {
        event.newBuilder("originfall_cataclysm", builder -> danceAnimation =
                builder.nextAccessor("boss_dance", OriginfallDanceAnimation::new));
    }

    /** 由模组构造器在确认 Epic Fight 已安装后反射调用；全部注册走模组事件总线。 */
    public static void init(IEventBus modBus) {
        modBus.addListener(OriginfallEpicFightCompat::registerEntityPatches);
        modBus.addListener(OriginfallEpicFightCompat::addEpicFightAttributes);
        // 「扒臀长舞」：把程序化舞蹈注册成史诗战斗自己的动画（见 OriginfallDanceAnimation），
        // 跳舞期间改由史诗战斗的 BIPED 骨骼演出，连段/武器挂点/火焰拖尾全部照常。
        modBus.addListener(OriginfallEpicFightCompat::registerDanceAnimation);
        AdaptiveCombatGoal.EPICFIGHT_MELEE_TAKEOVER = OriginfallEpicFightCompat::isMeleeHandledByEpicFight;
        // 技能命中的打击反馈：把模组自身的伤害（剑气/陨石/未接管的近战/直接结算的斩击）
        // 接入史诗战斗的硬直与受击动画管线。
        SkillCombatHooks.install(OriginfallEpicFightCompat::applySkillImpact);
        // 锚定现实的沉默打断：施加锚定的瞬间强制终结目标进行中的技能/动作演出。
        SilenceHooks.install(OriginfallEpicFightCompat::interruptActiveSkill);
        // 客户端：注册史诗战斗补丁渲染器，使挥剑连段/受击/格挡等动作在生物身上可见。
        // 外层再判一次 dist，保证服务端进程连客户端兼容类都不会触发加载。
        if (net.minecraftforge.fml.loading.FMLEnvironment.dist.isClient()) {
            OriginfallEpicFightClientCompat.init(modBus);
        }
        // 格挡（防御姿态）的近战减伤结算，走通用事件总线。
        MinecraftForge.EVENT_BUS.register(new OriginfallGuardEvents());
        // 技能动作桥：剑气/射击/投叉释放时广播史诗战斗的对应攻击动画
        // （骨骼动画渲染下原版摆臂不可见，默认的空实现保证未安装史诗战斗时零影响）。
        AdaptiveCombatGoal.EPICFIGHT_SKILL_MOTION = OriginfallEpicFightCompat::broadcastSkillMotion;
    }

    /**
     * 把一次模组技能命中转成史诗战斗的受击结算：目标按命中力度进入短硬直、长硬直或被击倒，
     * 播放它自己的受击动画（{@code LivingEntityPatch#applyStun}），并像史诗战斗那样在受击瞬间
     * 清空动量形成顿帧感。
     *
     * <p>刻意保留史诗战斗的三条规则，避免把战斗改成无限控制：</p>
     * <ul>
     *   <li>目标正处于动作动画（出招、施法、起身）中时不打断——{@code EntityState#inaction()}；</li>
     *   <li>目标已经在硬直中时不叠加，防止连续技能把人锁死；</li>
     *   <li>没有受击动画的补丁（源石傀儡这类仿铁傀儡的单位）返回 false，硬直不生效，
     *       与史诗战斗对霸体单位的处理一致。</li>
     * </ul>
     */
    private static void applySkillImpact(LivingEntity victim, float damage, SkillCombatHooks.Impact impact) {
        if (!(victim instanceof Mob) && !(victim instanceof net.minecraft.world.entity.player.Player)) return;
        LivingEntityPatch<?> patch = EpicFightCapabilities.getEntityPatch(victim, LivingEntityPatch.class);
        if (patch == null) return;
        // 轻微伤害（例如被溅射扫到 1 点）不值得打断对方节奏。
        if (impact == SkillCombatHooks.Impact.LIGHT && damage < 1.0F) return;
        StunType type = switch (impact) {
            case LIGHT -> StunType.SHORT;
            case HEAVY -> StunType.LONG;
            case KNOCKDOWN -> StunType.KNOCKDOWN;
        };
        // 非固定时长类型的第二个参数是附加硬直时长，按伤害小幅缩放并封顶，保证可反击窗口。
        float extra = type.hasFixedStunTime() ? 0.0F : Math.min(0.35F, Math.max(0.0F, damage * 0.02F));
        try {
            EntityState state = patch.getEntityState();
            // 出招/起身中不打断，已在硬直或已被击倒时不叠加：这是史诗战斗自身的连段规则。
            if (state == null || !state.inaction() || state.knockDown() || patch.isStunned()) return;
            patch.applyStun(type, extra);
        } catch (RuntimeException ignored) {
            // 兼容层的加分项：史诗战斗处于我们尚未覆盖的状态（自定义补丁、版本差异）时，
            // 宁可不加这段硬直表现，也绝不能让一次技能命中把伤害结算线程炸掉。
        }
    }

    /**
     * 锚定现实沉默的史诗战斗侧打断：施加锚定瞬间把目标进行中的出招/技能动画
     * 强制转成长硬直受击演出，终结当前技能。与 {@link #applySkillImpact} 不同，
     * 这里<b>不遵守“出招中不打断”的连段豁免</b>——沉默本身就是打断手段；
     * 已在硬直或击倒中的目标不叠加。仅覆盖动作演出层，模组自身的技能（领域、
     * 召唤、锁定陨石等）在各自发动入口按沉默拦截。
     */
    private static void interruptActiveSkill(LivingEntity victim) {
        LivingEntityPatch<?> patch = EpicFightCapabilities.getEntityPatch(victim, LivingEntityPatch.class);
        if (patch == null) return;
        try {
            EntityState state = patch.getEntityState();
            if (state != null && state.knockDown()) return;
            if (patch.isStunned()) return;
            patch.applyStun(StunType.LONG, 0.5F);
        } catch (RuntimeException ignored) {
            // 打断是加分表现：史诗战斗处于未覆盖状态时宁可不加硬直，也不炸掉控制结算。
        }
    }

    /** 把模组的技能释放转成史诗战斗攻击动画（仅服务端、仅对本模组的类人补丁生效）。 */
    private static void broadcastSkillMotion(Mob mob, AdaptiveCombatGoal.SkillMotion motion) {
        if (mob.level().isClientSide) return;
        if (!(mob instanceof PathfinderMob)) return;
        EntityPatch<?> patch = EpicFightCapabilities.getEntityPatch(mob, EntityPatch.class);
        if (!(patch instanceof OriginfallHumanoidPatch<?> humanoid)) return;
        AssetAccessor<? extends StaticAnimation> animation = switch (motion) {
            // 持械/空手的怪物挥击（剑类动画会随手持武器选择），弓箭/弩的放箭回弹，三叉戟的投掷。
            case SWORD_SWING -> Animations.ZOMBIE_ATTACK1;
            case RANGED_SHOT -> Animations.BIPED_BOW_SHOT;
            case TRIDENT_THROW -> Animations.BIPED_JAVELIN_THROW;
        };
        humanoid.playAnimationSynchronized(animation, 0.0F);
    }

    /**
     * Epic Fight 在通用初始化阶段广播该事件；这里为每个生物登记补丁工厂，
     * 并登记骨架（armature）——代码注册的补丁若缺少骨架，实体构造时会 NPE。
     * 人形生物的渲染由 {@link OriginfallEpicFightClientCompat} 另行注册史诗战斗
     * 补丁渲染器接管（贴图仍是模组自己的皮肤）；傀儡不注册，保留模组模型。
     */
    private static void registerEntityPatches(EntityPatchRegistryEvent event) {
        Map<EntityType<?>, Function<Entity, Supplier<EntityPatch<?>>>> patches = event.getTypeEntry();

        putHumanoid(patches, GeneratedMod.PROPHET);
        putHumanoid(patches, GeneratedMod.PRIESTESS);
        putHumanoid(patches, GeneratedMod.THERESIA);
        putHumanoid(patches, GeneratedMod.CALAMITY_MESSENGER);
        putHumanoid(patches, GeneratedMod.CALAMITY_PRINCESS);
        putHumanoid(patches, GeneratedMod.YOUNG_DEMON_LORD);
        putHumanoid(patches, GeneratedMod.END_WALKER);
        // 哈基玖：玩家型骨架同款补丁，舞蹈走 OriginfallDanceAnimation 的通用首领通道。
        putHumanoid(patches, GeneratedMod.APOCATA);

        putGolem(patches, GeneratedMod.SOURCE_ORE_GOLEM);
        putGolem(patches, GeneratedMod.PURE_SOURCE_ORE_GOLEM);
    }

    private static void putHumanoid(Map<EntityType<?>, Function<Entity, Supplier<EntityPatch<?>>>> patches,
                                    RegistryObject<? extends EntityType<? extends CalamityMob>> type) {
        patches.put(type.get(), entity -> () -> new OriginfallHumanoidPatch<PathfinderMob>());
        Armatures.registerEntityTypeArmature(type.get(), Armatures.BIPED);
    }

    private static void putGolem(Map<EntityType<?>, Function<Entity, Supplier<EntityPatch<?>>>> patches,
                                 RegistryObject<? extends EntityType<? extends SourceOreGolem>> type) {
        patches.put(type.get(), entity -> () -> new OriginfallGolemPatch());
        Armatures.registerEntityTypeArmature(type.get(), Armatures.IRON_GOLEM);
    }

    /** 为被接管的生物补齐史诗战斗属性；缺少 WEIGHT 等属性会在实体入世界时 NPE。 */
    private static void addEpicFightAttributes(EntityAttributeModificationEvent event) {
        addCommonAttributes(event, 2.0D,
                GeneratedMod.PROPHET.get(), GeneratedMod.PRIESTESS.get(), GeneratedMod.THERESIA.get(),
                GeneratedMod.CALAMITY_MESSENGER.get(), GeneratedMod.CALAMITY_PRINCESS.get(),
                GeneratedMod.YOUNG_DEMON_LORD.get(), GeneratedMod.END_WALKER.get(),
                GeneratedMod.APOCATA.get());
        // 两个源石傀儡仿照 Epic Fight 铁傀儡：高冲击让拍击真正把人「踹飞」，多段命中上限更高。
        addCommonAttributes(event, 6.0D,
                GeneratedMod.SOURCE_ORE_GOLEM.get(), GeneratedMod.PURE_SOURCE_ORE_GOLEM.get());
        addOffhandAttributes(event,
                GeneratedMod.PROPHET.get(), GeneratedMod.PRIESTESS.get(), GeneratedMod.THERESIA.get(),
                GeneratedMod.CALAMITY_MESSENGER.get(), GeneratedMod.CALAMITY_PRINCESS.get(),
                GeneratedMod.YOUNG_DEMON_LORD.get(), GeneratedMod.END_WALKER.get());
    }

    @SafeVarargs
    @SuppressWarnings("unchecked")
    private static void addCommonAttributes(EntityAttributeModificationEvent event, double impact,
                                            EntityType<?>... types) {
        for (EntityType<?> type : types) {
            if (!event.getTypes().contains(type)) continue;
            EntityType<? extends net.minecraft.world.entity.LivingEntity> living =
                    (EntityType<? extends net.minecraft.world.entity.LivingEntity>) type;
            event.add(living, EpicFightAttributes.WEIGHT.get());
            event.add(living, EpicFightAttributes.ARMOR_NEGATION.get());
            event.add(living, EpicFightAttributes.IMPACT.get(), impact);
            event.add(living, EpicFightAttributes.MAX_STRIKES.get());
            event.add(living, EpicFightAttributes.STUN_ARMOR.get());
        }
    }

    @SafeVarargs
    @SuppressWarnings("unchecked")
    private static void addOffhandAttributes(EntityAttributeModificationEvent event, EntityType<?>... types) {
        for (EntityType<?> type : types) {
            if (!event.getTypes().contains(type)) continue;
            EntityType<? extends net.minecraft.world.entity.LivingEntity> living =
                    (EntityType<? extends net.minecraft.world.entity.LivingEntity>) type;
            event.add(living, EpicFightAttributes.OFFHAND_ATTACK_SPEED.get());
            event.add(living, EpicFightAttributes.OFFHAND_MAX_STRIKES.get());
            event.add(living, EpicFightAttributes.OFFHAND_ARMOR_NEGATION.get());
            event.add(living, EpicFightAttributes.OFFHAND_IMPACT.get());
        }
    }

    /**
     * 该生物的近战是否已由史诗战斗的 AnimatedAttackGoal 接管：持有补丁、且目标
     * 选择器中存在带攻击行为的动画攻击目标时成立。持弓/弩/三叉戟的生物不会被
     * 挂上该目标（见 {@link OriginfallHumanoidPatch#setAIAsInfantry(boolean)}），
     * 因此返回 false，本模组的远程逻辑继续全权驱动它们。
     */
    private static boolean isMeleeHandledByEpicFight(Mob mob) {
        if (!(mob instanceof PathfinderMob)) return false;
        EntityPatch<?> patch = EpicFightCapabilities.getEntityPatch(mob, EntityPatch.class);
        if (!(patch instanceof MobPatch)) return false;
        for (WrappedGoal wrapped : mob.goalSelector.getAvailableGoals()) {
            if (wrapped.getGoal() instanceof AnimatedAttackGoal<?>) return true;
        }
        return false;
    }

    /**
     * 人形天灾生物的史诗战斗补丁：借用史诗战斗的类人生物攻击框架。
     * 近战武器/空手交给史诗战斗连段；远程（弓/弩/三叉戟）保留模组逻辑，
     * 但动作改走史诗战斗的拉弓/放箭/上弩动画。新增格挡（防御姿态）：
     * 目标近身攻击命中后，持近战武器的生物会举剑格挡短暂时间，
     * 期间正面近战伤害大幅减免（见 {@link OriginfallGuardEvents}）。
     */
    public static class OriginfallHumanoidPatch<T extends PathfinderMob> extends HumanoidMobPatch<T> {
        private Goal guardGoal;
        private Goal motionGoal;
        private Goal danceHoldGoal;

        public OriginfallHumanoidPatch() {
            super(Factions.ILLAGER);
        }

        @Override
        public void setAIAsInfantry(boolean holdingRangedWeapon) {
            // 持弓/弩/三叉戟时不挂史诗战斗的近战攻击与追击目标，移动交给 AdaptiveCombatGoal。
            if (holdingRangedWeapon) return;
            super.setAIAsInfantry(false);
        }

        /** 追加格挡与动作目标：史诗战斗每次重编 AI（入场/换武器）都会经过 initAI，这里幂等补挂。 */
        @Override
        protected void initAI() {
            super.initAI();
            if (this.original.level() != null && this.original.level().isClientSide) return;
            if (this.guardGoal == null) this.guardGoal = new OriginfallMobGuardGoal(this.original);
            if (this.motionGoal == null) this.motionGoal = new OriginfallMobMotionGoal(this.original);
            if (this.danceHoldGoal == null) this.danceHoldGoal = new OriginfallDanceHoldGoal(this.original);
            // 占位目标放最前：它用 MOVE/LOOK 标记压住史诗战斗挂的 TargetChasingGoal(1)，
            // 舞程内不让追击目标再碰移动与朝向；舞蹈本身有 MOVE 标记的原版目标也会被挡下。
            addGoalIdempotent(this.danceHoldGoal, 0);
            addGoalIdempotent(this.guardGoal, 4);
            addGoalIdempotent(this.motionGoal, 5);
        }

        private void addGoalIdempotent(Goal goal, int priority) {
            for (WrappedGoal wrapped : this.original.goalSelector.getAvailableGoals()) {
                if (wrapped.getGoal() == goal) return;
            }
            this.original.goalSelector.addGoal(priority, goal);
        }

        /** 该生物此刻是否正在跳「扒臀长舞」。 */
        private boolean isDancing() {
            return this.original instanceof CalamityMob calamity && BossTauntLogic.isActive(calamity);
        }

        /**
         * 舞程内冻结史诗战斗的战斗接管，让姿势与朝向完全由模组自己驱动。
         *
         * <p>只靠 {@link #overrideRender()} 交还渲染权还不够：史诗战斗的
         * {@code AnimatedAttackGoal} / {@code TargetChasingGoal} 仍会在生物 tick 里照常跑。
         * {@code BossTauntLogic} 虽然在每个等级 tick 末尾把目标清空，但原版
         * {@code NearestAttackableTargetGoal} 会在下一次 {@code serverAiStep} 里重新锁定玩家，
         * 于是史诗战斗继续出招——出招动画自己看不见（渲染已交还），可动画自带的
         * <b>根位移</b>会真实推动实体，追击目标的 {@code LookControl} 也会把身体重新转向玩家。
         * 结果就是「姿势是舞蹈的，站位和朝向却被史诗战斗拽走」，这是只有装了史诗战斗才会出现的
         * 偏差，也正是「该修复在史诗战斗下未生效」的原因。</p>
         *
         * <p>这里在 {@link LivingEvent.LivingTickEvent}（早于本 tick 的 {@code serverAiStep}）
         * 里再次清目标、停寻路，并配合下面的 {@link #getTarget()} 让史诗战斗的攻击/追击目标
         * 永远读不到目标；舞程结束目标恢复，连段节奏不受影响。</p>
         */
        @Override
        public void tick(LivingEvent.LivingTickEvent event) {
            super.tick(event);
            if (isDancing()) {
                this.original.setTarget(null);
                this.original.getNavigation().stop();
                this.original.setAggressive(false);
            }
        }

        /**
         * 舞程内对史诗战斗隐藏目标：{@code AnimatedAttackGoal} 与各段攻击行为都经由
         * {@code MobPatch#getTarget()} 取目标，返回 null 后它们既不选招式也不播攻击动画，
         * 因而不会产生任何根位移。只影响史诗战斗自己的读取，原版 {@code Mob#getTarget()}
         * 不受影响，舞停后立即恢复。
         */
        @Override
        public LivingEntity getTarget() {
            if (isDancing()) return null;
            return super.getTarget();
        }

        /**
         * 「扒臀长舞」的渲染归属：舞蹈已经登记成史诗战斗动画，正常情况下渲染权仍归史诗战斗。
         *
         * <p>{@link OriginfallDanceAnimation} 会把 {@code BossDanceKeyframes} 的 Blockbench
         * 关键帧换算到史诗战斗的 BIPED 骨骼上，于是舞蹈、连段、受击共用同一套骨架与渲染
         * 管线，武器挂点、火焰拖尾、补丁渲染器全部照常生效——不再需要像早期实现那样在
         * 舞程内退回模组自己的骨架（那样史诗战斗的连段骨架会把舞蹈吞掉，而且火焰会挂在
         * 一段没画出来的骨架上）。</p>
         *
         * <p>只有舞蹈动画没登记上时（{@code danceAnimation == null}，例如史诗战斗注册接口
         * 变动）才退回模组骨架：那时用史诗战斗给第三方模型（GeckoLib / AzureLib 实体）留的
         * 官方开关（{@code RenderEngine.Events#renderLivingEvent} 先看 {@code hasRendererFor}，
         * 再看 patch 的 overrideRender）返回 false，让原版补丁渲染器
         * （模组的 CalamityRenderer / PriestessRenderer）照常绘制，舞蹈由
         * {@code CalamityHumanoidModel} 自己还原，至少不会整段消失。</p>
         *
         * <p>只在客户端渲染路径被调用，服务端 AI 与伤害结算完全不经过这里。</p>
         */
        @Override
        public boolean overrideRender() {
            // 正常情况（舞蹈动画已登记）走史诗战斗自己的 BIPED 网格，舞蹈由 OriginfallDanceAnimation
            // 逐帧算姿势，不需要绕开渲染。只有注册事件没能把动画填上时——例如史诗战斗版本变动导致
            // 注册接口失效——才退回模组骨架渲染：此时舞蹈仍是模组 CalamityHumanoidModel 那条
            // 简化版（不弯腰的躯干 + 完整屈肘屈膝），至少舞蹈不会整段消失。
            if (danceAnimation == null && this.original instanceof CalamityMob calamity
                    && calamity.getTauntTicks() > 0) {
                return false;
            }
            return super.overrideRender();
        }

        @Override
        public void initAnimator(Animator animator) {
            super.initAnimator(animator);
            commonAggresiveMobAnimatorInit(animator);
            // 跑步/疾行：原版怪补丁的追击动作（CHASE，由冲刺标记触发）默认仍播走路动画，
            // 这里改为史诗战斗的双足奔跑动画，索敌冲刺时真正“跑起来”。
            animator.addLivingAnimation(LivingMotions.CHASE, Animations.BIPED_RUN);
            animator.addLivingAnimation(LivingMotions.RUN, Animations.BIPED_RUN);
            // 格挡姿态（剑防）与远程三段动作：配合客户端补丁渲染器即可见。
            animator.addLivingAnimation(LivingMotions.BLOCK, Animations.SWORD_GUARD);
            animator.addLivingAnimation(LivingMotions.AIM, Animations.BIPED_BOW_AIM);
            animator.addLivingAnimation(LivingMotions.SHOT, Animations.BIPED_BOW_SHOT);
            animator.addLivingAnimation(LivingMotions.RELOAD, Animations.BIPED_CROSSBOW_RELOAD);
            // 「扒臀长舞」占用 CELEBRATE 槽位：史诗战斗只在猪灵补丁里用过这个槽位，
            // 类人怪补丁的基线动画器不注册它，正好拿来挂模组的舞蹈（见 OriginfallDanceAnimation）。
            if (danceAnimation != null) {
                animator.addLivingAnimation(LivingMotions.CELEBRATE, danceAnimation);
            }
        }

        @Override
        public void updateMotion(boolean considerInaction) {
            if (isDancing()) {
                // 舞程内固定用舞蹈动画：史诗战斗不再按目标/冲刺切换追击、攻击等带动画根位移的动作，
                // 生物位置与朝向全权交给 BossTauntLogic 的逐 tick 推进。
                // （舞蹈动画没登记上时退回 IDLE，配合 overrideRender 的兜底走模组骨架。）
                if (danceAnimation != null) {
                    this.currentLivingMotion = LivingMotions.CELEBRATE;
                    this.currentCompositeMotion = LivingMotions.CELEBRATE;
                } else {
                    this.currentLivingMotion = LivingMotions.IDLE;
                    this.currentCompositeMotion = LivingMotions.IDLE;
                }
                return;
            }
            if (this.original instanceof CalamityMob calamity && calamity.getGuardTicks() > 0
                    && !isRangedWeapon(this.original.getMainHandItem())) {
                // 格挡窗口内：切换为史诗战斗的持剑防御姿态（服务端/客户端各自据同步数据选择，动作一致）。
                // 基础层与合成层都设为 BLOCK，否则底层动作会覆盖合成层，格挡动画在模型上不可见。
                this.currentLivingMotion = LivingMotions.BLOCK;
                this.currentCompositeMotion = LivingMotions.BLOCK;
                return;
            }
            if (isRangedWeapon(this.original.getMainHandItem())) {
                commonAggressiveRangedMobUpdateMotion(considerInaction);
            } else {
                commonAggressiveMobUpdateMotion(considerInaction);
            }
        }

        @Override
        public boolean isTargetInvulnerable(Entity target) {
            // 天灾 Boss 之间互相为敌（如预言家猎杀女祭司），取消史诗战斗的同阵营免伤。
            if (target instanceof Mob) return false;
            return super.isTargetInvulnerable(target);
        }

        /**
         * Epic Fight 攻击事件钩子：本生物在「领域展开•无我时序」内、且不在该领域白名单
         * （发动者本人与其弹射物）时，「无法攻击」——语义与 {@code ProphetSkillEvents.onLivingAttack}
         * 里取消 {@code LivingAttackEvent} 保持完全一致。
         *
         * <p>Epic Fight 接管近战后，人形生物的每一次挥击都经由本方法进入
         * {@code MobPatch#attack} → {@code doHurtTarget} 结算伤害；若攻击者本体已被任一
         * 激活领域压制，这里直接在结算前把本次攻击判为落空（{@code AttackResult.missed}），
         * 不再调用父类、不打出 {@code doHurtTarget}，因此不会造成任何伤害；白名单
         * （发动者本人）照常出手不受影响。</p>
         */
        @Override
        public AttackResult attack(EpicFightDamageSource source, Entity target, InteractionHand hand) {
            if (this.original != null && this.original.level() instanceof ServerLevel level
                    && ProphetSkillLogic.isAttackSuppressedByDomain(level, this.original)) {
                return AttackResult.missed(0.0F);
            }
            return super.attack(source, target, hand);
        }

        /**
         * 玩家用史诗战斗的守势技能（格挡/弹反）成功挡下本生物的进攻击时被回调。
         * 给攻击方一个短硬直（受击动画 + 顿帧），使弹反窗口真正产生反击机会。
         * 行为与 Epic Fight 对 Ravager 的 {@code RAVAGER_STUN} 反馈一致；出招中的重击
         * 或已在硬直/击倒中的单位不再额外叠加，避免被无限弹反锁死。
         */
        @Override
        public void onAttackBlocked(DamageSource damageSource, LivingEntityPatch<?> blocker) {
            if (this.original == null || !this.original.isAlive()) return;
            try {
                EntityState state = this.getEntityState();
                if (state == null || state.knockDown() || this.isStunned()) return;
                this.applyStun(StunType.SHORT, 0.0F);
            } catch (RuntimeException ignored) {
                // 弹反反馈是加分表现：史诗战斗处于未覆盖状态时静默跳过，绝不炸掉伤害线程。
            }
        }
    }

    /** 是否远程武器（弓/弩/三叉戟）：与 AdaptiveCombatGoal 的分支判断保持一致。 */
    private static boolean isRangedWeapon(ItemStack weapon) {
        if (weapon.isEmpty()) return false;
        return weapon.getItem() instanceof BowItem || weapon.getItem() instanceof CrossbowItem
                || weapon.is(Items.TRIDENT);
    }

    /**
     * 格挡 AI（仅服务端）：目标生物近身用近战武器命中过本生物后，短窗口内进入
     * 持剑防御姿态（{@link CalamityMob#setGuardTicks}），姿态期间正面近战伤害减免。
     * 未安装史诗战斗时该目标不存在，生物行为与原先完全一致。
     */
    public static class OriginfallMobGuardGoal extends Goal {
        /** 一次格挡姿态持续 tick 数；成功挡下一次攻击后额外扣除。 */
        private static final int GUARD_DURATION = 24;
        private static final int GUARD_COST_PER_BLOCK = 6;
        /** 结束格挡后的再触发冷却。 */
        private static final int RETRY_DELAY = 40;

        private final PathfinderMob mob;
        private int retryDelay;

        public OriginfallMobGuardGoal(PathfinderMob mob) {
            this.mob = mob;
            setFlags(EnumSet.noneOf(Flag.class));
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public boolean canUse() {
            if (this.retryDelay > 0 || !(this.mob instanceof CalamityMob calamity)) return false;
            // 舞程内不摆防御姿态：格挡动作会覆盖舞蹈姿势。
            if (BossTauntLogic.isActive(calamity)) return false;
            if (calamity.getGuardTicks() > 0) return false;
            if (calamity.isOrderedToSit()) return false;
            LivingEntity target = this.mob.getTarget();
            if (target == null || !target.isAlive()) return false;
            // 只对“刚刚用近战打到自己”的目标摆出防御姿态，符合史诗战斗的攻防回合感。
            if (this.mob.getLastHurtByMob() != target) return false;
            if (this.mob.tickCount - this.mob.getLastHurtByMobTimestamp() > 10) return false;
            if (this.mob.distanceToSqr(target) > 36.0D) return false;
            ItemStack weapon = this.mob.getMainHandItem();
            // 必须持近战武器才能持剑格挡；远程武器交给模组自身的射击逻辑。
            if (weapon.isEmpty() || isRangedWeapon(weapon)) return false;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return this.mob instanceof CalamityMob calamity && calamity.getGuardTicks() > 0;
        }

        @Override
        public void start() {
            ((CalamityMob) this.mob).setGuardTicks(GUARD_DURATION);
        }

        @Override
        public void tick() {
            if (this.retryDelay > 0) this.retryDelay--;
        }

        @Override
        public void stop() {
            this.retryDelay = RETRY_DELAY;
        }
    }

    /**
     * 舞程占位目标（仅服务端）：「扒臀长舞」期间唯一允许占用移动与朝向的原版目标。
     *
     * <p>它的作用不是做动作，而是<b>占住 {@code MOVE}/{@code LOOK} 两种目标标记</b>，
     * 让史诗战斗在 {@code setAIAsInfantry} 里挂在优先级 1 的
     * {@code TargetChasingGoal} 无法启动。该追击目标读的是原版 {@code Mob#getTarget()}
     * 而非补丁的 {@link OriginfallHumanoidPatch#getTarget()}，只靠补丁层的目标屏蔽拦不住它；
     * 而它每 tick 都会用 {@code LookControl.setLookAt} 把身体拧向玩家、并用寻路把首领拖离
     * 舞蹈站位——这正是装了史诗战斗后舞蹈朝向与位置对不上的直接原因。</p>
     *
     * <p>同时每 tick 清一次目标、停一次寻路，把原版目标选择器重新锁定的结果即时抹掉。
     * 舞程一结束 {@link #canUse()} 立即返回 false，原位释放，连段与追击自动恢复。</p>
     */
    public static class OriginfallDanceHoldGoal extends Goal {
        private final PathfinderMob mob;

        public OriginfallDanceHoldGoal(PathfinderMob mob) {
            this.mob = mob;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            return this.mob instanceof CalamityMob calamity && BossTauntLogic.isActive(calamity);
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            this.mob.setTarget(null);
            this.mob.getNavigation().stop();
            this.mob.setAggressive(false);
        }
    }

    /**
     * 动作目标（仅服务端）：让模组人形生物「学会」史诗战斗的跑步、疾行、冲刺与翻滚。
     * <ul>
     *   <li>跑步/疾行：按索敌距离开合原版冲刺标记。史诗战斗的动作选择逻辑在生物
     *       冲刺且正在移动时切到追击动作（{@link LivingMotions#CHASE}），
     *       {@code OriginfallHumanoidPatch#initAnimator} 已把该动作映射为双足奔跑动画
     *       {@code BIPED_RUN}，因此远处追击表现为奔跑，进入贴脸距离后自动回落为
     *       走位/待机；冲刺标记随实体数据同步，客户端渲染器看到的是同一动作。</li>
     *   <li>翻滚：有敌方弹射物朝自己直线飞来、或刚被近战攻击命中时，面向威胁播放
     *       史诗战斗的后跳翻滚动画 {@code BIPED_ROLL_BACKWARD}（带长冷却，
     *       格挡姿态、硬直、击倒与出招中不触发，不打断正常攻防回合）。</li>
     *   <li>冲刺攻击：敌人处于中距离（5~11 格）、自身持近战武器且状态空闲时，
     *       面向目标播放 {@code SWORD_DASH}/{@code FIST_DASH}，借助动画根位移突进接敌，
     *       命中结算沿用史诗战斗的攻击管线。</li>
     * </ul>
     * 未安装史诗战斗时本目标类根本不会被加载，生物行为与原先完全一致。
     */
    public static class OriginfallMobMotionGoal extends Goal {
        /** 冲刺追击的最小距离（格）：比这更近改走位，让攻击动画优先。 */
        private static final double SPRINT_MIN_DISTANCE_SQR = 16.0D;
        /** 冲刺攻击触发距离带（格平方）：5~11 格之间才值得突进。 */
        private static final double DASH_MIN_SQR = 25.0D;
        private static final double DASH_MAX_SQR = 121.0D;
        /** 两次冲刺攻击的最小间隔（tick）。 */
        private static final int DASH_COOLDOWN = 240;
        /** 两次翻滚闪避的最小间隔（tick）。 */
        private static final int ROLL_COOLDOWN = 140;
        /** 弹射物威胁判定半径（格）。 */
        private static final double THREAT_RADIUS = 7.0D;

        private final PathfinderMob mob;
        private int dashCooldown;
        private int rollCooldown;

        public OriginfallMobMotionGoal(PathfinderMob mob) {
            this.mob = mob;
            // 不声明任何 Flag：与史诗战斗自己的攻击/追击目标并行运行，互不抢占。
            setFlags(EnumSet.noneOf(Flag.class));
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public boolean canUse() {
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return true;
        }

        @Override
        public void tick() {
            if (this.mob.level().isClientSide) return;
            if (this.dashCooldown > 0) this.dashCooldown--;
            if (this.rollCooldown > 0) this.rollCooldown--;
            // 舞程内不冲刺、不翻滚、不突进：这些动作都带史诗战斗的根位移，会把舞蹈中的
            // 首领推离 BossTauntLogic 设定的站位；舞期本来也免疫伤害、弹飞弹射物。
            if (this.mob instanceof CalamityMob dancing && BossTauntLogic.isActive(dancing)) {
                if (this.mob.isSprinting()) this.mob.setSprinting(false);
                return;
            }
            // 沉默（锚定现实的打断效果）期间不再发动冲刺攻击与翻滚闪避；
            // 普通攻击与索敌不受沉默影响，仍由史诗战斗的攻击管线照常驱动。
            if (RuwosuojianLogic.isSilenced(this.mob)) return;
            LivingEntity target = this.mob.getTarget();
            boolean hasTarget = target != null && target.isAlive();
            boolean sitting = this.mob instanceof CalamityMob calamity && calamity.isOrderedToSit();
            boolean guarding = this.mob instanceof CalamityMob calamity && calamity.getGuardTicks() > 0;
            updateSprinting(hasTarget && !sitting && !guarding);
            if (sitting || this.mob.isSleeping()) return;
            LivingEntityPatch<?> patch = EpicFightCapabilities.getEntityPatch(this.mob, LivingEntityPatch.class);
            if (patch == null) return;
            if (animationSlotBusy(patch)) return;
            if (!guarding) tryDodgeRoll(hasTarget);
            if (hasTarget && !isRangedWeapon(this.mob.getMainHandItem())) tryDashAttack(target);
        }

        /** 跑步/疾行：远处索敌追击开冲刺（史诗战斗据此切到 BIPED_RUN 奔跑动画），其余情况关闭。 */
        private void updateSprinting(boolean pursue) {
            boolean sprint = pursue && this.mob.onGround()
                    && this.mob.getTarget() != null
                    && this.mob.distanceToSqr(this.mob.getTarget()) > SPRINT_MIN_DISTANCE_SQR;
            if (this.mob.isSprinting() != sprint) this.mob.setSprinting(sprint);
        }

        /** 翻滚闪避：弹射物直飞而来，或刚被当前目标的近战命中后小概率后跳翻滚。 */
        private void tryDodgeRoll(boolean hasTarget) {
            if (this.rollCooldown > 0 || !this.mob.onGround()) return;
            Entity threat;
            Projectile incoming = findIncomingProjectile();
            if (incoming != null) {
                threat = incoming;
                Entity owner = incoming.getOwner();
                if (owner instanceof LivingEntity && owner.isAlive()) threat = owner;
            } else {
                LivingEntity attacker = this.mob.getLastHurtByMob();
                if (attacker == null || !attacker.isAlive()) return;
                if (this.mob.tickCount - this.mob.getLastHurtByMobTimestamp() > 4) return;
                if (!hasTarget || this.mob.getTarget() != attacker) return;
                if (this.mob.distanceToSqr(attacker) > 64.0D) return;
                if (this.mob.getRandom().nextFloat() >= 0.14F) return;
                threat = attacker;
            }
            this.rollCooldown = ROLL_COOLDOWN;
            this.mob.setSprinting(false);
            this.mob.getNavigation().stop();
            facePoint(threat.getX(), threat.getZ());
            play(Animations.BIPED_ROLL_BACKWARD);
        }

        /** 冲刺攻击：中距离面向目标打出带根位移的突进斩/突拳击。 */
        private void tryDashAttack(LivingEntity target) {
            if (this.dashCooldown > 0 || !this.mob.onGround()) return;
            double distSqr = this.mob.distanceToSqr(target);
            if (distSqr < DASH_MIN_SQR || distSqr > DASH_MAX_SQR) return;
            if (this.mob.getRandom().nextFloat() >= 0.35F) return;
            this.dashCooldown = DASH_COOLDOWN;
            facePoint(target.getX(), target.getZ());
            ItemStack weapon = this.mob.getMainHandItem();
            boolean sword = weapon.getItem() instanceof net.minecraft.world.item.SwordItem;
            play(sword ? Animations.SWORD_DASH : Animations.FIST_DASH);
        }

        /** 找出正朝自己直线飞来的敌方弹射物；没有则返回 null。 */
        private Projectile findIncomingProjectile() {
            for (Entity entity : this.mob.level().getEntities(this.mob,
                    this.mob.getBoundingBox().inflate(THREAT_RADIUS),
                    candidate -> candidate instanceof Projectile
                            && ((Projectile) candidate).getOwner() != this.mob)) {
                Vec3 toMob = this.mob.position().add(0.0D, this.mob.getBbHeight() * 0.5D, 0.0D)
                        .subtract(entity.position());
                double length = toMob.length();
                if (length < 1.0E-4D || length > THREAT_RADIUS) continue;
                Vec3 velocity = entity.getDeltaMovement();
                if (velocity.lengthSqr() < 1.0E-6D) continue;
                if (toMob.normalize().dot(velocity.normalize()) < 0.93D) continue;
                return (Projectile) entity;
            }
            return null;
        }

        private void facePoint(double x, double z) {
            double dx = x - this.mob.getX();
            double dz = z - this.mob.getZ();
            if (dx * dx + dz * dz < 1.0E-6D) return;
            this.mob.setYRot((float) (net.minecraft.util.Mth.atan2(dz, dx) * 180.0D / Math.PI) - 180.0F);
            this.mob.yHeadRot = this.mob.getYRot();
            this.mob.yBodyRot = this.mob.getYRot();
        }

        /** 出招/硬直/击倒中不插发动作动画，交给史诗战斗自己的回合规则。 */
        private boolean animationSlotBusy(LivingEntityPatch<?> patch) {
            try {
                EntityState state = patch.getEntityState();
                return state == null || state.inaction() || state.knockDown() || patch.isStunned();
            } catch (RuntimeException ignored) {
                return true;
            }
        }

        private void play(AssetAccessor<? extends StaticAnimation> animation) {
            LivingEntityPatch<?> patch = EpicFightCapabilities.getEntityPatch(this.mob, LivingEntityPatch.class);
            if (patch == null) return;
            try {
                patch.playAnimationSynchronized(animation, 0.0F);
            } catch (RuntimeException ignored) {
                // 动作表现是加分项：任何版本差异宁可不播动画，也不能炸掉 AI tick。
            }
        }
    }

    /**
     * 格挡伤害结算：处于格挡姿态的天灾生物，被正面的近身攻击命中时伤害减免为 25%，
     * 并消耗格挡时间、播放金属格挡音。对弹射物、穿透护盾类伤害与背后袭击无效，
     * 保证「绕背仍痛、远程仍需走位」的史诗战斗博弈感。
     *
     * <p>与史诗战斗的攻防规则对齐：攻击方若打出史诗战斗的「破防」（{@code StunType#NEUTRALIZE}
     * 或 {@code KNOCKDOWN} 这类重击结算），格挡姿态直接被击碎——不享受任何减免、格挡立即结束，
     * 后续的硬直/击倒交给史诗战斗自己演出。这样连段的第三段、蓄力重击等依然是有效的拆盾手段。</p>
     */
    public static class OriginfallGuardEvents {
        private static final double GUARD_REACH_SQR = 36.0D;

        @SubscribeEvent
        public void onLivingHurt(LivingHurtEvent event) {
            if (!(event.getEntity() instanceof CalamityMob calamity) || !calamity.isGuarding()) return;
            DamageSource source = event.getSource();
            if (source.is(DamageTypeTags.BYPASSES_SHIELD) || source.is(DamageTypeTags.IS_PROJECTILE)) return;
            if (!(source.getEntity() instanceof LivingEntity attacker) || attacker == calamity) return;
            // 弹射物等间接伤害：directEntity 存在且不等于攻击者本体时不视为可格挡的近身攻击。
            if (source.getDirectEntity() != null && source.getDirectEntity() != attacker) return;
            if (attacker.distanceToSqr(calamity) > GUARD_REACH_SQR) return;
            Vec3 facing = calamity.getLookAngle();
            Vec3 toAttacker = attacker.position().add(0.0D, attacker.getBbHeight() * 0.5D, 0.0D)
                    .subtract(calamity.position().add(0.0D, calamity.getBbHeight() * 0.5D, 0.0D));
            if (toAttacker.lengthSqr() < 1.0E-4D) return;
            if (facing.dot(toAttacker.normalize()) < -0.2D) return; // 只有正面方向可格挡
            if (isGuardBreaking(source)) {
                // 破防：这一下挡不住，姿态被打碎，伤害全额吃下。
                calamity.setGuardTicks(0);
                return;
            }
            event.setAmount(event.getAmount() * 0.25F);
            calamity.setGuardTicks(Math.max(0, calamity.getGuardTicks() - OriginfallMobGuardGoal.GUARD_COST_PER_BLOCK));
            if (calamity.level() instanceof ServerLevel server) {
                server.playSound(null, calamity, SoundEvents.SHIELD_BLOCK, SoundSource.HOSTILE, 1.0F, 1.35F);
            }
        }

        /** 史诗战斗中能击碎防御姿态的重击结算（破防与击倒类）。 */
        private static boolean isGuardBreaking(DamageSource source) {
            if (!(source instanceof EpicFightDamageSource epic)) return false;
            StunType stunType = epic.getStunType();
            return stunType == StunType.NEUTRALIZE || stunType == StunType.KNOCKDOWN;
        }
    }

    /**
     * 源石傀儡的史诗战斗补丁：仿照 Epic Fight 对铁傀儡的处理，
     * 使用傀儡拍击连段的攻击逻辑与硬直判定。
     */
    public static class OriginfallGolemPatch extends MobPatch<SourceOreGolem> {
        /** 攻击行为表在 {@link #initAI()} 时按傀儡类型懒加载（构造时 {@code getOriginal()} 尚为空）。 */
        private CombatBehaviors<OriginfallGolemPatch> behaviors;

        public OriginfallGolemPatch() {
            super(Factions.VILLAGER);
        }

        /**
         * 源石傀儡的攻击动作表：保留史诗战斗对铁傀儡的骨架（{@code IRON_GOLEM}），
         * 因此在骨架安全的两组拍击动画 {@code GOLEM_ATTACK1-4} 内重新编排连段，
         * 并把「撞飞」终结（{@code GOLEM_ATTACK1}，带 {@link StunType#KNOCKDOWN}）
         * 与「破防」重锤（{@code GOLEM_ATTACK2}，带 {@code FINISHER} 增伤标记）
         * 串进连段里。两只傀儡行为不同：源石傀儡偏快速拍击破防，纯源石傀儡偏更重、
         * 更大概率接撞飞终结的连段。
         *
         * @param heavy 是否为纯源石傀儡（更重、撞飞终结概率更高）
         */
        private static CombatBehaviors.Builder<OriginfallGolemPatch> buildBehaviors(boolean heavy) {
            CombatBehaviors.Builder<OriginfallGolemPatch> builder = CombatBehaviors.<OriginfallGolemPatch>builder()
                    // 快速拍击：可被打断，用于贴身抢节奏。
                    .newBehaviorSeries(CombatBehaviors.BehaviorSeries.<OriginfallGolemPatch>builder()
                            .weight(10.0F).canBeInterrupted(true).looping(false)
                            .nextBehavior(CombatBehaviors.Behavior.<OriginfallGolemPatch>builder()
                                    .behavior(swingAndAnimate(Animations.GOLEM_ATTACK3))
                                    .withinEyeHeight().withinDistance(0.0D, 2.0D))
                            .nextBehavior(CombatBehaviors.Behavior.<OriginfallGolemPatch>builder()
                                    .behavior(swingAndAnimate(Animations.GOLEM_ATTACK4))
                                    .withinEyeHeight()));
            if (heavy) {
                // 纯源石傀儡：重锤破防起手，第三段高概率接「撞飞」终结，连段更连贯。
                builder.newBehaviorSeries(CombatBehaviors.BehaviorSeries.<OriginfallGolemPatch>builder()
                        .weight(14.0F).canBeInterrupted(false).looping(false)
                        .nextBehavior(CombatBehaviors.Behavior.<OriginfallGolemPatch>builder()
                                .behavior(swingAndAnimate(Animations.GOLEM_ATTACK2))
                                .withinEyeHeight().withinDistance(0.0D, 2.0D))
                        .nextBehavior(CombatBehaviors.Behavior.<OriginfallGolemPatch>builder()
                                .behavior(swingAndAnimate(Animations.GOLEM_ATTACK3))
                                .withinEyeHeight())
                        .nextBehavior(CombatBehaviors.Behavior.<OriginfallGolemPatch>builder()
                                .behavior(swingAndAnimate(Animations.GOLEM_ATTACK1))
                                .randomChance(0.55F).withinEyeHeight().withinDistance(0.0D, 2.0D)));
            } else {
                // 源石傀儡：快速两段破防，较概率接「撞飞」终结。
                builder.newBehaviorSeries(CombatBehaviors.BehaviorSeries.<OriginfallGolemPatch>builder()
                        .weight(10.0F).canBeInterrupted(false).looping(false)
                        .nextBehavior(CombatBehaviors.Behavior.<OriginfallGolemPatch>builder()
                                .behavior(swingAndAnimate(Animations.GOLEM_ATTACK2))
                                .withinEyeHeight().withinDistance(0.0D, 2.0D))
                        .nextBehavior(CombatBehaviors.Behavior.<OriginfallGolemPatch>builder()
                                .behavior(swingAndAnimate(Animations.GOLEM_ATTACK1))
                                .randomChance(0.35F).withinEyeHeight().withinDistance(0.0D, 2.0D)));
            }
            return builder;
        }

        /**
         * 拍击动画 + 原版挥臂广播。傀儡不注册补丁渲染器（保留模组自己的模型与贴图），
         * 史诗战斗动画无法直接在其身上绘制，因此每段攻击额外触发一次原版摆臂，
         * 使挥击动作在模组模型上可见，同时动画照常驱动史诗战斗的伤害判定与节奏。
         */
        private static Consumer<OriginfallGolemPatch> swingAndAnimate(
                AnimationManager.AnimationAccessor<? extends StaticAnimation> animation) {
            return patch -> {
                patch.getOriginal().swing(InteractionHand.MAIN_HAND, true);
                // 双参重载自带默认网络包提供者，动画会同步给所有跟踪该实体的客户端。
                patch.playAnimationSynchronized(animation, 0.0F);
            };
        }

        @Override
        protected void initAI() {
            // 基类会先清掉原版近战/移动索敌目标与本补丁上一轮的动画攻击目标。
            super.initAI();
            if (this.behaviors == null) {
                this.behaviors = buildBehaviors(this.original instanceof PureSourceOreGolem).build(this);
            }
            this.original.goalSelector.addGoal(0, new AnimatedAttackGoal<>(this, this.behaviors));
            this.original.goalSelector.addGoal(1, new TargetChasingGoal(this, this.original, 1.0D, false));
        }

        @Override
        protected void selectGoalToRemove(Set<Goal> toRemove) {
            super.selectGoalToRemove(toRemove);
            for (WrappedGoal wrapped : this.original.goalSelector.getAvailableGoals()) {
                if (wrapped.getGoal() instanceof MoveTowardsTargetGoal) toRemove.add(wrapped.getGoal());
            }
        }

        @Override
        public void initAnimator(Animator animator) {
            super.initAnimator(animator);
            animator.addLivingAnimation(LivingMotions.IDLE, Animations.GOLEM_IDLE);
            animator.addLivingAnimation(LivingMotions.WALK, Animations.GOLEM_WALK);
            animator.addLivingAnimation(LivingMotions.DEATH, Animations.GOLEM_DEATH);
        }

        @Override
        public void updateMotion(boolean considerInaction) {
            commonMobUpdateMotion(considerInaction);
        }

        @Override
        public AssetAccessor<? extends StaticAnimation> getHitAnimation(StunType stunType) {
            // 与 Epic Fight 的铁傀儡一致：拍击连段之间不做受击动作，避免打断组合。
            return null;
        }

        /**
         * 玩家守势成功弹反傀儡时被回调。傀儡有霸体（{@link #getHitAnimation} 返回 null，
         * 不吃短/长硬直动画），但仍应被顶开一小段作为「这一下真的挡下来了」的反馈：
         * 推送自身并播放一声重击音，与 Epic Fight 对掠夺者被弹反的反馈对齐。
         */
        @Override
        public void onAttackBlocked(DamageSource damageSource, LivingEntityPatch<?> blocker) {
            if (this.original == null || !this.original.isAlive()) return;
            // 向攻击者反方向推一下（保持水平分量，避免把霸体单位发射上天）。
            Vec3 away = this.original.position().subtract(blocker.getOriginal().position());
            away = new Vec3(away.x, 0.0D, away.z);
            if (away.lengthSqr() < 1.0E-5D) return;
            this.original.knockback(0.9D, away.normalize().x, away.normalize().z);
            if (this.original.level() instanceof ServerLevel server) {
                server.playSound(null, this.original, SoundEvents.IRON_GOLEM_STEP, SoundSource.HOSTILE, 1.0F, 1.1F);
            }
        }

        @Override
        public boolean isTargetInvulnerable(Entity target) {
            if (target instanceof Mob) return false;
            return super.isTargetInvulnerable(target);
        }

        /**
         * Epic Fight 攻击事件钩子：与 {@link OriginfallHumanoidPatch#attack} 同理，
         * 傀儡本体落在任一激活领域内且不在该领域白名单（发动者本人与其弹射物）时，
         * 拍击直接判为落空，不造成伤害。傀儡的攻击经由 {@code MobPatch#attack} →
         * {@code doHurtTarget} 结算，这里在结算前拦截，语义与原版
         * {@code LivingAttackEvent} 取消一致。
         */
        @Override
        public AttackResult attack(EpicFightDamageSource source, Entity target, InteractionHand hand) {
            if (this.original != null && this.original.level() instanceof ServerLevel level
                    && ProphetSkillLogic.isAttackSuppressedByDomain(level, this.original)) {
                return AttackResult.missed(0.0F);
            }
            return super.attack(source, target, hand);
        }
    }
}
