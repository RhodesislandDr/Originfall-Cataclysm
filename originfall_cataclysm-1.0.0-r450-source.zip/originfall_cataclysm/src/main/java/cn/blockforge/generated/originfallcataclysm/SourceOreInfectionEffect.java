package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.client.extensions.common.IClientMobEffectExtensions;

import java.util.UUID;
import java.util.function.Consumer;

/** 源石感染：持续造成无视防御的伤害，并削弱攻击力与护甲。 */
public final class SourceOreInfectionEffect extends MobEffect {
    static final UUID SPEED_MODIFIER = UUID.fromString("b2e0d1b8-7d52-4a4d-9a78-1b0a6b7db100");
    private static final UUID ATTACK_MODIFIER = UUID.fromString("b2e0d1b8-7d52-4a4d-9a78-1b0a6b7db101");
    private static final UUID ARMOR_MODIFIER = UUID.fromString("b2e0d1b8-7d52-4a4d-9a78-1b0a6b7db102");

    public SourceOreInfectionEffect() {
        super(MobEffectCategory.HARMFUL, 0x24151C);
        addAttributeModifier(Attributes.MOVEMENT_SPEED, SPEED_MODIFIER.toString(), -0.05D,
                AttributeModifier.Operation.MULTIPLY_TOTAL);
        addAttributeModifier(Attributes.ATTACK_DAMAGE, ATTACK_MODIFIER.toString(), -0.05D,
                AttributeModifier.Operation.MULTIPLY_TOTAL);
        addAttributeModifier(Attributes.ARMOR, ARMOR_MODIFIER.toString(), -0.05D,
                AttributeModifier.Operation.MULTIPLY_TOTAL);
    }

    @Override
    public void initializeClient(Consumer<IClientMobEffectExtensions> consumer) {
        consumer.accept(new cn.blockforge.generated.originfallcataclysm.client.SourceOreInfectionClientExtension());
    }

    @Override
    public double getAttributeModifierValue(int amplifier, AttributeModifier modifier) {
        int layers = Math.min(CalamityLogic.MAX_SOURCE_ORE_INFECTION_LAYERS,
                amplifier == Integer.MAX_VALUE ? CalamityLogic.MAX_SOURCE_ORE_INFECTION_LAYERS
                        : Math.max(1, amplifier + 1));
        double reduction = CalamityLogic.sourceOreInfectionReduction(layers);
        return -reduction;
    }

    @Override
    public void applyEffectTick(LivingEntity living, int amplifier) {
        // 源石感染是本模组附加的负面效果，必须绕过目标的免疫判定并继续生效。
        if (living.level().isClientSide) return;

        int layers = Math.min(CalamityLogic.MAX_SOURCE_ORE_INFECTION_LAYERS,
                amplifier == Integer.MAX_VALUE ? CalamityLogic.MAX_SOURCE_ORE_INFECTION_LAYERS
                        : Math.max(1, amplifier + 1));
        float damage = (float) CalamityLogic.sourceOreInfectionDamage(layers);
        boolean fatal = living.getHealth() <= damage;
        if (fatal) CalamityLogic.markSourceOreInfectionDeath(living);
        boolean hurt = living.hurt(living.damageSources().magic(), damage);
        if (fatal && !living.isDeadOrDying()) CalamityLogic.clearSourceOreInfectionDeath(living);
        if (!hurt && fatal) CalamityLogic.clearSourceOreInfectionDeath(living);
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        // 由 CommonEvents 每秒驱动，避免无限时长效果被每 tick 重复结算。
        return false;
    }
}
