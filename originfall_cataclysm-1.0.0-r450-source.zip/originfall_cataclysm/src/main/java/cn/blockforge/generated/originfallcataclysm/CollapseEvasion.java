package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 邪魔固有被动「坍缩闪避」：感染者的每一级坍缩感染提供 13% 的闪避概率
 * （{@link CalamityLogic#MAX_COLLAPSE_LAYERS} 层封顶即 13%×5 = 65%）。
 *
 * <p>判定挂在 {@link LivingHurtEvent}（护甲与附魔结算之后、伤害落实之前）：
 * 每次受击独立掷骰，命中闪避即整个取消此次攻击——不扣血、无击退、不闪红，
 * 依附于此次命中的受击型特效（如攻击方借受击事件传播的坍缩传染）一并落空。</p>
 *
 * <p>两类豁免，闪避无法生效：</p>
 * <ul>
 *   <li><b>/kill 类击杀</b>：{@link DamageTypes#GENERIC_KILL} 与
 *       {@link DamageTypeTags#BYPASSES_INVULNERABILITY}（命令处刑、{@code Entity#kill()}
 *       都走这一系），照单全收不可闪避；</li>
 *   <li><b>最大生命值削弱</b>：{@link TiantangzhidianLogic#applyMaxHpCut} 与
 *       {@link MaxHealthZeroLogic} 的削减通道是直接压属性、{@code setHealth}/{@code die()}
 *       结算，根本不经过受击事件链，天然在闪避之外。</li>
 * </ul>
 *
 * <p>只有「有攻击者的攻击」参与闪避：伤害来源实体为空的环境伤害（坠落、火焰、
 * 窒息、虚空等）与邪魔自身坍缩的每秒掉血不属于「此次攻击」，照常生效。</p>
 *
 * <p>成功闪避时在邪魔身上冒一小簇云絮粒子作为可读性反馈；另外被非线性移动
 * 狂暴加成的邪魔即使打空也要刷新狂暴窗口——「被攻击」不要求「被打中」，
 * 这里显式补记一次，避免事件取消导致 {@link CollapseCovenant#onHurt} 漏刷。</p>
 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID)
public final class CollapseEvasion {

    /** 每级坍缩感染提供的闪避概率：13%。 */
    public static final float DODGE_CHANCE_PER_LAYER = 0.13F;

    private CollapseEvasion() {
    }

    /** 该生物当前由坍缩感染提供的闪避概率；未感染返回 0。 */
    public static float dodgeChance(LivingEntity entity) {
        return DODGE_CHANCE_PER_LAYER * CalamityLogic.collapseLayers(entity);
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide || event.getAmount() <= 0.0F) return;
        if (!CalamityLogic.isCollapsed(victim)) return;
        DamageSource source = event.getSource();
        // 豁免一：/kill 类击杀不可闪避（generic_kill 与穿无敌标签一并挡掉）。
        if (source.is(DamageTypes.GENERIC_KILL) || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }
        // 只闪「此次攻击」：来源实体为空的环境伤害与邪魔自身坍缩掉血不参与掷骰。
        Entity attacker = source.getEntity();
        if (attacker == null || attacker == victim) return;
        if (!(victim.level() instanceof ServerLevel level)) return;
        if (level.getRandom().nextFloat() >= dodgeChance(victim)) return;
        // 闪避命中：整个取消此次攻击（原版在受击事件返回 0 后直接结束 hurt 流程，
        // 扣血、击退、受击动画与受击型传染全部落空）。
        event.setCanceled(true);
        // 非线性移动的狂暴窗口按「被攻击」刷新，打空也算挨了这一下。
        if (CollapseCovenant.stacks(CollapseCovenant.NONLINEAR_MOVEMENT) > 0) {
            CollapseCovenant.markCollapseRage(victim);
        }
        level.sendParticles(ParticleTypes.CLOUD, victim.getX(),
                victim.getY() + victim.getBbHeight() * 0.5D, victim.getZ(),
                8, victim.getBbWidth() * 0.6D, victim.getBbHeight() * 0.4D,
                victim.getBbWidth() * 0.6D, 0.02D);
    }
}
