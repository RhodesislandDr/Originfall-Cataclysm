package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 「扒臀长舞」服务端驱动——深蓝之树<b>本尊</b>哈基玖版。
 *
 * <p>装有《方块与深蓝之树》时，「张师块＋南瓜头」仪式产出的实体是本尊
 * {@code caerula_arbor:apocata}——外部实体类，不是本模组的 {@link CalamityMob}：
 * 同步实体数据（{@code TAUNT_TICKS}）与 {@link CalamityMob#tick} 的倒计时递减都挂不上去，
 * {@link BossTauntLogic} 的名单判定自然也不覆盖它，于是「装了深蓝之树就跳不了舞」。
 * 本类给本尊实现同一套规则，只换状态载体：</p>
 * <ul>
 *   <li><b>舞中状态</b>：服务端内存会话表（实体 UUID → 剩余/总 tick/施加者/维度）。
 *       重启或实体丢失后舞蹈自然失效，免疫态随之消失，绝不会残留「免伤却没人驱动动作」；</li>
 *   <li><b>首触标记</b>：实体持久化数据（跨存档，死亡重生不再走首触）；</li>
 *   <li><b>客户端演出</b>：开跳/补同步时经 {@link YangFireNetworking} 广播舞程，
 *       由 {@code NativeApocataAppearanceEvents} 用本模组玩家骨架 + 蕾缪安贴图<b>代画</b>
 *       （对方模型本模组无法驱动，替身与本尊同肤同骨架，观感一致）。</li>
 * </ul>
 *
 * <p>规则与替身、两位首领完全等同：首次枪械/魔法命中吞击起跳整曲；之后只剩枪械
 * {@link BossTauntLogic#RETRIGGER_CHANCE} 复触发；舞期内免疫一切伤害、弹开一切弹射物、
 * 自身出手归零；与首领同队列同曲目。转身、扭头、每秒 2 格背向贴近、交替后退根位移
 * 逐 tick 复刻 {@code BossTauntLogic.tickMobs}。</p>
 */
public final class NativeApocataTauntLogic {
    /** 实体持久化数据键：枪械/魔法首次触发已完成（随实体存档，重启不丢）。 */
    private static final String FIRST_DONE = "OfcNativeTauntFirstDone";
    /** 舞程钳制上下限，与 {@code BossTauntLogic.start} 同口径（30 ~ 6000 tick）。 */
    private static final int MIN_TICKS = 30;
    private static final int MAX_TICKS = 6000;
    /** 位移口径与 BossTauntLogic 完全一致：每秒 2 格贴近、2 格间距停步、转身 18°/tick、扭头 8°/tick。 */
    private static final double DANCE_SPEED = 0.1D;
    private static final double DANCE_MIN_GAP = 2.0D;
    private static final float TURN_STEP = 18.0F;
    private static final float HEAD_FOLLOW_STEP = 8.0F;
    /** 实体连续解析不到的 tick 数超过该值即回收会话（区块长期卸载/实体消失的兜底，防内存滞留）。 */
    private static final int UNLOADED_PURGE_TICKS = 200;
    /** {@link BossDanceKeyframes#sampleMove} 取样缓冲（服务端主线程单线程，复用即可）。 */
    private static final float[] MOVE_FROM = new float[3];
    private static final float[] MOVE_TO = new float[3];

    /** 舞者会话表：实体 UUID → 进行中的舞蹈。「正在跳」以本表为唯一判据（不读持久化的剩余 tick）。 */
    private static final Map<UUID, Session> SESSIONS = new ConcurrentHashMap<>();

    private static final class Session {
        int remainingTicks;
        final int totalTicks;
        @Nullable
        UUID targetId;
        /** 开跳维度：会话只在同维度的 level tick 里被驱动，跨维度条目留给对方维度处理。 */
        final ResourceKey<Level> dimension;
        /** 实体连续解析不到的 tick 计数：卸载中的舞蹈暂停递减，回归后继续（同 BossTauntLogic 只处理在场实体）。 */
        int missingTicks;

        Session(int totalTicks, @Nullable UUID targetId, ResourceKey<Level> dimension) {
            this.remainingTicks = totalTicks;
            this.totalTicks = totalTicks;
            this.targetId = targetId;
            this.dimension = dimension;
        }
    }

    private NativeApocataTauntLogic() {
    }

    /** 本尊此刻是否正在跳舞（服务端权威口径：只看内存会话）。 */
    public static boolean isActive(@Nullable LivingEntity entity) {
        if (entity == null) return false;
        Session session = SESSIONS.get(entity.getUUID());
        return session != null && session.remainingTicks > 0;
    }

    /**
     * 受击触发入口（与 {@code BossTauntLogic.handleIncomingHit} 同规则，仅状态载体换成会话/持久数据）。
     *
     * @return true 表示本次伤害应被免疫取消：舞期内任意受击，或首触/概率触发成功的那一击。
     */
    public static boolean handleIncomingHit(LivingEntity victim, DamageSource source, ServerLevel level) {
        if (!victim.isAlive()) return false;
        // 舞期免疫：跳舞中吞掉一切伤害来源（枪械、魔法、近战、爆炸皆然）。
        if (isActive(victim)) return true;
        boolean firearm = WeaponCompat.isFirearmDamage(source)
                // 深蓝之树自己的远程攻击按「枪械」计，与替身口径完全一致。
                || WeaponCompat.isCaerulaRangedDamage(source);
        boolean magic = !firearm && WeaponCompat.isMagicDamage(source);
        if (!firearm && !magic) return false;
        // 舞蹈目标 = 造成这一击的伤害施加者（谁开枪/施法就跟着谁）。
        LivingEntity attacker = source.getEntity() instanceof LivingEntity living && living != victim
                ? living : null;
        if (!victim.getPersistentData().getBoolean(FIRST_DONE)) {
            victim.getPersistentData().putBoolean(FIRST_DONE, true);
            beginDance(victim, level, attacker);
            return true;
        }
        if (firearm && level.getRandom().nextFloat() < BossTauntLogic.RETRIGGER_CHANCE) {
            beginDance(victim, level, attacker);
            return true;
        }
        return false;
    }

    /** 开跳并广播舞程；attacker 传 null 沿用会话里已记录的施加者（无记录则原地跳），口径同 {@code BossTauntLogic.start}。 */
    public static void start(LivingEntity mob, int ticks, @Nullable LivingEntity attacker) {
        if (!mob.isAlive() || mob.level().isClientSide) return;
        int clamped = Mth.clamp(ticks, MIN_TICKS, MAX_TICKS);
        Session existing = SESSIONS.get(mob.getUUID());
        UUID targetId = attacker != null ? attacker.getUUID()
                : existing != null ? existing.targetId : null;
        SESSIONS.put(mob.getUUID(), new Session(clamped, targetId, mob.level().dimension()));
        YangFireNetworking.syncNativeDance(mob, clamped, clamped);
    }

    /** 起舞并入队：无人在播则起播整曲并跳满；已有舞曲在播则跟随当前曲目剩余时长（与首领同一支曲子）。 */
    private static void beginDance(LivingEntity mob, ServerLevel level, @Nullable LivingEntity attacker) {
        boolean joining = TauntSongMusic.playOrJoin(level);
        int ticks = joining ? TauntSongMusic.remainingTicks() : TauntSongMusic.songTicks();
        start(mob, Math.max(ticks, MIN_TICKS), attacker);
    }

    /** 每个服务端 tick 调用：驱动本维度内所有正在跳舞的本尊（倒计时 + 转身 + 贴近 + 弹射物防御）。 */
    public static void tick(ServerLevel level) {
        if (SESSIONS.isEmpty()) return;
        Iterator<Map.Entry<UUID, Session>> iterator = SESSIONS.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Session> entry = iterator.next();
            Session session = entry.getValue();
            if (!level.dimension().equals(session.dimension)) continue;
            Entity entity = level.getEntity(entry.getKey());
            if (entity instanceof LivingEntity living && !living.isAlive()) {
                // 死亡即销舞（尸体消失前 isAlive 已为假，这里立即回收）。
                iterator.remove();
                continue;
            }
            if (!(entity instanceof LivingEntity dancer)) {
                // 解析不到：多半是区块卸载，舞蹈就地暂停；久不回归按 UNLOADED_PURGE_TICKS 回收。
                if (++session.missingTicks > UNLOADED_PURGE_TICKS) iterator.remove();
                continue;
            }
            session.missingTicks = 0;
            if (--session.remainingTicks <= 0) {
                iterator.remove();
                continue;
            }
            drive(level, dancer, session);
        }
    }

    /** 玩家开始追踪一个正在跳舞的本尊时，给这位玩家补发当前舞程（错过开跳广播的客户端按剩余时长续跳）。 */
    public static void resyncOnStartTracking(LivingEntity entity, ServerPlayer player) {
        if (!CaerulaArborCompat.isNativeApocataEntity(entity)) return;
        Session session = SESSIONS.get(entity.getUUID());
        if (session == null || session.remainingTicks <= 0) return;
        YangFireNetworking.sendNativeDanceTo(player, entity.getId(), session.totalTicks, session.remainingTicks);
    }

    /** 单舞步驱动：与 {@code BossTauntLogic.tickMobs} 的同一段逐句对应，只把状态从实体同步数据换成会话。 */
    private static void drive(ServerLevel level, LivingEntity dancer, Session session) {
        // 舞蹈期间放弃攻击目标与寻路：位移全部由下面的贴地平移接管（本尊是 Mob 时才有寻路可停）。
        if (dancer instanceof Mob mob) {
            mob.setTarget(null);
            mob.setAggressive(false);
            mob.getNavigation().stop();
        }
        // 舞曲持续期间全程弹飞靠近的弹射物（伤害免疫由受击事件入口负责）——与首领共用同一套弹反。
        BossTauntLogic.deflectAround(level, dancer);
        // 按「现有方向」扭头：头（yHeadRot）限步长追当前身体朝向，转身时落后、转完甩上。
        float headStep = Mth.clamp(Mth.wrapDegrees(dancer.getYRot() - dancer.getYHeadRot()),
                -HEAD_FOLLOW_STEP, HEAD_FOLLOW_STEP);
        dancer.setYHeadRot(dancer.getYHeadRot() + headStep);
        LivingEntity target = resolveTarget(level, dancer, session);
        if (target == null) {
            // 没有可跟随的伤害施加者：原地定身，保持入场时的朝向。
            dancer.setDeltaMovement(0.0D, dancer.getDeltaMovement().y, 0.0D);
            return;
        }
        double dx = target.getX() - dancer.getX();
        double dz = target.getZ() - dancer.getZ();
        double planarDistance = Math.sqrt(dx * dx + dz * dz);
        if (planarDistance < 1.0E-4D) {
            dancer.setDeltaMovement(0.0D, dancer.getDeltaMovement().y, 0.0D);
            return;
        }
        // 「背对方向为施加者方向」：面向 = 指向施加者的反方向。
        float awayYaw = (float) (Math.toDegrees(Mth.atan2(dz, dx)) + 90.0D);
        float step = Mth.clamp(Mth.wrapDegrees(awayYaw - dancer.getYRot()), -TURN_STEP, TURN_STEP);
        dancer.setYRot(dancer.getYRot() + step);
        dancer.setXRot(0.0F);
        // 每秒 2 格向施加者平移（背向滑步）；走 move() 直推位移，与首领同一实现。
        dancer.setDeltaMovement(0.0D, dancer.getDeltaMovement().y, 0.0D);
        double stepX = 0.0D;
        double stepZ = 0.0D;
        if (planarDistance > DANCE_MIN_GAP) {
            double scale = DANCE_SPEED / planarDistance;
            stepX += dx * scale;
            stepZ += dz * scale;
        }
        // 再叠加动作本身的地面位移（「交替后退」那两段），方向按当前朝向从模型本地系转到世界系。
        int elapsed = Math.max(session.totalTicks - session.remainingTicks, 0);
        int tickNow = elapsed % BossDanceKeyframes.TICKS;
        // 整段动作循环回起点的那一 tick 不补差值，否则每轮都会向前瞬移一格。
        int tickPrev = tickNow > 0 ? tickNow - 1 : 0;
        BossDanceKeyframes.sampleMove(tickPrev, MOVE_FROM);
        BossDanceKeyframes.sampleMove(tickNow, MOVE_TO);
        double moveX = (MOVE_TO[0] - MOVE_FROM[0]) / 16.0D;
        double moveZ = (MOVE_TO[2] - MOVE_FROM[2]) / 16.0D;
        if (moveX != 0.0D || moveZ != 0.0D) {
            double yaw = Math.toRadians(dancer.getYRot());
            double cos = Math.cos(yaw);
            double sin = Math.sin(yaw);
            stepX += moveX * cos + moveZ * sin;
            stepZ += moveX * sin - moveZ * cos;
        }
        if (stepX != 0.0D || stepZ != 0.0D) {
            dancer.move(MoverType.SELF, new Vec3(stepX, 0.0D, stepZ));
        }
    }

    /** 解析本尊本次舞蹈要跟随的伤害施加者：只认开跳那一击的凶手，超出 {@link BossTauntLogic#FACE_RANGE} 或死亡后清空原地续跳。 */
    @Nullable
    private static LivingEntity resolveTarget(ServerLevel level, LivingEntity dancer, Session session) {
        UUID id = session.targetId;
        if (id == null) return null;
        Entity entity = level.getEntity(id);
        if (entity instanceof LivingEntity living && living.isAlive()
                && living.distanceToSqr(dancer) <= BossTauntLogic.FACE_RANGE * BossTauntLogic.FACE_RANGE) {
            return living;
        }
        session.targetId = null;
        return null;
    }
}
