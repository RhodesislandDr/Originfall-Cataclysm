package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

/** 张师块：除作为特蕾西娅的召唤结构外，还会持续净化范围内的源石感染。 */
public final class ZhangshiBlock extends Block implements EntityBlock {
    public ZhangshiBlock(Properties properties) {
        super(properties);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ZhangshiBlockEntity(pos, state);
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
                                                                  BlockEntityType<T> type) {
        if (level.isClientSide || type != GeneratedMod.ZHANGSHI_BLOCK_ENTITY.get()) return null;
        return (currentLevel, pos, currentState, blockEntity) ->
                ZhangshiBlockEntity.serverTick(currentLevel, pos, currentState,
                        (ZhangshiBlockEntity) blockEntity);
    }
}
