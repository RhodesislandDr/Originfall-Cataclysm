package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** 源石耄耋的注册实体类型实现。 */
public final class SourceOreGolemEntity extends SourceOreGolem {
    public SourceOreGolemEntity(EntityType<? extends SourceOreGolemEntity> type, Level level) {
        super(type, level);
    }

    public static net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder createAttributes() {
        // 铁傀儡默认攻击 15；源石耄耋要求为其一半。
        return SourceOreGolem.createAttributes(7.5D);
    }

    @Override
    protected int infectionInterval() {
        return 3;
    }

    @Override
    protected int infectionLayersPerAttack() {
        return 1;
    }
}
