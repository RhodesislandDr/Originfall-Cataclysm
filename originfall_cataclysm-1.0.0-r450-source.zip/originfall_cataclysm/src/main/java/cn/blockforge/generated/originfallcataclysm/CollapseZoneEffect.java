package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

import java.util.UUID;

/**
 * 坍缩领域（「实质性坍缩」加成的载体）：邪魔移动时留下的感染空间内的范围削弱。
 *
 * <p>空间性质参考龙息：只影响处于其中的非邪魔生物。每层将移动速度与攻击速度
 * 各降低 3.25%（{@link CollapseCovenant#ZONE_REDUCE_PER_STACK}），层数以效果
 * amplifier 编码（层数 = amplifier + 1），由 {@link #getAttributeModifierValue}
 * 按层数动态计算。</p>
 */
public final class CollapseZoneEffect extends MobEffect {
    static final UUID SPEED_MODIFIER = UUID.fromString("8d2b4f60-1a3c-4e57-9b08-5d6e7f8a9b01");
    static final UUID ATTACK_SPEED_MODIFIER = UUID.fromString("8d2b4f60-1a3c-4e57-9b08-5d6e7f8a9b02");

    public CollapseZoneEffect() {
        // 与坍缩效果同一系的中性灰紫；本效果无 HUD 图标，仅作为属性载体。
        super(MobEffectCategory.HARMFUL, 0x3A2F47);
        addAttributeModifier(Attributes.MOVEMENT_SPEED, SPEED_MODIFIER.toString(), 0.0D,
                AttributeModifier.Operation.MULTIPLY_BASE);
        addAttributeModifier(Attributes.ATTACK_SPEED, ATTACK_SPEED_MODIFIER.toString(), 0.0D,
                AttributeModifier.Operation.MULTIPLY_BASE);
    }

    @Override
    public double getAttributeModifierValue(int amplifier, AttributeModifier modifier) {
        int stacks = Math.max(1, amplifier + 1);
        return -CollapseCovenant.ZONE_REDUCE_PER_STACK * stacks;
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        // 纯属性载体，不做周期结算。
        return false;
    }
}
