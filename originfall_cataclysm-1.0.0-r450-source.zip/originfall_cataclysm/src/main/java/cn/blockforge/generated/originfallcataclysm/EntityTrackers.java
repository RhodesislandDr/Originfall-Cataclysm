package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 周期性逻辑使用的轻量实体索引，替代按 tick 的全维度 AABB 实体检索。
 *
 * <p>此前 {@code PriestessSkillLogic.tick} / {@code ProphetSkillLogic.tick} /
 * {@code DomainSphereEntity.pruneOrphans} / {@code removeForCaster} 在每个维度的每个
 * tick 都要以「世界全域包围盒」调一次 {@code getEntitiesOfClass}，其代价是遍历全部已加载
 * 实体分区；地图越大、实体越多，每 tick 的固定开销越重，表现为模组整体卡顿。本类经
 * {@link EntityJoinLevelEvent} / {@link EntityLeaveLevelEvent} 维护各维度内的
 * 女祭司 / 预言家 / 领域结界球体名单（数量极少，通常个位数），把这些查询降为 O(名单长度)。</p>
 *
 * <p>快照读取时会顺带清掉失效条目（实体移除、换维度后的旧实例），事件若有遗漏也能自愈；
 * 服务端停止时整体清空。客户端侧同样跟踪陨石实体，供 {@code CameraEvents} 逐帧运镜抖动
 * 直接遍历小集合，代替每帧一次的大范围实体查询。</p>
 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID)
public final class EntityTrackers {

    private static final Map<ServerLevel, List<Priestess>> PRIESTESSES = new IdentityHashMap<>();
    private static final Map<ServerLevel, List<Prophet>> PROPHETS = new IdentityHashMap<>();
    /** 哈基玖：数量同样极少（彩蛋生物，只能召唤/刷怪蛋获得），供舞蹈 tick 遍历。 */
    private static final Map<ServerLevel, List<Apocata>> APOCATAS = new IdentityHashMap<>();
    private static final Map<ServerLevel, List<DomainSphereEntity>> SPHERES = new IdentityHashMap<>();

    /** 客户端：当前已加载世界内的全部陨石（运镜抖动按伤害倍率在读取时过滤）。 */
    private static ClientLevel clientLevel;
    private static final Set<MeteorEntity> CLIENT_METEORS = new LinkedHashSet<>();

    private EntityTrackers() {
    }

    // ---------------- 事件挂接 ----------------

    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide) {
            if (event.getEntity() instanceof MeteorEntity meteor) {
                CLIENT_METEORS.add(meteor);
            }
            return;
        }
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        Entity entity = event.getEntity();
        if (entity instanceof Priestess priestess) {
            PRIESTESSES.computeIfAbsent(level, k -> new ArrayList<>()).add(priestess);
        } else if (entity instanceof Prophet prophet) {
            PROPHETS.computeIfAbsent(level, k -> new ArrayList<>()).add(prophet);
        } else if (entity instanceof Apocata apocata) {
            APOCATAS.computeIfAbsent(level, k -> new ArrayList<>()).add(apocata);
        } else if (entity instanceof DomainSphereEntity sphere) {
            SPHERES.computeIfAbsent(level, k -> new ArrayList<>()).add(sphere);
        }
    }

    @SubscribeEvent
    public static void onLeave(EntityLeaveLevelEvent event) {
        if (event.getLevel().isClientSide) {
            if (event.getEntity() instanceof MeteorEntity meteor) {
                CLIENT_METEORS.remove(meteor);
            }
            return;
        }
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        Entity entity = event.getEntity();
        if (entity instanceof Priestess) {
            removeFrom(PRIESTESSES, level, entity);
        } else if (entity instanceof Prophet) {
            removeFrom(PROPHETS, level, entity);
        } else if (entity instanceof Apocata) {
            removeFrom(APOCATAS, level, entity);
        } else if (entity instanceof DomainSphereEntity) {
            removeFrom(SPHERES, level, entity);
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        PRIESTESSES.clear();
        PROPHETS.clear();
        APOCATAS.clear();
        SPHERES.clear();
    }

    private static <T extends Entity> void removeFrom(Map<ServerLevel, List<T>> map,
                                                      ServerLevel level, Entity entity) {
        List<T> list = map.get(level);
        if (list == null) return;
        list.remove(entity);
        if (list.isEmpty()) map.remove(level);
    }

    // ---------------- 快照读取 ----------------

    public static List<Priestess> priestesses(ServerLevel level) {
        return snapshot(PRIESTESSES, level);
    }

    public static List<Prophet> prophets(ServerLevel level) {
        return snapshot(PROPHETS, level);
    }

    /** 哈基玖名单：供 {@link BossTauntLogic#tick} 的舞蹈轮询与测试命令使用。 */
    public static List<Apocata> apocatas(ServerLevel level) {
        return snapshot(APOCATAS, level);
    }

    public static List<DomainSphereEntity> spheres(ServerLevel level) {
        return snapshot(SPHERES, level);
    }

    /**
     * 返回一份可与事件并发改写的安全快照；顺带剔除失效条目（实体移除 / 已迁移维度），
     * 即使个别路径漏发离开事件也能在下一次读取时自愈。
     */
    private static <T extends Entity> List<T> snapshot(Map<ServerLevel, List<T>> map, ServerLevel level) {
        List<T> list = map.get(level);
        if (list == null || list.isEmpty()) return Collections.emptyList();
        list.removeIf(entity -> entity.isRemoved() || entity.level() != level);
        if (list.isEmpty()) {
            map.remove(level);
            return Collections.emptyList();
        }
        // 技能结算可能当场杀死/移除名单中的个体（结束领域、丢弃球体），
        // 调用方按快照迭代，避免事件改写底层列表触发并发修改。
        return new ArrayList<>(list);
    }

    // ---------------- 客户端陨石跟踪 ----------------

    /** 世界切换（进服/退服/换维度客户端侧重建）时清空客户端陨石集合；同世界则原样可用。 */
    @OnlyIn(Dist.CLIENT)
    public static void syncClientWorld(ClientLevel level) {
        if (clientLevel != level) {
            clientLevel = level;
            CLIENT_METEORS.clear();
        }
    }

    /** 当前客户端世界的陨石集合（迭代时请自行按 isRemoved 惰性清理）。 */
    @OnlyIn(Dist.CLIENT)
    public static Set<MeteorEntity> clientMeteors() {
        return CLIENT_METEORS;
    }

    /** 集合迭代与惰性清理的小工具：移除已不在场的陨石。 */
    @OnlyIn(Dist.CLIENT)
    public static void pruneClientMeteors() {
        Iterator<MeteorEntity> iterator = CLIENT_METEORS.iterator();
        while (iterator.hasNext()) {
            MeteorEntity meteor = iterator.next();
            if (meteor.isRemoved() || meteor.level() != clientLevel) iterator.remove();
        }
    }

    // ---------------- 服务端停机兜底 ----------------

    /** 供 {@link MinecraftServer} 停止流程使用的显式清理（事件遗漏时的保险）。 */
    public static void clearAll() {
        PRIESTESSES.clear();
        PROPHETS.clear();
        SPHERES.clear();
    }
}
