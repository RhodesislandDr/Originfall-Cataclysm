package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.BlockPos;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;

public final class YoungDemonLord extends CalamityMob {
    public YoungDemonLord(EntityType<? extends YoungDemonLord> type, Level level) {
        super(type, level);
    }

    public static net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder createAttributes() {
        return CalamityMob.createAttributes(100.0D, 10.0D);
    }

    @Override
    protected double followRange() { return 64.0D; }

    @Override
    protected boolean canTeleportAcrossDimensions() { return false; }

    @Override
    public boolean canAttack(LivingEntity target) {
        // 邪魔（坍缩）个体与所有生物敌对，不受文明延续模式限制。
        if (CalamityLogic.isCollapsed(this)) return super.canAttack(target);
        // 文明延续模式下，无主的自然个体也将该玩家视为敌人；普通模式仍保持友好。
        if (getOwnerUUID() == null) {
            return target instanceof Player player
                    && CalamityLogic.isCivilizationContinuancePlayer(player)
                    && super.canAttack(target);
        }
        return super.canAttack(target);
    }

    @Override
    protected void serverNaturalAbilityTick(ServerLevel level) {
        // 自然生成后 200 秒首次召唤，此后每 400 秒召唤一只源石耄耋。
        if (tickCount >= 4000 && (tickCount == 4000 || (tickCount - 4000) % 8000 == 0)) {
            summonSourceOreGolem(level);
        }
    }

    private void summonSourceOreGolem(ServerLevel level) {
        SourceOreGolem golem = GeneratedMod.SOURCE_ORE_GOLEM.get().create(level);
        if (golem == null) return;
        double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
        double distance = 2.0D + level.getRandom().nextDouble() * 3.0D;
        double x = getX() + Math.cos(angle) * distance;
        double z = getZ() + Math.sin(angle) * distance;
        BlockPos spawn = level.getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING,
                new BlockPos(net.minecraft.util.Mth.floor(x), 0, net.minecraft.util.Mth.floor(z)));
        golem.moveTo(spawn.getX() + 0.5D, spawn.getY(), spawn.getZ() + 0.5D,
                level.getRandom().nextFloat() * 360.0F, 0.0F);
        golem.setManufacturerUUID(getUUID());
        golem.setCalamityFaction(CalamityLogic.isCalamityFactionMember(this));
        golem.setPlayerCreated(true);
        golem.setPersistenceRequired();
        level.addFreshEntity(golem);
    }

    @Override
    protected void serverAbilityTick(ServerLevel level) {
        Player owner = getOwner() instanceof Player player ? player : null;
        if (owner != null && CalamityLogic.isCalamityModePlayer(owner)
                && distanceToSqr(owner) <= 32.0D * 32.0D) {
            DisasterData data = DisasterData.get(level);
            if (!data.isCalamityActive()) data.activateBySource();
        }
        int hostileCount = level.getEntitiesOfClass(LivingEntity.class, area(this, 32.0D),
                entity -> CalamityLogic.isCalamityPopulationTarget(entity, this, 32.0D)).size();
        if (hostileCount > 5 && isAbilityReady()) {
            MeteorStaff.summon(level, this, MeteorStaff.count(level));
            setAbilityCooldown(100);
        }
    }

    @Override
    protected void onCalamityDeath(ServerLevel level, LivingEntity killer, net.minecraft.nbt.CompoundTag snapshot) {
        CalamityLogic.summonDemonLordDeathMeteor(level, this, killer, 100.0F, 100.0F, 0.5F, 0.5F);
    }
}
