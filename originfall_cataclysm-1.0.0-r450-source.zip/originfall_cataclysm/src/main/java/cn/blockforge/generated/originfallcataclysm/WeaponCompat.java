package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;

import java.util.Locale;

/**
 * 外部武器模组的伤害来源识别（「扒臀舞」触发兼容层）。
 *
 * <p>目标模组：永恒枪械工坊：零（TaCZ）、Iron 的法术与魔法书（铁魔法）及其附属、
 * 诡厄巫法（Goety）及其附属。本类<b>不引入任何编译期依赖</b>——只按注册表命名
 * （伤害类型键 / 直接实体类型键）的命名空间与路径关键字判定，因此目标模组装与不装、
 * 版本如何都不影响本模组加载；新附属模组若沿用含 spell/magic/bullet 等关键字的
 * 注册名，也能被同一规则覆盖。</p>
 *
 * <p>判定层次（命中其一即算）：</p>
 * <ol>
 *   <li>伤害类型注册键：命名空间前缀匹配，或路径含关键字；</li>
 *   <li>直接实体（弹射物）类型注册键：同上——覆盖用原版伤害类型、但弹射物自带命名空间的模组；</li>
 *   <li>{@code getMsgId()}：伤害类型未注册进注册表时（极少数用 {@link DamageSource} 裸构造的模组）
 *       的兜底，其格式为「namespace.path」。</li>
 * </ol>
 */
public final class WeaponCompat {

    /** 枪械侧命名空间前缀：TaCZ 与其弹药/枪械扩展包（tacz_xxx 形式）一并命中。 */
    private static final String[] GUN_NAMESPACES = {"tacz"};
    /** 魔法侧命名空间前缀：铁魔法、诡厄巫法，及沿用主模组前缀的附属（irons_spellbooks_xxx / goety_xxx）。 */
    private static final String[] MAGIC_NAMESPACES = {"irons_spellbooks", "iron_spellbooks", "goety"};
    /**
     * 深蓝之树命名空间：其远程攻击要求「等同于 TaCZ 等模组」接入跳舞开关与触发概率，
     * 单独走 {@link #isCaerulaRangedDamage} 的弹体口径判定——不能并入 {@code GUN_NAMESPACES}，
     * 否则该模组生物的近战咬抓（伤害类型同样落在 {@code caerula_arbor} 命名空间）也会起舞。
     */
    private static final String CAERULA_NAMESPACE = "caerula_arbor";
    /** 枪械侧路径关键字。 */
    private static final String[] GUN_KEYWORDS = {"bullet", "gunshot", "gunfire", "firearm", "gun_", "shelling"};
    /** 魔法侧路径关键字。 */
    private static final String[] MAGIC_KEYWORDS = {"spell", "magic", "mana", "arcane", "incantation"};

    /** 兼容模组的「弹体」注册路径特征（必须与兼容命名空间同时命中，避免把模组生物弹飞）。 */
    private static final String[] PROJECTILE_PATH_MARKS = {
            "bullet", "projectile", "missile", "bolt", "orb", "spell", "magic", "mana",
            "arcane", "shot", "gunfire", "firearm", "shelling", "incantation"
    };

    private WeaponCompat() {
    }

    /** 是否枪械伤害（永恒枪械工坊：零系）。 */
    public static boolean isFirearmDamage(DamageSource source) {
        return matches(source, GUN_NAMESPACES, GUN_KEYWORDS);
    }

    /** 是否魔法伤害（铁魔法与诡厄巫法系，含附属模组）。 */
    public static boolean isMagicDamage(DamageSource source) {
        return matches(source, MAGIC_NAMESPACES, MAGIC_KEYWORDS);
    }

    /**
     * 是否《方块与深蓝之树》（{@code caerula_arbor}）的<b>远程</b>攻击。
     *
     * <p>口径只认「伤害载体是该模组的非生物弹体」：{@code getDirectEntity()} 存在且
     * 注册命名空间为 {@code caerula_arbor}、并且它<b>不是</b>活体生物——活体生物作直接
     * 来源即是近战撕咬（{@code Mob#doHurtTarget} 的 damageSource 把攻击者自己写成直接
     * 来源），不算远程。该模组若用没有弹体的瞬发结算（direct 为空、伤害类型落在自己
     * 命名空间）同样视为远程攻击。识别结果按「枪械」接入舞蹈：首次命中起跳并免疫该击，
     * 之后每次命中沿用 {@code BossTauntLogic.RETRIGGER_CHANCE} 的复触发概率——与 TaCZ
     * 走的是同一个开关和同一套概率，不做任何特殊分支。</p>
     */
    public static boolean isCaerulaRangedDamage(DamageSource source) {
        if (source == null) return false;
        Entity direct = source.getDirectEntity();
        if (direct != null) {
            if (direct instanceof net.minecraft.world.entity.LivingEntity) return false;
            return isCaerulaType(EntityType.getKey(direct.getType()));
        }
        // 无直接载体的瞬发结算：只有伤害类型注册在该模组命名空间下才算它的远程手段。
        return source.typeHolder().unwrapKey()
                .map(key -> isCaerulaType(key.location()))
                .orElse(false);
    }

    /** 注册键是否落在深蓝之树命名空间（含该模组的附属前缀）。 */
    private static boolean isCaerulaType(ResourceLocation location) {
        if (location == null) return false;
        String ns = location.getNamespace().toLowerCase(Locale.ROOT);
        return ns.equals(CAERULA_NAMESPACE) || ns.startsWith(CAERULA_NAMESPACE + "_")
                || ns.startsWith(CAERULA_NAMESPACE + ".");
    }

    /**
     * 是否上述模组的「弹体类实体」：TaCZ 的子弹、铁魔法系与诡厄巫法的魔法飞弹/法术投射物。
     *
     * <p>这些模组的弹体大多继承 {@code Projectile}（{@code BossTauntLogic#deflectAround} 的
     * 常规查询已覆盖），但个别实现直接继承 {@code Entity} 自管位移（TaCZ 的部分弹型即是），
     * {@code getEntitiesOfClass(Projectile.class, …)} 抓不到。这里退到注册表口径：实体类型键
     * <b>同时</b>命中兼容命名空间与弹体特征路径才算——只按命名空间会把这些模组的生物也弹飞，
     * 必须双重条件。不依赖编译期模组依赖，与伤害侧识别同一套规则来源。</p>
     */
    public static boolean isCompatProjectile(Entity entity) {
        if (entity == null) return false;
        ResourceLocation type = EntityType.getKey(entity.getType());
        if (type == null) return false;
        String ns = type.getNamespace().toLowerCase(Locale.ROOT);
        // 深蓝之树要求「跳舞时反弹其所有远程攻击」：该命名空间下凡是「非生物、非掉落物」
        // 的移动实体一律按弹体处理（继承 Projectile 的常规弹体本就由 deflectAround 的
        // 类型查询接走，这里兜住自管位移的弹体/光束类实现）。
        if (isCaerulaType(type)) {
            return !(entity instanceof net.minecraft.world.entity.LivingEntity)
                    && !(entity instanceof net.minecraft.world.entity.item.ItemEntity);
        }
        boolean compatNamespace = false;
        for (String prefix : GUN_NAMESPACES) {
            if (ns.equals(prefix) || ns.startsWith(prefix + "_") || ns.startsWith(prefix + ".")) compatNamespace = true;
        }
        if (!compatNamespace) {
            for (String prefix : MAGIC_NAMESPACES) {
                if (ns.equals(prefix) || ns.startsWith(prefix + "_") || ns.startsWith(prefix + ".")) compatNamespace = true;
            }
        }
        if (!compatNamespace) return false;
        String path = type.getPath().toLowerCase(Locale.ROOT);
        for (String mark : PROJECTILE_PATH_MARKS) {
            if (path.contains(mark)) return true;
        }
        return false;
    }

    private static boolean matches(DamageSource source, String[] namespaces, String[] keywords) {
        if (source == null) return false;
        // 1) 伤害类型注册键
        java.util.Optional<ResourceKey<net.minecraft.world.damagesource.DamageType>> typeKey = source.typeHolder().unwrapKey();
        if (typeKey.isPresent() && matchesLocation(typeKey.get().location(), namespaces, keywords)) {
            return true;
        }
        // 2) 直接实体（弹射物）类型注册键
        Entity direct = source.getDirectEntity();
        if (direct != null) {
            ResourceLocation directType = EntityType.getKey(direct.getType());
            if (directType != null && matchesLocation(directType, namespaces, keywords)) return true;
            // 弹射物的持有者若是这些模组的实体（如施法者/射手本身），不作判据：
            // 判定始终跟着「伤害载体」走，避免友方实体在场时误伤其它近战。
        }
        // 2b) 若直接实体是射出的弹射物，弹射物所属枪械/法杖物品也来不及查（无物品栏暴露），
        //     维持注册名判定已足够覆盖 TaCZ：其弹道结算直接以 tacz 命名空间的伤害类型落地。
        // 3) 兜底：getMsgId()（格式 namespace.path），覆盖裸构造 DamageSource 的少数实现。
        String msgId = source.getMsgId();
        if (msgId != null) {
            String lower = msgId.toLowerCase(Locale.ROOT).replace('.', ':');
            if (locationHit(lower, namespaces, keywords)) return true;
        }
        return false;
    }

    private static boolean matchesLocation(ResourceLocation location, String[] namespaces, String[] keywords) {
        return locationHit(location.getNamespace() + ":" + location.getPath(), namespaces, keywords);
    }

    private static boolean locationHit(String joined, String[] namespaces, String[] keywords) {
        String lower = joined.toLowerCase(Locale.ROOT);
        int colon = lower.indexOf(':');
        String namespace = colon < 0 ? lower : lower.substring(0, colon);
        String path = colon < 0 ? "" : lower.substring(colon + 1);
        for (String prefix : namespaces) {
            if (namespace.equals(prefix) || namespace.startsWith(prefix + "_") || namespace.startsWith(prefix + ".")) {
                return true;
            }
        }
        for (String keyword : keywords) {
            if (path.contains(keyword)) return true;
        }
        return false;
    }
}
