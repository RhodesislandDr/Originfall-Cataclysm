package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.network.protocol.Packet;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

/**
 * 月牙形剑气：作为近战武器的延伸投出，命中后继承持械者近战武器的原有性质。
 * 黑色剑气（「女祭司」普瑞赛斯 / 特蕾西娅 / 「预言家」博士）为半透明能量；
 * 白色剑气（学到远程攻击且使用近战武器的其他生物）为实体化的白色月牙。
 * 仅作为远程攻击手段使用，不注册刷怪蛋，因此不会出现在创造栏。
 */
public final class SwordQiEntity extends Projectile {
    private static final EntityDataAccessor<Boolean> BLACK =
            SynchedEntityData.defineId(SwordQiEntity.class, EntityDataSerializers.BOOLEAN);
    private static final int MAX_LIFETIME = 80;
    private static final double SPEED = 1.8D;

    public SwordQiEntity(EntityType<? extends SwordQiEntity> type, Level level) {
        super(type, level);
        this.noCulling = true;
    }

    /** 由 EntityType 工厂之外的生产入口使用；构造后需调用 shoot 赋予速度。 */
    public SwordQiEntity(Level level, LivingEntity shooter, boolean black) {
        this(GeneratedMod.SWORD_QI.get(), level);
        setOwner(shooter);
        entityData.set(BLACK, black);
    }

    public boolean isBlack() {
        return entityData.get(BLACK);
    }

    public boolean isWhite() {
        return !entityData.get(BLACK);
    }

    /** 从持械者眼位朝目标投出剑气，黑色/白色由调用方指定。 */
    public static SwordQiEntity shoot(Level level, LivingEntity shooter, LivingEntity target, boolean black) {
        SwordQiEntity qi = new SwordQiEntity(level, shooter, black);
        Vec3 start = shooter.getEyePosition();
        Vec3 aim = target.position().add(0.0D, target.getBbHeight() * 0.5D, 0.0D);
        double dx = aim.x - start.x;
        double dy = aim.y - start.y;
        double dz = aim.z - start.z;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0e-4) len = 1.0e-4;
        qi.shoot(dx, dy, dz, (float) SPEED, 0.0F);
        qi.setPos(start.x, start.y, start.z);
        level.addFreshEntity(qi);
        return qi;
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(BLACK, false);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (getOwner() == null || !getOwner().isAlive() || tickCount > MAX_LIFETIME) {
            discard();
            return;
        }
        Vec3 before = position();
        HitResult result = ProjectileUtil.getHitResultOnMoveVector(this, this::canHitEntity);
        if (result.getType() != HitResult.Type.MISS) {
            onHit(result);
            return;
        }
        move(MoverType.SELF, getDeltaMovement());
        if (horizontalCollision || verticalCollision || before.distanceToSqr(position()) < 1.0e-6) {
            discard();
            return;
        }
        if (tickCount > 5) alignToMotion();
    }

    private void alignToMotion() {
        Vec3 motion = getDeltaMovement();
        double horiz = Math.sqrt(motion.x * motion.x + motion.z * motion.z);
        setYRot((float) (Mth.atan2(motion.z, motion.x) * 180.0D / Math.PI) - 90.0F);
        setXRot((float) (-Mth.atan2(motion.y, horiz) * 180.0D / Math.PI));
    }

    @Override
    protected boolean canHitEntity(Entity target) {
        if (target == null || target == getOwner() || target instanceof SwordQiEntity) return false;
        Entity owner = getOwner();
        if (owner instanceof LivingEntity holder && target instanceof LivingEntity living) {
            if (CalamityLogic.isFactionAlly(holder, living)) return false;
        }
        if (target instanceof Player player && (player.isCreative() || player.isSpectator())) return false;
        return target instanceof LivingEntity living && living.isAlive();
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        LivingEntity target = result.getEntity() instanceof LivingEntity living ? living : null;
        Entity ownerEntity = getOwner();
        if (target == null || !(ownerEntity instanceof LivingEntity shooter)) {
            discard();
            return;
        }
        if (shooter instanceof Theresia) {
            // 特蕾西娅的影霄走自身权能结算链，由 applyAttack 统一处理两段伤害与溅射。
            YingsiaoSwordItem.applyAttack(shooter, target, false, 0);
        } else {
            // 其余持械者（含「预言家」博士 / 「女祭司」普瑞赛斯）走 mobProjectile 伤害来源，
            // 由自定义剑逻辑依据“是否为近战武器延伸”继承其原有性质。
            DamageSource source = level().damageSources().mobProjectile(this, shooter);
            float damage = meleeExtensionDamage(shooter);
            target.hurt(source, damage);
            // 剑气是近战武器的延伸：命中也要给出史诗战斗的受击反馈（未装史诗战斗时空操作）。
            SkillCombatHooks.impact(target, damage, SkillCombatHooks.Impact.LIGHT);
        }
        discard();
    }

    @Override
    protected void onHitBlock(net.minecraft.world.phys.BlockHitResult result) {
        discard();
    }

    /** 近战武器延伸伤害：以持械者的近战攻击力为基准。 */
    private static float meleeExtensionDamage(LivingEntity shooter) {
        double attack = shooter.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE)
                ? shooter.getAttributeValue(Attributes.ATTACK_DAMAGE) : 1.0D;
        return Math.max(1.0F, (float) attack);
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public Packet getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
