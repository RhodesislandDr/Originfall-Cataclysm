package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/** 可由主人右键切换的跟随目标；不依赖原版 FollowOwnerGoal 的导航类型限制。 */
public final class CalamityFollowOwnerGoal extends Goal {
    private static final int TELEPORT_WHEN_DISTANCE_IS = 12;
    private static final int MIN_HORIZONTAL_DISTANCE_FROM_OWNER = 2;
    private static final int MAX_HORIZONTAL_DISTANCE_FROM_OWNER = 3;
    private static final int MIN_VERTICAL_DISTANCE_FROM_OWNER = -1;
    private static final int MAX_VERTICAL_DISTANCE_FROM_OWNER = 1;

    private final CalamityMob calamity;
    private final double speed;
    private final float startDistance;
    private final float stopDistance;
    private final boolean canTeleportAcrossDimensions;
    private LivingEntity owner;
    private int timeToRecalcPath;

    public CalamityFollowOwnerGoal(CalamityMob calamity, double speed, float startDistance,
                                   float stopDistance, boolean canTeleportAcrossDimensions) {
        this.calamity = calamity;
        this.speed = speed;
        this.startDistance = startDistance;
        this.stopDistance = stopDistance;
        this.canTeleportAcrossDimensions = canTeleportAcrossDimensions;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        owner = calamity.getOwner();
        return shouldFollow() && owner != null && owner.isAlive()
                && owner.level() == calamity.level()
                && calamity.distanceToSqr(owner) > startDistance * startDistance;
    }

    @Override
    public boolean canContinueToUse() {
        return shouldFollow() && owner != null && owner.isAlive()
                && (canTeleportAcrossDimensions || owner.level() == calamity.level())
                && calamity.distanceToSqr(owner) > stopDistance * stopDistance;
    }

    @Override
    public void start() {
        timeToRecalcPath = 0;
    }

    @Override
    public void stop() {
        owner = null;
        calamity.getNavigation().stop();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        if (owner == null || !owner.isAlive()) return;
        calamity.getLookControl().setLookAt(owner, 10.0F, calamity.getMaxHeadXRot());
        if (--timeToRecalcPath <= 0) {
            timeToRecalcPath = 10;
            if (!calamity.getNavigation().moveTo(owner, speed)
                    && calamity.distanceToSqr(owner) >= TELEPORT_WHEN_DISTANCE_IS * TELEPORT_WHEN_DISTANCE_IS) {
                teleportNearOwner();
            }
        }
    }

    private boolean shouldFollow() {
        return calamity.isFollowingOwner() && !calamity.isOrderedToSit()
                && calamity.getTarget() == null;
    }

    private void teleportNearOwner() {
        for (int dx = MIN_HORIZONTAL_DISTANCE_FROM_OWNER; dx <= MAX_HORIZONTAL_DISTANCE_FROM_OWNER; dx++) {
            for (int dz = MIN_HORIZONTAL_DISTANCE_FROM_OWNER; dz <= MAX_HORIZONTAL_DISTANCE_FROM_OWNER; dz++) {
                for (int signX : new int[] {-1, 1}) {
                    for (int signZ : new int[] {-1, 1}) {
                        BlockPos pos = owner.blockPosition().offset(dx * signX, 0, dz * signZ);
                        for (int dy = MIN_VERTICAL_DISTANCE_FROM_OWNER; dy <= MAX_VERTICAL_DISTANCE_FROM_OWNER; dy++) {
                            BlockPos candidate = pos.above(dy);
                            if (canTeleportTo(candidate)) {
                                calamity.moveTo(candidate.getX() + 0.5D, candidate.getY(), candidate.getZ() + 0.5D,
                                        calamity.getYRot(), calamity.getXRot());
                                calamity.getNavigation().stop();
                                return;
                            }
                        }
                    }
                }
            }
        }
    }

    private boolean canTeleportTo(BlockPos pos) {
        return calamity.level().noCollision(calamity, calamity.getBoundingBox().move(
                        pos.getX() + 0.5D - calamity.getX(), pos.getY() - calamity.getY(),
                        pos.getZ() + 0.5D - calamity.getZ()))
                && !calamity.level().getBlockState(pos.below()).isAir()
                && !calamity.level().getBlockState(pos).isSuffocating(calamity.level(), pos);
    }
}
