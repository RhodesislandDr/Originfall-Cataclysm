package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.SmoothSwimmingMoveControl;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.navigation.AmphibiousPathNavigation;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.WallClimberNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;

import java.util.UUID;

public abstract class CalamityMob extends TamableAnimal {
    public static final EntityDataAccessor<String> LEARNED_TRAITS_DATA =
            SynchedEntityData.defineId(CalamityMob.class, EntityDataSerializers.STRING);
    public static final EntityDataAccessor<Integer> LEARNED_LIMIT_DATA =
            SynchedEntityData.defineId(CalamityMob.class, EntityDataSerializers.INT);
    /** 独立形态的恶意等级同步值：服务端定级时写入，客户端名牌外显只读；
     *  装有莱特兰-恶意时本键闲置，等级与词条外显由恶意模组自身完成。 */
    public static final EntityDataAccessor<Integer> MALICE_LEVEL_DATA =
            SynchedEntityData.defineId(CalamityMob.class, EntityDataSerializers.INT);
    /**
     * 格挡（防御姿态）剩余 tick 数：由史诗战斗兼容层在检测到目标近战命中后写入，
     * 服务端与客户端共用同一份同步数据，客户端补丁据此切换史诗战斗的格挡动作。
     * 未安装史诗战斗时恒为 0，不影响模组自身逻辑。
     */
    public static final EntityDataAccessor<Integer> GUARD_TICKS =
            SynchedEntityData.defineId(CalamityMob.class, EntityDataSerializers.INT);
    /**
     * 「扒臀舞」剩余 tick：服务端写入并递减，客户端人形模型据此播放视频动作姿势
     * （背对伤害施加者、俯身、双手扒臀、左右扭动）。仅「女祭司」普瑞赛斯与「预言家」博士会被写入。
     */
    public static final EntityDataAccessor<Integer> TAUNT_TICKS =
            SynchedEntityData.defineId(CalamityMob.class, EntityDataSerializers.INT);
    /** 开跳时写入的舞蹈总 tick：客户端据此划分「回头→俯身→扭动→起身」各阶段。 */
    public static final EntityDataAccessor<Integer> TAUNT_TOTAL_TICKS =
            SynchedEntityData.defineId(CalamityMob.class, EntityDataSerializers.INT);
    private static final String REVIVAL_COUNT = "RevivalCount";
    private static final String COMBAT_READY = "CombatReady";
    private static final String SPAWN_EGG_SUMMONED = "SpawnEggSummoned";
    private static final String BASE_SHIELD = "CalamityBaseShield";
    private static final String CURRENT_SHIELD = "CalamityCurrentShield";
    private static final String PREVIOUS_MAX_HEALTH = "CalamityPreviousMaxHealth";
    private static final String PREVIOUS_TOTAL_SHIELD = "CalamityPreviousTotalShield";
    private static final String PREVIOUS_ATTACK_DAMAGE = "CalamityPreviousAttackDamage";
    private static final String FOLLOWING_OWNER = "FollowingOwner";
    /** 「扒臀舞」首次被枪械/魔法命中的触发是否已完成：跨存档持久，之后只剩枪械概率复触发。 */
    private static final String WEAPON_TAUNT_FIRST_DONE = "WeaponTauntFirstDone";
    /** 复活被阻断的“彻底击败”标记：影霄斩杀或内化宇宙/延迟原效果的不可复活死亡时记录。 */
    public static final String THOROUGH_DEFEAT_TAG = "OriginFallThoroughDefeat";
    /** “献祭”标记：被巴别塔回忆这类技能当作祭品抹除的生物，死亡时不再触发自身的死亡衍生链。 */
    public static final String SACRIFICED_TAG = "OriginFallSacrificed";

    private int revivalCount;
    private boolean combatReady;
    private boolean spawnEggSummoned;
    private boolean followingOwner = true;
    private int abilityCooldown;
    private int attackMeteorCooldown;
    private double baseShield;
    private double currentShield;
    private double previousMaxHealth;
    private double previousTotalShield;
    private double previousAttackDamage;
    private int naturalAbilityTicks;
    private boolean learnedFlightNavigation;
    private boolean learnedWallNavigation;
    private boolean weaponTauntFirstDone;
    /** 本次舞蹈背对并相向移动的伤害施加者（枪械/魔法攻击者）；仅服务端使用，不写存档。 */
    private UUID tauntTargetId;

    protected CalamityMob(EntityType<? extends CalamityMob> type, Level level) {
        super(type, level);
        moveControl = new AquaticMoveControl(this);
        setTame(true);
        setPersistenceRequired();
        combatReady = true;
        baseShield = 0.0D;
        currentShield = 0.0D;
        previousMaxHealth = 0.0D;
        previousTotalShield = baseShield;
        previousAttackDamage = 2.0D;
        setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
    }

    protected abstract double followRange();
    protected abstract boolean canTeleportAcrossDimensions();
    protected boolean shouldFollowOwner() { return true; }
    protected abstract void serverAbilityTick(ServerLevel level);

    /** 自然生成的首领使用独立计时器；刷怪蛋或认主实体不走该路径。 */
    protected void serverNaturalAbilityTick(ServerLevel level) {
    }

    protected void onCalamityDeath(ServerLevel level, LivingEntity killer, CompoundTag snapshot) {
    }

    public static AttributeSupplier.Builder createAttributes(double health, double armor) {
        return createAttributes(health, armor, 64.0D);
    }

    protected static AttributeSupplier.Builder createAttributes(double health, double armor, double followRange) {
        return TamableAnimal.createMobAttributes()
                .add(Attributes.MAX_HEALTH, health)
                .add(Attributes.ARMOR, armor)
                .add(Attributes.ARMOR_TOUGHNESS, armor * 0.25D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                // 所有 CalamityMob 都可能在运行中学习 flight，提前注册供 FlyingMoveControl 使用。
                .add(Attributes.FLYING_SPEED, 0.6D)
                .add(Attributes.FOLLOW_RANGE, followRange)
                .add(Attributes.ATTACK_DAMAGE, 2.0D);
    }

    protected final void setBaseShield(double value) {
        baseShield = Math.max(0.0D, value);
        previousTotalShield = getTotalShield();
        resetShield();
    }

    public final double getBaseShield() {
        return baseShield;
    }

    public final double getTotalShield() {
        return Math.max(0.0D, baseShield + getArmorValue());
    }

    protected final void resetShield() {
        currentShield = getTotalShield();
    }

    public final CompoundTag createRevivalSnapshot() {
        CompoundTag snapshot = new CompoundTag();
        save(snapshot);
        snapshot.putDouble(PREVIOUS_MAX_HEALTH, getMaxHealth());
        snapshot.putDouble(PREVIOUS_TOTAL_SHIELD, getTotalShield());
        snapshot.putDouble(PREVIOUS_ATTACK_DAMAGE, getAttributeValue(Attributes.ATTACK_DAMAGE));
        snapshot.putDouble(BASE_SHIELD, baseShield);
        TiantangzhidianLogic.writeRevivalNoRevive(this, snapshot);
        return snapshot;
    }

    public final void loadRevivalStats(CompoundTag snapshot) {
        previousMaxHealth = snapshot.contains(PREVIOUS_MAX_HEALTH)
                ? snapshot.getDouble(PREVIOUS_MAX_HEALTH) : getMaxHealth();
        previousTotalShield = snapshot.contains(PREVIOUS_TOTAL_SHIELD)
                ? snapshot.getDouble(PREVIOUS_TOTAL_SHIELD) : getTotalShield();
        previousAttackDamage = snapshot.contains(PREVIOUS_ATTACK_DAMAGE)
                ? snapshot.getDouble(PREVIOUS_ATTACK_DAMAGE) : getAttributeValue(Attributes.ATTACK_DAMAGE);
        baseShield = snapshot.contains(BASE_SHIELD) ? snapshot.getDouble(BASE_SHIELD) : previousTotalShield;
    }

    /**
     * 初次转化只复制原生生物当前数据，不套用死亡复活倍率。
     * 这些数值随后仅作为该转化实体第一次死亡时的死亡快照基准。
     */
    public final void initializeConvertedStats(double health, double currentHealth, double shield, double attackDamage) {
        double initialHealth = Math.max(0.0D, health);
        double initialShield = Math.max(0.0D, shield);
        double initialAttack = Math.max(0.0D, attackDamage);
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(initialHealth);
        getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(initialAttack);
        baseShield = Math.max(0.0D, initialShield - getArmorValue());
        previousMaxHealth = initialHealth;
        previousTotalShield = initialShield;
        previousAttackDamage = initialAttack;
        setHealth((float) Math.min(initialHealth, Math.max(1.0D, currentHealth)));
        resetShield();
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        AmphibiousPathNavigation navigation = new AmphibiousPathNavigation(this, level);
        navigation.setCanFloat(true);
        return navigation;
    }

    @Override
    public boolean canBreatheUnderwater() {
        return true;
    }

    @Override
    public boolean onClimbable() {
        return LearnedTraitLogic.has(this, LearnedTraitLogic.WALL_CLIMB) || super.onClimbable();
    }

    /** 学会 flight 后使用飞行移动，落地不应产生原版摔落伤害。 */
    @Override
    public boolean causeFallDamage(float fallDistance, float damageMultiplier, DamageSource source) {
        if (LearnedTraitLogic.has(this, LearnedTraitLogic.FLIGHT)) return false;
        return super.causeFallDamage(fallDistance, damageMultiplier, source);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(LEARNED_TRAITS_DATA, "");
        entityData.define(LEARNED_LIMIT_DATA, 0);
        entityData.define(MALICE_LEVEL_DATA, 0);
        entityData.define(GUARD_TICKS, 0);
        entityData.define(TAUNT_TICKS, 0);
        entityData.define(TAUNT_TOTAL_TICKS, 0);
    }

    /** 格挡姿态剩余 tick（服务端写入、客户端同步读取，用于切换史诗战斗格挡动作）。 */
    public int getGuardTicks() {
        return entityData.get(GUARD_TICKS);
    }

    public void setGuardTicks(int ticks) {
        int clamped = Math.max(0, ticks);
        if (getGuardTicks() != clamped) entityData.set(GUARD_TICKS, clamped);
    }

    public boolean isGuarding() {
        return getGuardTicks() > 0;
    }

    /** 「扒臀舞」剩余 tick（服务端递减，客户端姿势据此播放）。 */
    public int getTauntTicks() {
        return entityData.get(TAUNT_TICKS);
    }

    public void setTauntTicks(int ticks) {
        int clamped = Math.max(0, ticks);
        if (getTauntTicks() != clamped) entityData.set(TAUNT_TICKS, clamped);
    }

    /** 本次舞蹈的总 tick，开跳时一次性写入。 */
    public int getTauntTotalTicks() {
        return entityData.get(TAUNT_TOTAL_TICKS);
    }

    public void setTauntTotalTicks(int ticks) {
        int clamped = Math.max(0, ticks);
        if (getTauntTotalTicks() != clamped) entityData.set(TAUNT_TOTAL_TICKS, clamped);
    }

    /** 枪械/魔法首触（免疫该击并起舞）是否已完成；完成后仅按概率复触发。 */
    public boolean isWeaponTauntFirstDone() {
        return weaponTauntFirstDone;
    }

    public void setWeaponTauntFirstDone(boolean done) {
        this.weaponTauntFirstDone = done;
    }

    /** 舞蹈期间背对并相向移动的伤害施加者 ID；未设置或目标已失效时为 null。 */
    public UUID getTauntTargetId() {
        return tauntTargetId;
    }

    public void setTauntTargetId(UUID targetId) {
        this.tauntTargetId = targetId;
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (key == LEARNED_TRAITS_DATA || key == LEARNED_LIMIT_DATA) {
            LearnedTraitLogic.applyImmediateTraitState(this, entityData.get(LEARNED_TRAITS_DATA));
        }
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new AquaticSurfaceGoal(this));
        if (shouldFollowOwner()) {
            goalSelector.addGoal(2, new CalamityFollowOwnerGoal(this, 1.15D, 10.0F, 2.0F, canTeleportAcrossDimensions()));
        }
        goalSelector.addGoal(3, new AdaptiveCombatGoal(this, 1.15D));
        goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 12.0F));
        goalSelector.addGoal(9, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 10,
                true, false, this::canAttack));
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (abilityCooldown > 0) abilityCooldown--;
        if (attackMeteorCooldown > 0) attackMeteorCooldown--;
        // 格挡姿态倒计时：服务端递减，经同步数据驱动客户端的史诗战斗格挡动作。
        if (getGuardTicks() > 0) setGuardTicks(getGuardTicks() - 1);
        // 「扒臀舞」倒计时：服务端递减，客户端人形模型据此驱动视频动作姿势。
        if (getTauntTicks() > 0) {
            setTauntTicks(getTauntTicks() - 1);
            if (getTauntTicks() == 0) {
                setTauntTotalTicks(0);
                // 一曲终了即忘掉这一击的施加者，免得下次复触发时追着上个凶手跑。
                setTauntTargetId(null);
            }
        }
        if (previousMaxHealth <= 0.0D) {
            previousMaxHealth = getMaxHealth();
            previousTotalShield = getTotalShield();
            previousAttackDamage = getAttributeValue(Attributes.ATTACK_DAMAGE);
            currentShield = getTotalShield();
        }
        ServerLevel server = (ServerLevel) level();
        LearnedTraitLogic.tick(this);
        updateLearnedNavigation();
        if (!AssimilationEquipment.isAssigned(this)) {
            AssimilationEquipment.assign(this);
        }
        // 绑定武器保护：若主手被任何形式（例如绕过 setItemSlot 的直接槽位修改、
        // 读取到被篡改的存档槽位）替换或清空，服务端 tick 内立即恢复为绑定武器。
        Item boundWeapon = getBoundWeapon();
        if (boundWeapon != null && !getMainHandItem().is(boundWeapon)) {
            setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(boundWeapon));
        }
        if (shouldFollowOwner()) {
            LivingEntity owner = getOwner();
            if (owner != null && canTeleportAcrossDimensions() && owner.level() != level()
                    && owner instanceof net.minecraft.server.level.ServerPlayer player) {
                changeDimension((ServerLevel) player.level());
                return;
            }
        }
        if (getTarget() != null && !canAttack(getTarget())) setTarget(null);
        if (YingsiaoSwordItem.hasYingsiaoAccess(this)
                && getPersistentData().getBoolean(YingsiaoSwordItem.SURVIVAL_TAG)
                && getPersistentData().getLong(YingsiaoSwordItem.SURVIVAL_UNTIL) <= level().getGameTime()) {
            setHealth(0.0F);
            // 这里只借「无因果来源」的普通死亡结算：不能走 generic_kill，否则会被当作 /kill 类
            // 强制清理而跳过自身的死亡陨石/复活衍生链（见 CalamityLogic#isKillCommandDeath）。
            die(level().damageSources().generic());
            getPersistentData().remove(YingsiaoSwordItem.SURVIVAL_TAG);
            getPersistentData().remove(YingsiaoSwordItem.SURVIVAL_UNTIL);
            getPersistentData().remove(YingsiaoSwordItem.EMPOWERED_UNTIL);
            return;
        }
        if (!isOrderedToSit() && getOwnerUUID() != null
                && getOwner() instanceof Player owner && CalamityLogic.isCalamityModePlayer(owner)) {
            serverAbilityTick(server);
        }
        if (!isSpawnEggSummoned() && getOwnerUUID() == null) {
            serverNaturalAbilityTick(server);
        }
    }

    public LivingEntity getOwner() {
        UUID owner = getOwnerUUID();
        if (owner == null || !(level() instanceof ServerLevel server)) return null;
        return server.getServer().getPlayerList().getPlayer(owner);
    }

    /**
     * 主动技能通用就绪判定：冷却结束且<b>未被沉默</b>。锚定现实的“打断现有技能（沉默）”
     * 期间一切主动技能（锁定陨石、陨石杖齐射等经由本入口的能力）无法发动；
     * 普攻、索敌与被动成长不受沉默影响。
     */
    public boolean isAbilityReady() { return abilityCooldown <= 0 && !RuwosuojianLogic.isSilenced(this); }
    public void setAbilityCooldown(int ticks) { abilityCooldown = ticks; }
    public boolean isCombatReady() { return combatReady; }
    public int getRevivalCount() { return revivalCount; }
    public boolean isSpawnEggSummoned() { return spawnEggSummoned; }
    public void setSpawnEggSummoned(boolean value) { spawnEggSummoned = value; }
    public boolean isFollowingOwner() { return followingOwner; }
    public void setFollowingOwner(boolean value) { followingOwner = value; }
    public void setOrderedToSit(boolean value) {
        super.setOrderedToSit(value);
        if (value) {
            followingOwner = false;
            setTarget(null);
            getNavigation().stop();
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (hand != InteractionHand.MAIN_HAND) return super.mobInteract(player, hand);
        // 文明延续玩家空手右键初生魔王的所有动作均失效。
        if (this instanceof YoungDemonLord
                && CalamityLogic.isCivilizationContinuancePlayer(player) && stack.isEmpty()) {
            return InteractionResult.FAIL;
        }
        // 转化敌对生物不接受认主操作；原生两种天灾生物仍保留空手右键认主。
        if (this instanceof EndWalker) return InteractionResult.PASS;
        if (!stack.isEmpty()) return super.mobInteract(player, hand);
        if (level().isClientSide) return InteractionResult.sidedSuccess(true);
        if (isOwnedBy(player)) {
            if (player.isShiftKeyDown()) {
                setOrderedToSit(!isOrderedToSit());
                setFollowingOwner(false);
                return InteractionResult.CONSUME;
            }
            setOrderedToSit(false);
            setFollowingOwner(!isFollowingOwner());
            return InteractionResult.CONSUME;
        }
        if (getOwnerUUID() == null) {
            tame(player);
            setFollowingOwner(true);
            return InteractionResult.CONSUME;
        }
        return InteractionResult.PASS;
    }

    public boolean reviveWithScaling() {
        return reviveWithScaling(1.0D, 1.0D, 1.0D);
    }

    public boolean reviveWithScaling(double healthScale, double shieldScale, double attackScale) {
        // 「源石计划进度」需求 5：死后复活倍率中，原数值之外的提升部分（高于 1 的倍率）
        // 按档位幅度缩放；低于 1 的弱化复活倍率（波次击杀数不足时的降格复活）原样保留。
        healthScale = OriginiumPlanProgress.boostedUp(healthScale, this);
        shieldScale = OriginiumPlanProgress.boostedUp(shieldScale, this);
        attackScale = OriginiumPlanProgress.boostedUp(attackScale, this);
        double health = previousMaxHealth * healthScale;
        if (previousMaxHealth <= 0.0D || health <= 0.0D) return false;
        double shield = Math.max(0.0D, previousTotalShield * shieldScale);
        double attack = Math.max(0.0D, previousAttackDamage * attackScale);
        revivalCount++;
        getPersistentData().remove(CalamityLogic.REVIVAL_SCHEDULED_TAG);
        combatReady = true;
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(health);
        getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(attack);
        // 每次复活都重新生成一次随机附魔武器和随机部位护甲；护甲仍然实际装备，只隐藏外观。
        clearEquipment();
        randomizeEquipment();
        setOrderedToSit(false);
        baseShield = Math.max(0.0D, shield - getArmorValue());
        currentShield = shield;
        setHealth((float) health);
        return true;
    }

    protected final void clearEquipment() {
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (slot == EquipmentSlot.MAINHAND || slot == EquipmentSlot.OFFHAND || slot.isArmor()) {
                setItemSlot(slot, ItemStack.EMPTY);
            }
        }
    }

    protected final void randomizeEquipment() {
        AssimilationEquipment.assign(this);
    }

    /**
     * 本生物绑定在主手的专属武器；默认返回 null 表示不绑定（可正常更换装备）。
     * 「预言家」博士、「女祭司」普瑞赛斯、特蕾西娅重写此方法返回各自的专属武器，
     * 使主手武器无法以任何形式被替换。
     */
    protected Item getBoundWeapon() {
        return null;
    }

    /**
     * 阻止绑定武器被以任何形式替换（/replaceitem 命令、其他模组的装备写入、
     * setItemInHand、拾取战利品后的穿戴等全部经由本方法）。
     * 仅当目标槽位为主手且本生物绑定武器时生效：
     * 只允许写入绑定武器本身，其余一律拒绝，从而始终保持主手为该武器。
     * 未绑定武器的其余天灾生物行为不受影响。
     */
    @Override
    public void setItemSlot(EquipmentSlot slot, ItemStack stack) {
        if (slot == EquipmentSlot.MAINHAND) {
            Item bound = getBoundWeapon();
            if (bound != null && !stack.is(bound)) {
                // 拒绝替换绑定武器：维持当前主手武器不变。
                return;
            }
        }
        super.setItemSlot(slot, stack);
    }

    public void maybeCallMeteorOnAttack(LivingEntity target) {
        if (!CalamityLogic.canSummonNaturalMeteorFrom(this)) return;
        if (attackMeteorCooldown <= 0 && random.nextFloat() < 0.0325F && level() instanceof ServerLevel server) {
            server.addFreshEntity(MeteorEntity.createTargetedNatural(server, target, 1));
            attackMeteorCooldown = 20;
        }
    }

    /**
     * 学习到 flight 或 wall_climb 后替换寻路器，并同步移动控制与重力状态。
     * 「预言家」博士、「女祭司」普瑞赛斯与转化生物/特蕾西娅一样继承这里，
     * 因此学到 flight 时会自动注册飞行速度属性（Attributes.FLYING_SPEED，已在
     * createAttributes 预注册为 0.6）并切换到 FlyingPathNavigation/FlyingMoveControl。
     */
    private void updateLearnedNavigation() {
        boolean flight = LearnedTraitLogic.has(this, LearnedTraitLogic.FLIGHT);
        boolean wallClimb = LearnedTraitLogic.has(this, LearnedTraitLogic.WALL_CLIMB);
        if (flight && !learnedFlightNavigation) {
            // AttributeSupplier 已预注册该属性；首次学习 flight 时立即创建实体属性实例。
            getAttribute(Attributes.FLYING_SPEED);
            FlyingPathNavigation navigation = new FlyingPathNavigation(this, level());
            navigation.setCanOpenDoors(false);
            navigation.setCanPassDoors(false);
            navigation.setMaxVisitedNodesMultiplier(2.0F);
            this.navigation = navigation;
            moveControl = new FlyingMoveControl(this, 20, true);
            setNoGravity(true);
            learnedFlightNavigation = true;
            learnedWallNavigation = false;
        } else if (!flight && wallClimb && !learnedWallNavigation) {
            this.navigation = new WallClimberNavigation(this, level());
            moveControl = new MoveControl(this);
            setNoGravity(false);
            learnedWallNavigation = true;
            learnedFlightNavigation = false;
        } else if (!flight && !wallClimb && (learnedFlightNavigation || learnedWallNavigation)) {
            this.navigation = createNavigation(level());
            moveControl = new AquaticMoveControl(this);
            setNoGravity(false);
            learnedFlightNavigation = false;
            learnedWallNavigation = false;
        }
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        return combatReady && !isOrderedToSit()
                && CalamityLogic.canFactionCombatantAttack(this, target);
    }

    @Override
    public boolean isAlliedTo(net.minecraft.world.entity.Entity other) {
        return other instanceof LivingEntity living && CalamityLogic.isFactionAlly(this, living)
                || super.isAlliedTo(other);
    }

    @Override
    public boolean doHurtTarget(net.minecraft.world.entity.Entity target) {
        if (target instanceof LivingEntity living && !canAttack(living)) return false;
        boolean hurt = super.doHurtTarget(target);
        if (hurt && target instanceof LivingEntity living) maybeCallMeteorOnAttack(living);
        return hurt;
    }

    /**
     * 本模组生物（包括转化后实体）完全免疫所有爆炸伤害。
     * 两个例外：特蕾西娅按剧情定位可被爆炸影响；哈基玖是深蓝之树联动彩蛋生物，
     * 血量与防御一律按本尊白板设定结算，不享受首领级爆炸免疫。
     */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.IS_EXPLOSION)
                && !(this instanceof Theresia) && !(this instanceof Apocata)) {
            return false;
        }
        return super.hurt(source, amount);
    }

    @Override
    protected void actuallyHurt(DamageSource source, float damage) {
        float remaining = damage;
        if (currentShield > 0.0D) {
            double absorbed = Math.min(currentShield, remaining);
            currentShield -= absorbed;
            remaining -= (float) absorbed;
        }
        if (remaining > 0.0F) super.actuallyHurt(source, remaining);
    }

    @Override
    public void die(DamageSource source) {
        if (!level().isClientSide && level() instanceof ServerLevel server) {
            LivingEntity killer = source.getEntity() instanceof LivingEntity living ? living
                    : source.getDirectEntity() instanceof net.minecraft.world.entity.projectile.Projectile projectile
                    && projectile.getOwner() instanceof LivingEntity owner ? owner : null;
            // 学习特性不进入死亡快照；复活后的实体从空白能力重新开始。
            LearnedTraitLogic.clearOnDeath(this);
            // 祭品（如被巴别塔回忆献祭的天灾的王女）只是被抹除以完成仪式：不写“彻底击败”标记，
            // 也不触发自身的死亡陨石/复活衍生链，避免陨石波反噬刚刚复活的博士。
            boolean sacrificed = getPersistentData().getBoolean(SACRIFICED_TAG);
            // 影霄斩杀是明确的终结伤害，不得再进入复活、死亡陨石或其他死亡衍生链；
            // 这也避免玩家攻击触发斩杀时，死亡事件与复活实体重入造成客户端卡死。
            // 内化宇宙期间（含归来后兑现原本效果）死亡同样不可复活。
            boolean thoroughDefeat = YingsiaoSwordItem.hasExecutionMark(this)
                    || TiantangzhidianLogic.isNoRevive(this);
            // /kill 类代码（generic_kill 来源）是命令行/脚本的强制清理：不进入自身的死亡陨石/复活衍生链。
            boolean killCommandDeath = CalamityLogic.isKillCommandDeath(source);
            if (thoroughDefeat && !sacrificed) {
                // 记录一次“彻底击败”：这类死亡不会进入复活波次，供外部掉落逻辑读取。
                getPersistentData().putBoolean(THOROUGH_DEFEAT_TAG, true);
            }
            if (!sacrificed && !killCommandDeath && !YingsiaoSwordItem.hasExecutionMark(this)
                    && !TiantangzhidianLogic.isNoRevive(this)) {
                // 任意普通来源死亡都触发实体自身的死亡陨石规则；复活陨石的衍生陨石不计入原复活波次，
                // 但被它击杀的另一只天灾生物仍按自身类型开启独立复活波次。
                onCalamityDeath(server, killer, createRevivalSnapshot());
            }
        }
        super.die(source);
    }

    /** 「巴别塔回忆」等献祭路径调用：把这只生物标记为祭品，死亡时不再触发自身的死亡衍生链。 */
    public static void markSacrificed(LivingEntity entity) {
        if (entity == null || entity.level().isClientSide) return;
        entity.getPersistentData().putBoolean(SACRIFICED_TAG, true);
    }

    @Override
    public net.minecraft.world.entity.Entity changeDimension(ServerLevel destination) {
        if (!canTeleportAcrossDimensions()) return this;
        return super.changeDimension(destination);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt(REVIVAL_COUNT, revivalCount);
        tag.putBoolean(COMBAT_READY, combatReady);
        tag.putBoolean(SPAWN_EGG_SUMMONED, spawnEggSummoned);
        tag.putBoolean(FOLLOWING_OWNER, followingOwner);
        tag.putDouble(BASE_SHIELD, baseShield);
        tag.putDouble(CURRENT_SHIELD, currentShield);
        tag.putDouble(PREVIOUS_MAX_HEALTH, previousMaxHealth);
        tag.putDouble(PREVIOUS_TOTAL_SHIELD, previousTotalShield);
        tag.putDouble(PREVIOUS_ATTACK_DAMAGE, previousAttackDamage);
        tag.putBoolean(WEAPON_TAUNT_FIRST_DONE, weaponTauntFirstDone);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        revivalCount = tag.getInt(REVIVAL_COUNT);
        combatReady = !tag.contains(COMBAT_READY) || tag.getBoolean(COMBAT_READY) || revivalCount == 0;
        spawnEggSummoned = tag.getBoolean(SPAWN_EGG_SUMMONED);
        followingOwner = !tag.contains(FOLLOWING_OWNER) || tag.getBoolean(FOLLOWING_OWNER);
        // 保留 super.readAdditionalSaveData 读入的装备；盔甲只在客户端渲染器中隐藏，不能清空装备槽。
        baseShield = tag.contains(BASE_SHIELD) ? tag.getDouble(BASE_SHIELD) : 0.0D;
        previousMaxHealth = tag.contains(PREVIOUS_MAX_HEALTH) ? tag.getDouble(PREVIOUS_MAX_HEALTH) : getMaxHealth();
        previousTotalShield = tag.contains(PREVIOUS_TOTAL_SHIELD) ? tag.getDouble(PREVIOUS_TOTAL_SHIELD) : getTotalShield();
        previousAttackDamage = tag.contains(PREVIOUS_ATTACK_DAMAGE) ? tag.getDouble(PREVIOUS_ATTACK_DAMAGE) : getAttributeValue(Attributes.ATTACK_DAMAGE);
        currentShield = tag.contains(CURRENT_SHIELD) ? tag.getDouble(CURRENT_SHIELD) : getTotalShield();
        weaponTauntFirstDone = tag.getBoolean(WEAPON_TAUNT_FIRST_DONE);
    }

    @Override
    public SpawnGroupData finalizeSpawn(net.minecraft.world.level.ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType spawnType, SpawnGroupData groupData, CompoundTag tag) {
        if (spawnType == MobSpawnType.SPAWN_EGG) spawnEggSummoned = true;
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, spawnType, groupData, tag);
        // 首领永远是成年个体：vanilla 的群体生成携带 AgeableMobGroupData，第二只起有 5%
        // 概率直接 setAge(-24000) 变幼年；生成收尾时统一复位，杜绝幼年状态出现。
        setAge(0);
        return result;
    }

    /**
     * 天灾首领不存在幼年形态：年龄被任何来源写成负数都在这里归零。
     *
     * <p>这是修复「装了史诗战斗后身体显示异常」的关键一环。史诗战斗用
     * {@code PCustomHumanoidEntityRenderer}（BIPED 骨架网格）渲染本模组的七个人形首领，
     * 它对 {@code LivingEntity#isBaby()} 为真的实体做两件本模组从未预期的事：
     * {@code LivingEntityPatch#getModelMatrix} 把整个模型矩阵缩到 0.5 倍；
     * {@code setJointTransforms} 又<b>就地</b>往当前动画姿势的 Head 关节变换上再乘一个
     * 1.25 倍缩放——姿势对象在两次动画帧更新之间被逐渲染帧复用，缩放与它连带的位移
     * 反复累乘，头会在几秒内滚成数倍大的巨块并脱离身体浮到半空（实测截图正是如此）。
     * 首领继承 {@code TamableAnimal} 的宠物机制，{@code AgeableMob} 血统让年龄可能被
     * 群体生成（含第三方模组如莱特兰-恶意的群刷）、{@code Age} NBT 等来源写成负值；
     * 从实体侧根上拒绝幼年态，比在渲染端打补丁彻底。</p>
     */
    @Override
    public void setAge(int age) {
        super.setAge(Math.max(0, age));
    }

    /**
     * 首领永远按成年个体判定与渲染（见 {@link #setAge(int)} 的说明）。
     *
     * <p>{@code isBaby()} 是原版与史诗战斗所有幼年化表现的唯一开关：原版模型 {@code young}
     * 标志、史诗战斗的 0.5 倍模型矩阵与 Head 关节 1.25 倍就地缩放都从这里取值。
     * 覆写返回 false 后，即使旧存档里的个体已被写入负年龄，读档后也不会再触发
     * 史诗战斗的幼年渲染管线。</p>
     */
    @Override
    public boolean isBaby() {
        return false;
    }

    @Override
    public net.minecraft.world.entity.AgeableMob getBreedOffspring(ServerLevel level, net.minecraft.world.entity.AgeableMob partner) {
        return null;
    }

    public static AABB area(LivingEntity entity, double radius) {
        return entity.getBoundingBox().inflate(radius);
    }
}
