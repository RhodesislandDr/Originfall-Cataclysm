package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** 一次性强制将目标生物转化为源石天灾生物的道具。 */
public final class SourceOreBeautificationPackItem extends Item {
    public SourceOreBeautificationPackItem() {
        super(new Item.Properties().stacksTo(1).fireResistant());
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player,
                                                   LivingEntity target, InteractionHand hand) {
        if (player.level().isClientSide) return InteractionResult.sidedSuccess(true);
        if (!(target instanceof net.minecraft.world.entity.Mob mob) || target == player) {
            player.displayClientMessage(Component.literal("源石美化包只能作用于生物"), true);
            return InteractionResult.CONSUME;
        }

        LivingEntity converted = CalamityLogic.forceConvertMob(mob);
        if (converted == null) {
            player.displayClientMessage(Component.literal("源石美化包无法转化这个生物"), true);
            return InteractionResult.CONSUME;
        }
        if (!player.getAbilities().instabuild) stack.shrink(1);
        player.displayClientMessage(Component.literal("源石美化包：生物已被强制转化"), true);
        return InteractionResult.sidedSuccess(false);
    }
}
