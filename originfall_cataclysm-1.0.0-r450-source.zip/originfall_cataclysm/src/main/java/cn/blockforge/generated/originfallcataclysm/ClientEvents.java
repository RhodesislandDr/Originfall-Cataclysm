package cn.blockforge.generated.originfallcataclysm;

import cn.blockforge.generated.originfallcataclysm.client.CalamityMessengerRenderer;
import cn.blockforge.generated.originfallcataclysm.client.CalamityRenderer;
import cn.blockforge.generated.originfallcataclysm.client.DomainSphereRenderer;
import cn.blockforge.generated.originfallcataclysm.client.GravityCoreParticle;
import cn.blockforge.generated.originfallcataclysm.client.MeteorModel;
import cn.blockforge.generated.originfallcataclysm.client.MeteorRenderer;
import cn.blockforge.generated.originfallcataclysm.client.PriestessRenderer;
import cn.blockforge.generated.originfallcataclysm.client.ProphetRenderer;
import cn.blockforge.generated.originfallcataclysm.client.SourceOreGolemRenderer;
import cn.blockforge.generated.originfallcataclysm.client.SwordQiRenderer;
import cn.blockforge.generated.originfallcataclysm.client.TheresiaRenderer;
import cn.blockforge.generated.originfallcataclysm.client.UniverseSphereRenderer;
import cn.blockforge.generated.originfallcataclysm.client.WeaponFlameEvents;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientEvents {
    /**
     * 注册哈基玖渲染器时截获的渲染上下文：本模组内唯一一处能稳定拿到
     * {@link EntityRendererProvider.Context} 的时机，供深蓝之树本尊的替身外观
     * 代画渲染器惰性构建（见 {@code NativeApocataAppearanceEvents}）。
     */
    public static EntityRendererProvider.Context apocataRenderContext;

    private ClientEvents() {}

    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> ItemBlockRenderTypes.setRenderLayer(
                GeneratedMod.METEOR_BLOCK.get(), RenderType.translucent()));
    }

    @SubscribeEvent
    public static void registerLayer(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(MeteorRenderer.LAYER, MeteorModel::createBodyLayer);
        registerSourceOreGolemLayers(event);
        registerHumanoidLayers(event, "young_demon_lord");
        registerHumanoidLayers(event, "calamity_princess");
        registerHumanoidLayers(event, "end_walker");
        registerHumanoidLayers(event, "theresia");
        registerHumanoidLayers(event, "priestess");
        registerHumanoidLayers(event, "prophet");
        // 哈基玖：与特蕾西娅同一套玩家型骨架（原版 64×64 皮肤 UV），贴图换成蕾缪安皮肤。
        registerHumanoidLayers(event, "apocata");
        registerMessengerLayer(event);
    }

    private static void registerMessengerLayer(EntityRenderersEvent.RegisterLayerDefinitions event) {
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "calamity_messenger");
        event.registerLayerDefinition(new ModelLayerLocation(id, "main"), CalamityMessengerModel::createBodyLayer);
    }

    private static void registerSourceOreGolemLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "source_ore_golem");
        event.registerLayerDefinition(new ModelLayerLocation(id, "main"), SourceOreGolemModel::createBodyLayer);
        event.registerLayerDefinition(new ModelLayerLocation(id, "inner_armor"), SourceOreGolemModel::createInnerArmorLayer);
        event.registerLayerDefinition(new ModelLayerLocation(id, "outer_armor"), SourceOreGolemModel::createOuterArmorLayer);
    }

    private static void registerHumanoidLayers(EntityRenderersEvent.RegisterLayerDefinitions event, String name) {
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, name);
        event.registerLayerDefinition(new ModelLayerLocation(id, "main"), CalamityHumanoidModel::createBodyLayer);
        event.registerLayerDefinition(new ModelLayerLocation(id, "inner_armor"), CalamityHumanoidModel::createInnerArmorLayer);
        event.registerLayerDefinition(new ModelLayerLocation(id, "outer_armor"), CalamityHumanoidModel::createOuterArmorLayer);
    }

    @SubscribeEvent
    public static void registerRenderer(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(GeneratedMod.METEOR.get(), MeteorRenderer::new);
        event.registerEntityRenderer(GeneratedMod.SWORD_QI.get(), SwordQiRenderer::new);
        event.registerEntityRenderer(GeneratedMod.SOURCE_ORE_GOLEM.get(), context -> new SourceOreGolemRenderer<>(
                context, ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID,
                        "textures/entity/source_ore_golem.png"),
                new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "source_ore_golem"), "main")));
        event.registerEntityRenderer(GeneratedMod.PURE_SOURCE_ORE_GOLEM.get(), context -> new SourceOreGolemRenderer<>(
                context, ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID,
                        "textures/entity/pure_source_ore_golem.png"),
                new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "source_ore_golem"), "main")));
        event.registerEntityRenderer(GeneratedMod.YOUNG_DEMON_LORD.get(), calamityRenderer("young_demon_lord.png", "young_demon_lord"));
        event.registerEntityRenderer(GeneratedMod.CALAMITY_PRINCESS.get(), calamityRenderer("calamity_princess.png", "calamity_princess"));
        event.registerEntityRenderer(GeneratedMod.CALAMITY_MESSENGER.get(), context -> new CalamityMessengerRenderer(
                context,
                ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "textures/entity/calamity_messenger.png"),
                new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "calamity_messenger"), "main")));
        event.registerEntityRenderer(GeneratedMod.THERESIA.get(), context -> new TheresiaRenderer(
                context,
                ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "textures/entity/theresia.png"),
                new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "theresia"), "main")));
        event.registerEntityRenderer(GeneratedMod.PRIESTESS.get(), context -> new PriestessRenderer(
                context,
                ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "textures/entity/priestess.png"),
                new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "priestess"), "main")));
        event.registerEntityRenderer(GeneratedMod.PROPHET.get(), context -> new ProphetRenderer(
                context,
                ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "textures/entity/prophet.png"),
                new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "prophet"), "main")));
        // 哈基玖的渲染注册顺带截获 Context：本尊代跳渲染器要用同一套骨架层与贴图。
        event.registerEntityRenderer(GeneratedMod.APOCATA.get(), context -> {
            apocataRenderContext = context;
            return calamityRenderer("apocata.png", "apocata").create(context);
        });
        event.registerEntityRenderer(GeneratedMod.END_WALKER.get(), calamityRenderer("end_walker.png", "end_walker"));
        event.registerEntityRenderer(GeneratedMod.DOMAIN_SPHERE.get(), DomainSphereRenderer::new);
        event.registerEntityRenderer(GeneratedMod.UNIVERSE_SPHERE.get(), UniverseSphereRenderer::new);
    }

    /**
     * 注册首领武装火焰的两个粒子提供者。
     *
     * <p>放在这个已验证可用的模组总线订阅类里，而不是另建嵌套订阅类：粒子提供者一旦漏注册，
     * {@code ClientLevel#addParticle} 会静默丢掉整簇火焰（不报错、也不显示），是「特效完全不生效」
     * 里最难排查的一种；挂在这里可以确定它一定被调用。</p>
     *
     * <p>「重力核」（邪魔领域地面渗出的深色团，贴图由用户提供）同理由这里注册，
     * 理由相同：漏注册时，服务端 {@code sendParticles} 发出的粒子会在客户端被静默丢弃。</p>
     */
    @SubscribeEvent
    public static void registerWeaponFlameParticles(RegisterParticleProvidersEvent event) {
        WeaponFlameEvents.registerParticleProviders(event);
        event.registerSpriteSet(GravityCoreParticles.GRAVITY_CORE.get(), GravityCoreParticle::factory);
    }

    private static <T extends CalamityMob> EntityRendererProvider<T> calamityRenderer(String texture, String name) {
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, name);
        return context -> new CalamityRenderer<>(context,
                ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "textures/entity/" + texture),
                new ModelLayerLocation(id, "main"), new ModelLayerLocation(id, "inner_armor"),
                new ModelLayerLocation(id, "outer_armor"));
    }
}
