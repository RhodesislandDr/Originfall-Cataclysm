package cn.blockforge.generated.originfallcataclysm;

/**
 * 需求参数：普瑞赛斯「源石强化理论」的所有提升幅度，一律取各自原始值的 10%——
 * <ul>
 *   <li>附近生物死亡 +10% → +1%；</li>
 *   <li>自身/自身机制击杀 +32.5% → +3.25%。</li>
 * </ul>
 *
 * <p>注意：博士「我是一有原则且自制力很强的人」的每次触发幅度已由后续需求单独指定为
 * +0.65%，定义在 {@code ProphetSkillLogic.DAMAGE_AURA_RATIO}，<b>不再</b>从这里的
 * {@link #PERCENT_SCALE} 派生，改动此处不会影响该技能。</p>
 */
public final class BoostTuning {

    /** 需求指定的统一缩放系数：原值的 10%（仅用于「源石强化理论」）。 */
    public static final double PERCENT_SCALE = 0.10D;

    private BoostTuning() {
    }

    /** 把技能的原始提升幅度换算为需求要求的最终幅度（原值 × 10%）。 */
    public static double scaled(double original) {
        return original * PERCENT_SCALE;
    }
}
