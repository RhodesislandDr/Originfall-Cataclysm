package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraftforge.event.entity.living.MobEffectEvent;
import net.minecraft.network.chat.Component;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;

import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class CommonEvents {
    private static final long SPAWN_INTERVAL = 300L;
    /** 初生魔王的自然生成概率按每个游戏 tick 计算；这里的数值已经换算为百分比的小数。 */
    private static final double YOUNG_LORD_NORMAL_SPAWN_CHANCE = 0.0000325D;
    private static final double YOUNG_LORD_CONTINUANCE_SPAWN_CHANCE = 0.00000325D;
    /** 当前区块含源石时，每 tick 额外增加 0.0325%（0.000325）。 */
    private static final double YOUNG_LORD_SOURCE_ORE_BONUS = 0.000325D;
    /** 当前区块含至纯源石时，每 tick 额外增加 0.325%（0.00325）。 */
    private static final double YOUNG_LORD_PURE_SOURCE_ORE_BONUS = 0.00325D;
    private static final int YOUNG_LORD_NORMAL_REGION_RADIUS_CHUNKS = 10;
    private static final int YOUNG_LORD_CONTINUANCE_REGION_RADIUS_CHUNKS = 100;
    private static final int YOUNG_LORD_REGION_CAP = 2;
    /** 全舰防御系统开启时，特蕾西娅沿用初生魔王的生成机制，概率为其 1%。 */
    private static final double THERESIA_SPAWN_RATE = 0.01D;
    private static final int THERESIA_CHUNK_CAP = 1;
    private static final int THERESIA_REGION_CAP = 1;

    /**
     * 区块源石富集检测缓存：初生魔王/特蕾西娅的自然生成概率要按「玩家所在区块是否含黑色晶体
     * 或至纯源石」加成，而这段检测需要遍历该区块的全部 section（每 section 一次
     * {@code maybeHas}）。原实现每个天灾玩家每个 tick 都重扫一遍，属于与实体数量无关、
     * 却随视距内方块量放大的固定开销。缓存以「维度 + 区块」为键，命中期内直接复用结果，
     * 把每 tick 的重复扫描摊薄为每 {@value #ORE_BONUS_CACHE_TICKS} tick 一次。
     * 方块构成变化（玩家放置晶体、陨石落地）最多延迟一个缓存周期生效，对自然生成概率不可感知。
     */
    private static final long ORE_BONUS_CACHE_TICKS = 100L;
    /** 单个维度的缓存条目上限；超出后先清理过期项，仍超限则整体丢弃重建。 */
    private static final int ORE_BONUS_CACHE_LIMIT = 2048;
    private static final Map<ServerLevel, Long2ObjectMap<ChunkOreBonus>> ORE_BONUS_CACHE = new IdentityHashMap<>();

    /** 区块富集加成的缓存条目：到期 tick + 加成值。 */
    private record ChunkOreBonus(long expiresAt, double bonus) {
    }

    @SubscribeEvent
    public void onAttachCapabilities(AttachCapabilitiesEvent<Entity> event) {
        LearnedTraitLogic.attachCapabilities(event);
    }

    @SubscribeEvent
    public void onPlayerClone(PlayerEvent.Clone event) {
        // 死亡复活会创建新的 ServerPlayer；显式转移玩家选择和天灾模式。
        if (CalamityLogic.isCalamityModePlayer(event.getOriginal())) {
            CalamityLogic.setCalamityModePlayer(event.getEntity(), true);
        }
        if (CalamityLogic.isCivilizationContinuancePlayer(event.getOriginal())) {
            CalamityLogic.enableCivilizationContinuance(event.getEntity());
        }
        if (CalamityLogic.hasReceivedCivilizationGift(event.getOriginal())) {
            CalamityLogic.markCivilizationGiftGiven(event.getEntity());
        }
        if (OriginFallManualItem.hasReceivedManual(event.getOriginal())) {
            OriginFallManualItem.markManualGiven(event.getEntity());
        }
    }

    @SubscribeEvent
    public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)
                || !(player.level() instanceof ServerLevel level)) return;

        CalamityLogic.enforceCivilizationContinuanceRestrictions(level.getServer());
        giveManualIfNeeded(player);
        if (!level.getServer().isSingleplayer() || CalamityLogic.hasReceivedCivilizationGift(player)) return;

        ItemStack gift = new ItemStack(GeneratedMod.CIVILIZATION_CONTINUANCE.get());
        if (player.getMainHandItem().isEmpty()) {
            player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, gift);
        } else if (!player.getInventory().add(gift)) {
            return;
        }
        CalamityLogic.markCivilizationGiftGiven(player);
        player.displayClientMessage(Component.literal("你获得了文明的存续"), false);
    }

    /** 开局时给玩家赠送一本质机制说明书（每人仅一次）。 */
    private void giveManualIfNeeded(ServerPlayer player) {
        if (OriginFallManualItem.hasReceivedManual(player)) return;
        ItemStack manual = new ItemStack(GeneratedMod.ORIGINFALL_MANUAL.get());
        if (player.getMainHandItem().isEmpty()) {
            player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, manual);
        } else if (!player.getInventory().add(manual)) {
            return;
        }
        OriginFallManualItem.markManualGiven(player);
        player.displayClientMessage(Component.literal("你获得了《源石对世界的融合研究及实践》"), false);
    }

    @SubscribeEvent
    public void onItemCrafted(PlayerEvent.ItemCraftedEvent event) {
        Player player = event.getEntity();
        if (CalamityLogic.isCivilizationContinuancePlayer(player)) {
            CalamityLogic.removeSourceOfRuinFromInventory(player);
            if (player instanceof ServerPlayer serverPlayer) {
                CalamityLogic.removeSourceOfRuinRecipe(serverPlayer);
            }
            if (event.getCrafting().is(GeneratedMod.SOURCE_OF_RUIN.get())) {
                event.getCrafting().setCount(0);
                player.displayClientMessage(Component.literal("文明的延续模式无法合成灾厄之源"), true);
            }
        }
    }

    @SubscribeEvent
    public void onPumpkinPlaced(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        BlockPos placed = event.getBlockSnapshot().getPos();
        boolean carved = event.getPlacedBlock().is(net.minecraft.world.level.block.Blocks.CARVED_PUMPKIN)
                || event.getPlacedBlock().is(net.minecraft.world.level.block.Blocks.JACK_O_LANTERN);
        // 哈基玖的南瓜头沿用雪傀儡口径：普通南瓜、雕刻南瓜、南瓜灯都认。
        boolean anyPumpkin = carved || event.getPlacedBlock().is(net.minecraft.world.level.block.Blocks.PUMPKIN);
        if (anyPumpkin && trySummonApocata(level, placed)) return;
        if (!carved) return;
        trySummonSourceOreGolem(level, placed, event.getEntity());
        trySummonTheresia(level, placed);
    }

    /**
     * 哈基玖召唤（雪傀儡式两层结构）：下侧一个张师块、上侧一个南瓜头。
     *
     * <p>原型是雪傀儡的「下侧身体减一层」：雪傀儡是雪块＋雪块＋南瓜头，减掉一层雪块后
     * 剩下的雪块换成张师块，即「一张师块＋南瓜头」。判定刻意收得比另两种仪式更严，
     * 保证互不误触：</p>
     * <ul>
     *   <li>南瓜正下方必须是张师块，再下方<b>不能</b>还是张师块（那是特蕾西娅的堆高柱式）；</li>
     *   <li>张师块所在层<b>不能</b>有成对的横向臂（那是特蕾西娅的十字）。</li>
     * </ul>
     *
     * <p>该仪式是《方块与深蓝之树》的联动彩蛋，但<b>召唤本身不依赖深蓝之树在场</b>：
     * 未安装深蓝之树时照常消费方块并生成等价替身（本模组的 {@link Apocata}），
     * 只是替身死亡时不再掉落「哈基玖本人」、也不触发潮曦奇美拉钩子（见
     * {@link Apocata#die}）。装有深蓝之树时产出的实体优先为本尊
     * {@code caerula_arbor:apocata}，其定义、掉落与怪物召唤机制天然生效，
     * 仅当对方版本里查不到本尊实体类型时才回退生成等价替身。</p>
     *
     * @return true 表示本次放置已按哈基玖仪式消费，不再走其它召唤判定。
     */
    private boolean trySummonApocata(ServerLevel level, BlockPos pumpkin) {
        // 召唤不挂钩深蓝之树：装了优先出本尊，没装直接出替身（掉落结算另行让位）。
        BlockPos core = pumpkin.below();
        if (!isZhangshiPart(level, core)) return false;
        // 堆高柱式与十字形都归特蕾西娅，这里只认「单块立柱」。
        if (isZhangshiPart(level, pumpkin.below(2))) return false;
        boolean eastWest = isZhangshiPart(level, core.east()) && isZhangshiPart(level, core.west());
        boolean northSouth = isZhangshiPart(level, core.north()) && isZhangshiPart(level, core.south());
        if (eastWest || northSouth) return false;

        level.removeBlock(pumpkin, false);
        level.removeBlock(core, false);
        Vec3 spawnPos = new Vec3(core.getX() + 0.5D, core.getY(), core.getZ() + 0.5D);
        if (CaerulaArborCompat.summonNativeApocata(level, spawnPos) != null) return true;
        return Apocata.spawnStandIn(level, spawnPos) != null;
    }

    /**
     * 特蕾西娅召唤：说明书写作「在张师块构成的十字结构上放置雕刻南瓜或南瓜灯」。
     *
     * <p>旧判定只认「南瓜下方两层都是张师块 + 中层至少一对相对两臂」的堆高结构，于是玩家
     * 照说明书在平地上摆一个贴地的十字再放南瓜时，第二层是地面而非张师块，判定直接失败——
     * 南瓜放上去什么都不会发生，就是「召唤仪式失效」。现在同时接受两种摆法：</p>
     * <ul>
     *   <li><b>十字</b>：中心加东南西北四臂共 5 块张师块、南瓜放在中心正上方（说明书写法）。</li>
     *   <li><b>带底座的十字</b>：南瓜下方两层都是张师块且中层有相对两臂（旧版结构，保留兼容）。</li>
     * </ul>
     * <p>误触保护仍然保留：若十字四臂之外的四个斜角也全是张师块，说明这是整片张师块地面/
     * 平台而不是刻意摆的十字，南瓜只是随手放上去，不召唤。</p>
     */
    private void trySummonTheresia(ServerLevel level, BlockPos pumpkin) {
        BlockPos core = pumpkin.below();
        if (!isZhangshiPart(level, core)) return;
        BlockPos base = pumpkin.below(2);
        boolean eastWest = isZhangshiPart(level, core.east()) && isZhangshiPart(level, core.west());
        boolean northSouth = isZhangshiPart(level, core.north()) && isZhangshiPart(level, core.south());
        // 真正的十字需要两轴齐全；若四个斜角也铺满张师块，则判为地面/平台，不算十字。
        boolean cross = eastWest && northSouth && !isZhangshiFloor(level, core);
        // 旧版堆高结构：南瓜下方两层都是张师块且至少有一对相对两臂。
        boolean pillar = isZhangshiPart(level, base) && (eastWest || northSouth);
        if (!cross && !pillar) return;

        level.removeBlock(pumpkin, false);
        level.removeBlock(core, false);
        if (isZhangshiPart(level, base)) level.removeBlock(base, false);
        if (eastWest) {
            level.removeBlock(core.east(), false);
            level.removeBlock(core.west(), false);
        }
        if (northSouth) {
            level.removeBlock(core.north(), false);
            level.removeBlock(core.south(), false);
        }
        Theresia theresia = GeneratedMod.THERESIA.get().create(level);
        if (theresia == null) return;
        // 落在十字中心被清空的这一格：贴地十字的下方是地面、堆高结构的下方已掏空，
        // 两种情况都不会把实体埋进方块里。
        theresia.moveTo(core.getX() + 0.5D, core.getY(), core.getZ() + 0.5D,
                level.getRandom().nextFloat() * 360.0F, 0.0F);
        theresia.setPersistenceRequired();
        level.addFreshEntity(theresia);
    }

    private boolean isZhangshiPart(ServerLevel level, BlockPos pos) {
        return level.getBlockState(pos).is(GeneratedMod.ZHANGSHI_BLOCK.get());
    }

    /** 十字四臂之外的四个斜角也全是张师块：说明南瓜只是放在一片张师块地面/平台上，不算十字仪式。 */
    private boolean isZhangshiFloor(ServerLevel level, BlockPos core) {
        return isZhangshiPart(level, core.north().east()) && isZhangshiPart(level, core.north().west())
                && isZhangshiPart(level, core.south().east()) && isZhangshiPart(level, core.south().west());
    }

    /** 击败末影龙后召唤「女祭司」普瑞赛斯的职责已移交 {@link DragonKillWatcher}。 */

    private void trySummonSourceOreGolem(ServerLevel level, BlockPos pumpkin, Entity manufacturer) {
        BlockPos core = pumpkin.below();
        BlockPos base = pumpkin.below(2);
        boolean pure = level.getBlockState(core).is(GeneratedMod.METEOR_BLOCK.get());
        boolean black = level.getBlockState(core).is(GeneratedMod.BLACK_CRYSTAL.get());
        if (!pure && !black) return;

        // 四个源石方块必须是同一种材质，避免黑色晶体和至纯源石混搭召唤出错误类型。
        if (!isCrystalPart(level, base, pure)) return;
        boolean eastWest = isCrystalPart(level, core.east(), pure) && isCrystalPart(level, core.west(), pure);
        boolean northSouth = isCrystalPart(level, core.north(), pure) && isCrystalPart(level, core.south(), pure);
        if (!eastWest && !northSouth) return;
        if (manufacturer instanceof LivingEntity living) {
            spawnSourceOreGolem(level, pumpkin, pure, living, eastWest);
        } else {
            spawnSourceOreGolem(level, pumpkin, pure, null, eastWest);
        }
    }

    private boolean isCrystalPart(ServerLevel level, BlockPos pos, boolean pure) {
        return level.getBlockState(pos).is(pure
                ? GeneratedMod.METEOR_BLOCK.get() : GeneratedMod.BLACK_CRYSTAL.get());
    }

    private void spawnSourceOreGolem(ServerLevel level, BlockPos pumpkin, boolean pure,
                                     LivingEntity manufacturer, boolean eastWest) {
        BlockPos core = pumpkin.below();
        BlockPos base = pumpkin.below(2);
        level.removeBlock(pumpkin, false);
        level.removeBlock(core, false);
        level.removeBlock(base, false);
        if (eastWest) {
            level.removeBlock(core.east(), false);
            level.removeBlock(core.west(), false);
        } else {
            level.removeBlock(core.north(), false);
            level.removeBlock(core.south(), false);
        }
        SourceOreGolem golem = pure ? GeneratedMod.PURE_SOURCE_ORE_GOLEM.get().create(level)
                : GeneratedMod.SOURCE_ORE_GOLEM.get().create(level);
        if (golem == null) return;
        golem.moveTo(core.getX() + 0.5D, base.getY(), core.getZ() + 0.5D,
                level.getRandom().nextFloat() * 360.0F, 0.0F);
        if (manufacturer != null) {
            golem.setManufacturerUUID(manufacturer.getUUID());
            golem.setCalamityFaction(CalamityLogic.isCalamityFactionMember(manufacturer));
        }
        golem.setPlayerCreated(true);
        level.addFreshEntity(golem);
    }

    @SubscribeEvent
    public void onSourceOreInfectionExpired(MobEffectEvent.Expired event) {
        if (event.getEntity().level().isClientSide) return;
        MobEffectInstance expired = event.getEffectInstance();
        if (expired.getEffect() == GeneratedMod.SOURCE_ORE_INFECTION.get()) {
            CalamityLogic.downgradeSourceOreInfection(event.getEntity(), expired);
        }
    }

    @SubscribeEvent
    public void onLivingAttack(LivingAttackEvent event) {
        LivingEntity victim = event.getEntity();
        LivingEntity attacker = resolveAttacker(event.getSource());

        // 「扒臀舞」受击入口：枪械/魔法首次命中博士、普瑞赛斯或哈基玖即免疫该击并起舞；
        // 舞曲期间任何伤害一律吞掉。须排在其它伤害改写之前，规则详见 BossTauntLogic。
        if (victim instanceof CalamityMob taunter && BossTauntLogic.canTaunt(taunter)
                && victim.level() instanceof ServerLevel tauntLevel
                && BossTauntLogic.handleIncomingHit(taunter, event.getSource(), tauntLevel)) {
            event.setCanceled(true);
            return;
        }

        // 「扒臀舞」出手封锁：跳舞中的首领打出的一切伤害归零（近战、弹射、技能皆然），
        // 即「音乐播放期间不会进行任何攻击」。受击方免疫由上面的入口负责，这里管施害方。
        if (attacker instanceof CalamityMob dancer && BossTauntLogic.canTaunt(dancer)
                && BossTauntLogic.isActive(dancer)) {
            event.setCanceled(true);
            return;
        }

        // 深蓝之树本尊哈基玖（外部实体 caerula_arbor:apocata）接入同一套「扒臀舞」：
        // 它不是 CalamityMob，挂不上同步实体数据，舞蹈状态由 NativeApocataTauntLogic 的
        // 服务端内存会话驱动，客户端外观接管与舞步通道见 NativeApocataAppearanceEvents；规则与替身完全一致。
        if (CaerulaArborCompat.isNativeApocataEntity(victim)
                && victim.level() instanceof ServerLevel nativeTauntLevel
                && NativeApocataTauntLogic.handleIncomingHit(victim, event.getSource(), nativeTauntLevel)) {
            event.setCanceled(true);
            return;
        }
        if (CaerulaArborCompat.isNativeApocataEntity(attacker)
                && NativeApocataTauntLogic.isActive(attacker)) {
            event.setCanceled(true);
            return;
        }

        // 影霄接管玩家的普通近战入口，避免原版伤害与自定义两段伤害叠加。
        if (attacker instanceof Player player && YingsiaoSwordItem.isSwordAttackSource(event.getSource())
                && !victim.getPersistentData().getBoolean(YingsiaoSwordItem.INTERNAL_DAMAGE)) {
            event.setCanceled(true);
            YingsiaoSwordItem.applyAttack(player, victim, false, 0);
            return;
        }

        // 终焉极道：影霄持有者受到致命伤害时锁血并传送；玩家和特蕾西娅均适用。
        if (YingsiaoSwordItem.hasYingsiaoAccess(victim)
                && !victim.getPersistentData().getBoolean(YingsiaoSwordItem.INTERNAL_DAMAGE)
                && event.getAmount() >= victim.getHealth()
                && !victim.getPersistentData().getBoolean(YingsiaoSwordItem.SURVIVAL_TAG)
                && YingsiaoSwordItem.canActivateSurvival(victim)
                // 坍缩个体失去复活：影霄锁血同样失效。
                && !CalamityLogic.isCollapsed(victim)
                && victim.level() instanceof ServerLevel level) {
            Entity destination = level.getEntitiesOfClass(LivingEntity.class,
                            victim.getBoundingBox().inflate(64.0D), entity -> entity != victim
                                    && entity.isAlive() && !entity.isAlliedTo(victim)
                                    && !CalamityLogic.isFactionAlly(victim, entity))
                    .stream().min(Comparator.comparingDouble(victim::distanceToSqr)).orElse(null);
            if (destination != null) {
                event.setCanceled(true);
                victim.setHealth(1.0F);
                YingsiaoSwordItem.activateSurvival(victim);
                victim.teleportTo(destination.getX() + 1.5D, destination.getY(), destination.getZ() + 1.5D);
                return;
            }
        }

        // 阵营关系不仅约束 AI，也拦截玩家或投射物对友军的直接伤害。
        if (attacker != null && CalamityLogic.isFactionAlly(attacker, victim)) {
            event.setCanceled(true);
            return;
        }

        if (LearnedTraitLogic.sameLearnerFamily(attacker, victim)) {
            event.setCanceled(true);
            return;
        }

        if (CalamityLogic.isHoldingSourceOfRuin(victim)
                && event.getSource().is(DamageTypes.WITHER)) {
            event.setCanceled(true);
            victim.removeEffect(net.minecraft.world.effect.MobEffects.WITHER);
            victim.removeEffect(net.minecraft.world.effect.MobEffects.WEAKNESS);
            return;
        }

        // 标记但尚未替换的转化生物也必须免疫爆炸伤害；CalamityMob
        // 自身另有 hurt() 兜底，确保非事件路径同样不会受到爆炸伤害。
        if (event.getSource().is(DamageTypeTags.IS_EXPLOSION)
                && (victim instanceof CalamityMob && !(victim instanceof Theresia)
                 || CalamityLogic.isConvertedHostile(victim))) {
            event.setCanceled(true);
            return;
        }

        // 普通模式下源石实体是友好生物，转换生物及模组天灾生物不能攻击它们。
        if (victim instanceof SourceOreGolem golem
                && !(attacker instanceof Theresia)
                && (attacker instanceof CalamityMob || CalamityLogic.isConvertedHostile(attacker))
                && !CalamityLogic.isSourceOreGolemHostile(golem)) {
            event.setCanceled(true);
            return;
        }

        // 同一阵营的源石实体与天灾实体不互相造成伤害；AI 之外的近战、投射物等路径也要兜底。
        if ((attacker instanceof CalamityMob || attacker instanceof SourceOreGolem
                || CalamityLogic.isConvertedHostile(attacker))
                && (victim instanceof CalamityMob || victim instanceof SourceOreGolem
                || CalamityLogic.isConvertedHostile(victim))
                && CalamityLogic.isFactionAlly(attacker, victim)) {
            event.setCanceled(true);
            return;
        }

        if (CalamityLogic.isSameConvertedFaction(attacker, victim)) {
            event.setCanceled(true);
            return;
        }

        if (victim instanceof Player player && attacker != null
                && (attacker instanceof CalamityMob || attacker instanceof SourceOreGolem
                || CalamityLogic.isConvertedHostile(attacker))
                && !CalamityLogic.canCalamityEntityAttackPlayer(attacker, player)) {
            // 模式关闭后，已发出的远程投射物也不能继续保持天灾对玩家的敌对状态。
            event.setCanceled(true);
        } else if (victim instanceof Player player
                && player.level() instanceof ServerLevel level
                && DisasterData.get(level).isCalamityActive()
                && !CalamityLogic.isCivilizationContinuancePlayer(player)
                && attacker != null && !(attacker instanceof Player)
                && !(attacker instanceof CalamityMob)
                && !CalamityLogic.isNaturalHostile(attacker)) {
            CalamityLogic.markCalamityHostile(attacker);
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onLivingDamage(LivingDamageEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide) return;
        LivingEntity attacker = resolveAttacker(event.getSource());
        // 影霄的真实伤害已经直接结算，避免死亡事件前被重复压血；第二段仍保留原版护甲、附魔和事件链。
        if (victim.getPersistentData().getBoolean(YingsiaoSwordItem.INTERNAL_DAMAGE)) {
            victim.getPersistentData().remove(YingsiaoSwordItem.INTERNAL_DAMAGE);
        }
        if (attacker != null && event.getAmount() > 0.0F) {
            // 击杀归属账本：记录该学习者最近一次对目标的伤害，供武器特效/爆裂/阳火等
            // 丢失来源实体的击杀在死亡事件里补回攻击者。
            LearnedTraitLogic.recordKillCredit(attacker, victim);
            CalamityLogic.applySourceOreInfectionFromCalamityAttack(attacker, victim);
            // 被坍缩生物攻击时有 10% 概率附加一层坍缩。
            CalamityLogic.applyCollapseFromAttack(attacker, victim);
            LearnedTraitLogic.onSuccessfulAttack(attacker, victim, event.getSource());
        }
    }

    @SubscribeEvent
    public void onLivingDeath(LivingDeathEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide || !(victim.level() instanceof ServerLevel level)) return;

        // 击败末影龙：交给「女祭司」召唤兼容层登记，延迟到安全时机再生成。
        // 与 Epic Fight 等 Boss 改造模组共存时死亡事件链可能被吞，兼容层会以尸检 +
        // 战况双通道补登记，并顺带把被吞的龙战安全推进到“已击杀”。
        if (victim instanceof net.minecraft.world.entity.boss.enderdragon.EnderDragon dragon) {
            DragonKillWatcher.onDragonDeathEvent(level, dragon);
            return;
        }

        // 「巴别塔回忆」的兜底登记：博士死亡后 20 tick 触发。这里与 Prophet#die 构成双入口，
        // onProphetDeath 内部按 UUID 去重，重复调用无副作用；万一某条死亡衍生链绕过了实体
        // 自身的 die 覆写，也能在这一步补上登记，对应需求里的「解决死亡后未触发该技能问题」。
        // 坍缩个体失去死亡后效果：博士的「巴别塔回忆」不再登记。
        if (victim instanceof Prophet prophet && !CalamityLogic.isCollapsed(victim)) {
            ProphetSkillLogic.onProphetDeath(prophet, level);
        }

        // 印记只能在死亡或内化宇宙判定结束时清除，不能随普通计时自然消失。
        TiantangzhidianLogic.clearYinYangMarks(victim);

        if (victim instanceof Player player) {
            // 玩家死亡时影霄必然掉落，并清除本次持剑积累的额外生命；玩家本身允许正常复活。
            if (YingsiaoSwordItem.hasInInventory(player)) {
                YingsiaoSwordItem.removeSwordFromPlayer(player);
                YingsiaoSwordItem.clearExtraHealth(player);
            }
            player.getPersistentData().remove(YingsiaoSwordItem.SURVIVAL_TAG);
            player.getPersistentData().remove(YingsiaoSwordItem.SURVIVAL_UNTIL);
            player.getPersistentData().remove(YingsiaoSwordItem.EMPOWERED_UNTIL);
        }

        LivingEntity attacker = resolveAttacker(event.getSource());
        // 武器特效、爆裂、阳火/点燃等伤害常常丢失攻击者实体（爆裂的单参伤害来源不带实体，
        // 火焰持续伤害同样如此）：从目标近期被学习者造成的伤害记录里把击杀者补回来。
        if (attacker == null) {
            LivingEntity credited = LearnedTraitLogic.recentKillCredit(victim);
            if (credited != null) attacker = credited;
        }
        if (attacker instanceof Theresia && victim != attacker) {
            ((Theresia) attacker).recordKill();
        }
        boolean sameLearnerFamily = attacker != null && LearnedTraitLogic.sameLearnerFamily(attacker, victim);
        boolean canLearnFromThisKill = attacker != null
                && LearnedTraitLogic.canLearnFromKill(attacker, victim, event.getSource());
        // 莱特兰恶意词条学习通道的闸门：近战/远程直接击杀，或目标确实被该击杀者以武器特效、
        // 爆裂、阳火、溅射等方式伤害过。恶意词条通道对「该模组所有生物 + 该模组所有召唤生物」
        // 开放（内置 kube 备用脚本的模组化口径）；行为特性通道仍只对本模组的学习者开放。
        // 玩家与一切非模组生物击杀既不学词条，也不继承等级，不会把词条「感染」出去。
        boolean canLearnMaliceFromThisKill = LearnedTraitLogic.canLearnMaliceFromKill(
                attacker, victim, event.getSource());
        // 美化包已经直接替换目标；若某个外部路径仍补发死亡事件，必须切断所有普通死亡衍生逻辑。
        if (CalamityLogic.isBeautificationKill(victim)) {
            CalamityLogic.clearBeautificationKill(victim);
            return;
        }
        // 影霄斩杀属于武器特效击杀：同样计入学习，但不进入转化、复活或其他死亡衍生链。
        if (YingsiaoSwordItem.hasExecutionMark(victim)) {
            applyMaliceKillLearning(canLearnMaliceFromThisKill, attacker, victim);
            if (canLearnFromThisKill && !sameLearnerFamily) {
                LearnedTraitLogic.learnAfterConversion(attacker, victim, event.getSource());
            }
            YingsiaoSwordItem.clearExecution(victim);
            LearnedTraitLogic.clearOnDeath(victim);
            return;
        }
        // 莱特兰恶意词条学习通道：装有莱特兰-恶意时由兼容层把目标的恶意词条学给凶手
        // （相同词条融合升级、不占名额，数量上限为原有行动逻辑的两倍、恶意等级每 20 级再 +1）；
        // 独立形态下恶意词条即下方行为特性学习链，本入口自动空转，不产生额外开销。
        // 先结算击杀继承的等级（32.5%、向上取整），再学词条：
        // 新等级带来的「每 20 级 +1 词条上限」当场生效。
        applyMaliceKillLearning(canLearnMaliceFromThisKill, attacker, victim);
        boolean continuancePlayerAttack = CalamityLogic.isCivilizationContinuancePlayerAttack(attacker);
        boolean infectionDeath = CalamityLogic.diedFromSourceOreInfection(victim);
        // /kill 类代码（generic_kill 来源）属于命令行/脚本的强制清理，不构成世界内的因果击杀：
        // 感染转化与死后陨石等死亡衍生链一律不进入。
        boolean killCommandDeath = CalamityLogic.isKillCommandDeath(event.getSource());
        // 陨石会在伤害循环中用伤害前快照处理自身击杀，避免与此处重复替换；
        // 同时陨石路径的转化不受“转化生物密度”上限约束。
        boolean meteorHandled = event.getSource().getDirectEntity() instanceof MeteorEntity;
        if (infectionDeath) {
            // 文明延续玩家造成的攻击不应借由感染 DoT 间接触发生物同化；/kill 同样不触发。
            if (!continuancePlayerAttack && !killCommandDeath) {
                CalamityLogic.convertAfterSourceOreInfectionDeath(level, victim, meteorHandled);
            }
            CalamityLogic.clearSourceOreInfectionDeath(victim);
        }

        // 任意方式击杀普通 Mob 都进入统一的天灾转化判定；玩家、天灾实体和已转化实体不重复转化。
        // 处于源石感染期间的个体改为概率判定：源石阵营击杀 = 规则「初始转化概率」+ 每层 3.25%，
        // 其他生物或伤害来源 = 每层 3.25%；感染伤害致死与陨石击杀在上面两条路径里必定转化。
        // /kill 类代码是强制清理，不进入该判定。
        if (CalamityLogic.isPlayerAssimilationTarget(victim) && !continuancePlayerAttack
                && !infectionDeath && !meteorHandled && !killCommandDeath && !CalamityLogic.isCollapsed(victim)
                && CalamityLogic.rollInfectionKillConversion(level, victim, attacker)) {
            LivingEntity converted = CalamityLogic.convertAfterAnyKillDeath(level, victim, attacker);
            if (converted != null && canLearnFromThisKill && !sameLearnerFamily) {
                LearnedTraitLogic.learnAfterConversion(attacker, victim, event.getSource());
            }
        }

        if (canLearnFromThisKill && !sameLearnerFamily && !CalamityLogic.isPlayerAssimilationTarget(victim)
                && !YingsiaoSwordItem.hasExecutionMark(victim)) {
            LearnedTraitLogic.learnAfterConversion(attacker, victim, event.getSource());
        }

        // 转化生物死亡后的陨石波次：/kill 强制清理不触发。
        if (!killCommandDeath && CalamityLogic.isConvertedHostile(victim)
                && !(victim instanceof EndWalker)
                && !(victim instanceof CalamityMessenger)
                && !(victim instanceof SourceOreGolem)) {
            CalamityLogic.summonConvertedDeathMeteors(level, victim);
        }
        LearnedTraitLogic.clearOnDeath(victim);

    }

    @SubscribeEvent
    public void onLivingChangeTarget(LivingChangeTargetEvent event) {
        LivingEntity source = event.getEntity();
        LivingEntity target = event.getNewTarget();
        if (target == null) return;

        // 目标切换事件是原版 AI 的另一条入口，必须复用与自定义目标选择相同的阵营判定。
        if (CalamityLogic.isFactionAlly(source, target)) {
            event.setNewTarget(null);
        } else if (source instanceof SourceOreGolem golem && !golem.canAttack(target)) {
            event.setNewTarget(null);
        } else if (source instanceof CalamityMob calamity && !calamity.canAttack(target)) {
            event.setNewTarget(null);
        } else if (CalamityLogic.isConvertedHostile(source)
                && !CalamityLogic.canConvertedHostileAttack(source, target)) {
            event.setNewTarget(null);
        }
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) YingsiaoSwordItem.tickPlayer(event.player);
    }

    @SubscribeEvent
    public void onLivingTick(LivingEvent.LivingTickEvent event) {
        LivingEntity living = (LivingEntity) event.getEntity();
        if (living.level().isClientSide) return;
        // 模组生物速度治理：速度过快时，上限速度仅用于索敌追击；未索敌按每秒 6 格移动。
        // 同时为博士/普瑞赛斯提供 128 格索敌保底（旧存档同样生效）。
        MovementGovernor.tick(living);
        // 转化标记可能在实体替换前短暂存在；每 tick 清掉已附着的陨石/晶体负面效果。
        if (living.hasEffect(net.minecraft.world.effect.MobEffects.WITHER)
                || living.hasEffect(net.minecraft.world.effect.MobEffects.WEAKNESS)) {
            // 模组附加的源石感染无视目标的负面效果免疫；原版效果仅作为触发媒介并被清理。
            CalamityLogic.applySourceOreInfection(living, 1, 0);
            living.removeEffect(net.minecraft.world.effect.MobEffects.WITHER);
            living.removeEffect(net.minecraft.world.effect.MobEffects.WEAKNESS);
        }
        if (living.getBlockStateOn().is(GeneratedMod.BLACK_CRYSTAL.get())) {
            CalamityLogic.applySourceOreInfection(living, 1, 0);
            CalamityLogic.markInfectionExposure(living);
        }
        CalamityLogic.tickSourceOreInfection(living);
        // 坍缩（邪魔）：传播、升级计时与玩家掉血的服务端驱动。
        CalamityLogic.tickCollapse(living);
        if (living instanceof Player player && living.level() instanceof ServerLevel level
                && !DisasterData.get(level).isCalamityActive()) {
            CalamityLogic.setCalamityModePlayer(player, false);
            CalamityLogic.clearCivilizationContinuance(player);
        }
        if (CalamityLogic.isMeteorAndCrystalImmune(living)) {
            CalamityLogic.clearMeteorAndCrystalEffects(living);
        }
        if (living instanceof Mob mob) {
            // 坍缩个体不与已坍缩的同阵营互斗：目标若是刚坍缩成邪魔（或已是邪魔），
            // 立即脱手丢弃——目标选择器谓词已挡住重新选它，这里处理"已经锁定"的旧目标。
            LivingEntity currentTarget = mob.getTarget();
            if (currentTarget != null && CalamityLogic.isCollapsed(mob)
                    && CalamityLogic.isCollapsed(currentTarget)) {
                mob.setTarget(null);
            }
            if (CalamityLogic.isConvertedHostile(living)) {
                if (!(living instanceof EndWalker) && !(living instanceof CalamityMessenger)) {
                    CalamityLogic.convertMob(mob);
                    return;
                }
                CalamityLogic.ensureConvertedHostileGoal(mob);
                LivingEntity target = mob.getTarget();
                if (target != null && !CalamityLogic.canConvertedHostileAttack(mob, target)) mob.setTarget(null);
            } else if (CalamityLogic.isConvertedHostile(mob.getTarget())) {
                mob.setTarget(null);
            }
        }
    }

    private static LivingEntity resolveAttacker(net.minecraft.world.damagesource.DamageSource source) {
        Entity attacker = source.getEntity();
        if (attacker instanceof LivingEntity living) return living;
        Entity direct = source.getDirectEntity();
        if (direct instanceof LivingEntity living) return living;
        if (direct instanceof Projectile projectile && projectile.getOwner() instanceof LivingEntity living) return living;
        return null;
    }

    /**
     * 莱特兰配置加载/重载时自动检测并修正 {@code allowTraitOnOwnable} 与 {@code allowPlayerAllies}：
     * 前者为 false 时莱特兰会每 tick 清空玩家驯服/认主生物身上的恶意词条；后者为 false 时
     * 它会把与玩家结盟的生物在初始化阶段跳过成 0 级、不生成词条。本模组由玩家驯服、认主或
     * 召唤（刷怪蛋/道具/代码）的学习者都会因此丢词条或永远学不到词条，
     * 详见 {@link MaliceCompat#forceCompatConfigs()}。
     */
    @SubscribeEvent
    public static void onModConfig(net.minecraftforge.fml.event.config.ModConfigEvent event) {
        if (event == null || event.getConfig() == null) return;
        if (!MaliceCompat.L2HOSTILITY_MOD_ID.equals(event.getConfig().getModId())) return;
        MaliceCompat.forceCompatConfigs();
    }

    /** 恶意词条击杀学习：先继承等级（32.5%、向上取整），再学词条，让新等级的词条上限当场生效。 */
    private static void applyMaliceKillLearning(boolean canLearn, LivingEntity attacker, LivingEntity victim) {
        if (!canLearn) return;
        MaliceCompat.inheritLevelFromKill(attacker, victim);
        MaliceCompat.onLearnerKill(attacker, victim);
    }

    /**
     * 「预言家」仪式祭品一被抛出就交给 {@link ProphetRitual#onToss} 逐 tick 盯防。
     * 仪式操作是站在池边把八件祭品依次丢进水里，而 Q 键丢出的物品约 1 秒后就能被
     * 扔掷者重新吸回背包；旧实现只有低频周期扫描，祭品在第一次被扫到之前就已经回到
     * 玩家手里，于是水池永远凑不齐、进度播报也从不出现——这正是「水池仪式投了没反应」
     * 连续几轮修不好的根因。这里在抛出的瞬间登记监视并给拾取保护，落水当 tick 即记账。
     */
    @SubscribeEvent
    public void onItemToss(ItemTossEvent event) {
        ProphetRitual.onToss(event.getPlayer(), event.getEntity());
    }

    /** 测试命令 /ofctaunt：预览「女祭司」普瑞赛斯与「预言家」博士的视频动作（正式触发机制后续补充）。 */
    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        BossTauntLogic.registerCommands(event);
    }

    /**
     * 玩家开始追踪实体：正在跳舞的深蓝之树本尊若错过了开跳广播（事后进入视野/换维度），
     * 给这位玩家补发一条当前舞程，客户端按剩余时长续跳并对上姿势相位。
     *
     * <p>同一入口顺带补发坍缩效果：原版 1.20.1 从不下发普通生物的效果实例
     * （{@code ServerEntity} 里没有这段逻辑），客户端上的 {@code getEffect(COLLAPSE)} 对非玩家
     * 实体恒为 null，头部标志贴图便无从绘制。{@link CalamityLogic#addCollapseLayer} 负责感染
     * 当刻的广播，这里补上「后来才进入视野」的那一批——玩家走近、换维度、重连后都能看到标志。</p>
     */
    @SubscribeEvent
    public void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getTarget() instanceof LivingEntity living
                && event.getEntity() instanceof ServerPlayer player) {
            NativeApocataTauntLogic.resyncOnStartTracking(living, player);
            MobEffectInstance collapse = living.getEffect(GeneratedMod.COLLAPSE.get());
            if (collapse != null) {
                player.connection.send(new net.minecraft.network.protocol.game.ClientboundUpdateMobEffectPacket(
                        living.getId(), collapse));
            }
        }
    }

    @SubscribeEvent
    public void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        // 「源石计划进度」：每 tick 刷新档位缓存系数。服务端读权威规则值，客户端读同步副本，
        // 供 MobEffect 属性覆写这类拿不到世界上下文的路径使用（两端都要保持同步）。
        OriginiumPlanProgress.refreshCache(event.level);
        if (event.level.isClientSide || !(event.level instanceof ServerLevel level)) return;
        // 配置加载事件若因加载顺序被错过，这里在每个服务端 tick 兜底再修正一次（成功后即不再执行）。
        MaliceCompat.forceCompatConfigs();
        // 击败末影龙后召唤「女祭司」普瑞赛斯的兼容层：事件 + 龙尸检 + 战况三通道，
        // 并兜底推进被 Epic Fight 等 Boss 改造模组吞掉击杀链的龙战。
        DragonKillWatcher.tick(level);
        CalamityLogic.tickRevivalWaves(level);
        CalamityLogic.tickRevivals(level);
        // 内化宇宙光点：4秒逐渐扩张至32格、结束时收缩熄灭并清除阴/阳标记。
        UniverseLightLogic.tick(level);
        // 「预言家」博士召唤仪式：张师块围出矩形水池，投满八种祭品后传送音响起并凝聚「表里之间」。
        ProphetRitual.tick(level);
        // 「预言家」博士自身技能：游刃有余/领域展开/精锐集结/黑闪等状态结算。
        ProphetSkillLogic.tick(level);
        // 「女祭司」普瑞赛斯自身技能：女祭司之眼/领域展开•矢量偏移/状态增强等状态结算。
        PriestessSkillLogic.tick(level);
        // 「扒臀舞」（视频动作适配）：跳舞中的首领锁定背对伤害施加者，并以每秒 2 格向其贴近。
        BossTauntLogic.tick(level);
        // 深蓝之树本尊哈基玖（外部实体）的同一支舞：内存会话驱动转身/贴近/弹反/倒计时。
        NativeApocataTauntLogic.tick(level);
        // 清理游离的领域结界球体（其施术者已无激活领域时移除）。
        DomainSphereEntity.pruneOrphans(level);
        // 「坍缩渗透」：开启后每个晚上 0 点判定一次，累积概率感染一只随机生物。
        CollapseInfiltration.tick(level);
        // 邪魔之约：每维度推进「实质性坍缩」留下的感染空间；主世界每秒结算累计层数与档位。
        CollapseCovenant.tickZones(level);
        if (net.minecraft.world.level.Level.OVERWORLD.equals(level.dimension())) {
            CollapseCovenant.tickServer(level.getServer());
        }

        DisasterData data = DisasterData.get(level);
        initializeHardcore(level, data);
        // 性能：地狱核心清理与文明延续结算都要遍历全维度实体/全服玩家，原实现每个维度
        // 每个 tick 各跑一遍（三个维度即三倍全量扫描）。降频为每秒一次，且跨维度的服务器级
        // 结算只在主世界 tick 上执行一次，行为语义不变（1 秒的收敛延迟对清理类逻辑不可感知）。
        if (event.level.getGameTime() % 20L == 0L) {
            removeHardcoreSources(level);
            if (net.minecraft.world.level.Level.OVERWORLD.equals(level.dimension())) {
                CalamityLogic.enforceCivilizationContinuanceRestrictions(level.getServer());
            }
        }
        if (!data.isCalamityActive() || !CalamityLogic.anyCalamityModePlayer(level)) return;
        spawnYoungDemonLords(level);
        spawnTheresiasNaturally(level);
        summonPrincesses(level);

        long gameTime = level.getGameTime();
        if (data.getNextMeteorTick() < 0L) {
            data.scheduleNextMeteor(gameTime + SPAWN_INTERVAL);
            return;
        }
        if (gameTime < data.getNextMeteorTick()) return;
        data.scheduleNextMeteor(gameTime + SPAWN_INTERVAL);

        for (ServerPlayer player : level.players()) {
            if (!CalamityLogic.isCalamityModePlayer(player)) continue;
            if (CalamityLogic.isCivilizationContinuancePlayer(player)) continue;
            if (level.getEntities(player, player.getBoundingBox().inflate(96.0D), entity -> entity instanceof MeteorEntity).size() >= 64) continue;
            spawnForAnchor(level, player, 32.0D);
        }
        for (CalamityMob calamity : level.getEntitiesOfClass(CalamityMob.class,
                new net.minecraft.world.phys.AABB(-3.0E7D, level.getMinBuildHeight(), -3.0E7D,
                        3.0E7D, level.getMaxBuildHeight(), 3.0E7D), Entity::isAlive)) {
            if (!CalamityLogic.canSummonNaturalMeteorFrom(calamity)) continue;
            if (level.getEntities(calamity, calamity.getBoundingBox().inflate(96.0D), entity -> entity instanceof MeteorEntity).size() < 64) {
                spawnForAnchor(level, calamity, 32.0D);
            }
        }
    }

    /**
     * 服务端停止时清空区块富集缓存：不同存档可能复用同一维度（overworld 等），
     * 若沿用旧存档的缓存条目会在新存档里给出错误的生成加成。
     */
    @SubscribeEvent
    public void onServerStopped(ServerStoppedEvent event) {
        ORE_BONUS_CACHE.clear();
    }

    private double youngLordSpawnChance(ServerLevel level, ChunkPos chunkPos, boolean continuation) {
        double chance = continuation
                ? YOUNG_LORD_CONTINUANCE_SPAWN_CHANCE : YOUNG_LORD_NORMAL_SPAWN_CHANCE;
        return chance + cachedOreBonus(level, chunkPos);
    }

    /** 取该区块的源石富集加成，命中缓存则直接返回；未加载的区块不参与加成、也不写入缓存。 */
    private static double cachedOreBonus(ServerLevel level, ChunkPos chunkPos) {
        if (level.getChunkSource().getChunkNow(chunkPos.x, chunkPos.z) == null) return 0.0D;
        long now = level.getGameTime();
        Long2ObjectMap<ChunkOreBonus> cache = ORE_BONUS_CACHE.computeIfAbsent(
                level, key -> new Long2ObjectOpenHashMap<>());
        long key = chunkPos.toLong();
        ChunkOreBonus cached = cache.get(key);
        if (cached != null && cached.expiresAt() > now) return cached.bonus();
        double bonus = computeOreBonus(level, chunkPos);
        if (cache.size() >= ORE_BONUS_CACHE_LIMIT) pruneOreBonusCache(cache, now);
        cache.put(key, new ChunkOreBonus(now + ORE_BONUS_CACHE_TICKS, bonus));
        return bonus;
    }

    /** 遍历区块的全部 section，统计黑色晶体与至纯源石的存在情况；两者都找到即提前结束。 */
    private static double computeOreBonus(ServerLevel level, ChunkPos chunkPos) {
        LevelChunk chunk = level.getChunkSource().getChunkNow(chunkPos.x, chunkPos.z);
        if (chunk == null) return 0.0D;
        boolean hasSourceOre = false;
        boolean hasPureSourceOre = false;
        for (LevelChunkSection section : chunk.getSections()) {
            if (!hasSourceOre && section.maybeHas(state -> state.is(GeneratedMod.BLACK_CRYSTAL.get()))) {
                hasSourceOre = true;
            }
            if (!hasPureSourceOre && section.maybeHas(state -> state.is(GeneratedMod.METEOR_BLOCK.get()))) {
                hasPureSourceOre = true;
            }
            if (hasSourceOre && hasPureSourceOre) break;
        }
        double bonus = 0.0D;
        if (hasSourceOre) bonus += YOUNG_LORD_SOURCE_ORE_BONUS;
        if (hasPureSourceOre) bonus += YOUNG_LORD_PURE_SOURCE_ORE_BONUS;
        return bonus;
    }

    private static void pruneOreBonusCache(Long2ObjectMap<ChunkOreBonus> cache, long now) {
        Iterator<ChunkOreBonus> iterator = cache.values().iterator();
        while (iterator.hasNext()) {
            if (iterator.next().expiresAt() <= now) iterator.remove();
        }
        if (cache.size() >= ORE_BONUS_CACHE_LIMIT) cache.clear();
    }

    private void spawnYoungDemonLords(ServerLevel level) {
        for (ServerPlayer player : level.players()) {
            // 自然生成只在天灾玩家附近进行；Hardcore 由全局天灾状态触发。
            if (!level.getLevelData().isHardcore()
                    && !CalamityLogic.isCalamityModePlayer(player)) continue;

            boolean continuation = CalamityLogic.isCivilizationContinuancePlayer(player);
            ChunkPos chunk = player.chunkPosition();
            double spawnChance = youngLordSpawnChance(level, chunk, continuation);
            if (level.getRandom().nextDouble() >= spawnChance) continue;

            net.minecraft.world.phys.AABB chunkArea = new net.minecraft.world.phys.AABB(
                    chunk.getMinBlockX(), level.getMinBuildHeight(), chunk.getMinBlockZ(),
                    chunk.getMaxBlockX() + 1.0D, level.getMaxBuildHeight(), chunk.getMaxBlockZ() + 1.0D);
            // 单区块上限统计全部存活个体，避免已认主个体旁边继续自然堆叠。
            if (level.getEntitiesOfClass(YoungDemonLord.class, chunkArea, Entity::isAlive).size() >= 1) continue;

            int radiusChunks = continuation
                    ? YOUNG_LORD_CONTINUANCE_REGION_RADIUS_CHUNKS
                    : YOUNG_LORD_NORMAL_REGION_RADIUS_CHUNKS;
            net.minecraft.world.phys.AABB regionArea = new net.minecraft.world.phys.AABB(
                    chunk.getMinBlockX() - radiusChunks * 16.0D, level.getMinBuildHeight(),
                    chunk.getMinBlockZ() - radiusChunks * 16.0D,
                    chunk.getMaxBlockX() + 1.0D + radiusChunks * 16.0D, level.getMaxBuildHeight(),
                    chunk.getMaxBlockZ() + 1.0D + radiusChunks * 16.0D);
            // 认主后不再占用区域内的两个自然生成名额。
            long unownedCount = level.getEntitiesOfClass(YoungDemonLord.class, regionArea,
                    lord -> lord.isAlive() && lord.getOwnerUUID() == null).size();
            if (unownedCount >= YOUNG_LORD_REGION_CAP) continue;

            int x = chunk.getMinBlockX() + level.getRandom().nextInt(16);
            int z = chunk.getMinBlockZ() + level.getRandom().nextInt(16);
            BlockPos spawn = level.getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING,
                    new BlockPos(x, 0, z));
            YoungDemonLord lord = GeneratedMod.YOUNG_DEMON_LORD.get().create(level);
            if (lord == null || !level.noCollision(lord, new net.minecraft.world.phys.AABB(
                    spawn.getX() + 0.2D, spawn.getY(), spawn.getZ() + 0.2D,
                    spawn.getX() + 0.8D, spawn.getY() + 1.95D, spawn.getZ() + 0.8D))) continue;
            lord.moveTo(spawn.getX() + 0.5D, spawn.getY(), spawn.getZ() + 0.5D,
                    level.getRandom().nextFloat() * 360.0F, 0.0F);
            lord.finalizeSpawn(level, level.getCurrentDifficultyAt(spawn),
                    net.minecraft.world.entity.MobSpawnType.NATURAL, null, new net.minecraft.nbt.CompoundTag());
            lord.setPersistenceRequired();
            level.addFreshEntity(lord);
        }
    }

    /**
     * 全舰防御系统：开启时特蕾西娅沿用初生魔王的自然生成机制，但概率只有其 1%。
     * 关闭后只能靠张师块召唤结构获得，不再自然刷新。
     */
    private void spawnTheresiasNaturally(ServerLevel level) {
        if (!OriginFallGameRules.isFullShipDefenseSystem(level)) return;
        for (ServerPlayer player : level.players()) {
            if (!level.getLevelData().isHardcore()
                    && !CalamityLogic.isCalamityModePlayer(player)) continue;

            boolean continuation = CalamityLogic.isCivilizationContinuancePlayer(player);
            ChunkPos chunk = player.chunkPosition();
            // 与初生魔王共用同一套概率模型（含区块内源石/至纯源石加成），再取其 1%。
            double spawnChance = youngLordSpawnChance(level, chunk, continuation) * THERESIA_SPAWN_RATE;
            if (level.getRandom().nextDouble() >= spawnChance) continue;

            net.minecraft.world.phys.AABB chunkArea = new net.minecraft.world.phys.AABB(
                    chunk.getMinBlockX(), level.getMinBuildHeight(), chunk.getMinBlockZ(),
                    chunk.getMaxBlockX() + 1.0D, level.getMaxBuildHeight(), chunk.getMaxBlockZ() + 1.0D);
            if (level.getEntitiesOfClass(Theresia.class, chunkArea, Entity::isAlive).size()
                    >= THERESIA_CHUNK_CAP) continue;

            int radiusChunks = continuation
                    ? YOUNG_LORD_CONTINUANCE_REGION_RADIUS_CHUNKS
                    : YOUNG_LORD_NORMAL_REGION_RADIUS_CHUNKS;
            net.minecraft.world.phys.AABB regionArea = new net.minecraft.world.phys.AABB(
                    chunk.getMinBlockX() - radiusChunks * 16.0D, level.getMinBuildHeight(),
                    chunk.getMinBlockZ() - radiusChunks * 16.0D,
                    chunk.getMaxBlockX() + 1.0D + radiusChunks * 16.0D, level.getMaxBuildHeight(),
                    chunk.getMaxBlockZ() + 1.0D + radiusChunks * 16.0D);
            long unownedCount = level.getEntitiesOfClass(Theresia.class, regionArea,
                    lady -> lady.isAlive() && lady.getOwnerUUID() == null).size();
            if (unownedCount >= THERESIA_REGION_CAP) continue;

            int x = chunk.getMinBlockX() + level.getRandom().nextInt(16);
            int z = chunk.getMinBlockZ() + level.getRandom().nextInt(16);
            BlockPos spawn = level.getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING,
                    new BlockPos(x, 0, z));
            Theresia theresia = GeneratedMod.THERESIA.get().create(level);
            if (theresia == null || !level.noCollision(theresia, new net.minecraft.world.phys.AABB(
                    spawn.getX() + 0.2D, spawn.getY(), spawn.getZ() + 0.2D,
                    spawn.getX() + 0.8D, spawn.getY() + 1.95D, spawn.getZ() + 0.8D))) continue;
            theresia.moveTo(spawn.getX() + 0.5D, spawn.getY(), spawn.getZ() + 0.5D,
                    level.getRandom().nextFloat() * 360.0F, 0.0F);
            theresia.finalizeSpawn(level, level.getCurrentDifficultyAt(spawn),
                    net.minecraft.world.entity.MobSpawnType.NATURAL, null, new net.minecraft.nbt.CompoundTag());
            theresia.setPersistenceRequired();
            level.addFreshEntity(theresia);
            player.displayClientMessage(Component.literal("全舰防御系统：特蕾西娅已在这片大地上苏醒"), true);
        }
    }

    private void summonPrincesses(ServerLevel level) {
        if (level.getGameTime() % 20L != 0L) return;
        for (ServerPlayer player : level.players()) {
            List<YoungDemonLord> candidates = level.getEntitiesOfClass(YoungDemonLord.class,
                    player.getBoundingBox().inflate(16.0D), lord -> lord.isAlive()
                            && lord.distanceToSqr(player) <= 256.0D
                            && !lord.hasEffect(net.minecraft.world.effect.MobEffects.REGENERATION));
            if (candidates.size() < 5) continue;
            boolean princessAlreadyPresent = !level.getEntitiesOfClass(CalamityPrincess.class,
                    player.getBoundingBox().inflate(16.0D), princess -> princess.isAlive()
                            && princess.distanceToSqr(player) <= 256.0D).isEmpty();
            if (princessAlreadyPresent) continue;

            CalamityPrincess princess = GeneratedMod.CALAMITY_PRINCESS.get().create(level);
            if (princess == null) continue;
            princess.moveTo(player.getX(), player.getY(), player.getZ(), player.getYRot(), 0.0F);
            princess.setOwnerUUID(player.getUUID());
            level.addFreshEntity(princess);
            candidates.stream().sorted(Comparator.comparingDouble(lord -> lord.distanceToSqr(player)))
                    .limit(5).forEach(lord -> lord.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                            net.minecraft.world.effect.MobEffects.REGENERATION, Integer.MAX_VALUE, 1, false, true, true)));
        }
    }

    private void initializeHardcore(ServerLevel level, DisasterData data) {
        if (!level.getLevelData().isHardcore() || data.isHardcoreInitialized()) return;
        data.activateHardcore();
        data.initializeHardcore();
    }

    private void removeHardcoreSources(ServerLevel level) {
        if (!level.getLevelData().isHardcore()) return;
        for (ServerPlayer player : level.players()) removeSourceItems(player);
        for (ItemEntity item : level.getEntities(EntityType.ITEM,
                entity -> entity.getItem().is(GeneratedMod.SOURCE_OF_RUIN.get()))) item.discard();
    }

    private void removeSourceItems(Player player) {
        for (int slot = 0; slot < player.getInventory().getContainerSize(); slot++) {
            ItemStack stack = player.getInventory().getItem(slot);
            if (stack.is(GeneratedMod.SOURCE_OF_RUIN.get())) player.getInventory().setItem(slot, ItemStack.EMPTY);
        }
    }

    private void spawnForAnchor(ServerLevel level, LivingEntity anchor, double radius) {
        level.addFreshEntity(MeteorEntity.createNaturalForPlayer(level, anchor, radius));
    }

    private static boolean levelHasCivilizationContinuancePlayer(LivingEntity source) {
        if (!(source.level() instanceof ServerLevel level)) return false;
        // 文明延续只允许在单人存档启用，因此信使交易渠道按该存档全局降率。
        return level.players().stream().anyMatch(CalamityLogic::isCivilizationContinuancePlayer);
    }

    @SubscribeEvent
    public void onVillagerTrades(VillagerTradesEvent event) {
        if (event.getType() == VillagerProfession.NONE || event.getType() == VillagerProfession.NITWIT) return;
        if (event.getTrades().containsKey(1) && !event.getTrades().get(1).isEmpty()) {
            event.getTrades().get(1).add(new CalamityTrade());
        }
    }

    @SubscribeEvent
    public void onLivingDrops(LivingDropsEvent event) {
        // 三位人形首领的专属武器只允许通过死亡模型右键拾取，原实体死亡不直接掉落。
        if (event.getEntity() instanceof Theresia || event.getEntity() instanceof Priestess
                || event.getEntity() instanceof Prophet) {
            event.getDrops().removeIf(drop -> GeneratedMod.isModWeapon(drop.getItem()));
        }
        if (!(event.getEntity() instanceof Theresia) && !(event.getEntity() instanceof Priestess)
                && !(event.getEntity() instanceof Prophet)) {
            forceModWeaponDrops(event);
        }
        // 「女祭司」普瑞赛斯被彻底击败（复活被阻断的死亡）时，额外掉落「毁灭与救赎」与「源石美化包」。
        if (event.getEntity() instanceof Priestess
                && event.getEntity().getPersistentData().getBoolean(CalamityMob.THOROUGH_DEFEAT_TAG)) {
            for (ItemStack thoroughDrop : List.of(
                    new ItemStack(GeneratedMod.DESTRUCTION_AND_SALVATION.get()),
                    new ItemStack(GeneratedMod.SOURCE_ORE_BEAUTIFICATION_PACK.get()))) {
                event.getDrops().add(new ItemEntity(event.getEntity().level(), event.getEntity().getX(),
                        event.getEntity().getY(), event.getEntity().getZ(), thoroughDrop));
            }
        }
        boolean continuation = event.getEntity().level() instanceof ServerLevel level
                && level.getServer().getPlayerList().getPlayers().stream()
                .anyMatch(CalamityLogic::isCivilizationContinuancePlayer);
        if (event.getEntity().getType() == EntityType.IRON_GOLEM
                && event.getEntity().level().getRandom().nextDouble() < (continuation ? 0.001D : 0.01D)) {
            event.getDrops().add(new ItemEntity(event.getEntity().level(), event.getEntity().getX(),
                    event.getEntity().getY(), event.getEntity().getZ(), new ItemStack(GeneratedMod.OATH_OF_BABEL.get())));
        }
        if (!(event.getEntity() instanceof Player) && event.getSource().getEntity() instanceof LivingEntity
                && event.getEntity().level().getRandom().nextDouble() < 0.00325D) {
            event.getDrops().add(new ItemEntity(event.getEntity().level(), event.getEntity().getX(),
                    event.getEntity().getY(), event.getEntity().getZ(), new ItemStack(GeneratedMod.METEOR_STAFF.get())));
        }
    }

    /**
     * “这片大地”的传承：开启时，生物（玩家除外）持有的本模组武器必定掉落。
     * 原版装备掉落概率只有 8.5%，这里在掉落事件里补齐缺失的那一份，不叠加重复掉落。
     */
    private void forceModWeaponDrops(LivingDropsEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity instanceof Player || !(entity.level() instanceof ServerLevel level)
                || !OriginFallGameRules.isLandInheritance(level)) return;
        for (net.minecraft.world.entity.EquipmentSlot slot
                : new net.minecraft.world.entity.EquipmentSlot[]{
                net.minecraft.world.entity.EquipmentSlot.MAINHAND,
                net.minecraft.world.entity.EquipmentSlot.OFFHAND}) {
            ItemStack held = entity.getItemBySlot(slot);
            if (!GeneratedMod.isModWeapon(held)) continue;
            boolean alreadyDropped = event.getDrops().stream()
                    .anyMatch(item -> GeneratedMod.isModWeapon(item.getItem())
                            && item.getItem().is(held.getItem()));
            if (alreadyDropped) continue;
            ItemEntity drop = new ItemEntity(level, entity.getX(),
                    entity.getY() + 0.2D, entity.getZ(), held.copy());
            drop.setPickUpDelay(20);
            event.getDrops().add(drop);
        }
    }

    private static final class CalamityTrade implements net.minecraft.world.entity.npc.VillagerTrades.ItemListing {
        @Override
        public MerchantOffer getOffer(net.minecraft.world.entity.Entity trader, net.minecraft.util.RandomSource random) {
            boolean continuation = trader instanceof LivingEntity living
                    && levelHasCivilizationContinuancePlayer(living);
            if (random.nextFloat() >= (continuation ? 0.00325F : 0.0325F)) return null;
            return new MerchantOffer(new ItemStack(Items.DIRT, 32), ItemStack.EMPTY,
                    new ItemStack(GeneratedMod.OATH_OF_BABEL.get()), 1, 10, 0.05F);
        }
    }
}
