package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;

/**
 * 「扒臀长舞」客户端姿势：把 {@link BossDanceKeyframesVanilla} 里由
 * {@code work/generate_boss_dance.py} 生成的 Blockbench 关键帧采样到
 * {@link CalamityHumanoidModel} 的玩家骨架上。
 *
 * <p>整段 28.86 秒（577 tick；编排 30.3 秒按需求整体降为基础速度 ×1.05）分成十段：深蹲夹臀 → 前倾拍臀 → 岔腿交替后退 →
 * 抱胸摆臂 → 扶腿撅臀跳 → 趴地撅臀撑起（此处按需求起跳腾空） → 黑帮摇（编排 20 秒） → 站直跨步跳 →
 * 前倾蹦跳、右手拍臀、左手指向身后 → 转身五圈后<b>左腿向左伸</b>、深下腰把左手从
 * 膝盖一路摸到大腿根。舞曲播放期间这段动画循环播放。</p>
 *
 * <p><b>本类只服务「无史诗战斗」的原模组渲染路径，数据按本轮需求单独编辑过</b>：
 * 身子、胳膊和腿的全部动作都翻到了背面——整套关键帧是史诗战斗档
 * {@link BossDanceKeyframes} 绕前后镜面的镜像（旋转 (x,y,z)→(-x,-y,z)、位移 z→-z，
 * 镜像共轭对 ZYX 欧拉角逐骨骼严格成立，烘焙好的 IK 落点跟着一起翻），原本的弯腰
 * 现在是下腰、朝观众的前后动作全部转到身后，转身五圈随全身一起反向；侧向语义
 * （向左 zRot 为负、向右为正）在镜像下不变，收势一式回退为<b>左腿向左伸腿</b>。
 * 头节点不带任何独立角度（{@link BossDanceKeyframesVanilla#HEAD} 旋转整段为零），
 * 也不再叠加实体的 netHeadYaw/headPitch——<b>头完全跟随身子移动</b>。
 * 有史诗战斗时走 {@code OriginfallDanceAnimation}（消费未镜像的
 * {@link BossDanceKeyframes}，收势仍是左腿向右伸交叉＋70° 扭头层），那一档舞蹈
 * 不变；服务端 {@link BossTauntLogic} 的节拍、后退位移与实体逻辑两档共用，也不变。</p>
 *
 * <h2>骨架与轴心（这一版的两个关键修正）</h2>
 * <p><b>1. 躯干绕胯转，不再绕脖子转。</b>原版玩家骨架里 {@code body} 的轴心在脖子上
 * （本地原点 y=0），一弯腰整块躯干就绕着脖子甩出去，胯部与两条腿之间裂开一道大口子——
 * 这就是「舞蹈身体和腿分开」的原因。Blockbench 原始模型里躯干轴心本来就在胯
 * （y=12），所以这里按「绕任意轴心旋转」的通用做法给躯干补一个位置补偿
 * {@code pos = Hip − R_body·Hip}，让躯干、头、双臂一起绕胯旋转，腰胯始终连在腿上。</p>
 *
 * <p><b>2. 肘与膝回来了。</b>{@link CalamityHumanoidModel} 在标准玩家骨架上加了两节
 * 小臂与两节小腿，本类把关键帧里的 {@code right_fore}/{@code left_fore}
 * （屈肘）与 {@code right_shin}/{@code left_shin}（屈膝）原样驱动上去，屈肘屈膝可达
 * 150° 以上，黑帮摇的抬膝、抱头等动作都完整了。</p>
 *
 * <h2>父子合成</h2>
 * <p>头、双臂与躯干在原版骨架里是平级的兄弟骨骼，躯干转动不会自动带走它们；关键帧里
 * {@code head}/{@code arm} 存的是相对躯干的角度，所以这里自己做
 * {@code R = R_body × R_rel} 的旋转合成（逐轴相加在躯干同时俯仰与扭转时会串轴），
 * 并按躯干绕胯转过的向量搬动肩轴心：{@code pos = Hip + R_body·(A − Hip)}。</p>
 *
 * <h2>没有史诗战斗时的简化</h2>
 * <p>装了史诗战斗时这条路径根本不会被调用——舞程由 {@code OriginfallDanceAnimation}
 * 直接驱动史诗战斗自己的 BIPED 骨架。所以本类就是「纯模组渲染」那一档：按需求把弯腰
 * 幅度压下来（{@link #LEAN_SCALE}、{@link #LEAN_LIMIT}），舞蹈保持直立、简单，
 * 不会出现趴地撅臀那种极端前倾；屈肘屈膝与整体结构照常保留。</p>
 */
public final class BossTauntPose {
    private static final float DEG = (float) (Math.PI / 180.0D);
    /** 胯部轴心高度（原版骨架躯干底端就在 y=12，方块凳模型里躯干轴心也在这里）。 */
    private static final float HIP_Y = 12.0F;
    /** 右/左肩轴心在 root 本地系里的 X（原版骨架肩轴心偏向身体一侧，并不对称）。 */
    private static final float ARM_BASE_X = 5.0F;
    /** 肩轴心相对 root 原点的 Y（+Y 朝下）。 */
    private static final float ARM_BASE_Y = 2.0F;
    /** 无史诗战斗时躯干前倾（弯腰）幅度的缩放。 */
    private static final float LEAN_SCALE = 0.45F;
    /** 无史诗战斗时躯干前倾/后仰的硬上限（度）。 */
    private static final float LEAN_LIMIT = 45.0F;

    // 采样缓冲，避免每帧分配
    private static final float[] ROOT = new float[6];
    private static final float[] BODY = new float[6];
    private static final float[] RIGHT_ARM = new float[6];
    private static final float[] LEFT_ARM = new float[6];
    private static final float[] RIGHT_FORE = new float[6];
    private static final float[] LEFT_FORE = new float[6];
    private static final float[] RIGHT_LEG = new float[6];
    private static final float[] LEFT_LEG = new float[6];
    private static final float[] RIGHT_SHIN = new float[6];
    private static final float[] LEFT_SHIN = new float[6];
    private static final float[] DELTA = new float[3];
    private static final float[] REL = new float[3];
    private static final float[] MAT_A = new float[9];
    private static final float[] MAT_B = new float[9];
    private static final float[] MAT_C = new float[9];

    private BossTauntPose() {
    }

    /**
     * 覆盖 vanilla 肢体姿势。在 {@code super.setupAnim} 之后调用；不在跳舞（剩余 tick ≤0）时
     * 只把自己动过的量复位，让走位/攻击动画照常接管。
     *
     * @param netHeadYaw 原版算好的头部偏航（{@code yHeadRot − yBodyRot}）。本轮需求
     *                   「头完全跟随身子移动」后，跳舞期间<b>不再</b>把它合成进头——
     *                   头逐帧照抄躯干旋转；非跳舞时段原版仍会自行写头，不受影响
     * @param headPitch  原版算好的头部俯仰（实体 {@code xRot}），口径同上，跳舞期间忽略
     */
    public static void apply(CalamityHumanoidModel<?> model, CalamityMob mob, float ageInTicks,
                             float netHeadYaw, float headPitch) {
        applyDance(model, mob.getTauntTicks(), mob.getTauntTotalTicks(), ageInTicks);
    }

    /**
     * 深蓝之树本尊（外部实体）的代跳姿势：本尊拿不到 {@code CalamityMob} 的同步实体数据，
     * 舞程由客户端舞蹈会话表解析后送进来，其余走与替身完全相同的关键帧通道。
     */
    public static void applyNative(CalamityHumanoidModel<?> model, int remaining, int total, float ageInTicks) {
        applyDance(model, remaining, total, ageInTicks);
    }

    private static void applyDance(CalamityHumanoidModel<?> model, int remaining, int total, float ageInTicks) {
        if (remaining <= 0) {
            clear(model);
            model.setDanceJunctionsVisible(false);
            return;
        }
        // 需求「肢体与躯干平滑链接」：跳舞期间点亮衔接填缝块（颈/骨盆/双肩/双髋），
        // 深蹲、趴地撅臀、收势 62° 交叉伸腿这些大角度里，胯/肩/颈张开的楔形缺口
        // 由它们随下游骨骼转动补上；舞停立刻熄灭，普通动画与加块之前逐像素一致
        // （历史上常显版会在走路摆臂时戳穿画面，见 CalamityHumanoidModel 类注释）。
        model.setDanceJunctionsVisible(true);
        total = Math.max(remaining, total);
        // 用渲染帧时钟的小数部分补间，20Hz 的同步数据也能走出连续动作。
        float elapsed = (total - remaining) + Mth.frac(ageInTicks);
        float t = elapsed % BossDanceKeyframesVanilla.TICKS;
        if (t < 0.0F) t += BossDanceKeyframesVanilla.TICKS;

        // 纯模组档数据（BossDanceKeyframesVanilla）：全身镜像翻到背面、收势左腿
        // 向左、头节点无独立角度。EF 档 BossDanceKeyframes 不在本类消费。
        sample(BossDanceKeyframesVanilla.ROOT, t, ROOT);
        sample(BossDanceKeyframesVanilla.BODY, t, BODY);
        // HEAD 轨道整段为零（头完全跟随身子），不采样、不叠加，见下方头部块。
        sample(BossDanceKeyframesVanilla.RIGHT_ARM, t, RIGHT_ARM);
        sample(BossDanceKeyframesVanilla.LEFT_ARM, t, LEFT_ARM);
        sample(BossDanceKeyframesVanilla.RIGHT_FORE, t, RIGHT_FORE);
        sample(BossDanceKeyframesVanilla.LEFT_FORE, t, LEFT_FORE);
        sample(BossDanceKeyframesVanilla.RIGHT_LEG, t, RIGHT_LEG);
        sample(BossDanceKeyframesVanilla.LEFT_LEG, t, LEFT_LEG);
        sample(BossDanceKeyframesVanilla.RIGHT_SHIN, t, RIGHT_SHIN);
        sample(BossDanceKeyframesVanilla.LEFT_SHIN, t, LEFT_SHIN);

        // 纯模组渲染这一档：把弯腰幅度压下来，舞蹈直立、简单。
        BODY[0] = Mth.clamp(BODY[0] * LEAN_SCALE, -LEAN_LIMIT, LEAN_LIMIT);

        // 整体（root）：旋转负责原地转圈，位移负责下蹲高度与蹦跳。
        model.rootPart().xRot = ROOT[0] * DEG;
        model.rootPart().yRot = ROOT[1] * DEG;
        model.rootPart().zRot = ROOT[2] * DEG;
        model.rootPart().x = ROOT[3];
        model.rootPart().y = ROOT[4];
        model.rootPart().z = ROOT[5];

        // 躯干：绕胯轴（HIP_Y）旋转——本体角照写，位置补偿 (Hip − R·Hip) 把轴心从脖子搬到胯。
        hipOffset(BODY[0], BODY[1], BODY[2], 0.0F, 0.0F, 0.0F, DELTA);
        model.body.x = DELTA[0];
        model.body.y = DELTA[1];
        model.body.z = DELTA[2];
        model.body.xRot = BODY[0] * DEG;
        model.body.yRot = BODY[1] * DEG;
        model.body.zRot = BODY[2] * DEG;

        // 头：需求「头完全跟随身子移动」——本档关键帧的头节点旋转已整段清零，
        // 这里也不再叠加生物自身的 netHeadYaw/headPitch（上一版的前置合成按本轮
        // 需求撤除）：头的旋转直接照抄躯干，位移补偿与躯干同一份 DELTA，逐帧与
        // 上身同转同倾，不做任何独立扭头。非跳舞时段头仍走原版（clear 只复位
        // vanilla 不管的分量，见下）。
        model.head.xRot = BODY[0] * DEG;
        model.head.yRot = BODY[1] * DEG;
        model.head.zRot = BODY[2] * DEG;
        model.head.x = DELTA[0];
        model.head.y = DELTA[1];
        model.head.z = DELTA[2];

        // 双臂：跟随躯干，肩轴心在 root 本地系是 (∓5, 2, 0)。
        hipOffset(BODY[0], BODY[1], BODY[2], -ARM_BASE_X, ARM_BASE_Y, 0.0F, DELTA);
        compose(BODY[0], BODY[1], BODY[2], RIGHT_ARM[0], RIGHT_ARM[1], RIGHT_ARM[2], REL);
        model.rightArm.x = DELTA[0];
        model.rightArm.y = DELTA[1];
        model.rightArm.z = DELTA[2];
        model.rightArm.xRot = REL[0] * DEG;
        model.rightArm.yRot = REL[1] * DEG;
        model.rightArm.zRot = REL[2] * DEG;
        hipOffset(BODY[0], BODY[1], BODY[2], ARM_BASE_X, ARM_BASE_Y, 0.0F, DELTA);
        compose(BODY[0], BODY[1], BODY[2], LEFT_ARM[0], LEFT_ARM[1], LEFT_ARM[2], REL);
        model.leftArm.x = DELTA[0];
        model.leftArm.y = DELTA[1];
        model.leftArm.z = DELTA[2];
        model.leftArm.xRot = REL[0] * DEG;
        model.leftArm.yRot = REL[1] * DEG;
        model.leftArm.zRot = REL[2] * DEG;

        // 屈肘：小臂相对上臂转，关键帧里只有俯仰。
        model.foreArm(HumanoidArm.RIGHT).xRot = RIGHT_FORE[0] * DEG;
        model.foreArm(HumanoidArm.LEFT).xRot = LEFT_FORE[0] * DEG;

        // 腿挂在 root 上，不受躯干影响；屈膝由小腿相对大腿转。
        // 方向语义（已确认）：双腿夹角就是两条腿各自的 z 轴夹角——左腿向左为负、
        // 右腿向右为正；大腿与小腿的夹角走小腿的俯仰（xRot）。早先「V 型开膝 /
        // 收脚」那层对 y、z 的改写已按需求撤销，关键帧里小腿的 yRot/zRot 恒为 0，
        // 这里照常透传三个分量只是为了让轨道保持通用。
        model.rightLeg.xRot = RIGHT_LEG[0] * DEG;
        model.rightLeg.yRot = RIGHT_LEG[1] * DEG;
        model.rightLeg.zRot = RIGHT_LEG[2] * DEG;
        model.leftLeg.xRot = LEFT_LEG[0] * DEG;
        model.leftLeg.yRot = LEFT_LEG[1] * DEG;
        model.leftLeg.zRot = LEFT_LEG[2] * DEG;
        model.shin(HumanoidArm.RIGHT).xRot = RIGHT_SHIN[0] * DEG;
        model.shin(HumanoidArm.RIGHT).yRot = RIGHT_SHIN[1] * DEG;
        model.shin(HumanoidArm.RIGHT).zRot = RIGHT_SHIN[2] * DEG;
        model.shin(HumanoidArm.LEFT).xRot = LEFT_SHIN[0] * DEG;
        model.shin(HumanoidArm.LEFT).yRot = LEFT_SHIN[1] * DEG;
        model.shin(HumanoidArm.LEFT).zRot = LEFT_SHIN[2] * DEG;
    }

    /** 舞停后复位本类动过的量；vanilla 每帧会自己重置旋转，这里只补它不管的那些。 */
    private static void clear(CalamityHumanoidModel<?> model) {
        model.rootPart().xRot = 0.0F;
        model.rootPart().yRot = 0.0F;
        model.rootPart().zRot = 0.0F;
        model.rootPart().x = 0.0F;
        model.rootPart().y = 0.0F;
        model.rootPart().z = 0.0F;
        // 躯干只有 xRot 由 vanilla 每帧清掉，剩余的 y/z 与位移是这里写的，不主动复位
        // 舞停后上身会一直扭着、甚至整块躯干悬在胯外。
        model.body.x = 0.0F;
        model.body.y = 0.0F;
        model.body.z = 0.0F;
        model.body.yRot = 0.0F;
        model.body.zRot = 0.0F;
        // 头部只复位 vanilla 不管的那几项：xRot/yRot vanilla 每帧都会从 headPitch/netHeadYaw
        // 重新赋值，这里清零反而把「按现有方向的扭头」抹掉（非跳舞时段头钉死的另一个原因）。
        model.head.zRot = 0.0F;
        model.head.x = 0.0F;
        model.head.y = 0.0F;
        model.head.z = 0.0F;
        // 肩轴心回到原版 PartPose 的位置。
        model.rightArm.x = -ARM_BASE_X;
        model.leftArm.x = ARM_BASE_X;
        model.rightArm.y = ARM_BASE_Y;
        model.leftArm.y = ARM_BASE_Y;
        model.rightArm.z = 0.0F;
        model.leftArm.z = 0.0F;
        // 肘与膝回到伸直。小腿的 y/z（收脚）vanilla 不会自己清，必须复位。
        model.foreArm(HumanoidArm.RIGHT).xRot = 0.0F;
        model.foreArm(HumanoidArm.LEFT).xRot = 0.0F;
        model.shin(HumanoidArm.RIGHT).xRot = 0.0F;
        model.shin(HumanoidArm.RIGHT).yRot = 0.0F;
        model.shin(HumanoidArm.RIGHT).zRot = 0.0F;
        model.shin(HumanoidArm.LEFT).xRot = 0.0F;
        model.shin(HumanoidArm.LEFT).yRot = 0.0F;
        model.shin(HumanoidArm.LEFT).zRot = 0.0F;
    }

    /**
     * 绕胯轴旋转时，轴心为 {@code P} 的部件该补的位移：{@code pos = Hip + R_body·(P − Hip)}。
     * 传入 {@code P=(0,0,0)} 得到躯干/头的补偿；传入肩轴心得到两臂的补偿。
     */
    private static void hipOffset(float bx, float by, float bz, float px, float py, float pz, float[] out) {
        rotXYZ(bx, by, bz, px, py - HIP_Y, pz, out);
        out[1] = HIP_Y + out[1];
    }

    /**
     * 把「躯干旋转 + 肢体相对角」合成成肢体在 root 坐标系里的 ZYX 欧拉角。
     *
     * <p>原版骨架里头与双臂和躯干是<b>平级</b>的兄弟骨骼，所以肢体最终朝向必须自己做
     * 父子合成 {@code R = Rz(bz)Ry(by)Rx(bx) · Rz(lz)Ry(ly)Rx(lx)}。早先直接分量相加
     * （{@code bx+lx, by+ly, bz+lz}）只在躯干仅有一个轴有角度时成立；躯干一旦同时俯仰
     * 又扭转（黑帮摇的扭胯、P9 的回头指向），串轴误差能到 75°，头和胳膊就会从躯干上甩开。
     * 合成结果再分解回 ZYX 欧拉角写进 ModelPart，与原版 {@code translateAndRotate} 的顺序一致。</p>
     */
    private static void compose(float bx, float by, float bz, float lx, float ly, float lz, float[] out) {
        zyx(bx, by, bz, MAT_A);
        zyx(lx, ly, lz, MAT_B);
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                MAT_C[r * 3 + c] = MAT_A[r * 3] * MAT_B[c]
                        + MAT_A[r * 3 + 1] * MAT_B[3 + c]
                        + MAT_A[r * 3 + 2] * MAT_B[6 + c];
            }
        }
        double y = Math.asin(Mth.clamp(-MAT_C[6], -1.0F, 1.0F));
        out[0] = (float) Math.toDegrees(Mth.atan2(MAT_C[7], MAT_C[8]));
        out[1] = (float) Math.toDegrees(y);
        out[2] = (float) Math.toDegrees(Mth.atan2(MAT_C[3], MAT_C[0]));
    }

    /** 行主序写入 {@code Rz(z)·Ry(y)·Rx(x)}，与 {@code ModelPart.translateAndRotate} 的语义一致。 */
    private static void zyx(float xDeg, float yDeg, float zDeg, float[] m) {
        double rx = xDeg * DEG;
        double ry = yDeg * DEG;
        double rz = zDeg * DEG;
        double cx = Math.cos(rx);
        double sx = Math.sin(rx);
        double cy = Math.cos(ry);
        double sy = Math.sin(ry);
        double cz = Math.cos(rz);
        double sz = Math.sin(rz);
        m[0] = (float) (cz * cy);
        m[1] = (float) (cz * sy * sx - sz * cx);
        m[2] = (float) (cz * sy * cx + sz * sx);
        m[3] = (float) (sz * cy);
        m[4] = (float) (sz * sy * sx + cz * cx);
        m[5] = (float) (sz * sy * cx - cz * sx);
        m[6] = (float) (-sy);
        m[7] = (float) (cy * sx);
        m[8] = (float) (cy * cx);
    }

    /** 把 (x, y, z) 按 {@code rotationZYX(zRot, yRot, xRot)} 旋转，与 ModelPart 的语义一致。 */
    private static void rotXYZ(float xDeg, float yDeg, float zDeg, float x, float y, float z, float[] out) {
        double rx = xDeg * DEG;
        double ry = yDeg * DEG;
        double rz = zDeg * DEG;
        double cx = Math.cos(rx);
        double sx = Math.sin(rx);
        double cy = Math.cos(ry);
        double sy = Math.sin(ry);
        double cz = Math.cos(rz);
        double sz = Math.sin(rz);
        // 与 ModelPart 相同的顺序：先绕 X，再绕 Y，最后绕 Z
        double y1 = y * cx - z * sx;
        double z1 = y * sx + z * cx;
        double x2 = x * cy + z1 * sy;
        double z2 = -x * sy + z1 * cy;
        out[0] = (float) (x2 * cz - y1 * sz);
        out[1] = (float) (x2 * sz + y1 * cz);
        out[2] = (float) z2;
    }

    /**
     * 在关键帧数组里线性/平滑取样。数组 8 个数字一组：
     * {@code time, xRot, yRot, zRot, posX, posY, posZ, interp}。
     */
    private static void sample(float[] kf, float t, float[] out) {
        int n = kf.length / 8;
        if (n <= 0) {
            for (int c = 0; c < 6; c++) out[c] = 0.0F;
            return;
        }
        int i = 0;
        while (i < n - 1 && kf[(i + 1) * 8] <= t) i++;
        int j = Math.min(i + 1, n - 1);
        float t0 = kf[i * 8];
        float t1 = kf[j * 8];
        float f = t1 > t0 ? (t - t0) / (t1 - t0) : 0.0F;
        if (f < 0.0F) f = 0.0F;
        if (f > 1.0F) f = 1.0F;
        if (kf[i * 8 + 7] > 0.5F) f = f * f * (3.0F - 2.0F * f);
        int a = i * 8 + 1;
        int b = j * 8 + 1;
        for (int c = 0; c < 6; c++) {
            out[c] = kf[a + c] + (kf[b + c] - kf[a + c]) * f;
        }
    }
}
