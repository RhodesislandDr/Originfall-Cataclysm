package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.CalamityHumanoidModel;
import cn.blockforge.generated.originfallcataclysm.Theresia;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;
import com.mojang.blaze3d.vertex.PoseStack;

/** 特蕾西娅使用原版玩家人形骨骼，但不渲染实际装备的护甲。 */
public final class TheresiaRenderer extends MobRenderer<Theresia, CalamityHumanoidModel<Theresia>> {
    private final ResourceLocation texture;

    public TheresiaRenderer(EntityRendererProvider.Context context, ResourceLocation texture,
                             ModelLayerLocation layer) {
        super(context, new CalamityHumanoidModel<>(context.bakeLayer(layer)), 0.5F);
        this.texture = texture;
        // 护甲仍用于实际属性计算，但特蕾西娅不渲染盔甲层。
        addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
    }

    @Override
    public ResourceLocation getTextureLocation(Theresia entity) {
        return texture;
    }

    @Override
    public void render(Theresia entity, float yaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        poseStack.scale(0.9375F, 0.9375F, 0.9375F);
        super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
        poseStack.popPose();
    }
}
