package cn.blockforge.generated.originfallcataclysm.mixin;

import cn.blockforge.generated.originfallcataclysm.CalamityLogic;
import cn.blockforge.generated.originfallcataclysm.GeneratedMod;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 让本模组状态效果穿透免疫检查，并直接维护 LivingEntity 的效果列表。
 *
 * <p>坍缩（{@code originfall_cataclysm:collapse}）另有一条更强的规则：
 * <b>无法以任何形式清除</b>。因此这里额外拦下 {@code removeEffect}、
 * {@code removeEffectNoUpdate} 与 {@code removeAllEffects}——牛奶桶、{@code /effect clear}、
 * 其他模组的净化、死亡清理等入口都不能把它洗掉，其余效果照常被清除。</p>
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityEffectImmunityMixin {
    @Shadow @Final
    private Map<MobEffect, MobEffectInstance> activeEffects;

    @Shadow
    protected abstract void onEffectAdded(MobEffectInstance effect, Entity source);

    @Shadow
    protected abstract void onEffectUpdated(MobEffectInstance effect, boolean reapplyEffect, Entity source);

    @Inject(method = "canBeAffected", at = @At("HEAD"), cancellable = true)
    private void originfall$allowModEffects(MobEffectInstance effect,
                                             CallbackInfoReturnable<Boolean> callback) {
        LivingEntity entity = (LivingEntity) (Object) this;
        // 坍缩按设定感染所有生物，不受源石感染白名单与任何免疫影响。
        if (CalamityLogic.isCollapseEffect(effect)
                || (CalamityLogic.isOriginFallModEffect(effect)
                && !CalamityLogic.isSourceOreInfectionImmune(entity))) {
            callback.setReturnValue(true);
        }
    }

    /**
     * 绕过 addEffect 的免疫入口，直接把效果放进原版效果表；已有效果沿用原版 update 规则叠层。
     * 白名单目标不接受源石感染，并清理可能由旧逻辑留下的残留效果；坍缩不受白名单限制。
     */
    @Inject(method = "addEffect(Lnet/minecraft/world/effect/MobEffectInstance;Lnet/minecraft/world/entity/Entity;)Z",
            at = @At("HEAD"), cancellable = true)
    private void originfall$directlyAddModEffect(MobEffectInstance effect, Entity source,
                                                   CallbackInfoReturnable<Boolean> callback) {
        if (!CalamityLogic.isOriginFallModEffect(effect)) return;

        LivingEntity entity = (LivingEntity) (Object) this;
        if (!CalamityLogic.isCollapseEffect(effect) && CalamityLogic.isSourceOreInfectionImmune(entity)) {
            entity.removeEffect(effect.getEffect());
            callback.setReturnValue(false);
            return;
        }

        MobEffectInstance current = activeEffects.get(effect.getEffect());
        if (current == null) {
            activeEffects.put(effect.getEffect(), effect);
            onEffectAdded(effect, source);
            callback.setReturnValue(true);
        } else if (current.update(effect)) {
            onEffectUpdated(current, true, source);
            callback.setReturnValue(true);
        } else {
            callback.setReturnValue(false);
        }
    }

    /** forceAddEffect 同样直接操作效果表，保证强制附加与强制叠层不再受免疫代码影响。 */
    @Inject(method = "forceAddEffect(Lnet/minecraft/world/effect/MobEffectInstance;Lnet/minecraft/world/entity/Entity;)V",
            at = @At("HEAD"), cancellable = true)
    private void originfall$directlyForceAddModEffect(MobEffectInstance effect, Entity source,
                                                       CallbackInfo callback) {
        if (!CalamityLogic.isOriginFallModEffect(effect)) return;

        LivingEntity entity = (LivingEntity) (Object) this;
        if (!CalamityLogic.isCollapseEffect(effect) && CalamityLogic.isSourceOreInfectionImmune(entity)) {
            entity.removeEffect(effect.getEffect());
            callback.cancel();
            return;
        }

        MobEffectInstance current = activeEffects.get(effect.getEffect());
        if (current == null) {
            activeEffects.put(effect.getEffect(), effect);
            onEffectAdded(effect, source);
        } else if (current.update(effect)) {
            onEffectUpdated(current, true, source);
        }
        callback.cancel();
    }

    /** 坍缩无法被单独移除。 */
    @Inject(method = "removeEffect(Lnet/minecraft/world/effect/MobEffect;)Z",
            at = @At("HEAD"), cancellable = true)
    private void originfall$protectCollapse(MobEffect effect, CallbackInfoReturnable<Boolean> callback) {
        if (effect == GeneratedMod.COLLAPSE.get()) callback.setReturnValue(false);
    }

    /** 坍缩无法被无更新移除。 */
    @Inject(method = "removeEffectNoUpdate(Lnet/minecraft/world/effect/MobEffect;)Lnet/minecraft/world/effect/MobEffectInstance;",
            at = @At("HEAD"), cancellable = true)
    private void originfall$protectCollapseNoUpdate(MobEffect effect,
                                                     CallbackInfoReturnable<MobEffectInstance> callback) {
        if (effect == GeneratedMod.COLLAPSE.get()) callback.setReturnValue(null);
    }

    /**
     * 「清除全部效果」入口：有坍缩时改为逐个移除其余效果，坍缩本身保留。
     * 该路径覆盖牛奶桶、{@code /effect clear} 与其他模组的净化实现。
     */
    @Inject(method = "removeAllEffects()Z", at = @At("HEAD"), cancellable = true)
    private void originfall$removeAllEffectsExceptCollapse(CallbackInfoReturnable<Boolean> callback) {
        MobEffect collapse = GeneratedMod.COLLAPSE.get();
        if (collapse == null || !activeEffects.containsKey(collapse)) return;
        LivingEntity entity = (LivingEntity) (Object) this;
        List<MobEffect> others = new ArrayList<>();
        for (MobEffect effect : activeEffects.keySet()) {
            if (effect != collapse) others.add(effect);
        }
        for (MobEffect effect : others) entity.removeEffect(effect);
        callback.setReturnValue(!others.isEmpty());
    }
}
