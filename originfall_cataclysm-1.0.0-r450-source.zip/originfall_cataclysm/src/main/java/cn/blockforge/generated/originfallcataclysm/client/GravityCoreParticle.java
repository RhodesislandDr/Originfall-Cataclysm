package cn.blockforge.generated.originfallcataclysm.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;

/**
 * 邪魔区域地面冒出的「重力核」粒子。
 *
 * <p>贴图就是用户提供的 {@code gravity_core.png}：中心浓黑、向外羽化透明的软圆点。
 * 这里不改贴图，只负责运动——冒出的方式照搬原版岩浆粒子：贴地点先被地面顶起，
 * 在重力下画一道短促的抛物线，再落回去，所以一层黑点看起来是「咕嘟咕嘟从地里冒出来」，
 * 而不是旧版那样平飘上浮的一缕雾。</p>
 *
 * <p>“冒出”的初速由粒子自己给（服务端只负责落点）：原版 {@code sendParticles} 的
 * speed 参数只能产生随机方向的初速，那样黑点会朝四面八方乱飞，出不来贴地的抛物线。</p>
 *
 * <p>渲染用原版半透明混合（{@link ParticleRenderType#PARTICLE_SHEET_TRANSLUCENT}）而不是
 * 加法混合：贴图自己就是一张黑团，加法混合会把黑抬成灰白，反而失去「黑点」的质感。</p>
 */
public class GravityCoreParticle extends TextureSheetParticle {

    private final SpriteSet sprites;
    /** 基础尺寸（格）：黑点要贴着地面读得出来，又不能大到连成一片。 */
    private final float baseSize;

    protected GravityCoreParticle(ClientLevel level, SpriteSet sprites,
                                  double x, double y, double z, double vx, double vy, double vz) {
        super(level, x, y, z, 0.0D, 0.0D, 0.0D);
        this.sprites = sprites;
        this.baseSize = 0.14F + this.random.nextFloat() * 0.14F;
        this.quadSize = this.baseSize;
        // 岩浆式冒出：向上弹一下，重力把它拉回来，横向只留极小的抖动。
        this.gravity = 0.75F;
        this.friction = 0.98F;
        this.xd = (this.random.nextDouble() - 0.5D) * 0.05D;
        this.zd = (this.random.nextDouble() - 0.5D) * 0.05D;
        this.yd = 0.12D + this.random.nextDouble() * 0.12D;
        this.hasPhysics = false;
        this.lifetime = 14 + this.random.nextInt(10);
        // 从全透明开始，落地那一帧不会硬生生闪出一个黑点。
        this.alpha = 0.0F;
        this.setSpriteFromAge(sprites);
    }

    @Override
    public void tick() {
        super.tick();
        this.setSpriteFromAge(this.sprites);
        // 冒出的一瞬最实，随后散掉：前 15% 迅速显形，之后线性淡出。
        float progress = Mth.clamp((float) this.age / (float) this.lifetime, 0.0F, 1.0F);
        this.alpha = progress < 0.15F
                ? 0.90F * (progress / 0.15F)
                : 0.90F * (1.0F - (progress - 0.15F) / 0.85F);
    }

    @Override
    public float getQuadSize(float scaleFactor) {
        float progress = Mth.clamp(
                ((float) this.age + scaleFactor) / (float) this.lifetime, 0.0F, 1.0F);
        // 刚被顶出地面时略小，落回来时摊开一点，像一颗被顶起的黑泡。
        return this.baseSize * (0.70F + progress * 0.60F);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    protected int getLightColor(float partialTick) {
        // 贴图本身是黑团，不加自发光时夜里和地面一起黑掉；给一档低强度自发光，
        // 白天是清晰的黑点，夜里也只是勉强读得出轮廓，不会变成发光的灯。
        return LightTexture.pack(8, 15);
    }

    /** 供 {@code ClientEvents} 在模组总线上注册提供者。 */
    public static ParticleProvider<SimpleParticleType> factory(SpriteSet sprites) {
        return (type, level, x, y, z, vx, vy, vz) ->
                new GravityCoreParticle(level, sprites, x, y, z, vx, vy, vz);
    }
}
