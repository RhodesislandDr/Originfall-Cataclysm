package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.GeneratedMod;
import cn.blockforge.generated.originfallcataclysm.Priestess;
import cn.blockforge.generated.originfallcataclysm.Prophet;
import cn.blockforge.generated.originfallcataclysm.WeaponFlameParticles;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;

/**
 * 首领武装火焰的客户端表现：博士手持武器时武器表面燃起金色火焰、普瑞赛斯则是紫色火焰，
 * 挥砍时火焰会沿武器扫过的轨迹拉出拖尾。火焰与武器绑定：<b>如我所见</b>为金色、
 * <b>天堂支点</b>为紫色，因此任何持有这两把武器的人形单位（含两位首领）都会燃火。
 *
 * <p><b>为什么喷火点挂在 {@link RenderLevelStageEvent} 而不是 {@code RenderLivingEvent}：</b>
 * 装了史诗战斗（Epic Fight）的客户端上，史诗战斗会在 {@code RenderLivingEvent.Pre} 里用骨架
 * 动画把实体自己画完，然后 {@code setCanceled(true)}；Forge 的 {@code LivingEntityRenderer.render}
 * 一旦看到事件被取消就立刻 {@code return}，{@code Post} 根本不会派发。于是挂在 {@code Post}
 * 上的实现整段变成死代码，而挂在 {@code Pre} 上的实现只要姿势解析任何一步落空也会整段消失
 * ——两条路都不够稳。</p>
 *
 * <p>现在改为在 {@link RenderLevelStageEvent} 的 {@code AFTER_ENTITIES} 阶段主动遍历附近实体：
 * 这个事件每渲染帧必然触发、且不可被取消，与「谁画了这个实体、有没有取消事件」完全无关，
 * 从根上避开了上面的坑。每个目标按三级优先级取武器线段：</p>
 * <ol>
 *   <li>史诗战斗骨架的武器关节（{@code Tool_R}/{@code Tool_L}）——连段、冲刺斩、翻滚都如实反映；</li>
 *   <li>取不到时退回实体渲染器的人形模型（{@code HumanoidModel#translateToHand}）；</li>
 *   <li>再取不到时按身体朝向与持械手做一次粗糙兜底——宁可位置略偏，也绝不让火焰消失。</li>
 * </ol>
 *
 * <p>三条路都直接产出<b>世界坐标</b>的武器线段（{@code ClientLevel#addParticle} 用的就是世界坐标），
 * 每游戏刻沿线段采样喷点：常驻火苗 + 攻击动画期间的密集补点。</p>
 *
 * <p>整段逻辑只在客户端运行，不发送任何报文、不参与伤害与状态判定，纯装饰。
 * 未安装本模组的客户端看不到这两个粒子，也不影响服务端行为。</p>
 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT)
public final class WeaponFlameEvents {

    /** 只有玩家附近的实体才喷粒子，避免远处战斗无谓消耗。 */
    private static final double MAX_DISTANCE_SQR = 128.0D * 128.0D;

    /** 「如我所见」：博士的剑，金色火焰。 */
    private static final ResourceLocation RUWOSUOJIAN_ID =
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "ruwosuojian");

    /** 「天堂支点」：普瑞赛斯的剑，紫色火焰。 */
    private static final ResourceLocation TIANTANGZHIDIAN_ID =
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "tiantangzhidian");

    /** 「影霄」：模组第三把剑，同样按武器识别，避免因基类改动而漏判。 */
    private static final ResourceLocation YINGSIAO_ID =
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "yingsiao");

    /** 粒子相对实体原点的最大允许偏差：超过说明姿势换算出了问题，改用下一级兜底。 */
    private static final double POSE_SANITY_SQR = 64.0D;

    /**
     * 武器在手部坐标系里的起点、末端（原版人形模型空间）。
     * 该空间 +Y 朝下（人物下方）、-Z 朝人物正前方；自然持剑时武器从手里向前上方伸出，
     * 因此末端比起点更靠前（-Z 更小）、更靠上（+Y 更小）。
     */
    private static final Vector3f WEAPON_START = new Vector3f(0.0F, 0.70F, -0.22F);
    private static final Vector3f WEAPON_END = new Vector3f(0.0F, 0.16F, -1.24F);

    /** 模组首领渲染器在 {@code super.render} 之前额外缩小的比例，火焰要跟着一起缩。 */
    private static final float RENDER_SCALE = 0.9375F;

    /**
     * 史诗战斗接管渲染时的武器姿势提供者；未安装史诗战斗时永远返回 null。
     *
     * <p>入参用 {@link InteractionHand} 而不是 {@link HumanoidArm}，是因为史诗战斗对
     * 「哪只手」的判定与实体左右撇子无关：它固定把主手物品画在 {@code Tool_R}、
     * 副手物品画在 {@code Tool_L}（见其 {@code RenderItemBase#getCorrectionMatrix}）。
     * 火焰要跟武器重合，就必须用同一套手→关节映射。</p>
     */
    @FunctionalInterface
    public interface EpicFightWeaponPose {

        /**
         * 取史诗战斗骨架里持武器那只手的关节，换算成武器在世界坐标里的线段。
         *
         * @return 史诗战斗不可用（未安装、该实体没有补丁、关节缺失）时返回 null，
         *         调用方据此回落到下一级姿势
         */
        WeaponPose pose(LivingEntity entity, InteractionHand hand, float partialTick);
    }

    /** 武器在世界坐标里的一段，外加「是否正在出招」标记。 */
    public static final class WeaponPose {
        public final Vec3 start;
        public final Vec3 end;
        public final boolean attacking;

        public WeaponPose(Vec3 start, Vec3 end, boolean attacking) {
            this.start = start;
            this.end = end;
            this.attacking = attacking;
        }
    }

    private static final EpicFightWeaponPose NO_EPIC_FIGHT = (entity, arm, partialTick) -> null;
    private static volatile EpicFightWeaponPose epicFightPose = NO_EPIC_FIGHT;

    /**
     * 上一次真正喷火时的游戏刻；同一刻内的后续渲染帧直接跳过。
     *
     * <p>{@code RenderLevelStageEvent} 是<b>每渲染帧</b>派发一次的，而粒子本身按<b>游戏刻</b>
     * 推进。若不加这道闸，喷出的粒子数就正比于帧率：240 帧的机器上每秒喷出的是 60 帧机器的
     * 四倍，火焰会糊成一大团发光球、掉帧严重；低帧率时又稀得只剩几颗。按刻节流之后，
     * 密度回到「每秒固定颗数」，与帧率解耦，视觉上也就稳定了。</p>
     *
     * <p>用读写都在渲染线程的 {@code long}，不需要同步。</p>
     */
    private static long lastEmitGameTime = Long.MIN_VALUE;

    private WeaponFlameEvents() {
    }

    /** 由史诗战斗兼容层（独立源码集）在客户端安装；传 null 表示卸载。 */
    public static void installEpicFightPose(EpicFightWeaponPose provider) {
        epicFightPose = provider == null ? NO_EPIC_FIGHT : provider;
    }

    /**
     * 唯一喷火点：在实体画完之后遍历附近实体，给持械的目标沿武器线段喷火。
     * 事件本身每渲染帧都来，但真正的喷火按游戏刻节流（见 {@link #lastEmitGameTime}）。
     *
     * <p>选 {@code AFTER_ENTITIES} 有两个原因：一是此时本帧的模型姿势（原版与史诗战斗）
     * 都已经摆好，读到的姿态是当帧的；二是这个事件永远不会被取消，不像
     * {@code RenderLivingEvent.Post} 那样在史诗战斗环境下彻底不来。</p>
     */
    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        Minecraft minecraft = Minecraft.getInstance();
        ClientLevel level = minecraft.level;
        if (level == null) return;
        if (minecraft.player == null || !minecraft.player.isAlive()) return;
        // 按游戏刻节流：同一刻只喷一次，粒子密度与帧率无关（见 lastEmitGameTime 的说明）。
        long gameTime = level.getGameTime();
        if (gameTime == lastEmitGameTime) return;
        lastEmitGameTime = gameTime;
        float partialTick = event.getPartialTick();
        // entitiesForRendering 是当前客户端已加载、需要渲染的实体集合，遍历开销与实体数同阶。
        for (Entity raw : level.entitiesForRendering()) {
            if (!(raw instanceof LivingEntity entity)) continue;
            if (!canEmit(entity, level, minecraft)) continue;
            InteractionHand hand = weaponHand(entity);
            if (hand == null) continue;
            SimpleParticleType type = flameType(entity, heldWeapon(entity));
            if (type == null) continue;
            emitFlames(level, type, resolvePose(entity, hand, partialTick));
        }
    }

    /**
     * 博士金、普瑞赛斯紫；火焰同时与武器绑定——如我所见必为金、天堂支点必为紫，
     * 因此把这两把武器交给别的类人单位也会照常燃火。其余实体不喷火。
     */
    private static SimpleParticleType flameType(LivingEntity entity, ItemStack weapon) {
        ResourceLocation id = BuiltInRegistries.ITEM.getKey(weapon.getItem());
        if (RUWOSUOJIAN_ID.equals(id)) return WeaponFlameParticles.GOLDEN_WEAPON_FLAME.get();
        if (TIANTANGZHIDIAN_ID.equals(id)) return WeaponFlameParticles.PURPLE_WEAPON_FLAME.get();
        if (entity instanceof Prophet) return WeaponFlameParticles.GOLDEN_WEAPON_FLAME.get();
        if (entity instanceof Priestess) return WeaponFlameParticles.PURPLE_WEAPON_FLAME.get();
        return null;
    }

    /** 可见性、存活与距离的公共门槛。 */
    private static boolean canEmit(LivingEntity entity, ClientLevel level, Minecraft minecraft) {
        if (!entity.isAlive() || entity.isInvisible()) return false;
        if (entity.level() != level) return false;
        return minecraft.player.distanceToSqr(entity) <= MAX_DISTANCE_SQR;
    }

    /** 持武器那把手里的武器；空手（或手上不是武器）返回空栈。 */
    private static ItemStack heldWeapon(LivingEntity entity) {
        if (isWeapon(entity.getMainHandItem())) return entity.getMainHandItem();
        if (isWeapon(entity.getOffhandItem())) return entity.getOffhandItem();
        return ItemStack.EMPTY;
    }

    /**
     * 持武器那只手：主手优先，主手不是武器时才看副手；两只手都没有武器返回 null。
     *
     * <p>这里刻意返回 {@link InteractionHand} 而不是 {@link HumanoidArm}。史诗战斗渲染
     * 持械姿势时并不看 {@code getMainArm()}，而是固定「主手 = Tool_R、副手 = Tool_L」；
     * 若跟错手，火焰就会整条跑到另一只手上（看起来正是「特效出现在副手」）。
     * 把「哪只手」与「哪根关节」的判断分开后，两条渲染路径各自用自己正确的映射。</p>
     */
    private static InteractionHand weaponHand(LivingEntity entity) {
        if (isWeapon(entity.getMainHandItem())) return InteractionHand.MAIN_HAND;
        if (isWeapon(entity.getOffhandItem())) return InteractionHand.OFF_HAND;
        return null;
    }

    /**
     * 原版人形模型里「某只手」对应的手臂：主手用 {@code getMainArm()}，副手取反。
     * 只有回落到原版渲染路径时才会用到它——原版 {@code ItemInHandLayer} 正是按
     * {@code getMainArm()} 决定物品画在哪条手臂上的。
     */
    private static HumanoidArm vanillaArm(LivingEntity entity, InteractionHand hand) {
        HumanoidArm main = entity.getMainArm();
        return hand == InteractionHand.MAIN_HAND ? main : main.getOpposite();
    }

    private static boolean isWeapon(ItemStack stack) {
        if (stack.isEmpty()) return false;
        if (stack.getItem() instanceof SwordItem || stack.getItem() instanceof AxeItem
                || stack.getItem() instanceof TridentItem) {
            return true;
        }
        // 显式点名模组的三把剑：即使将来它们的基类被改动，火焰也不会莫名其妙消失。
        ResourceLocation id = BuiltInRegistries.ITEM.getKey(stack.getItem());
        return RUWOSUOJIAN_ID.equals(id) || TIANTANGZHIDIAN_ID.equals(id) || YINGSIAO_ID.equals(id);
    }

    /**
     * 三级姿态解析：史诗战斗骨架 → 渲染器的人形模型 → 身体朝向兜底。
     * 每一级都做一次「离实体不能太远」的合理性检查，异常结果直接丢弃换下一级。
     */
    private static WeaponPose resolvePose(LivingEntity entity, InteractionHand hand, float partialTick) {
        WeaponPose epic = epicFightPose.pose(entity, hand, partialTick);
        if (epic != null) {
            // 史诗战斗给出的关节世界坐标不含模组首领渲染器的整体缩放，先补上再喷点。
            Vec3 pivot = entity.getPosition(partialTick);
            Vec3 start = applyRenderScale(pivot, epic.start);
            Vec3 end = applyRenderScale(pivot, epic.end);
            if (isSane(entity, start) && isSane(entity, end)) {
                return new WeaponPose(start, end, epic.attacking);
            }
        }
        // 回落到原版人形模型：此时按 getMainArm() 找手臂，与原版 ItemInHandLayer 一致。
        HumanoidArm arm = vanillaArm(entity, hand);
        Minecraft minecraft = Minecraft.getInstance();
        EntityRenderer renderer = minecraft.getEntityRenderDispatcher().getRenderer(entity);
        if (!(renderer instanceof LivingEntityRenderer<?, ?> livingRenderer)) {
            return bodyRelativePose(entity, arm, partialTick);
        }
        EntityModel<?> rawModel = livingRenderer.getModel();
        if (rawModel instanceof HumanoidModel<?> model) {
            Vec3 start = handPoint(entity, model, arm, partialTick, WEAPON_START);
            Vec3 end = handPoint(entity, model, arm, partialTick, WEAPON_END);
            if (isSane(entity, start) && isSane(entity, end)) {
                boolean attacking = entity.getAttackAnim(partialTick) > 0.05F
                        || (epic != null && epic.attacking);
                return new WeaponPose(start, end, attacking);
            }
        }
        return bodyRelativePose(entity, arm, partialTick);
    }

    /** 姿势结果是否可信：坐标必须有穷、且武器线段两端都贴着实体本身。 */
    private static boolean isSane(LivingEntity entity, Vec3 point) {
        if (point == null) return false;
        if (!Double.isFinite(point.x) || !Double.isFinite(point.y) || !Double.isFinite(point.z)) {
            return false;
        }
        return point.distanceToSqr(entity.position()) <= POSE_SANITY_SQR;
    }

    /**
     * 把「原版人形手部坐标系里的一个点」换算成世界坐标。
     *
     * <p>变换顺序与真实渲染链路一致：模组首领渲染器先对整体做 0.9375 缩放，随后原版人形
     * 依次施加身体朝向、上下左右翻转、以及把原点从脚底抬到腰胯高度的 1.501 下移，
     * 最后才轮到当前帧的手臂姿态。矩阵作用在相对实体脚底的偏移上，加回实体本帧位置
     * 就是 {@code addParticle} 要的世界坐标。</p>
     */
    private static Vec3 handPoint(LivingEntity entity, HumanoidModel<?> model, HumanoidArm arm,
                                  float partialTick, Vector3f local) {
        PoseStack poseStack = new PoseStack();
        poseStack.scale(RENDER_SCALE, RENDER_SCALE, RENDER_SCALE);
        float bodyRot = Mth.rotLerp(partialTick, entity.yBodyRotO, entity.yBodyRot);
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - bodyRot));
        poseStack.scale(-1.0F, -1.0F, 1.0F);
        poseStack.translate(0.0F, -1.501F, 0.0F);
        model.translateToHand(arm, poseStack);
        Vector3f point = new Vector3f(local);
        point.mulPosition(poseStack.last().pose());
        return entity.getPosition(partialTick).add(point.x, point.y, point.z);
    }

    /**
     * 最后一道兜底：不依赖任何模型或骨架，直接按身体朝向、身高与持械手侧摆出一段
     * 从手到斜前方的线段。位置会比精确姿势略偏，但保证「武器上一定有火」。
     */
    private static WeaponPose bodyRelativePose(LivingEntity entity, HumanoidArm arm, float partialTick) {
        Vec3 base = entity.getPosition(partialTick);
        float bodyRot = Mth.rotLerp(partialTick, entity.yBodyRotO, entity.yBodyRot);
        float yaw = bodyRot * Mth.DEG_TO_RAD;
        Vec3 forward = new Vec3(-Math.sin(yaw), 0.0D, Math.cos(yaw));
        // 面朝 forward 时，实体右手边为 forward 绕 Y 轴顺时针转 90°。
        Vec3 side = new Vec3(-forward.z, 0.0D, forward.x);
        if (arm == HumanoidArm.LEFT) side = side.scale(-1.0D);
        double reach = entity.getBbWidth() * 0.5D + 0.18D;
        Vec3 hand = base.add(0.0D, entity.getBbHeight() * 0.62D, 0.0D)
                .add(side.scale(reach))
                .add(forward.scale(0.12D));
        Vec3 tip = hand.add(forward.scale(0.9D)).add(0.0D, 0.35D, 0.0D);
        return new WeaponPose(hand, tip, entity.getAttackAnim(partialTick) > 0.05F);
    }

    /**
     * 把史诗战斗骨架给出的世界坐标套上模组首领渲染器的整体缩放。
     *
     * <p>模组首领渲染器在 {@code super.render} 之前先乘了一次 0.9375，史诗战斗正是在这层
     * 缩放之内绘制骨架的，而它自己算关节位置时并不知道这层缩放。以实体脚底为原点按同一
     * 比例缩放关节位移，火焰才会和画出来的武器重合。</p>
     */
    private static Vec3 applyRenderScale(Vec3 entityPos, Vec3 point) {
        return entityPos.add(point.subtract(entityPos).scale(RENDER_SCALE));
    }

    /**
     * 常驻火苗 + 挥砍拖尾：都在武器线段上采样，所以火焰是贴着武器烧的。
     *
     * <p>这里的颗数是<b>每游戏刻</b>（不是每帧，见 {@link #lastEmitGameTime}）的用量：常驻
     * 3~4 颗保证静止持械时刀身就有一条连续的火线；出招时再叠 4~5 颗，整条武器线段被点满，
     * 随着手臂挥动自然连成火焰弧。按 20 刻/秒折算约 70 颗/秒，与粒子的 12~20 刻寿命相乘，
     * 同时存在约 60~70 颗，肉眼是一层厚实但不会糊成光球的火。</p>
     *
     * <p>为了「流畅」，这里刻意避开两个抖动源：一是同一刻内的数量不再在全有/全无之间跳
     * （常驻保底 3 颗、出招时再加 4 颗），二是采样点用<b>分层取样</b>而不是纯随机，
     * 粒子沿刀刃均匀铺开、不会这一帧挤成一团、下一帧空出一截。粒子本身还带了随机的
     * 明灭相位，因此整条火线看上去是连续流动的，而不是一簇簇同生同灭地闪。</p>
     */
    private static void emitFlames(ClientLevel level, SimpleParticleType type, WeaponPose pose) {
        RandomSource random = level.random;
        // 常驻火苗：贴着武器表面随机燃起一点，落在武器线段上任意位置。
        // 保底 3 颗，保证静止持械时肉眼就能看到武器在烧。
        int base = 3 + (random.nextFloat() < 0.5F ? 1 : 0);
        for (int i = 0; i < base; i++) {
            spawnFlame(level, type, pose.start, pose.end, strata(i, base, random), random, 0.012D);
        }
        // 挥砍拖尾：攻击动画期间整条武器线段上都补点，随着手臂挥动自然连成火焰弧。
        if (pose.attacking) {
            int trail = 4 + (random.nextFloat() < 0.5F ? 1 : 0);
            for (int i = 0; i < trail; i++) {
                spawnFlame(level, type, pose.start, pose.end, strata(i, trail, random), random, 0.020D);
            }
        }
    }

    /** 分层取样：把 [0,1] 均分 {@code count} 段，每段内再随机取一点，粒子分布均匀而不结块。 */
    private static float strata(int index, int count, RandomSource random) {
        return ((float) index + random.nextFloat()) / (float) count;
    }

    /** 在武器线段上按比例 t 取一点，喷出一枚火焰粒子。 */
    private static void spawnFlame(ClientLevel level, SimpleParticleType type, Vec3 start, Vec3 end,
                                   float t, RandomSource random, double spread) {
        Vec3 axis = end.subtract(start);
        Vec3 point = start.lerp(end, t);
        // 只做很小的侧向抖动：让火苗从刃口两侧略微舔出来，又不会糊成一团挡住武器。
        Vec3 side = perpendicular(axis);
        point = point.add(side.scale((random.nextDouble() - 0.5D) * 0.05D))
                .add(0.0D, (random.nextDouble() - 0.3D) * 0.05D, 0.0D);
        double vx = (random.nextDouble() - 0.5D) * spread;
        double vy = 0.006D + random.nextDouble() * spread;
        double vz = (random.nextDouble() - 0.5D) * spread;
        level.addParticle(type, point.x, point.y, point.z, vx, vy, vz);
    }

    /** 与武器线段垂直的单位方向；线段退化时返回零向量（调用方乘上抖动也只是不加偏移）。 */
    private static Vec3 perpendicular(Vec3 axis) {
        Vec3 unit = axis.normalize();
        if (unit.lengthSqr() < 1.0E-6D) return Vec3.ZERO;
        Vec3 helper = Math.abs(unit.y) > 0.9D ? new Vec3(1.0D, 0.0D, 0.0D) : new Vec3(0.0D, 1.0D, 0.0D);
        return unit.cross(helper).normalize();
    }

    /** 供 {@code ClientEvents} 在模组总线上注册两种火焰粒子的提供者。 */
    public static void registerParticleProviders(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(WeaponFlameParticles.GOLDEN_WEAPON_FLAME.get(), WeaponFlameParticle::golden);
        event.registerSpriteSet(WeaponFlameParticles.PURPLE_WEAPON_FLAME.get(), WeaponFlameParticle::purple);
    }
}
