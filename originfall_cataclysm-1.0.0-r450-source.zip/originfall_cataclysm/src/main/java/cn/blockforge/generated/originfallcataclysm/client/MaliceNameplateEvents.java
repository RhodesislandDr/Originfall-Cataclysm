package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.CalamityMob;
import cn.blockforge.generated.originfallcataclysm.GeneratedMod;
import cn.blockforge.generated.originfallcataclysm.LearnedTraitLogic;
import cn.blockforge.generated.originfallcataclysm.MaliceCompat;
import cn.blockforge.generated.originfallcataclysm.SourceOreGolem;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderNameTagEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 独立形态（未安装莱特兰-恶意）下的恶意等级与词条名牌外显。
 *
 * <p>装有莱特兰-恶意时本类整体空转——等级与词条的外显由它自身的名字牌渲染完成，
 * 避免两套外显叠加。独立形态下，恶意等级与已学词条经实体同步数据下发到客户端，
 * 这里把它们拼进原版名牌文本，格式对齐恶意模组的 "Lv.N" + "/" 分隔词条样式。</p>
 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT)
public final class MaliceNameplateEvents {

    private MaliceNameplateEvents() {}

    @SubscribeEvent
    public static void onRenderNameTag(RenderNameTagEvent event) {
        if (MaliceCompat.l2Active()) return; // 莱特兰在场：外显由它自己负责。
        if (!(event.getEntity() instanceof LivingEntity living)) return;
        int level;
        String traits;
        if (living instanceof CalamityMob calamity) {
            level = calamity.getEntityData().get(CalamityMob.MALICE_LEVEL_DATA);
            traits = calamity.getEntityData().get(CalamityMob.LEARNED_TRAITS_DATA);
        } else if (living instanceof SourceOreGolem golem) {
            level = golem.getEntityData().get(SourceOreGolem.MALICE_LEVEL_DATA);
            traits = golem.getEntityData().get(SourceOreGolem.LEARNED_TRAITS_DATA);
        } else {
            return;
        }
        boolean hasTraits = traits != null && !traits.isBlank();
        if (level <= 0 && !hasTraits) return;
        if (!LearnedTraitLogic.isLearner(living)) return;

        MutableComponent suffix = Component.empty();
        if (level > 0) {
            suffix.append(Component.translatable("malice.originfall_cataclysm.level", level)
                    .withStyle(level >= 120 ? ChatFormatting.DARK_RED : ChatFormatting.RED));
        }
        if (hasTraits) {
            if (level > 0) suffix.append(Component.literal(" "));
            suffix.append(traitDisplay(traits));
        }
        event.setContent(event.getContent().copy().append(Component.literal("\n")).append(suffix));
    }

    /** 把同步串 "speed:2,flight" 渲染成 "急速Ⅱ/飞行" 样式（词条名走语言文件，等级用罗马数字）。 */
    private static Component traitDisplay(String encoded) {
        MutableComponent result = Component.empty().withStyle(ChatFormatting.AQUA);
        boolean first = true;
        for (String token : encoded.split(",")) {
            if (token.isBlank()) continue;
            if (!first) result.append(Component.literal("/"));
            first = false;
            int sep = token.indexOf(':');
            String id = sep < 0 ? token : token.substring(0, sep);
            int level = 1;
            if (sep >= 0) {
                try {
                    level = Math.max(1, Integer.parseInt(token.substring(sep + 1)));
                } catch (NumberFormatException ignored) {
                    level = 1;
                }
            }
            result.append(Component.translatable("trait.originfall_cataclysm." + id));
            if (level > 1) result.append(Component.literal(roman(level)));
        }
        return result;
    }

    private static String roman(int level) {
        return switch (Math.max(1, Math.min(3, level))) {
            case 2 -> "Ⅱ";
            case 3 -> "Ⅲ";
            default -> "";
        };
    }
}
