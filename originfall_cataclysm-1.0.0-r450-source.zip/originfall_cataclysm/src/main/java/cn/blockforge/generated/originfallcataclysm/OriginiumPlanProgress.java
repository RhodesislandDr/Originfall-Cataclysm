package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

/**
 * 「源石计划进度」难度分级：游戏规则 0~18 共十九档，依次对应
 * -99、-95、-90、-80、-70、-60、-50、-40、-30、-20、-10、0、10、20、30、40、50、60、70 百分比，
 * 默认 11 档（0%，即与本规则引入前的行为完全一致）。
 *
 * <p>档位换算出的统一缩放系数 {@code factor = (100 + 百分比) / 100}（0.01~1.70），
 * 按需求只作用于以下八类“提升/削弱幅度”与时长调节，不影响基础数值本身：</p>
 * <ol>
 *   <li>首领（博士/普瑞赛斯/特蕾西娅）的各种方式提升幅度：
 *       游刃有余、领域自身增速、伤害光环、黑闪增幅、源石强化理论、击杀成长等；</li>
 *   <li>陨石的爆炸伤害（向下取整）；地形感染（感染半径的晶化替换）受难度档位的影响
 *       降为原影响比例的 10%，见 {@link #terrainFactor(Level)}；</li>
 *   <li>转化生物原数值之外的提升数值（感染层数倍率的超出部分）；</li>
 *   <li>生物的战斗或机制提升幅度（战斗追击移速加成、天灾攻击保底 1 层之外的追加感染层数；
 *       天灾攻击的触发概率与保底 1 层属规格固定值，不随进度变化）；</li>
 *   <li>转化生物死后复活的原数值之外提升部分（复活倍率超过 1 的部分）；</li>
 *   <li>源石感染各项数值的削弱幅度（每秒伤害与移速/攻击/护甲削弱）；</li>
 *   <li>邪魔（坍缩）的感染强化幅度与各项机制加成幅度（每层移速/攻击加成、攻击传染概率、玩家掉血）；</li>
 *   <li>邪魔区域累计感染时间：难度负比例为延长比例、正比例为缩短比例，
 *       见 {@link #zoneInfectionTimeFactor(Level)}。</li>
 * </ol>
 *
 * <p>游戏规则是服务器级的（不随维度变化），因此这里维护一个每 tick 刷新的缓存系数，
 * 供 {@code MobEffect#getAttributeModifierValue} 这类拿不到世界上下文的路径读取；
 * 服务端与客户端各自在 tick 里刷新（见 {@code CommonEvents#onLevelTick}）。</p>
 */
public final class OriginiumPlanProgress {

    /** 十九档进度对应的幅度（百分比）：下标即档位，0 档 = -99%，11 档 = 0%，18 档 = +70%。 */
    public static final int[] PERCENT_BY_TIER = {
            -99, -95, -90, -80, -70, -60, -50, -40, -30, -20, -10, 0, 10, 20, 30, 40, 50, 60, 70};
    public static final int MIN_TIER = 0;
    public static final int MAX_TIER = PERCENT_BY_TIER.length - 1;
    /** 默认档位 11：0%，未调整规则时一切行为与引入本规则之前相同。 */
    public static final int DEFAULT_TIER = 11;

    /** 跨端缓存的缩放系数：每 tick 由 {@link #refreshCache(Level)} 刷新。 */
    private static volatile double cachedFactor = 1.0D;

    private OriginiumPlanProgress() {
    }

    /** 当前世界的进度档位（0~18）；越界值先夹紧。 */
    public static int tier(Level level) {
        return OriginFallGameRules.originiumPlanProgressTier(level);
    }

    /** 当前档位对应的幅度（百分比数值，-99~+70）。 */
    public static int percent(Level level) {
        return PERCENT_BY_TIER[Mth.clamp(tier(level), MIN_TIER, MAX_TIER)];
    }

    /** 统一缩放系数：(100 + 档位百分比) / 100，范围 0.01~1.70。 */
    public static double factor(Level level) {
        return (100.0D + percent(level)) / 100.0D;
    }

    /** 难度档位对地形感染（黑色晶体替换）的影响比例：只保留原影响幅度的 10%。 */
    public static final double TERRAIN_INFLUENCE_RATIO = 0.10D;

    /**
     * 地形感染专用系数：难度档位对地形感染的影响降为原影响比例的 10%，
     * 即把幅度压缩为原来的十分之一——18 档（+70%）的晶化半径只 ×1.07，
     * 0 档（−99%）也只 ×0.901；默认 11 档仍为 ×1.0。
     */
    public static double terrainFactor(Level level) {
        return 1.0D + (factor(level) - 1.0D) * TERRAIN_INFLUENCE_RATIO;
    }

    /**
     * 邪魔区域累计感染时间专用系数：难度负比例即延长比例、正比例即缩短比例，
     * 即 {@code 1 − 档位百分比/100}（等价于 {@code 2 − factor}）——
     * 0 档（−99%）累计感染时间 ×1.99（10 秒 → 约 19.9 秒），
     * 18 档（+70%）则 ×0.30（10 秒 → 3 秒）；默认 11 档（0%）仍为 ×1.0。
     */
    public static double zoneInfectionTimeFactor(Level level) {
        return 1.0D - percent(level) / 100.0D;
    }

    /** 从实体所在世界取系数；实体缺失时退回每 tick 刷新的缓存值。 */
    public static double factor(LivingEntity entity) {
        return entity != null ? factor(entity.level()) : cachedFactor;
    }

    /** 直接缩放一个“幅度”：比例的零点是“无效果”，所以整体乘以进度系数。 */
    public static double amplify(double amount, Level level) {
        return amount * factor(level);
    }

    public static double amplify(double amount, LivingEntity entity) {
        return amount * factor(entity);
    }

    /** 相对原值的倍率：只缩放超出 1 的幅度，倍率 → 1 + (倍率 - 1) × 进度系数。 */
    public static double boosted(double scale, Level level) {
        return 1.0D + (scale - 1.0D) * factor(level);
    }

    public static double boosted(double scale, LivingEntity entity) {
        return 1.0D + (scale - 1.0D) * factor(entity);
    }

    /** 同 {@link #boosted}，但只压缩倍率高于 1 的部分；低于 1 的“弱化”部分原样保留。 */
    public static double boostedUp(double scale, Level level) {
        return scale > 1.0D ? 1.0D + (scale - 1.0D) * factor(level) : scale;
    }

    public static double boostedUp(double scale, LivingEntity entity) {
        return scale > 1.0D ? 1.0D + (scale - 1.0D) * factor(entity) : scale;
    }

    /** 概率类幅度：按进度缩放并以 100% 封顶。 */
    public static double chance(double base, Level level) {
        return Math.min(1.0D, base * factor(level));
    }

    public static double chance(double base, LivingEntity entity) {
        return Math.min(1.0D, base * factor(entity));
    }

    /**
     * 整数幅度（感染追加层数这类）：按期望值等比缩放，零头概率取整——
     * 例如 3 层 ×1.7 = 5.1，则 5 层保底、10% 概率再多 1 层。
     */
    public static int scaleInt(int amount, Level level, RandomSource random) {
        if (amount <= 0) return 0;
        double scaled = amount * factor(level);
        int floored = Mth.floor(scaled);
        if (random.nextDouble() < scaled - floored) floored++;
        return floored;
    }

    /** 每 tick 刷新缓存系数：属性修饰符覆写这类无世界上下文的路径只读这里。 */
    public static double cachedFactor() {
        return cachedFactor;
    }

    public static void refreshCache(Level level) {
        if (level == null) return;
        double fresh = factor(level);
        if (fresh != cachedFactor) cachedFactor = fresh;
    }
}
