package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * 天堂支点的全部能力定义：
 * 1. 两段伤害：第一段为使用者最大生命值40%的真实伤害；第二段为原有攻击数值，
 *    仍走原版受击链（护甲、盾牌、附魔、击退全部有效）。
 * 2. 极•源石权柄•阴：攻击造成伤害50%回复自身；自身半径32格内死亡的生物按40%死前最大生命值
 *    回复持有者；满血时溢出治疗转化为最大生命上限。仅在携带本武器时生效，丢弃/掉落后清除加成。
 * 3. 流放虚空：每次攻击基础3.25%概率将目标放逐到虚空10~60秒（等概率随机时长），每次未触发攻击
 *    概率提高0.5%，触发后回到基础概率；期间每秒受到使用者最大生命值1%的伤害；同一施术者
 *    （每只生物独立计时）对同一目标内置冷却30秒。触发时为目标施加“阴”标记，标记随内置冷却一起到期消失。（“阳”标记不再由本武器授予，
 *    唯一来源为“如我所见”的锚定现实。）
 * 4. 每次造成伤害32.5%概率削减目标最大生命值（削减量=本次伤害×32.5%，目标带“阴”标记再提升50%）；
 *    削减判定之后再判0.325%“源石之始”：造成100%敌方最大生命值的真实伤害。
 *    目标为玩家且削减量达到其现有生命值时立刻击杀，无视复活与锁血；复活后最大生命值强制锁定为1，
 *    期间武器生命加成视为0。玩家的普通上限削减最高只把生效上限削到 2 点，
 *    超出 2 点保底的那部分削减量当场转为真实伤害直接压血（修复“玩家削上限死亡后
 *    重生反复归零、无法复活”的死循环）。
 * 5. 咫尺天堂：持有者受到致命伤害时拒绝死亡（本次伤害完全无效、血量保留），10秒无敌，
 *    无敌结束后现有最大生命值降低50%；使用间隔按生命档位计算：1000血基准32.5秒，
 *    每层（血量每翻十倍算一层）降低初始时间20%，加成最大降低80%。
 * 6. 无下限•内化宇宙•阴：持有“阳”标记（来源于“如我所见”的锚定现实）的使用者成功对目标
 *    施加“阴”标记时，附近所有带阴/阳标记的
 *    存活生物被拉入虚空并在原地留下空间锚点，10秒后归来。期间每秒判定：5%即死；其余95%在
 *    +3250、+325、+3.25%上限、+32.5%上限、-3250、-325、-3.25%上限、-32.5%上限八档中平分。
 *    该状态下无法移动、无法攻击，复活与免死效果无效。
 * 7. 无下限•内化宇宙•开放：与阴/阳独立判定——同一生物同时持有“阴”“阳”两枚印记即可触发，
 *    判定与光点表现完全复用第6条的内化宇宙。
 * 8. 触发流放虚空或锚定现实并同时触发无下限•内化宇宙时，原本的流放/锚定效果推迟到
 *    10秒判定归来后兑现：效果造成者死亡则该效果不再触发；目标在内化宇宙中死亡则无法复活。
 * 9. 生命上限不再设“生存下限”：未经原版 1.0 截断的原始上限总值被任何来源（本模组削减、
 *    阳火、咫尺天堂衰减、外部模组等）削到 0 及以下时，视为正常死亡且无法复活、无法被
 *    转化（详见 MaxHealthZeroLogic）；玩家按第4条保底 2 点处理，本模组内不再出现玩家
 *    归零死亡，旧存档中已“钉 1”的玩家同样被新的 2 点保底覆盖抬回 2。
 *
 * 真伤路径（第一段、源石之始、虚空每秒伤害）直接压血，不经事件链；
 * 流放落地延迟一tick，等第二段原版伤害结算完仍存活才放逐。
 */
public final class TiantangzhidianLogic {

    // ---------------- Persistent data 键 ----------------
    public static final String INTERNAL_DAMAGE = "OfcTtzInternalDamage";
    private static final String EXTRA_HEALTH = "OfcTtzExtraHealth";
    private static final String MAX_HP_CUT = "OfcTtzMaxHpCut";
    /**
     * 玩家生命上限保底：一切上限削减对玩家最高只把生效上限削到 2 点（1 颗心），
     * 削不进的部分在削减入口处转为真实伤害。旧实现让玩家可以被削到归零，
     * 重生时携带的削减又立即再次归零，形成“反复死亡、无法复活”的死循环。
     */
    private static final double PLAYER_HEALTH_CUT_FLOOR = 2.0D;
    private static final String UNIVERSE_HP = "OfcTtzUniverseHp";
    private static final String PP_STACKS = "OfcTtzPpStacks";
    private static final String PP_INVULN_UNTIL = "OfcTtzPpInvulnUntil";
    private static final String PP_PENDING_UNTIL = "OfcTtzPpPendingUntil";
    private static final String PP_LAST_USE = "OfcTtzPpLastUse";
    private static final String EXEC_PENDING = "OfcTtzExecPending";
    private static final String EXEC_LOCK_UNTIL = "OfcTtzExecLockUntil";
    private static final String YIN_UNTIL = "OfcTtzYinUntil";
    private static final String YANG_UNTIL = "OfcTtzYangUntil";
    /** 新版印记使用 Long.MAX_VALUE 表示永久，直到死亡或内化宇宙判定结束。 */
    private static final long PERMANENT_MARK = Long.MAX_VALUE;
    private static final String EXILE_UNTIL = "OfcTtzExileUntil";
    /** 「流放虚空」对同一目标的内置冷却：只记在施术者身上，按目标 UUID 分开，同种生物不共用。 */
    private static final String EXILE_CD_ABILITY = "tiantangzhidian_exile_void";
    private static final String EXILE_MODE = "OfcTtzExileMode";
    private static final String EXILE_NEXT = "OfcTtzExileNext";
    private static final String EXILE_DPS = "OfcTtzExileDps";
    private static final String EXILE_OWNER = "OfcTtzExileOwner";
    private static final String EXILE_AX = "OfcTtzExileAx";
    private static final String EXILE_AY = "OfcTtzExileAy";
    private static final String EXILE_AZ = "OfcTtzExileAz";
    private static final String EXILE_VX = "OfcTtzExileVx";
    private static final String EXILE_VY = "OfcTtzExileVy";
    private static final String EXILE_VZ = "OfcTtzExileVz";
    // 被流放实体强加载虚空区块（保证持续 tick、到期能按时归来）的记录。
    private static final String EXILE_CX = "OfcTtzExileCx";
    private static final String EXILE_CZ = "OfcTtzExileCz";
    private static final String EXILE_FORCED = "OfcTtzExileForced";
    // 下一tick落地的流放申请
    private static final String EXILE_REQUEST = "OfcTtzExileRequest";
    private static final String EXILE_REQUEST_OWNER = "OfcTtzExileRequestOwner";
    private static final String EXILE_REQUEST_YANG = "OfcTtzExileRequestYang";
    /** 持械者连续未触发流放的攻击次数（用于概率递增；触发后归零）。 */
    private static final String EXILE_STREAK = "OfcTtzExileAtkStreak";
    // 内化宇宙接管时推迟的“原本效果”（流放虚空/锚定现实）记录。
    private static final String DEFER_TYPE = "OfcTtzDeferType";
    private static final String DEFER_OWNER = "OfcTtzDeferOwner";
    private static final String DEFER_DURATION = "OfcTtzDeferDuration";
    // 内化宇宙及其延迟原效果期间死亡不可复活的标记。
    private static final String UNIVERSE_NO_REVIVE = "OfcTtzUniverseNoRevive";
    /** 写入复活快照，防止任何延迟复活入口绕过不可复活状态。 */
    public static final String REVIVAL_NO_REVIVE = "OfcTtzRevivalNoRevive";

    // ---------------- 属性修饰符 UUID ----------------
    private static final UUID EXTRA_UUID = UUID.fromString("7c2f51a3-9d44-4b21-8a3e-0c6d21f77001");
    private static final UUID CUT_UUID = UUID.fromString("7c2f51a3-9d44-4b21-8a3e-0c6d21f77002");
    private static final UUID UNIVERSE_UUID = UUID.fromString("7c2f51a3-9d44-4b21-8a3e-0c6d21f77003");
    private static final UUID PP_UUID = UUID.fromString("7c2f51a3-9d44-4b21-8a3e-0c6d21f77004");
    private static final UUID FLOOR_UUID = UUID.fromString("7c2f51a3-9d44-4b21-8a3e-0c6d21f77005");

    // ---------------- 数值常量 ----------------
    private static final double FIRST_STAGE_RATIO = 0.40D;
    private static final double LIFESTEAL_RATIO = 1.0D;
    private static final double KILL_HEAL_RATIO = 0.4D;
    private static final double KILL_HEAL_RADIUS = 64.0D;
    private static final double EXILE_CHANCE = 0.0325D;
    /** 流放虚空概率递增步长：每次未触发攻击 +0.5%。 */
    private static final double EXILE_CHANCE_STEP = 0.005D;
    private static final double EXILE_DPS_RATIO = 0.01D;
    private static final long EXILE_MARK_TICKS = 600L;
    private static final double HP_CUT_CHANCE = 0.325D;
    private static final double HP_CUT_RATIO = 0.325D;
    private static final double YIN_CUT_BOOST = 1.5D;
    private static final double GENESIS_CHANCE = 0.00325D;
    private static final long PP_INVULN_TICKS = 200L;
    private static final double PP_BASE_HEALTH = 1000.0D;
    private static final long PP_BASE_INTERVAL_TICKS = 650L;
    private static final long UNIVERSE_TICKS = 200L;
    private static final double UNIVERSE_DEATH_CHANCE = 0.05D;
    private static final long EXEC_LOCK_TICKS = 6000L;
    private static final int EXILE_MODE_VOID = 1;
    private static final int EXILE_MODE_UNIVERSE = 2;
    /** 推迟的“原本效果”类型：流放虚空。 */
    public static final int DEFER_MODE_VOID = 1;
    /** 推迟的“原本效果”类型：锚定现实。 */
    public static final int DEFER_MODE_ANCHOR = 2;

    // ---------------- 虚空强加载（区块引用计数） ----------------
    /** 各维度已强加载虚空区块的引用计数：维度 -> 区块长键 -> 引用数。 */
    private static final Map<ResourceKey<Level>, Map<Long, Integer>> FORCED_CHUNKS = new HashMap<>();
    /** 本服务端进程内已对某实体施加过强加载的实体 UUID（进程重启后被清空，用于重新施加）。 */
    private static final Set<UUID> FORCED_APPLIED = new HashSet<>();

    private TiantangzhidianLogic() {
    }

    // ---------------- 持有判定 ----------------

    public static boolean isSwordHeld(LivingEntity entity) {
        if (entity == null) return false;
        return entity.getMainHandItem().is(GeneratedMod.TIANTANGZHIDIAN.get())
                || entity.getOffhandItem().is(GeneratedMod.TIANTANGZHIDIAN.get());
    }

    /** 携带判定：主手、副手或背包中的任意一格。 */
    public static boolean hasAccess(LivingEntity entity) {
        if (entity == null) return false;
        if (isSwordHeld(entity)) return true;
        if (entity instanceof Player player) {
            for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
                if (player.getInventory().getItem(i).is(GeneratedMod.TIANTANGZHIDIAN.get())) return true;
            }
        }
        return false;
    }

    /**
     * 天堂支点的普通近战命中入口；月牙形剑气作为近战武器延伸同样计入。
     * 只认主手：与如我所见、影霄保持同一判定，副手武器不再触发命中附加效果。
     */
    public static boolean isSwordAttackSource(DamageSource source) {
        return source != null && source.getEntity() instanceof LivingEntity attacker
                && attacker.getMainHandItem().is(GeneratedMod.TIANTANGZHIDIAN.get())
                && (source.getDirectEntity() == attacker
                    || source.getDirectEntity() instanceof SwordQiEntity qi && qi.getOwner() == attacker);
    }

    // ---------------- 阴 / 阳 / 流放状态 ----------------

    public static boolean hasYin(LivingEntity entity) {
        if (entity == null) return false;
        long value = entity.getPersistentData().getLong(YIN_UNTIL);
        return value == PERMANENT_MARK || value > entity.level().getGameTime();
    }

    public static boolean hasYang(LivingEntity entity) {
        if (entity == null) return false;
        long value = entity.getPersistentData().getLong(YANG_UNTIL);
        return value == PERMANENT_MARK || value > entity.level().getGameTime();
    }

    /** 施加永久“阴”标记：只有死亡或内化宇宙判定结束才会清除。 */
    public static void setYinMark(LivingEntity entity) {
        if (entity == null || entity.level().isClientSide) return;
        entity.getPersistentData().putLong(YIN_UNTIL, PERMANENT_MARK);
    }

    /** 施加永久“阳”标记：唯一来源是“如我所见”的锚定现实。 */
    public static void setYangMark(LivingEntity entity, long durationTicks) {
        if (entity == null || entity.level().isClientSide) return;
        entity.getPersistentData().putLong(YANG_UNTIL, PERMANENT_MARK);
    }

    /** 是否处于“处刑锁定”：复活后最大生命值钉为1，所有武器生命加成视为0。 */
    public static boolean isExecutionLocked(LivingEntity entity) {
        return entity != null && entity.getPersistentData().getLong(EXEC_LOCK_UNTIL)
                > entity.level().getGameTime();
    }

    /** 记入“待执行处刑”：玩家死亡重生后进入 5 分钟处刑锁定（上限钉1、武器生命加成视为0）。 */
    public static void markExecutionPending(LivingEntity entity) {
        if (entity != null && !entity.level().isClientSide) {
            entity.getPersistentData().putBoolean(EXEC_PENDING, true);
        }
    }

    private static boolean isExiledInternal(LivingEntity entity) {
        return entity != null && entity.getPersistentData().getLong(EXILE_UNTIL) > entity.level().getGameTime();
    }

    /** 是否处于虚空流放/内化宇宙状态（“如我所见”复用同一套虚空机制）。 */
    public static boolean isExiled(LivingEntity entity) {
        return isExiledInternal(entity);
    }

    // ---------------- 伤害结算 ----------------

    private static DamageSource attributionSource(LivingEntity holder, Level level) {
        return holder instanceof Player player
                ? level.damageSources().playerAttack(player)
                : level.damageSources().mobAttack(holder);
    }

    /** 咫尺天堂能否拒绝这次致死伤害（无敌期、流放中、冷却内均不触发）。 */
    private static boolean canPpSave(LivingEntity victim, long now) {
        if (!hasAccess(victim) || isExiledInternal(victim)) return false;
        if (victim.getPersistentData().getLong(PP_INVULN_UNTIL) > now) return false;
        return now - victim.getPersistentData().getLong(PP_LAST_USE) >= ppIntervalTicks(victim.getMaxHealth());
    }

    /** 供“如我所见”等外部武器查询：这次伤害若致死，会不会被“咫尺天堂”拒绝。 */
    public static boolean canLethalBeRefused(LivingEntity victim, long now) {
        return victim.isAlive() && canPpSave(victim, now);
    }

    /** 与 canLethalBeRefused 配对：外部已取消事件后，正式兑现咫尺天堂的保命。 */
    public static void grantLethalRefusal(LivingEntity victim, long now) {
        activatePp(victim, now);
    }

    /**
     * 真实伤害：直接压血并按持有者身份结算死亡；返回实际造成的伤害量。
     * allowPpSave=true 时，致死会被“咫尺天堂”拒绝（返回0）。
     * derived=true 表示该击杀属于派生真实伤害（源石之始/流放虚空），非近战直接击杀，
     * 会被“女祭司”普瑞赛斯的击杀学习判定排除（详见 LearnedTraitLogic.canLearnFromKill）。
     */
    private static float applyTrueDamage(LivingEntity holder, LivingEntity victim, double amount,
                                         boolean allowPpSave, boolean derived) {
        if (victim == null || !victim.isAlive() || amount <= 0.0D) return 0.0F;
        long now = victim.level().getGameTime();
        if (victim.getHealth() - amount <= 0.0F
                && allowPpSave && canPpSave(victim, now)) {
            activatePp(victim, now);
            return 0.0F;
        }
        float dealt = (float) Math.min(Math.max(0.0D, amount), (double) victim.getHealth());
        if (dealt <= 0.0F) return 0.0F;
        victim.setHealth(Math.max(0.0F, victim.getHealth() - dealt));
        // setHealth 压到零血后 isAlive() 已为 false；必须无条件 die()，否则目标停留在零生命状态、
        // 死亡登记（含博士巴别塔回忆的死亡快照）等一律等不到。die() 内部会对已死/已移除再判。
        if (victim.getHealth() <= 0.0F) {
            if (derived) LearnedTraitLogic.markDerivedKill(victim);
            victim.die(attributionSource(holder, victim.level()));
        }
        return dealt;
    }

    /**
     * 一次“造成伤害”的派生判定：50%吸血、32.5%削减（先）、削减之后再判0.325%源石之始。
     * 源石之始与虚空每秒伤害不再派生新的判定链，避免自我放大。
     */
    private static void procOnDamage(LivingEntity holder, LivingEntity victim, double dealt) {
        if (dealt <= 0.0D) return;
        healHolder(holder, dealt * LIFESTEAL_RATIO);
        if (victim == null || !victim.isAlive()) return;
        Level level = victim.level();
        if (level.getRandom().nextDouble() < HP_CUT_CHANCE) {
            double cut = dealt * HP_CUT_RATIO * (hasYin(victim) ? YIN_CUT_BOOST : 1.0D);
            applyMaxHpCut(holder, victim, cut);
        }
        if (victim.isAlive() && level.getRandom().nextDouble() < GENESIS_CHANCE) {
            double genesis = victim.getMaxHealth();
            float genesisDealt = applyTrueDamage(holder, victim, genesis, true, true);
            if (genesisDealt > 0.0F) {
                healHolder(holder, genesisDealt * LIFESTEAL_RATIO);
            }
        }
    }

    /**
     * 最大生命值削减；玩家目标且削减量达到现有生命值时执行“立刻击杀”。
     * “如我所见”的阳火共用这条上限削减/处刑通道。
     * 玩家普通削减按 {@link #PLAYER_HEALTH_CUT_FLOOR} 保底：上限最多削到 2 点，
     * 够不着保底的剩余削减量转为真实伤害直接压血——致死属于正常死亡，
     * 重生不再被残留削减反复归零处死；非玩家保留“削到归零按正常死亡结算”的原口径。
     */
    public static void applyMaxHpCut(LivingEntity holder, LivingEntity victim, double cut) {
        if (cut <= 0.0D || !victim.isAlive()) return;
        CompoundTag vd = victim.getPersistentData();
        if (victim instanceof Player && cut >= victim.getHealth()) {
            // 无视复活能力与锁血能力：不走任何受击事件，直接压血结算死亡。
            vd.putBoolean(EXEC_PENDING, true);
            victim.setHealth(0.0F);
            // setHealth(0) 后 isAlive() 已为 false；必须无条件 die()，否则目标停留在零生命状态、
            // 死亡登记（含博士巴别塔回忆的死亡快照）等一律等不到。die() 内部会对已死/已移除再判。
            victim.die(attributionSource(holder, victim.level()));
            return;
        }
        if (victim instanceof Player player) {
            // 玩家保底口径：削减量先把生效上限削向 2 点，削不进的部分转真实伤害。
            double floorRoom = Math.max(0.0D, player.getMaxHealth() - PLAYER_HEALTH_CUT_FLOOR);
            double applied = Math.min(cut, floorRoom);
            double overflow = cut - applied;
            if (applied > 0.0D) {
                vd.putDouble(MAX_HP_CUT, vd.getDouble(MAX_HP_CUT) - applied);
                MaxHealthZeroLogic.markCutAttribution(victim, holder);
                syncModifiers(victim);
                if (victim.getHealth() > victim.getMaxHealth()) {
                    victim.setHealth(victim.getMaxHealth());
                }
            }
            if (overflow > 0.0D) {
                // 溢出真实伤害致死等同于原“削减致死”口径：照常挂处刑锁定（复活后上限钉 1），
                // 且按击杀者归属记入正常死亡链，重生不受残留削减影响。
                if (overflow >= victim.getHealth()) {
                    vd.putBoolean(EXEC_PENDING, true);
                }
                applyTrueDamage(holder, victim, overflow, false, false);
            }
            return;
        }
        vd.putDouble(MAX_HP_CUT, vd.getDouble(MAX_HP_CUT) - cut);
        // 归零结算按击杀者归属：记名本轮削减者后，属性同步里若上限已 0 即正常死亡。
        MaxHealthZeroLogic.markCutAttribution(victim, holder);
        syncModifiers(victim);
        if (victim.getHealth() > victim.getMaxHealth()) {
            victim.setHealth(victim.getMaxHealth());
        }
    }

    /** 回复持有者；满血时溢出部分转化为最大生命上限。 */
    public static void healHolder(LivingEntity holder, double amount) {
        if (holder == null || !holder.isAlive() || amount <= 0.0D || !hasAccess(holder)) return;
        CompoundTag d = holder.getPersistentData();
        float before = holder.getHealth();
        holder.heal((float) amount);
        double overflow = amount - (holder.getHealth() - before);
        if (overflow > 0.0D) {
            d.putDouble(EXTRA_HEALTH, Math.max(0.0D, d.getDouble(EXTRA_HEALTH)) + overflow);
            syncModifiers(holder);
            holder.heal((float) overflow);
        }
    }

    // ---------------- 流放虚空 / 内化宇宙 ----------------

    private static void beginExile(LivingEntity victim, LivingEntity owner, int mode, long durationTicks) {
        Level level = victim.level();
        if (!(level instanceof ServerLevel serverLevel) || !victim.isAlive()) return;
        long now = level.getGameTime();
        CompoundTag d = victim.getPersistentData();
        // 已在流放中（例如内化宇宙接管普通流放）时保留最初的空间锚点。
        if (d.getLong(EXILE_UNTIL) <= now) {
            d.putDouble(EXILE_AX, victim.getX());
            d.putDouble(EXILE_AY, victim.getY());
            d.putDouble(EXILE_AZ, victim.getZ());
        }
        d.putLong(EXILE_UNTIL, now + durationTicks);
        d.putInt(EXILE_MODE, mode);
        d.putLong(EXILE_NEXT, now + 20L);
        d.putLong(EXILE_DPS, Double.doubleToLongBits(mode == EXILE_MODE_VOID
                ? Math.max(1.0D, owner.getMaxHealth() * EXILE_DPS_RATIO) : 0.0D));
        d.putString(EXILE_OWNER, owner.getUUID().toString());
        double voidY = serverLevel.getMinBuildHeight() - 8;
        d.putDouble(EXILE_VX, victim.getX());
        d.putDouble(EXILE_VY, voidY);
        d.putDouble(EXILE_VZ, victim.getZ());
        if (victim instanceof Mob mob) {
            // 放逐即沉默：丢弃索敌目标、停掉寻路并进入无 AI，杜绝其在虚空中继续攻击/施放判定。
            mob.setNoAi(true);
            mob.setTarget(null);
            mob.getNavigation().stop();
        }
        victim.setNoGravity(true);
        victim.setDeltaMovement(Vec3.ZERO);
        victim.fallDistance = 0.0F;
        victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, (int) durationTicks + 40, 255,
                false, false));
        victim.teleportTo(victim.getX(), voidY, victim.getZ());
        serverLevel.playSound(null, victim.getX(), voidY, victim.getZ(),
                SoundEvents.CHORUS_FRUIT_TELEPORT, SoundSource.PLAYERS, 1.0F, 0.7F);
        spawnAnchorParticles(serverLevel, victim.getX(), voidY, victim.getZ());
        // 强加载虚空所在区块：确保被流放者持续 tick，玩家走多远都能按时归来。
        // 已在流放中（例如内化宇宙接管普通流放）时保留原有的强加载引用，避免重复计数。
        if (!d.getBoolean(EXILE_FORCED)) {
            int cx = Mth.floor(victim.getX()) >> 4;
            int cz = Mth.floor(victim.getZ()) >> 4;
            forceChunk(serverLevel, cx, cz);
            d.putInt(EXILE_CX, cx);
            d.putInt(EXILE_CZ, cz);
            d.putBoolean(EXILE_FORCED, true);
            FORCED_APPLIED.add(victim.getUUID());
        }
    }

    private static void endExile(LivingEntity entity, boolean returnToAnchor) {
        CompoundTag d = entity.getPersistentData();
        if (d.getLong(EXILE_UNTIL) <= 0L) return;
        double ax = d.getDouble(EXILE_AX);
        double ay = d.getDouble(EXILE_AY);
        double az = d.getDouble(EXILE_AZ);
        d.remove(EXILE_UNTIL);
        d.remove(EXILE_MODE);
        d.remove(EXILE_NEXT);
        d.remove(EXILE_DPS);
        d.remove(EXILE_OWNER);
        // 释放虚空区块强加载引用；最后一个离开该区块的实体才真正解除强加载。
        if (d.getBoolean(EXILE_FORCED)) {
            int cx = d.getInt(EXILE_CX);
            int cz = d.getInt(EXILE_CZ);
            if (entity.level() instanceof ServerLevel serverLevel) {
                releaseChunk(serverLevel, cx, cz);
            }
            d.remove(EXILE_CX);
            d.remove(EXILE_CZ);
            d.remove(EXILE_FORCED);
            FORCED_APPLIED.remove(entity.getUUID());
        }
        if (entity.isAlive()) {
            entity.setNoGravity(false);
            if (entity instanceof Mob mob) mob.setNoAi(false);
            entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
            entity.setDeltaMovement(Vec3.ZERO);
            if (returnToAnchor) {
                entity.teleportTo(ax, ay, az);
                if (entity.level() instanceof ServerLevel serverLevel) {
                    spawnAnchorParticles(serverLevel, ax, ay, az);
                    serverLevel.playSound(null, ax, ay, az,
                            SoundEvents.CHORUS_FRUIT_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.3F);
                }
            }
        }
    }

    private static void spawnAnchorParticles(ServerLevel level, double x, double y, double z) {
        level.sendParticles(ParticleTypes.PORTAL, x, y + 1.0D, z, 40, 0.4D, 1.0D, 0.4D, 0.15D);
        level.sendParticles(ParticleTypes.END_ROD, x, y + 1.0D, z, 12, 0.3D, 0.8D, 0.3D, 0.02D);
    }

    // ---------------- 虚空强加载 ----------------

    /** 强加载一个区块（引用计数：最后一个使用者解除时才真正解除）。 */
    private static void forceChunk(ServerLevel level, int cx, int cz) {
        long key = ChunkPos.asLong(cx, cz);
        Map<Long, Integer> dimMap = FORCED_CHUNKS.computeIfAbsent(level.dimension(), k -> new HashMap<>());
        int count = dimMap.merge(key, 1, Integer::sum);
        if (count == 1) {
            level.setChunkForced(cx, cz, true);
        }
    }

    /** 释放一个区块的强加载引用；引用归零时真正解除强加载。 */
    private static void releaseChunk(ServerLevel level, int cx, int cz) {
        Map<Long, Integer> dimMap = FORCED_CHUNKS.get(level.dimension());
        if (dimMap == null) return;
        long key = ChunkPos.asLong(cx, cz);
        Integer n = dimMap.get(key);
        if (n == null) return;
        if (n <= 1) {
            dimMap.remove(key);
            level.setChunkForced(cx, cz, false);
        } else {
            dimMap.put(key, n - 1);
        }
        if (dimMap.isEmpty()) {
            FORCED_CHUNKS.remove(level.dimension());
        }
    }

    /**
     * 在流放期间回收强加载状态（含服务端重启后重新施加）。
     * 重启后静态索引被清空、而实体的持久化标记仍在，需要在首次 tick 时重新 setChunkForced，
     * 否则重启后处于流放中的实体所在区块不再被强加载，会因区块卸载而永远无法归来。
     */
    private static void ensureExileChunkForced(LivingEntity entity) {
        CompoundTag d = entity.getPersistentData();
        if (!d.getBoolean(EXILE_FORCED)) return;
        if (entity.level() instanceof ServerLevel level && !FORCED_APPLIED.contains(entity.getUUID())) {
            forceChunk(level, d.getInt(EXILE_CX), d.getInt(EXILE_CZ));
            FORCED_APPLIED.add(entity.getUUID());
        }
    }

    /**
     * 内化宇宙：拉入范围内所有带阴/阳标记的存活生物（含使用者与目标）。
     * “阴”（天堂支点流放触发）与“阳”（如我所见锚定触发）共用这条虚空通道。
     * 触发中心生成紫色明亮光点：4秒逐渐扩张至半径32格、伴随玩家提供的音乐，
     * 内化宇宙结束时收拢成小光点熄灭并清除所有阴/阳标记；全体被拉入者于结束时附加一分二十六秒速度II。
     */
    public static void triggerUniverse(LivingEntity holder, LivingEntity victim, String label) {
        Level level = holder.level();
        if (!(level instanceof ServerLevel serverLevel)) return;
        // 阴/阳与开放是独立判定的两套机制，可能在同一次施加印记时同时满足条件。
        // 目标一旦已被本 tick 拉入内化宇宙，就不再重复拉入，避免双重光点与双重播报。
        if (victim != null && isExiled(victim)
                && victim.getPersistentData().getInt(EXILE_MODE) == EXILE_MODE_UNIVERSE) {
            return;
        }
        // 触发中心：必须在放逐传送前取坐标，光点与音乐都以这里为准。
        Vec3 center = victim.position();
        boolean openUniverse = label.contains("开放");
        Set<LivingEntity> marked = new LinkedHashSet<>();
        if (!openUniverse) marked.add(holder);
        marked.add(victim);
        List<LivingEntity> candidates = serverLevel.getEntitiesOfClass(LivingEntity.class,
                victim.getBoundingBox().inflate(openUniverse ? 64.0D : 128.0D),
                entity -> entity.isAlive() && (openUniverse || hasYin(entity) || hasYang(entity)));
        marked.addAll(candidates);
        if (openUniverse) {
            marked.removeIf(entity -> entity.distanceToSqr(victim) > 64.0D * 64.0D);
        }
        List<LivingEntity> pulled = new ArrayList<>();
        for (LivingEntity entity : marked) {
            if (!entity.isAlive()) continue;
            pulled.add(entity);
            beginExile(entity, holder, EXILE_MODE_UNIVERSE, UNIVERSE_TICKS);
            // 内化宇宙期间（含归来后兑现原本效果）死亡不可复活。
            entity.getPersistentData().putBoolean(UNIVERSE_NO_REVIVE, true);
            if (entity instanceof Player player) {
                player.displayClientMessage(Component.literal(label)
                        .withStyle(ChatFormatting.DARK_PURPLE), true);
            }
        }
        serverLevel.playSound(null, center.x, center.y, center.z,
                SoundEvents.END_PORTAL_SPAWN, SoundSource.PLAYERS, 1.0F, 1.0F);
        UniverseLightLogic.trigger(serverLevel, center, pulled, UNIVERSE_TICKS);
    }

    /** 清除目标的“阴”“阳”两枚标记（虚空传送时间结束时由光点管理器统一调用）。 */
    public static void clearYinYangMarks(LivingEntity entity) {
        if (entity == null || entity.level().isClientSide) return;
        CompoundTag d = entity.getPersistentData();
        d.remove(YIN_UNTIL);
        d.remove(YANG_UNTIL);
    }

    /**
     * 内化宇宙接管时记录“原本效果”（流放虚空或锚定现实），将其推迟到 10 秒判定归来后兑现。
     *
     * @param mode          DEFER_MODE_VOID（流放虚空）或 DEFER_MODE_ANCHOR（锚定现实）
     * @param durationTicks 原本效果的时长（tick）：流放时长或锚定停滞时长
     */
    public static void deferOriginalEffect(LivingEntity victim, LivingEntity owner, int mode, long durationTicks) {
        if (victim == null || victim.level().isClientSide) return;
        CompoundTag d = victim.getPersistentData();
        d.putInt(DEFER_TYPE, mode);
        d.putString(DEFER_OWNER, owner == null ? "" : owner.getUUID().toString());
        d.putLong(DEFER_DURATION, durationTicks);
        // 延迟的流放虚空/锚定现实从触发时起持续到原效果结束，期间死亡不得复活。
        d.putBoolean(UNIVERSE_NO_REVIVE, true);
    }

    /** 内化宇宙/延迟原效果期间、以及生命上限归零死亡不可复活（CalamityMob.die 读取）。 */
    public static boolean isNoRevive(LivingEntity entity) {
        if (entity == null) return false;
        // 感染坍缩后失去复活与一切死亡后效果：死亡不再写入任何复活波次/复活快照。
        if (CalamityLogic.isCollapsed(entity)) return true;
        CompoundTag d = entity.getPersistentData();
        // 兼容已存在的延迟效果数据：即使旧数据没有布尔标记，延迟记录本身也代表锁定期。
        return d.getBoolean(UNIVERSE_NO_REVIVE) || d.getInt(DEFER_TYPE) != 0
                || d.getBoolean(MaxHealthZeroLogic.CAP_ZERO_DEATH);
    }

    /** 把当前不可复活状态写入死亡快照，供复活调度器在事件链之外再次校验。 */
    public static void writeRevivalNoRevive(LivingEntity entity, CompoundTag snapshot) {
        if (entity != null && snapshot != null && isNoRevive(entity)) {
            snapshot.putBoolean(REVIVAL_NO_REVIVE, true);
        }
    }

    /** 判断死亡快照是否在内化宇宙或其延迟原效果期间生成。 */
    public static boolean snapshotIsNoRevive(CompoundTag snapshot) {
        return snapshot != null && snapshot.getBoolean(REVIVAL_NO_REVIVE);
    }

    /** 原本效果结束后解除“不可复活”标记（目标存活归来）。 */
    public static void clearNoRevive(LivingEntity entity) {
        if (entity == null) return;
        entity.getPersistentData().remove(UNIVERSE_NO_REVIVE);
    }

    /**
     * 「巴别塔回忆」无视彻底死亡时的收尾清理：死亡快照重建出的博士会带回死亡瞬间的
     * 复活阻断（内化宇宙/延迟原效果、处刑锁定）、生命上限削减与“彻底击败”标记。
     * 若不清掉，重建后的博士会在下一 tick 被 {@link #syncModifiers} 重新削到上限归零而再次死亡，
     * 或被复活/转化链继续当作不可复活目标。这里把这类状态一次性抹掉，让复活真正生效。
     */
    public static void clearThoroughDefeatState(LivingEntity entity) {
        if (entity == null || entity.level().isClientSide) return;
        CompoundTag d = entity.getPersistentData();
        d.remove(UNIVERSE_NO_REVIVE);
        d.remove(DEFER_TYPE);
        d.remove(DEFER_OWNER);
        d.remove(DEFER_DURATION);
        d.remove(EXEC_PENDING);
        d.remove(EXEC_LOCK_UNTIL);
        d.remove(MAX_HP_CUT);
        d.remove(UNIVERSE_HP);
        d.remove(CalamityMob.THOROUGH_DEFEAT_TAG);
        AttributeInstance maxHealth = entity.getAttribute(Attributes.MAX_HEALTH);
        if (maxHealth != null) {
            clearHealthModifiers(maxHealth);
        }
        MaxHealthZeroLogic.clearCapZero(entity);
    }

    /**
     * 内化宇宙结束（目标回到战场）时兑现被推迟的“原本效果”。
     * 效果造成者死亡则取消该效果；目标在内化宇宙中死亡则保持“不可复活”。
     */
    private static void resolveDeferredEffect(LivingEntity entity, long now) {
        if (entity == null || entity.level().isClientSide) return;
        CompoundTag d = entity.getPersistentData();
        int type = d.getInt(DEFER_TYPE);
        if (type == 0) {
            // 无推迟效果的普通内化宇宙：归来后解除“不可复活”。
            if (entity.isAlive()) d.remove(UNIVERSE_NO_REVIVE);
            return;
        }
        String ownerUuid = d.getString(DEFER_OWNER);
        long duration = d.getLong(DEFER_DURATION);
        d.remove(DEFER_TYPE);
        d.remove(DEFER_OWNER);
        d.remove(DEFER_DURATION);
        if (!entity.isAlive()) {
            // 目标在内化宇宙中死亡：保持“不可复活”，原本效果不再触发。
            return;
        }
        LivingEntity owner = null;
        if (!ownerUuid.isEmpty() && entity.level() instanceof ServerLevel serverLevel) {
            try {
                owner = serverLevel.getEntity(UUID.fromString(ownerUuid)) instanceof LivingEntity living
                        ? living : null;
            } catch (IllegalArgumentException ignored) {
            }
        }
        if (owner == null || !owner.isAlive()) {
            // 效果造成者死亡：原本效果不会触发；目标存活则解除“不可复活”。
            d.remove(UNIVERSE_NO_REVIVE);
            return;
        }
        // 造成者存活、目标存活：兑现原本效果（流放虚空 / 锚定现实）。
        if (type == DEFER_MODE_VOID) {
            beginExile(entity, owner, EXILE_MODE_VOID, duration);
            setYinMark(entity);
            AbilityCooldowns.armFor(owner, entity, now, EXILE_MARK_TICKS, EXILE_CD_ABILITY);
            if (entity instanceof Player target) {
                target.displayClientMessage(Component.literal("流放虚空：目标已被放逐")
                        .withStyle(ChatFormatting.DARK_AQUA), true);
            }
        } else if (type == DEFER_MODE_ANCHOR) {
            RuwosuojianLogic.applyDeferredAnchor(owner, entity, duration, now);
        }
        // 保持 UNIVERSE_NO_REVIVE，直到原本效果（流放结束/锚定结束）解除。
    }

    /** 流放/内化期间每秒一次的虚空结算。 */
    private static void tickExile(LivingEntity entity, CompoundTag d, long now) {
        if (entity.tickCount % 5 == 0 && entity.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.PORTAL, entity.getX(), entity.getY() + 1.0D, entity.getZ(),
                    6, 0.3D, 0.7D, 0.3D, 0.05D);
        }
        if (now < d.getLong(EXILE_NEXT)) return;
        d.putLong(EXILE_NEXT, now + 20L);
        if (d.getInt(EXILE_MODE) == EXILE_MODE_VOID) {
            // 每秒：使用者最大生命值1%的伤害（按使用者当前上限实时计算）。流放中免死无效。
            LivingEntity owner = resolveExileOwner(entity);
            double dps = owner != null && owner.isAlive()
                    ? Math.max(1.0D, owner.getMaxHealth() * EXILE_DPS_RATIO)
                    : Double.longBitsToDouble(d.getLong(EXILE_DPS));
            if (dps > 0.0D) {
                applyTrueDamage(owner != null ? owner : entity, entity, dps, false, true);
            }
        } else {
            if (entity.tickCount % 10 == 0 && entity.level() instanceof ServerLevel anchorLevel) {
                // 空间锚点持续闪烁，标记 10 秒后的归位之处。
                anchorLevel.sendParticles(ParticleTypes.END_ROD,
                        d.getDouble(EXILE_AX), d.getDouble(EXILE_AY) + 1.0D, d.getDouble(EXILE_AZ),
                        6, 0.25D, 0.6D, 0.25D, 0.01D);
            }
            universeRoll(entity, d);
        }
    }

    private static LivingEntity resolveExileOwner(LivingEntity entity) {
        if (!(entity.level() instanceof ServerLevel serverLevel)) return null;
        String owner = entity.getPersistentData().getString(EXILE_OWNER);
        if (owner.isEmpty()) return null;
        try {
            return serverLevel.getEntity(UUID.fromString(owner)) instanceof LivingEntity living ? living : null;
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    /** 内化宇宙每秒判定：5%即死；其余95%在八档生命增减中平分。 */
    private static void universeRoll(LivingEntity entity, CompoundTag d) {
        Level level = entity.level();
        // 这条武器特效的致死走的是不带实体的 magic 伤害来源，击杀事件解析不出武器持有者；
        // 先把持有者记为目标当前的击杀归属，学习（含莱特兰词条与等级继承）才不会漏掉这次击杀。
        LivingEntity owner = resolveExileOwner(entity);
        if (level.getRandom().nextDouble() < UNIVERSE_DEATH_CHANCE) {
            entity.setHealth(0.0F);
            // setHealth(0) 后 isAlive() 已为 false；必须无条件 die()，否则目标停留在零生命状态、
            // 死亡登记（含博士巴别塔回忆的死亡快照）等一律等不到。die() 内部会对已死/已移除再判。
            if (owner != null) LearnedTraitLogic.recordKillCredit(owner, entity);
            entity.die(level.damageSources().magic());
            return;
        }
        int slot = level.getRandom().nextInt(8);
        double max = entity.getMaxHealth();
        double delta = switch (slot) {
            case 0 -> 3250.0D;
            case 1 -> 325.0D;
            case 2 -> max * 0.0325D;
            case 3 -> max * 0.325D;
            case 4 -> -3250.0D;
            case 5 -> -325.0D;
            case 6 -> -max * 0.0325D;
            default -> -max * 0.325D;
        };
        d.putDouble(UNIVERSE_HP, d.getDouble(UNIVERSE_HP) + delta);
        syncModifiers(entity);
        if (delta > 0.0D) {
            entity.heal((float) delta);
        } else {
            // “及血量”：上限与当前血量同时下降；免死在本状态无效。
            entity.setHealth(Math.max(0.0F, entity.getHealth() + (float) delta));
            // setHealth 压到零血后 isAlive() 已为 false；必须无条件 die()，否则目标停留在零生命状态、
            // 死亡登记（含博士巴别塔回忆的死亡快照）等一律等不到。die() 内部会对已死/已移除再判。
            if (entity.getHealth() <= 0.0F) {
                if (owner != null) LearnedTraitLogic.recordKillCredit(owner, entity);
                entity.die(level.damageSources().magic());
            }
        }
        if (entity instanceof Player player) {
            String sign = delta >= 0.0D ? "+" : "";
            player.displayClientMessage(Component.literal("内化宇宙判定：" + sign + format2(delta))
                    .withStyle(delta >= 0.0D ? ChatFormatting.GREEN : ChatFormatting.RED), true);
        }
    }

    private static String format2(double value) {
        return String.format(Locale.ROOT, "%.2f", value);
    }

    // ---------------- 咫尺天堂 ----------------

    /** 32.5秒 @ 1000血基准；每层（每翻十倍血量算一层）降低初始时间20%，加成最大降低80%。 */
    private static long ppIntervalTicks(double maxHealth) {
        double ratio = Math.max(1.0D, maxHealth) / PP_BASE_HEALTH;
        int tier = (int) Math.floor(Math.log10(ratio));
        if (tier < 0) tier = 0;
        // 每层降低初始时间20%（×0.8），时长缩短加成最大80%，即最短为基准时间的20%。
        double factor = Math.pow(0.8D, tier);
        if (factor < 0.2D) factor = 0.2D;
        long ticks = Math.round(PP_BASE_INTERVAL_TICKS * factor);
        return Math.max(1L, ticks);
    }

    private static void activatePp(LivingEntity victim, long now) {
        CompoundTag d = victim.getPersistentData();
        d.putLong(PP_LAST_USE, now);
        d.putLong(PP_INVULN_UNTIL, now + PP_INVULN_TICKS);
        d.putLong(PP_PENDING_UNTIL, now + PP_INVULN_TICKS);
        if (victim.level() instanceof ServerLevel level) {
            level.playSound(null, victim.getX(), victim.getY(), victim.getZ(),
                    SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 1.0F, 1.0F);
            level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, victim.getX(), victim.getY() + 1.0D, victim.getZ(),
                    30, 0.5D, 0.8D, 0.5D, 0.05D);
        }
        if (victim instanceof Player player) {
            player.displayClientMessage(Component.literal("咫尺天堂：拒绝死亡，10秒无敌")
                    .withStyle(ChatFormatting.GOLD), true);
        }
    }

    // ---------------- 属性同步 ----------------

    /**
     * 依据持久化数据重建最大生命值修饰符：源石权柄溢出加成、内化宇宙增减、生命削减、
     * 咫尺天堂的50%累计衰减，以及“处刑锁定”期间强制生命上限为1。
     */
    public static void syncModifiers(LivingEntity entity) {
        if (entity == null || entity.level().isClientSide) return;
        AttributeInstance maxHealth = entity.getAttribute(Attributes.MAX_HEALTH);
        if (maxHealth == null) return;
        CompoundTag d = entity.getPersistentData();
        long now = entity.level().getGameTime();
        // 先整体清除本逻辑写入的生命修饰符，再按当前状态重建：
        // 同步入口同时挂在受击事件、治疗回调与周期 tick 上，必须可重入，
        // 否则同一 UUID 被重复添加会让原版抛出
        // “Modifier is already applied on this attribute!” 并直接崩服。
        clearHealthModifiers(maxHealth);
        if (d.getLong(EXEC_LOCK_UNTIL) > now) {
            // 被“阴”执行后的复活锁定：生命上限强制为1，所有武器加成视为0。
            OfcAttributes.set(maxHealth, FLOOR_UUID, "天堂支点•处刑锁定",
                    1.0D - maxHealth.getValue(), AttributeModifier.Operation.ADDITION);
        } else {
            boolean hasSword = hasAccess(entity);
            if (!hasSword) {
                // “丢弃或掉落后清除加成”：武器离开携带范围时，源石权柄的溢出生命立即消失。
                d.remove(EXTRA_HEALTH);
            }
            double extra = hasSword ? Math.max(0.0D, d.getDouble(EXTRA_HEALTH)) : 0.0D;
            double universe = d.getDouble(UNIVERSE_HP);
            double cut = Math.min(0.0D, d.getDouble(MAX_HP_CUT));
            int stacks = d.getInt(PP_STACKS);
            OfcAttributes.set(maxHealth, EXTRA_UUID, "天堂支点•源石权柄", extra,
                    AttributeModifier.Operation.ADDITION);
            OfcAttributes.set(maxHealth, UNIVERSE_UUID, "天堂支点•内化宇宙", universe,
                    AttributeModifier.Operation.ADDITION);
            OfcAttributes.set(maxHealth, CUT_UUID, "天堂支点•生命削减", cut,
                    AttributeModifier.Operation.ADDITION);
            // 每层咫尺天堂把上限×0.5：MULTIPLY_TOTAL 的 (1+amount) = 0.5^stacks。
            OfcAttributes.set(maxHealth, PP_UUID, "天堂支点•咫尺代价",
                    Math.pow(0.5D, stacks) - 1.0D, AttributeModifier.Operation.MULTIPLY_TOTAL, stacks > 0);
            // 不再给所有实体设“生存下限”：上限原始总值被削到 0 视为正常死亡（见 MaxHealthZeroLogic）。
            // 玩家则按保底 2 点口径处理：任何来源（本模组削减叠加、内化宇宙负档、咫尺天堂衰减、
            // 外部模组、旧存档残留的“钉 1”状态）把生效上限压到 2 以下时一律钉回 2——
            // 玩家的生效上限从此不会归零，重生后也不会再被残留削减反复处死，
            // 从根源解决“削减上限死亡后重复死亡、无法复活”的死循环。1.20.1 原版
            // MAX_HEALTH 生效值下限是 2.0E-10，钉不住，必须由本逻辑自行抬。
            if (entity instanceof Player && maxHealth.getValue() < PLAYER_HEALTH_CUT_FLOOR) {
                OfcAttributes.set(maxHealth, FLOOR_UUID, "天堂支点•玩家保底",
                        PLAYER_HEALTH_CUT_FLOOR - maxHealth.getValue(), AttributeModifier.Operation.ADDITION);
            }
        }
        if (entity.getHealth() > entity.getMaxHealth()) {
            entity.setHealth(entity.getMaxHealth());
        }
        // 任何来源的削减在此处生效后立即结算：原始上限总值归零的实体当场按正常死亡处理。
        MaxHealthZeroLogic.settleIfZeroCap(entity);
    }

    /** 清除本类写入最大生命值上的全部修饰符。 */
    private static void clearHealthModifiers(AttributeInstance maxHealth) {
        OfcAttributes.clear(maxHealth, EXTRA_UUID);
        OfcAttributes.clear(maxHealth, UNIVERSE_UUID);
        OfcAttributes.clear(maxHealth, CUT_UUID);
        OfcAttributes.clear(maxHealth, PP_UUID);
        OfcAttributes.clear(maxHealth, FLOOR_UUID);
    }

    // ---------------- 事件入口 ----------------

    // 注意：嵌套类简单名必须全局唯一，原因见 RuwosuojianLogic.RuwosuojianEvents 的注释。
    public static final class TiantangzhidianEvents {

        public TiantangzhidianEvents() {
        }

        @SubscribeEvent
        public void onLivingAttack(LivingAttackEvent event) {
            LivingEntity victim = event.getEntity();
            Level level = victim.level();
            if (level.isClientSide || event.isCanceled()) return;
            CompoundTag vd = victim.getPersistentData();
            long now = level.getGameTime();
            if (vd.getBoolean(INTERNAL_DAMAGE)) {
                vd.remove(INTERNAL_DAMAGE);
                return;
            }
            // 咫尺天堂：无敌期内所有伤害无效。
            if (vd.getLong(PP_INVULN_UNTIL) > now) {
                event.setCanceled(true);
                return;
            }
            // 流放期间身处虚空，无法被任何外部来源命中。
            if (isExiled(victim)) {
                event.setCanceled(true);
                return;
            }
            DamageSource source = event.getSource();
            LivingEntity attacker = source.getEntity() instanceof LivingEntity living ? living : null;
            // 被放逐者无法攻击。
            if (attacker != null && isExiled(attacker)) {
                event.setCanceled(true);
                return;
            }
            float incoming = event.getAmount();
            if (attacker != null && attacker != victim && isSwordAttackSource(source)) {
                // 第一段：使用者最大生命值40%的真实伤害；第二段仍交给原版伤害链结算。
                double first = attacker.getMaxHealth() * FIRST_STAGE_RATIO;
                boolean targetHadYangBefore = hasYang(victim);
                if (first + incoming >= victim.getHealth() && canPpSave(victim, now)) {
                    // 整段致死：咫尺天堂拒绝本次攻击。
                    event.setCanceled(true);
                    activatePp(victim, now);
                    return;
                }
                float dealt = applyTrueDamage(attacker, victim, first, false, false);
                if (dealt > 0.0F) {
                    procOnDamage(attacker, victim, dealt);
                }
                if (victim.isAlive()) {
                    // 第二段的“造成伤害”按面板数值参与派生判定（吸血/削减/源石之始）。
                    procOnDamage(attacker, victim, incoming);
                    requestExileRoll(attacker, victim, targetHadYangBefore, now);
                }
                // 不取消事件：原版本段伤害（第二段）照常走护甲、盾牌与附魔链。
                return;
            }
            // 咫尺天堂：其它来源的致命伤害同样拒绝死亡。
            if (victim.isAlive() && incoming >= victim.getHealth() && canPpSave(victim, now)) {
                event.setCanceled(true);
                activatePp(victim, now);
            }
        }

        /** 流放判定：基础3.25%，每次未触发攻击 +0.5%，触发后回到基础；延迟到下一tick落地。 */
        private void requestExileRoll(LivingEntity holder, LivingEntity victim, boolean targetHadYang, long now) {
            if (victim instanceof ServerPlayer target && (target.isCreative() || target.isSpectator())) return;
            // 冷却记在施术者（holder）身上、按目标分开：同种生物各记各的，不会互相吞掉。
            if (!AbilityCooldowns.readyFor(holder, victim, now, EXILE_CD_ABILITY)) return;
            CompoundTag hd = holder.getPersistentData();
            int streak = hd.getInt(EXILE_STREAK);
            double chance = EXILE_CHANCE + streak * EXILE_CHANCE_STEP;
            if (victim.level().getRandom().nextDouble() < chance) {
                // 触发：重置连续未触发计数，回到基础概率。
                hd.putInt(EXILE_STREAK, 0);
                CompoundTag vd = victim.getPersistentData();
                vd.putBoolean(EXILE_REQUEST, true);
                vd.putBoolean(EXILE_REQUEST_YANG, targetHadYang);
                vd.putString(EXILE_REQUEST_OWNER, holder.getUUID().toString());
            } else {
                // 未触发：连续计数 +1，下一次概率提高 0.5%。
                hd.putInt(EXILE_STREAK, streak + 1);
            }
        }

        @SubscribeEvent
        public void onLivingDeath(LivingDeathEvent event) {
            LivingEntity victim = event.getEntity();
            Level level = victim.level();
            if (level.isClientSide || !(level instanceof ServerLevel serverLevel)) return;
            victim.getPersistentData().remove(EXILE_REQUEST);
            // 流放中死亡：先回到空间锚点再落地，避免掉落物消散在虚空底部。
            if (isExiled(victim)) {
                CompoundTag d = victim.getPersistentData();
                double ax = d.getDouble(EXILE_AX);
                double ay = d.getDouble(EXILE_AY);
                double az = d.getDouble(EXILE_AZ);
                endExile(victim, false);
                victim.teleportTo(ax, ay, az);
            }
            // 极•源石权柄•阴：半径32格内死亡的生物按40%死前最大生命值回复携带者。
            if (victim instanceof Player) return;
            double heal = victim.getMaxHealth() * KILL_HEAL_RATIO;
            if (heal <= 0.0D) return;
            for (LivingEntity carrier : serverLevel.getEntitiesOfClass(LivingEntity.class,
                    victim.getBoundingBox().inflate(KILL_HEAL_RADIUS),
                    entity -> entity != victim && entity.isAlive() && hasAccess(entity))) {
                healHolder(carrier, heal);
            }
        }

        @SubscribeEvent
        public void onLivingTick(LivingEvent.LivingTickEvent event) {
            LivingEntity entity = event.getEntity();
            Level level = entity.level();
            if (level.isClientSide) return;
            CompoundTag d = entity.getPersistentData();
            long now = level.getGameTime();
            // 流放申请落地：本tick开始时才真正放逐，确保第二段伤害已结算。
            if (d.getBoolean(EXILE_REQUEST)) {
                d.remove(EXILE_REQUEST);
                boolean hadYang = d.getBoolean(EXILE_REQUEST_YANG);
                String ownerUuid = d.getString(EXILE_REQUEST_OWNER);
                d.remove(EXILE_REQUEST_YANG);
                d.remove(EXILE_REQUEST_OWNER);
                LivingEntity holder = null;
                if (level instanceof ServerLevel serverLevel && !ownerUuid.isEmpty()) {
                    try {
                        holder = serverLevel.getEntity(UUID.fromString(ownerUuid)) instanceof LivingEntity living
                                ? living : null;
                    } catch (IllegalArgumentException ignored) {
                    }
                }
                if (entity.isAlive() && !isExiled(entity) && holder != null && holder.isAlive()
                        && AbilityCooldowns.readyFor(holder, entity, now, EXILE_CD_ABILITY)) {
                    long duration = 200L + level.getRandom().nextInt(1001); // 10~60秒等概率
                    // 流放效果触发：目标获得“阴”标记，随30秒内置冷却一并到期消失。
                    // “阳”标记不再由本武器授予——其唯一来源是“如我所见”的锚定现实。
                    setYinMark(entity);
                    AbilityCooldowns.armFor(holder, entity, now, EXILE_MARK_TICKS, EXILE_CD_ABILITY);
                    if (entity instanceof Player target) {
                        target.displayClientMessage(Component.literal("流放虚空")
                                .withStyle(ChatFormatting.DARK_AQUA), true);
                    }
                    if (holder instanceof Player user) {
                        user.displayClientMessage(Component.literal("流放虚空：目标已被放逐")
                                .withStyle(ChatFormatting.DARK_AQUA), true);
                    }
                    // 无下限•内化宇宙•阴：施术者持有“阳”标记（来源于“如我所见”的锚定现实），
                    // 对目标施加反向印记“阴”。无下限•内化宇宙•开放：同一生物同时持有阴阳两枚印记。
                    // 阴与开放是独立判定的两套机制，此处分别检查，同时满足时由 triggerUniverse 去重。
                    boolean wielderHasYang = hasYang(holder);
                    if (wielderHasYang) {
                        // 阴之机制：内化宇宙接管，原本的流放虚空效果推迟到10秒判定归来后兑现。
                        deferOriginalEffect(entity, holder, DEFER_MODE_VOID, duration);
                        triggerUniverse(holder, entity, "无下限•内化宇宙•阴");
                    }
                    if (hadYang) {
                        // 开放之机制：目标同时持有阴阳两枚印记，原本的流放虚空效果推迟到归来后兑现。
                        deferOriginalEffect(entity, holder, DEFER_MODE_VOID, duration);
                        triggerUniverse(holder, entity, "无下限•内化宇宙•开放");
                    }
                    if (!wielderHasYang && !hadYang) {
                        beginExile(entity, holder, EXILE_MODE_VOID, duration);
                    }
                }
            }
            long until = d.getLong(EXILE_UNTIL);
            if (until > 0L) {
                if (now >= until) {
                    int exileMode = d.getInt(EXILE_MODE);
                    endExile(entity, true);
                    if (exileMode == EXILE_MODE_UNIVERSE) {
                        // 内化宇宙结束（目标回到战场）：兑现被推迟的“原本效果”。
                        resolveDeferredEffect(entity, now);
                    } else if (exileMode == EXILE_MODE_VOID) {
                        // 普通/延迟流放结束：解除“不可复活”。
                        d.remove(UNIVERSE_NO_REVIVE);
                    }
                } else {
                    // 虚空囚禁：无法移动，位置逐tick钉回。
                    // 保证虚空区块始终强加载（进程重启等场景下重新施加），使被流放者按时归来。
                    ensureExileChunkForced(entity);
                    entity.setDeltaMovement(Vec3.ZERO);
                    entity.fallDistance = 0.0F;
                    if (!entity.isNoGravity()) entity.setNoGravity(true);
                    double vx = d.getDouble(EXILE_VX);
                    double vy = d.getDouble(EXILE_VY);
                    double vz = d.getDouble(EXILE_VZ);
                    if (Math.abs(entity.getX() - vx) > 0.25D
                            || Math.abs(entity.getY() - vy) > 0.25D
                            || Math.abs(entity.getZ() - vz) > 0.25D) {
                        entity.teleportTo(vx, vy, vz);
                    }
                    tickExile(entity, d, now);
                }
            }
            // 阴阳印记不再按时间自动清除，只在死亡或内化宇宙判定结束时清除。
            // 处刑锁定：复活后的第一tick向玩家播报（Clone 阶段消息客户端还收不到）。
            if (entity.tickCount == 2 && d.getLong(EXEC_LOCK_UNTIL) > now && entity instanceof Player locked) {
                syncModifiers(locked);
                locked.displayClientMessage(Component.literal("处刑锁定：最大生命值被强制锁定为1，武器生命加成视为0")
                        .withStyle(ChatFormatting.DARK_RED), false);
            }
            // 咫尺天堂：10秒无敌结束后兑现“现有最大生命值降低50%”。
            long pending = d.getLong(PP_PENDING_UNTIL);
            if (pending > 0L && now >= pending) {
                d.putLong(PP_PENDING_UNTIL, 0L);
                d.putInt(PP_STACKS, d.getInt(PP_STACKS) + 1);
                syncModifiers(entity);
                if (entity instanceof Player player) {
                    player.displayClientMessage(Component.literal("咫尺天堂：现有最大生命值降低50%")
                            .withStyle(ChatFormatting.RED), true);
                }
            }
            // 周期性重同步：处理武器丢弃/拾取导致的加成清除与恢复、处刑锁定到期。
            if (entity.tickCount % 10 == 0
                    && (entity instanceof Player || d.contains(MAX_HP_CUT) || d.contains(UNIVERSE_HP))) {
                syncModifiers(entity);
            }
        }

        @SubscribeEvent
        public void onPlayerClone(PlayerEvent.Clone event) {
            if (!event.isWasDeath()) return;
            CompoundTag original = event.getOriginal().getPersistentData();
            CompoundTag copy = event.getEntity().getPersistentData();
            long now = event.getEntity().level().getGameTime();
            // 生命上限相关状态跨死亡保留；“阴”执行标记转为5分钟的复活锁定。
            copy.putInt(PP_STACKS, original.getInt(PP_STACKS));
            copy.putLong(PP_LAST_USE, original.getLong(PP_LAST_USE));
            copy.putDouble(MAX_HP_CUT, original.getDouble(MAX_HP_CUT));
            copy.putDouble(UNIVERSE_HP, original.getDouble(UNIVERSE_HP));
            // 流放内置冷却按生物记录：玩家重生后，自己对各目标的冷却终点原样带过去。
            AbilityCooldowns.copyTargetMap(original, copy, EXILE_CD_ABILITY);
            // “归零兜底已死过一次”标记跨死亡保留：新口径下玩家保底 2 点、
            // 本模组不再造成归零死亡，这里只兜旧存档与外部模组的残留状态。
            copy.putBoolean(MaxHealthZeroLogic.CAP_ZERO_PIN, original.getBoolean(MaxHealthZeroLogic.CAP_ZERO_PIN));
            if (original.getBoolean(EXEC_PENDING)) {
                copy.putLong(EXEC_LOCK_UNTIL, now + EXEC_LOCK_TICKS);
            }
        }
    }
}
