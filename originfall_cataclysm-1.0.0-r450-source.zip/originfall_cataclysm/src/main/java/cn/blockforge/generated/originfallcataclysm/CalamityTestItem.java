package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * 邪魔测试物品：仅供创造模式使用的调试工具。
 *
 * <p>右键任意生物（含玩家）为其附加一层坍缩，走的是与游戏内感染完全相同的入口
 * {@link CalamityLogic#addCollapseLayer}——层数封顶 {@link CalamityLogic#MAX_COLLAPSE_LAYERS}、
 * 无限时长、效果同步与邪魔之约记账全部按正式规则结算，方便在生存/创造里逐层测试
 * 坍缩的移速攻击加成、粒子表现与后续传染链。</p>
 *
 * <p>仅创造可获得：物品不接任何配方、战利品表与村民交易，只出现在本模组创造标签页；
 * 生存模式下即便通过 {@code /give} 拿到，右键也直接拒绝生效。</p>
 */
public final class CalamityTestItem extends Item {
    public CalamityTestItem() {
        super(new Item.Properties().stacksTo(1).fireResistant());
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player,
                                                   LivingEntity target, InteractionHand hand) {
        if (player.level().isClientSide) return InteractionResult.sidedSuccess(true);
        if (!player.getAbilities().instabuild) {
            player.displayClientMessage(Component.literal("邪魔测试物品：仅创造模式可以使用"), true);
            return InteractionResult.CONSUME;
        }
        int current = CalamityLogic.collapseLayers(target);
        if (current >= CalamityLogic.MAX_COLLAPSE_LAYERS) {
            player.displayClientMessage(Component.literal(target.getDisplayName().getString()
                    + " 的坍缩已达上限（" + CalamityLogic.MAX_COLLAPSE_LAYERS + " 层）"), true);
            return InteractionResult.CONSUME;
        }
        CalamityLogic.addCollapseLayer(target, 1);
        player.displayClientMessage(Component.literal(target.getDisplayName().getString()
                + " 坍缩层数：" + CalamityLogic.collapseLayers(target)
                + "/" + CalamityLogic.MAX_COLLAPSE_LAYERS), true);
        return InteractionResult.sidedSuccess(false);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip,
                                 TooltipFlag flag) {
        tooltip.add(Component.literal("右键任意生物：附加一层坍缩（上限"
                + CalamityLogic.MAX_COLLAPSE_LAYERS + "层，走正式感染入口）")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("调试用：仅创造模式可获得与使用")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
