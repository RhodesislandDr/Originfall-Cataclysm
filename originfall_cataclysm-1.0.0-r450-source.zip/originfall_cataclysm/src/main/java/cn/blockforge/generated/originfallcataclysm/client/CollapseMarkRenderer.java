package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.GeneratedMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

/**
 * 坍缩标志：在所有感染坍缩的生物<b>头部前方</b>绘制用户提供的白色贴图。
 *
 * <p>贴图取自参考图整幅画面——中央的白色光环加上向两侧延伸的亮条纹
 * （{@code textures/entity/collapse_mark.png}，128×64，内容占中间 45 行）。贴图以告示牌方式
 * 正对摄像机渲染，带轻微的呼吸式明暗变化。渲染挂在
 * {@link RenderLevelStageEvent.Stage#AFTER_ENTITIES} 阶段，因此对原版、本模组与
 * 其他模组的任意生物一视同仁，不需要给每种实体单独注册渲染层。</p>
 *
 * <p>标志的落点由 {@link #installHeadAnchor} 的锚点钩子决定：装了史诗战斗时，
 * 兼容层从骨架 {@code Head} 关节取世界坐标，标志随连段/翻滚/击倒的头部动画一起动；
 * 没有兼容层时回落到原版「躯干朝向 + 身高」的推算，两者互不干扰。</p>
 *
 * <p>客户端能在这里判断「谁坍缩了」，靠的是服务端在感染与开始跟踪时补发的
 * {@code ClientboundUpdateMobEffectPacket}：原版从不同步普通生物的效果实例，
 * 不补这一包的话这里 {@code getEffect} 恒为 null，贴图永远画不出来。</p>
 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT)
public final class CollapseMarkRenderer {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "textures/entity/collapse_mark.png");
    /** 贴图的宽高比（128×64）。 */
    private static final float TEXTURE_ASPECT = 2.0F;
    /** 贴图里可见内容占整幅高度的比例（内容 45 行 / 画布 64 行，上下留透明边）。 */
    private static final float CONTENT_HEIGHT_RATIO = 45.0F / 64.0F;
    /** 可见内容（中央光环那一圈）的高度，单位格：约为旧版 0.9 格见方标志的一半。 */
    private static final float CONTENT_HEIGHT = 0.45F;
    /** 四边形半高：把「内容高」换算成含透明边在内的整幅贴图高度，再取一半。 */
    private static final float HALF_HEIGHT = CONTENT_HEIGHT / CONTENT_HEIGHT_RATIO / 2.0F;
    /** 四边形半宽：按贴图宽高比展开，两侧亮条纹因此完整保留。 */
    private static final float HALF_WIDTH = HALF_HEIGHT * TEXTURE_ASPECT;
    /** 标志相对实体头部向前偏移的距离（格）。 */
    private static final double FORWARD_OFFSET = 0.55D;

    /**
     * 标志锚点提供者：接管实体渲染的兼容层（当前为史诗战斗）用它把标志钉到<b>动画头骨</b>上。
     *
     * <p>纯模组环境（甚至装了史诗战斗但该实体没有补丁）下该钩子为空，走
     * {@link #vanillaAnchor} 的原版推算。钩子只在客户端安装，且实现方自行兜住异常，
     * 因此它对渲染主循环没有额外风险。</p>
     */
    @FunctionalInterface
    public interface HeadAnchor {
        /**
         * @return 标志要锚定的世界坐标；返回 null 表示该实体不由本锚点接管，调用方回落到原版推算
         */
        Vec3 locate(LivingEntity entity, float partialTick);
    }

    /** 由兼容层在初始化时安装；为空时完全按原版头部推算。 */
    private static volatile HeadAnchor headAnchor;

    private CollapseMarkRenderer() {}

    /**
     * 安装/替换头部锚点提供者。目前由史诗战斗客户端兼容层在初始化时调用一次：
     * 史诗战斗用骨架动画渲染实体，头会随连段、翻滚、击倒等动画离开
     * {@code getViewVector} 所代表的躯干朝向，原版推算出的标志会脱头悬空；
     * 兼容层改为从骨架的 {@code Head} 关节直接取世界坐标，标志因此始终贴在头上。
     */
    public static void installHeadAnchor(HeadAnchor anchor) {
        headAnchor = anchor;
    }

    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) return;
        PoseStack pose = event.getPoseStack();
        Vec3 cameraPos = event.getCamera().getPosition();
        float partialTick = event.getPartialTick();
        RenderType renderType = RenderType.entityTranslucentEmissive(TEXTURE);
        MultiBufferSource.BufferSource buffers = minecraft.renderBuffers().bufferSource();
        VertexConsumer consumer = buffers.getBuffer(renderType);
        boolean rendered = false;
        for (Entity entity : minecraft.level.entitiesForRendering()) {
            if (!(entity instanceof LivingEntity living) || !living.isAlive()) continue;
            MobEffectInstance collapse = living.getEffect(GeneratedMod.COLLAPSE.get());
            if (collapse == null) continue;
            if (!event.getFrustum().isVisible(living.getBoundingBox().inflate(1.5D))) continue;
            // 优先问接管渲染的兼容层要动画头骨坐标；没装（或该实体没被接管）时回落到原版推算。
            HeadAnchor anchor = headAnchor;
            Vec3 head = anchor == null ? null : anchor.locate(living, partialTick);
            if (head == null) head = vanillaAnchor(living, partialTick);
            // 呼吸式明暗：范围 185~255，避免完全熄灭时看不出标志。
            int alpha = 185 + (int) (70.0D
                    * (0.5D + 0.5D * Math.sin((living.tickCount + partialTick) * 0.15D)));
            renderMark(pose, consumer, event.getCamera(), cameraPos, head.x, head.y, head.z, alpha);
            rendered = true;
        }
        if (rendered) buffers.endBatch(renderType);
    }

    /**
     * 原版/无补丁实体的标志位置：躯干朝向的水平前方偏移 {@link #FORWARD_OFFSET} 格，
     * 高度取身高的 92%。原版模型的头没有独立于躯干的位移，这样算与头顶基本重合。
     */
    private static Vec3 vanillaAnchor(LivingEntity living, float partialTick) {
        Vec3 pos = living.getPosition(partialTick);
        Vec3 look = living.getViewVector(partialTick);
        double flat = Math.sqrt(look.x * look.x + look.z * look.z);
        double forwardX = flat < 1.0E-4D ? 0.0D : look.x / flat;
        double forwardZ = flat < 1.0E-4D ? 0.0D : look.z / flat;
        return new Vec3(pos.x + forwardX * FORWARD_OFFSET,
                pos.y + living.getBbHeight() * 0.92D,
                pos.z + forwardZ * FORWARD_OFFSET);
    }

    /** 以摄像机朝向绘制一块正对玩家的贴图四边形（宽高比与贴图一致，两侧条纹不被压扁）。 */
    private static void renderMark(PoseStack pose, VertexConsumer consumer, Camera camera,
                                   Vec3 cameraPos, double x, double y, double z, int alpha) {
        pose.pushPose();
        pose.translate(x - cameraPos.x, y - cameraPos.y, z - cameraPos.z);
        pose.mulPose(camera.rotation());
        Matrix4f matrix = pose.last().pose();
        float w = HALF_WIDTH;
        float h = HALF_HEIGHT;
        consumer.vertex(matrix, -w, -h, 0.0F).color(255, 255, 255, alpha)
                .uv(0.0F, 1.0F).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT)
                .normal(0.0F, 0.0F, 1.0F).endVertex();
        consumer.vertex(matrix, w, -h, 0.0F).color(255, 255, 255, alpha)
                .uv(1.0F, 1.0F).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT)
                .normal(0.0F, 0.0F, 1.0F).endVertex();
        consumer.vertex(matrix, w, h, 0.0F).color(255, 255, 255, alpha)
                .uv(1.0F, 0.0F).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT)
                .normal(0.0F, 0.0F, 1.0F).endVertex();
        consumer.vertex(matrix, -w, h, 0.0F).color(255, 255, 255, alpha)
                .uv(0.0F, 0.0F).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT)
                .normal(0.0F, 0.0F, 1.0F).endVertex();
        pose.popPose();
    }
}
