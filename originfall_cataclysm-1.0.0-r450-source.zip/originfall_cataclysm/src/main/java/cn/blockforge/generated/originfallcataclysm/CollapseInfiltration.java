package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

import java.util.List;

/**
 * 「坍缩渗透」游戏规则的夜间判定。
 *
 * <p>规则默认关闭；开启后，每个晚上 0 点（游戏时间的午夜，即当天第 {@value #NIGHT_TIME_OF_DAY} 刻）
 * 进行一次判定：</p>
 * <ul>
 *   <li>以当前概率感染主世界中一只随机生物，附加一层坍缩；</li>
 *   <li>基础概率 32.5%，当天未感染则次日概率增加 32.5%（封顶 100%）；</li>
 *   <li>成功感染后概率回到初始 32.5%。</li>
 * </ul>
 *
 * <p>概率与「已完成判定的夜晚」记录在 {@link DisasterData} 里随存档保存：
 * 服务器重启不会重置累积概率，同一夜也只会判定一次。判定只跑在主世界——夜晚与
 * 生物随机取样都以下界/末地之外的常驻维度为准。</p>
 */
public final class CollapseInfiltration {
    /** 初始判定概率：32.5%。 */
    public static final double BASE_CHANCE = 0.325D;
    /** 每失败一夜增加的判定概率：32.5%。 */
    public static final double CHANCE_STEP = 0.325D;
    /** 一个游戏日的 tick 数。 */
    private static final long DAY_LENGTH = 24000L;
    /** 「晚上 0 点」：游戏时间内当天的午夜（日落 13000、午夜 18000）。 */
    public static final long NIGHT_TIME_OF_DAY = 18000L;
    /** 世界边界半径，用于一次性取回主世界已加载的全部生物。 */
    private static final double WORLD_BOUNDS = 3.0E7D;

    private CollapseInfiltration() {
    }

    /** 每 tick 由 {@link CommonEvents} 在主世界调用；只在午夜那一刻真正做判定。 */
    public static void tick(ServerLevel level) {
        if (level == null || !Level.OVERWORLD.equals(level.dimension())) return;
        if (!OriginFallGameRules.isCollapseInfiltration(level)) return;
        long dayTime = level.getDayTime();
        long timeOfDay = dayTime % DAY_LENGTH;
        // 午夜之前（06:00~24:00 之前）不做判定；夜里过了 0 点则在本日窗口内补判，
        // 避免服务器卡顿刚好跳过 18000 那一 tick 时整夜漏掉。
        if (timeOfDay < NIGHT_TIME_OF_DAY) return;
        long night = dayTime / DAY_LENGTH;
        DisasterData data = DisasterData.get(level);
        if (data.getCollapseInfiltrationLastNight() >= night) return;
        data.markCollapseInfiltrationNight(night);

        double chance = data.getCollapseInfiltrationChance();
        if (level.getRandom().nextDouble() >= chance) {
            // 本夜未感染：下一夜概率提高一档，最高 100%。
            data.setCollapseInfiltrationChance(Math.min(1.0D, chance + CHANCE_STEP));
            return;
        }
        Mob victim = pickRandomVictim(level);
        if (victim == null) {
            // 主世界此刻没有可感染的生物：视为本夜空过，概率保持累积值不变。
            return;
        }
        CalamityLogic.addCollapseLayer(victim, 1);
        // 成功感染后概率返回初始 32.5%。
        data.setCollapseInfiltrationChance(BASE_CHANCE);
    }

    /** 从主世界已加载、存活且尚未坍缩的生物中随机取一只。 */
    private static Mob pickRandomVictim(ServerLevel level) {
        AABB bounds = new AABB(-WORLD_BOUNDS, level.getMinBuildHeight(), -WORLD_BOUNDS,
                WORLD_BOUNDS, level.getMaxBuildHeight(), WORLD_BOUNDS);
        List<Mob> candidates = level.getEntitiesOfClass(Mob.class, bounds,
                mob -> mob.isAlive() && !CalamityLogic.isCollapsed(mob));
        if (candidates.isEmpty()) return null;
        return candidates.get(level.getRandom().nextInt(candidates.size()));
    }
}
