package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * 阳火粒子注册：作为“阳火”状态的独立火苗粒子（明亮白金色，随粒子图集自动播放动态帧）。
 * 仅为状态形态服务，不注册任何物品/方块，因此不存在创造模式获取入口。
 */
public final class YangFireParticles {

    public static final DeferredRegister<ParticleType<?>> PARTICLE_TYPES =
            DeferredRegister.create(ForgeRegistries.Keys.PARTICLE_TYPES, GeneratedMod.MOD_ID);

    /** 重注册的阳火建模粒子；旧的 yang_fire 注册不再使用。 */
    public static final RegistryObject<SimpleParticleType> YANG_FIRE_MODEL = PARTICLE_TYPES.register("yang_fire_model",
            () -> new SimpleParticleType(true));

    private YangFireParticles() {
    }

    public static void init(IEventBus modBus) {
        PARTICLE_TYPES.register(modBus);
    }
}
