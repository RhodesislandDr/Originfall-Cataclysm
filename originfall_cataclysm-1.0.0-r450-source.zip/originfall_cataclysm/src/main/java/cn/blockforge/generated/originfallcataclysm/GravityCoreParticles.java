package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * 「重力核」粒子注册：用户提供的黑色粒子贴图（{@code textures/particle/gravity_core.png}，
 * 中心浓黑、向外羽化透明的软圆点）。
 *
 * <p>它只服务于「坍缩（邪魔）」的区域视觉：每 10 tick 在坍缩生物半径 4 格
 * （{@code CalamityLogic#COLLAPSE_SPREAD_RADIUS}）内的地面上撒几颗，黑点按岩浆粒子的方式
 * 从地里冒出、弹起后落回（见 {@code CalamityLogic#spawnCollapseFieldParticles} 与
 * 客户端 {@code GravityCoreParticle}）。粒子本身不参与任何伤害、属性或状态判定，纯装饰，
 * 也不需要创造模式获取入口。</p>
 */
public final class GravityCoreParticles {

    public static final DeferredRegister<ParticleType<?>> PARTICLE_TYPES =
            DeferredRegister.create(ForgeRegistries.Keys.PARTICLE_TYPES, GeneratedMod.MOD_ID);

    /** 邪魔区域地面冒出的黑点（贴图即用户提供的黑色粒子）。 */
    public static final RegistryObject<SimpleParticleType> GRAVITY_CORE =
            PARTICLE_TYPES.register("gravity_core", () -> new SimpleParticleType(true));

    private GravityCoreParticles() {
    }

    public static void init(IEventBus modBus) {
        PARTICLE_TYPES.register(modBus);
    }
}
