package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NumericTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.fml.ModList;

import javax.annotation.Nullable;
import java.util.IdentityHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 《方块与深蓝之树》（Caerula Arbor，modid {@code caerula_arbor}）联动钩子。
 *
 * <p>哈基玖是该模组的彩蛋生物（实体注册名 {@code caerula_arbor:apocata}，
 * 击败者名字含 Goodsquid 时召唤潮曦奇美拉 {@code caerula_arbor:tide_chimera}，
 * 死亡掉落「哈基玖本人」）。本类只做不依赖编译期模组存在的软解析：</p>
 * <ul>
 *   <li>张师块＋南瓜头的<b>召唤仪式不依赖深蓝之树在场</b>：未安装时照常消费方块
 *       并产出本模组的等价替身；但替身死亡不掉「哈基玖本人」、也不触发潮曦奇美拉
 *       ——<b>死亡掉落与召唤生物钩子只在装有深蓝之树时生效</b>；</li>
 *   <li>装了深蓝之树时，召唤优先产出其本尊实体——
 *       本尊的定义、掉落、刷怪蛋与结构召唤天然生效，本模组完全让位；
 *       替身死亡结算也优先取本尊内容（潮曦奇美拉与「哈基玖本人」物品），
 *       查不到才回退替身自身的等价内容。</li>
 *   <li>「扒臀长舞」不因让位而缺席：本尊是外部实体、挂不上本模组的同步实体数据，
 *       由 {@link NativeApocataTauntLogic} 以服务端内存会话驱动同一套舞蹈规则，
 *       客户端用本模组骨架走舞步通道（见 {@code NativeApocataAppearanceEvents}）。</li>
 *   <li>本模组在场时哈基玖<b>外观全程统一为替身</b>：本尊的渲染由
 *       {@code NativeApocataAppearanceEvents} 接管、画成替身同款（玩家骨架＋蕾缪安贴图，
 *       含眨眼与持械姿势）；接管只动客户端像素层，本尊的 AI、技能、掉落与奇美拉
 *       钩子原样保留——「在深蓝之树存在时赋予本体所有能力」由让位召唤＋外观接管达成。</li>
 * </ul>
 *
 * <p>所有查询都走 {@link BuiltInRegistries} 按注册名软解析：未安装深蓝之树时
 * 一律返回空/ {@code null}，绝不加载或触达对方任何类。</p>
 */
public final class CaerulaArborCompat {
    /** 深蓝之树的 modid（其注册命名空间与实体命令前缀一致）。 */
    public static final String MOD_ID = "caerula_arbor";

    private CaerulaArborCompat() {
    }

    /** 当前环境是否装有深蓝之树。 */
    public static boolean isLoaded() {
        return ModList.get().isLoaded(MOD_ID);
    }

    /**
     * 在指定位置召唤深蓝之树本尊哈基玖。
     *
     * @return 生成成功返回其实体；未装模组或注册名不存在返回 {@code null}（调用方回退替身）。
     */
    @Nullable
    public static Entity summonNativeApocata(ServerLevel level, Vec3 pos) {
        return spawnNative(level, pos, "apocata");
    }

    /** 潮曦奇美拉钩子：生成深蓝之树本尊 tide_chimera；查不到实体类型则返回 null。 */
    @Nullable
    public static Entity summonNativeTideChimera(ServerLevel level, Vec3 pos) {
        return spawnNative(level, pos, "tide_chimera");
    }

    /**
     * 「哈基玖本人」掉落物：优先精确命中注册名 {@code caerula_arbor:apocata} 的物品
     * （对方掉落表用的就是它自己），查不到再退而扫描同名路径。找不到返回空手。
     */
    public static ItemStack nativeApocataDropItem() {
        if (!isLoaded()) return ItemStack.EMPTY;
        var exact = BuiltInRegistries.ITEM
                .getOptional(ResourceLocation.fromNamespaceAndPath(MOD_ID, "apocata"));
        if (exact.isPresent()) return new ItemStack(exact.get());
        for (ResourceLocation id : BuiltInRegistries.ITEM.keySet()) {
            if (MOD_ID.equals(id.getNamespace()) && id.getPath().contains("apocata")
                    && !id.getPath().endsWith("_spawn_egg")) {
                return new ItemStack(BuiltInRegistries.ITEM.get(id));
            }
        }
        return ItemStack.EMPTY;
    }

    // ---------------- 生物归属与运行模式软探测（共同索敌联动用） ----------------

    /** 实体类型 → 是否深蓝之树生物的缓存（注册类型在运行期不变，缓存无失效风险）。 */
    private static final Map<EntityType<?>, Boolean> CAERULA_TYPE_CACHE = new ConcurrentHashMap<>();
    /** 模式探测缓存：按维度实例隔离，TTL 内直接命中，避免每次索敌都重建游戏规则 NBT。 */
    private static final Map<ServerLevel, ModeProbe> MODE_PROBES = new IdentityHashMap<>();
    private static final long MODE_PROBE_TTL = 100L;

    /** 全面反击关键词：对方任何带模组标识、含这些词的真值布尔规则都算命中。 */
    private static final String[] RETALIATION_KEYWORDS = {"retaliation", "counterattack", "retaliate", "counter"};
    /** 全面进攻关键词（避开反击组的子串，防止 counterattack 被误判为进攻）。 */
    private static final String[] OFFENSIVE_KEYWORDS = {"offensive", "offense", "assault", "aggressive", "attack"};
    /** 规则名中的深蓝之树标识：命名空间或模组名子串。 */
    private static final String[] CAERULA_MARKERS = {MOD_ID, "caerula", "arbor"};

    /** 是否深蓝之树模组的生物（按实体类型注册命名空间判定，未安装时恒为假）。 */
    public static boolean isCaerulaEntity(@Nullable Entity entity) {
        if (entity == null) return false;
        return CAERULA_TYPE_CACHE.computeIfAbsent(entity.getType(), type -> {
            ResourceLocation key = BuiltInRegistries.ENTITY_TYPE.getKey(type);
            return key != null && MOD_ID.equals(key.getNamespace());
        });
    }

    /** 实体类型 → 是否深蓝之树本尊哈基玖的缓存（与 {@link #CAERULA_TYPE_CACHE} 同生命周期）。 */
    private static final Map<EntityType<?>, Boolean> APOCATA_TYPE_CACHE = new ConcurrentHashMap<>();

    /**
     * 是否深蓝之树的本尊哈基玖（注册名 {@code caerula_arbor:apocata}，兼容同名变体路径）。
     * 未安装深蓝之树时恒为假。本尊与替身在本模组机制里同等对待：中立、
     * 不免疫陨石爆炸伤害与源石感染，但任何转化路径都不得把它变成转化生物。
     */
    public static boolean isNativeApocataEntity(@Nullable Entity entity) {
        if (entity == null) return false;
        return APOCATA_TYPE_CACHE.computeIfAbsent(entity.getType(), type -> {
            ResourceLocation key = BuiltInRegistries.ENTITY_TYPE.getKey(type);
            return key != null && MOD_ID.equals(key.getNamespace())
                    && key.getPath().contains("apocata");
        });
    }

    /**
     * 服务器/联动方手动钉值入口：非 null 时直接采信，跳过关键词扫描
     * （深蓝之树模式命名变化时的兜底钩子；默认 null = 自动探测）。
     */
    @Nullable
    private static Boolean retaliationOverride;
    @Nullable
    private static Boolean offensiveOverride;

    public static void setRetaliationOverride(@Nullable Boolean value) {
        retaliationOverride = value;
        MODE_PROBES.clear();
    }

    public static void setOffensiveOverride(@Nullable Boolean value) {
        offensiveOverride = value;
        MODE_PROBES.clear();
    }

    /**
     * 深蓝之树「全面反击」模式是否开启。软探测：钉值入口优先，其次对方注册的
     * 带模组标识与反击关键词的布尔游戏规则；未安装深蓝之树且未钉值时恒为假，
     * 联动逻辑自动退化为"无全面反击"。
     */
    public static boolean isFullRetaliation(@Nullable ServerLevel level) {
        if (retaliationOverride != null) return retaliationOverride;
        return level != null && probe(level).fullRetaliation();
    }

    /** 深蓝之树「全面进攻」模式是否开启；探测口径同上，未安装时恒为假。 */
    public static boolean isFullOffensive(@Nullable ServerLevel level) {
        if (offensiveOverride != null) return offensiveOverride;
        return level != null && probe(level).fullOffensive();
    }

    private record ModeProbe(long expiry, boolean fullRetaliation, boolean fullOffensive) {
    }

    private static ModeProbe probe(ServerLevel level) {
        long now = level.getGameTime();
        ModeProbe cached = MODE_PROBES.get(level);
        if (cached != null && cached.expiry() > now) return cached;
        if (MODE_PROBES.size() > 8) MODE_PROBES.clear(); // 维度重载后旧实例自愈式清理
        boolean retaliation = readModeFlag(level, RETALIATION_KEYWORDS);
        boolean offensive = readModeFlag(level, OFFENSIVE_KEYWORDS);
        ModeProbe probe = new ModeProbe(now + MODE_PROBE_TTL, retaliation, offensive);
        MODE_PROBES.put(level, probe);
        return probe;
    }

    /**
     * 扫描游戏规则的 NBT 快照，找名字含深蓝之树标识与给定关键词的布尔规则，
     * 任一为真即算开启；"反击"与"进攻"关键词冲突时（counterattack 含 attack 子串），
     * 进攻组跳过命中反击组的规则名。
     */
    private static boolean readModeFlag(ServerLevel level, String[] keywords) {
        if (!isLoaded()) return false;
        CompoundTag rules = level.getGameRules().createTag();
        for (String name : rules.getAllKeys()) {
            String lower = name.toLowerCase(Locale.ROOT);
            if (!startsWithMarker(lower)) continue;
            Tag value = rules.get(name);
            if (!(value instanceof NumericTag numeric)) continue;
            int asInt = numeric.getAsInt();
            if (asInt != 1) continue;
            if (matches(lower, keywords)) return true;
        }
        return false;
    }

    private static boolean startsWithMarker(String lowerName) {
        for (String marker : CAERULA_MARKERS) {
            if (lowerName.contains(marker)) return true;
        }
        return false;
    }

    private static boolean matches(String lowerName, String[] keywords) {
        // 进攻判定先排除反击组关键词，避免 counter*attack 被双计。
        if (keywords == OFFENSIVE_KEYWORDS) {
            for (String retaliation : RETALIATION_KEYWORDS) {
                if (lowerName.contains(retaliation)) return false;
            }
        }
        for (String keyword : keywords) {
            if (lowerName.contains(keyword)) return true;
        }
        return false;
    }

    /** 按注册路径在深蓝之树命名空间内软生成实体；未安装或查不到返回 null。 */
    @Nullable
    private static Entity spawnNative(ServerLevel level, Vec3 pos, String path) {
        if (!isLoaded()) return null;
        EntityType<?> type = BuiltInRegistries.ENTITY_TYPE
                .getOptional(ResourceLocation.fromNamespaceAndPath(MOD_ID, path))
                .orElse(null);
        if (type == null) return null;
        Entity entity = type.create(level);
        if (entity == null) return null;
        entity.moveTo(pos.x, pos.y, pos.z, level.getRandom().nextFloat() * 360.0F, 0.0F);
        level.addFreshEntity(entity);
        return entity;
    }
}
