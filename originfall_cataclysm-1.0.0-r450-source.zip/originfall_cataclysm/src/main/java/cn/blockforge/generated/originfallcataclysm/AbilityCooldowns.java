package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.LivingEntity;

import java.util.ArrayList;

/**
 * 冷却账本：本模组所有「冷却类效果」一律<b>按生物</b>独立计时。
 *
 * <p>冷却状态直接写在该生物自身的 {@code persistentData} 上，因此同种生物各记各的——
 * 两只「预言家」博士、两只「特蕾西娅」、两只「女祭司」都不会共用同一份冷却；
 * 冷却只随该生物自己的死亡/清理而消失，不会被同类的另一次触发重置或吞掉。</p>
 *
 * <p>提供两类计时：</p>
 * <ul>
 *   <li><b>单体冷却</b>（{@link #ready}/{@link #arm}）：只属于该生物自己，
 *       例如「巴别塔回忆」的 30 秒冷却。</li>
 *   <li><b>按目标冷却</b>（{@link #readyFor}/{@link #armFor}）：仍然记在<b>施术者</b>身上，
 *       只是按目标 UUID 分开保存，例如「锚定现实」「流放虚空」对同一个目标的内置冷却。
 *       这样两只同种生物可以各自对同一目标独立判定，而同一只生物对同一目标仍受冷却约束。</li>
 * </ul>
 *
 * <p>按目标冷却会顺手清理已过期条目，避免随交战目标数量无限增长。</p>
 */
public final class AbilityCooldowns {

    private static final String SCALAR_PREFIX = "OfcAbilityCd_";
    private static final String TARGET_PREFIX = "OfcAbilityTargetCd_";

    private AbilityCooldowns() {
    }

    // ---------------- 单体冷却 ----------------

    /** 该生物此刻是否已越过自己的冷却终点。 */
    public static boolean ready(LivingEntity entity, long now, String ability) {
        if (entity == null) return true;
        return entity.getPersistentData().getLong(scalarKey(ability)) <= now;
    }

    /** 该生物冷却终点的游戏刻；未设置过时为 0，即没有初始冷却。 */
    public static long readyAt(LivingEntity entity, String ability) {
        if (entity == null) return 0L;
        return entity.getPersistentData().getLong(scalarKey(ability));
    }

    /** 记下该生物自己的下一次可用时刻：{@code ticks} 为从 {@code now} 起的冷却时长。 */
    public static void arm(LivingEntity entity, long now, long ticks, String ability) {
        if (entity == null || entity.level().isClientSide) return;
        entity.getPersistentData().putLong(scalarKey(ability), now + Math.max(0L, ticks));
    }

    /** 立即结束该生物自己的冷却。 */
    public static void clear(LivingEntity entity, String ability) {
        if (entity == null) return;
        entity.getPersistentData().remove(scalarKey(ability));
    }

    // ---------------- 按目标冷却（仍记在施术者身上） ----------------

    /** 施术者此刻是否可以对该目标再次发动该效果。 */
    public static boolean readyFor(LivingEntity caster, LivingEntity target, long now, String ability) {
        if (caster == null || target == null) return true;
        CompoundTag map = caster.getPersistentData().getCompound(targetKey(ability));
        return map.getLong(target.getUUID().toString()) <= now;
    }

    /** 记下施术者对该目标的下一次可用时刻；顺带清理已过期的目标条目。 */
    public static void armFor(LivingEntity caster, LivingEntity target, long now, long ticks, String ability) {
        if (caster == null || target == null || caster.level().isClientSide) return;
        CompoundTag map = caster.getPersistentData().getCompound(targetKey(ability));
        for (String key : new ArrayList<>(map.getAllKeys())) {
            if (map.getLong(key) <= now) map.remove(key);
        }
        map.putLong(target.getUUID().toString(), now + Math.max(0L, ticks));
        caster.getPersistentData().put(targetKey(ability), map);
    }

    /** 立即结束施术者对该目标的冷却。 */
    public static void clearFor(LivingEntity caster, LivingEntity target, String ability) {
        if (caster == null || target == null) return;
        CompoundTag map = caster.getPersistentData().getCompound(targetKey(ability));
        map.remove(target.getUUID().toString());
        caster.getPersistentData().put(targetKey(ability), map);
    }

    /**
     * 跨死亡复制按目标冷却（玩家重生用）：施术者换了一具实体，
     * 其对各目标的冷却终点原样带到新实体上，避免死亡重置冷却。
     */
    public static void copyTargetMap(CompoundTag from, CompoundTag to, String ability) {
        if (from == null || to == null) return;
        String key = targetKey(ability);
        if (from.contains(key)) to.put(key, from.get(key).copy());
    }

    private static String scalarKey(String ability) {
        return SCALAR_PREFIX + ability;
    }

    private static String targetKey(String ability) {
        return TARGET_PREFIX + ability;
    }
}
