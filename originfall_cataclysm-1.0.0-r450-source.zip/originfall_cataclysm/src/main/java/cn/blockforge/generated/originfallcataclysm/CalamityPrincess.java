package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

public final class CalamityPrincess extends CalamityMob {
    private static final String PURE_GOLEM_TIMER = "PureSourceOreGolemTimer";
    private static final int FIRST_PURE_GOLEM_TICKS = 100 * 20;
    private static final int REPEAT_PURE_GOLEM_TICKS = 800 * 20;
    private int pureGolemTimer;

    public CalamityPrincess(EntityType<? extends CalamityPrincess> type, Level level) {
        super(type, level);
        addEffect(new MobEffectInstance(MobEffects.REGENERATION, Integer.MAX_VALUE, 1, false, true, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || isSpawnEggSummoned()) return;
        if (++pureGolemTimer >= FIRST_PURE_GOLEM_TICKS && summonPureSourceOreGolem((ServerLevel) level())) {
            pureGolemTimer = FIRST_PURE_GOLEM_TICKS - REPEAT_PURE_GOLEM_TICKS;
        }
    }

    private boolean summonPureSourceOreGolem(ServerLevel level) {
        PureSourceOreGolem golem = GeneratedMod.PURE_SOURCE_ORE_GOLEM.get().create(level);
        if (golem == null) return false;
        double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
        double distance = 2.0D + level.getRandom().nextDouble() * 3.0D;
        int x = net.minecraft.util.Mth.floor(getX() + Math.cos(angle) * distance);
        int z = net.minecraft.util.Mth.floor(getZ() + Math.sin(angle) * distance);
        BlockPos spawn = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, new BlockPos(x, 0, z));
        golem.moveTo(spawn.getX() + 0.5D, spawn.getY(), spawn.getZ() + 0.5D,
                level.getRandom().nextFloat() * 360.0F, 0.0F);
        if (!level.noCollision(golem, golem.getBoundingBox())) return false;
        golem.setManufacturerUUID(getUUID());
        golem.setCalamityFaction(CalamityLogic.isCalamityFactionMember(this));
        golem.setPlayerCreated(true);
        golem.setPersistenceRequired();
        level.addFreshEntity(golem);
        return true;
    }

    public static net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder createAttributes() {
        return CalamityMob.createAttributes(1000.0D, 50.0D);
    }

    @Override
    protected double followRange() { return 64.0D; }

    @Override
    protected boolean canTeleportAcrossDimensions() { return true; }

    @Override
    protected void serverAbilityTick(ServerLevel level) {
        Player owner = getOwner() instanceof Player player ? player : null;
        if (owner != null && CalamityLogic.isCalamityModePlayer(owner)
                && distanceToSqr(owner) <= 32.0D * 32.0D) {
            DisasterData data = DisasterData.get(level);
            if (!data.isCalamityActive()) data.activateBySource();
        }

        if (tickCount % 200 == 0) {
            for (LivingEntity living : level.getEntitiesOfClass(LivingEntity.class, area(this, 32.0D),
                    entity -> entity.isAlive() && (entity instanceof Player || entity instanceof CalamityMob))) {
                living.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 0, false, true, true));
                living.addEffect(new MobEffectInstance(MobEffects.LUCK, 200, 1, false, true, true));
            }
        }

        if (!isSpawnEggSummoned()) {
            for (YoungDemonLord lord : level.getEntitiesOfClass(YoungDemonLord.class, area(this, 16.0D),
                    entity -> entity.isAlive())) {
                lord.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 40, 1, false, true, true));
                lord.addEffect(new MobEffectInstance(MobEffects.LUCK, 40, 1, false, true, true));
            }
        }

        int count = level.getEntitiesOfClass(LivingEntity.class, area(this, 32.0D),
                entity -> CalamityLogic.isCalamityPopulationTarget(entity, this, 32.0D)).size();
        LivingEntity highest = CalamityLogic.highestHealthTarget(level, this, 32.0D);
        if (highest != null && highest.getMaxHealth() > 325.0F) {
            if (isAbilityReady()) setAbilityCooldown(100);
            if (tickCount % 20 == 0) {
                level.addFreshEntity(MeteorEntity.createTargetedNatural(level, highest, 1));
            }
            for (YoungDemonLord lord : level.getEntitiesOfClass(YoungDemonLord.class, area(this, 8.0D),
                    entity -> entity.isAlive() && lordCanAct(entity))) {
                if (lord.isAbilityReady()) {
                    lord.setAbilityCooldown(100);
                    MeteorStaff.summon(level, lord, MeteorStaff.count(level));
                }
            }
        } else if (count > 20 && isAbilityReady()) {
            if (highest != null) {
                int meteorCount = MeteorStaff.count(level);
                for (int i = 0; i < meteorCount; i++) {
                    level.addFreshEntity(MeteorEntity.createTargetedNatural(level, highest, 1));
                }
            } else {
                MeteorStaff.summon(level, this, MeteorStaff.count(level));
            }
            setAbilityCooldown(100);
        }
    }

    private boolean lordCanAct(YoungDemonLord lord) {
        return lord.isAlive() && lord.getOwnerUUID() != null;
    }

    @Override
    public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt(PURE_GOLEM_TIMER, pureGolemTimer);
    }

    @Override
    public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        pureGolemTimer = tag.getInt(PURE_GOLEM_TIMER);
    }

    @Override
    protected void onCalamityDeath(ServerLevel level, LivingEntity killer, net.minecraft.nbt.CompoundTag snapshot) {
        CalamityLogic.summonDemonLordDeathMeteor(level, this, killer, 1000.0F, 200.0F, 1.0F, 0.5F);
    }
}
