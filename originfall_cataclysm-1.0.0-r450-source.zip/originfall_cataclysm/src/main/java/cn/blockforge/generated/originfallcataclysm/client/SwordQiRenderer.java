package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.SwordQiEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * 渲染月牙形剑气：直接把整幅月牙贴图铺在一个双面可见的水平面上（平躺于 XZ 平面），
 * 只绕 Y 对齐飞行航向——月牙凸面朝外（远离发射者），凹面朝向发射者。
 * 黑色剑气（三位指定首领）贴图自带半透明；白色剑气（其余持近战武器的学习者）为实心。
 */
public final class SwordQiRenderer extends EntityRenderer<SwordQiEntity> {
    private static final ResourceLocation BLACK =
            ResourceLocation.fromNamespaceAndPath("originfall_cataclysm", "textures/entity/sword_qi_black.png");
    private static final ResourceLocation WHITE =
            ResourceLocation.fromNamespaceAndPath("originfall_cataclysm", "textures/entity/sword_qi_white.png");

    public SwordQiRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(SwordQiEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        // 水平面展示：只绕 Y 对齐航向，不施加俯仰——月牙始终平躺在水平面上横向飞行。
        // 本地 +Z 即飞行方向（凸面朝外、远离发射者），-Z 指向发射者（凹面朝向发射者）。
        poseStack.mulPose(Axis.YP.rotationDegrees(horizontalYaw(entity, partialTick)));
        // 轻微脉动，让能量感更足；黑色略大、白色略小。
        float pulse = 1.0F + 0.07F * Mth.sin((entity.tickCount + partialTick) * 0.45F);
        float scale = (entity.isBlack() ? 0.95F : 0.85F) * pulse;
        poseStack.scale(scale, scale, scale);
        VertexConsumer consumer = buffer.getBuffer(RenderType.entityTranslucent(texture(entity)));
        // entityTranslucent 不剔除背面：单面四边形上下两面都能看到完整月牙。
        float w = 0.5F;
        Matrix4f matrix4f = poseStack.last().pose();
        Matrix3f matrix3f = poseStack.last().normal();
        // 四边形平躺于本地 XZ 平面：贴图顶部（凸面，v=0）映射到 +Z（航向/朝外），
        // 贴图底部（凹面，v=1）映射到 -Z（朝发射者）。
        consumer.vertex(matrix4f, -w, 0.0F, w).color(1.0F, 1.0F, 1.0F, 1.0F)
                .uv(0.0F, 0.0F).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(packedLight)
                .normal(matrix3f, 0.0F, 1.0F, 0.0F).endVertex();
        consumer.vertex(matrix4f, w, 0.0F, w).color(1.0F, 1.0F, 1.0F, 1.0F)
                .uv(1.0F, 0.0F).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(packedLight)
                .normal(matrix3f, 0.0F, 1.0F, 0.0F).endVertex();
        consumer.vertex(matrix4f, w, 0.0F, -w).color(1.0F, 1.0F, 1.0F, 1.0F)
                .uv(1.0F, 1.0F).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(packedLight)
                .normal(matrix3f, 0.0F, 1.0F, 0.0F).endVertex();
        consumer.vertex(matrix4f, -w, 0.0F, -w).color(1.0F, 1.0F, 1.0F, 1.0F)
                .uv(0.0F, 1.0F).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(packedLight)
                .normal(matrix3f, 0.0F, 1.0F, 0.0F).endVertex();
        poseStack.popPose();
        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
    }

    private static ResourceLocation texture(SwordQiEntity entity) {
        return entity.isBlack() ? BLACK : WHITE;
    }

    /**
     * 计算月牙的水平航向角（使本地 +Z 对准水平飞行方向）。
     * 直接从实体速度向量推导，避免 spawn ~ tick5 期间实体 yRot 尚未对齐运动方向造成的 180° 翻转。
     */
    private static float horizontalYaw(SwordQiEntity entity, float partialTick) {
        Vec3 motion = entity.getDeltaMovement();
        double horiz = Math.sqrt(motion.x * motion.x + motion.z * motion.z);
        if (horiz < 1.0E-4D) {
            return -Mth.rotLerp(partialTick, entity.yRotO, entity.getYRot());
        }
        return (float) (Mth.atan2(motion.x, motion.z) * 180.0D / Math.PI);
    }

    @Override
    public ResourceLocation getTextureLocation(SwordQiEntity entity) {
        return texture(entity);
    }
}
