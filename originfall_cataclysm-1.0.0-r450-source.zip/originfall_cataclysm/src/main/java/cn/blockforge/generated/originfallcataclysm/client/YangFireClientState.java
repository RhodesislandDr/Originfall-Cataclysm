package cn.blockforge.generated.originfallcataclysm.client;

import java.util.HashMap;
import java.util.Map;

/**
 * 客户端侧的阳火层数表：由 {@link cn.blockforge.generated.originfallcataclysm.YangFireNetworking}
 * 的同步报文驱动，渲染器据此决定叠加阳火模型的实体。
 */
public final class YangFireClientState {

    private static final Map<Integer, Integer> LAYERS = new HashMap<>();

    private YangFireClientState() {
    }

    public static void apply(int entityId, int layers) {
        if (layers <= 0) {
            LAYERS.remove(entityId);
        } else {
            LAYERS.put(entityId, layers);
        }
    }

    public static int get(int entityId) {
        return LAYERS.getOrDefault(entityId, 0);
    }

    public static void clear() {
        LAYERS.clear();
    }
}
