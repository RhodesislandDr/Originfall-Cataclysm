package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;

/**
 * 「预言家」博士「巴别塔回忆」献祭特蕾西娅时播放的专属音乐（由玩家提供的曲目转码而来）。
 *
 * <p>音乐优先级规则：本音乐优先级最低——内化宇宙音乐与 1000 倍陨石坠落音乐都排在它前面。
 * 因此：</p>
 * <ul>
 *   <li>起播时若已有其它音乐在放，本音乐直接让位、不起播；</li>
 *   <li>播放期间若有其它音乐起播，本音乐立即被打断（向所有在线玩家发送停止音效包）。</li>
 * </ul>
 *
 * <p>时长以墙上时钟记（30.6 秒取整为 31 秒），不依赖服务器 tickCount：
 * 同一进程内切换存档会重置 tickCount，而本类静态状态跨存档存活，用 tick 记账会误判。</p>
 *
 * <p>音频资源 {@code babel_memory_music.ogg} 必须是<b>纯 Vorbis 音频</b>：源 mp3 带封面图，
 * 转码时若未丢弃视频流会在 ogg 里混入一条 Theora 流，Minecraft 的 Ogg 解码器读到非 Vorbis
 * 码流就播不出声——这正是「博士复活时音乐播放异常」的根因。重新转码请用
 * {@code ffmpeg -i 源.mp3 -vn -c:a libvorbis 目标.ogg}。</p>
 */
public final class BabelMemoryMusic {

    /** 音乐响度：与内化宇宙音乐一致，经 playNotifySound 在玩家自身位置播放。 */
    private static final float VOLUME = 1.0F;
    /** 曲目时长向上取整（30.6 秒 → 31 秒），仅用于判断本音乐是否仍在播放。 */
    private static final long MUSIC_MILLIS = 31_000L;
    /** 1000 倍陨石坠落音乐时长（23 秒）向上取整，用于判断它是否仍在播放。 */
    private static final long CALAMITY_MUSIC_MILLIS = 24_000L;
    /** 本模组音效命名空间下的音乐资源 ID。 */
    private static final ResourceLocation BABEL_MEMORY_ID =
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "babel_memory_music");

    private static volatile long activeUntilMillis = 0L;

    /** 1000 倍陨石坠落音乐预计结束时刻（墙上时钟毫秒）。 */
    private static volatile long calamityMusicUntilMillis = 0L;

    private BabelMemoryMusic() {
    }

    /** 巴别塔回忆音乐此刻是否仍在播放。 */
    public static boolean isActive() {
        return System.currentTimeMillis() < activeUntilMillis;
    }

    /** 1000 倍陨石坠落音乐此刻是否仍在播放（供本音乐判断是否让位）。 */
    public static boolean isCalamityMusicActive() {
        return System.currentTimeMillis() < calamityMusicUntilMillis;
    }

    /**
     * 献祭时起播巴别塔回忆音乐。
     * 其它音乐正在播放时不重复起播，也不与之叠播（本音乐让位）。
     */
    public static void play(ServerLevel level) {
        if (isActive()) return;
        // 「扒臀舞」琵琶曲是最高优先级：在播期间本音乐让位，不与舞曲叠播。
        if (TauntSongMusic.isActive()) return;
        if (UniverseLightLogic.isUniverseMusicActive() || isCalamityMusicActive()) return;
        MinecraftServer server = level.getServer();
        // 先确认服务器实例可用，再登记播放期：否则起播失败也会把音乐误标为「正在播放」，
        // 之后 31 秒内的复活都被去重吞掉。
        if (server == null) return;
        activeUntilMillis = System.currentTimeMillis() + MUSIC_MILLIS;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.playNotifySound(GeneratedMod.BABEL_MEMORY_MUSIC.get(), SoundSource.MASTER, VOLUME, 1.0F);
        }
    }

    /** 1000 倍陨石坠落音乐起播登记：记录其播放期，并打断正在播放的巴别塔回忆音乐。 */
    public static void onCalamityMusicPlayed(ServerLevel level) {
        calamityMusicUntilMillis = System.currentTimeMillis() + CALAMITY_MUSIC_MILLIS;
        interrupt(level.getServer());
    }

    /** 其它音乐起播时调用：立即打断（停止）正在播放的巴别塔回忆音乐。 */
    public static void interrupt(MinecraftServer server) {
        if (!isActive()) return;
        activeUntilMillis = 0L;
        if (server == null) return;
        ClientboundStopSoundPacket packet = new ClientboundStopSoundPacket(BABEL_MEMORY_ID, SoundSource.MASTER);
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.connection.send(packet);
        }
    }
}
