package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;

/**
 * 「扒臀舞」触发曲（玩家提供的琵琶曲）的播放会话——音乐优先级体系里的<b>最高级</b>：
 * 播放期间不可被打断，其它音乐（内化宇宙 / 1000 倍陨石坠落 / 巴别塔回忆）一律让位，
 * 既不叠播也不接档；反向地，本曲起播时会先把正在播放的其它音乐静音（逐首下发停止包）。
 *
 * <p>与其它音乐同一套格式与管线：mp3 源经 {@code ffmpeg -vn -c:a libvorbis} 转成<b>纯
 * Vorbis</b> 的 {@code taunt_dance_music.ogg}（源文件带封面图，若保留视频流会让 MC 的
 * Ogg 解码器静默失败），sounds.json 以 {@code stream: true} 登记，服务端向全体在线玩家
 * {@code playNotifySound}（MASTER 分类，只受主音量支配）。时长同样以墙上时钟记
 * （94.8 秒取整为 95 秒），不依赖 tickCount——静态状态跨存档存活，tick 记账会误判。</p>
 */
public final class TauntSongMusic {

    /** 曲目时长向上取整（94.8 秒 → 95 秒）。 */
    public static final long MUSIC_MILLIS = 95_000L;
    /** 舞曲响度：与内化宇宙音乐一致，经 playNotifySound 在玩家自身位置播放。 */
    private static final float VOLUME = 1.0F;
    /** 舞曲自身的音效注册 ID（停止包按它静音客户端播放）。 */
    private static final ResourceLocation TAUNT_DANCE_ID =
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "taunt_dance_music");

    private static volatile long activeUntilMillis = 0L;

    private TauntSongMusic() {
    }

    /** 舞曲此刻是否仍在播放（含被其它个体跟随的时段）。 */
    public static boolean isActive() {
        return System.currentTimeMillis() < activeUntilMillis;
    }

    /** 舞曲总时长对应的 tick 数（新一轮起播时跳满整曲用）。 */
    public static int songTicks() {
        return (int) ((MUSIC_MILLIS + 999L) / 1000L * 20L);
    }

    /** 舞曲剩余时长对应的 tick 数（向上取整；未播放时为 0）。 */
    public static int remainingTicks() {
        long remaining = activeUntilMillis - System.currentTimeMillis();
        if (remaining <= 0L) return 0;
        return (int) Math.min(Integer.MAX_VALUE, (remaining + 49L) / 50L);
    }

    /**
     * 起播或跟随：舞曲未播放时向全服起播并静音其它音乐；已在播放时不做任何播放，
     * 由调用方按 {@link #remainingTicks()} 让触发者跟随当前曲目共同时长。
     *
     * @return true 表示本次是<b>跟随</b>当前正在播放的曲目；false 表示本次真正起播了新曲。
     */
    public static synchronized boolean playOrJoin(ServerLevel level) {
        if (isActive()) return true;
        MinecraftServer server = level.getServer();
        if (server == null) return true;
        silenceOtherMusic(server);
        activeUntilMillis = System.currentTimeMillis() + MUSIC_MILLIS;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.playNotifySound(GeneratedMod.TAUNT_DANCE_MUSIC.get(), SoundSource.MASTER, VOLUME, 1.0F);
        }
        return false;
    }

    /** 本曲起播前静音其它在播音乐：巴别塔回忆走自身打断入口，宇宙/天灾直接下发停止包。 */
    private static void silenceOtherMusic(MinecraftServer server) {
        BabelMemoryMusic.interrupt(server);
        stopForAll(server, ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "universe_music"));
        stopForAll(server, ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "calamity_music"));
    }

    private static void stopForAll(MinecraftServer server, ResourceLocation soundId) {
        ClientboundStopSoundPacket packet = new ClientboundStopSoundPacket(soundId, SoundSource.MASTER);
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.connection.send(packet);
        }
    }
}
