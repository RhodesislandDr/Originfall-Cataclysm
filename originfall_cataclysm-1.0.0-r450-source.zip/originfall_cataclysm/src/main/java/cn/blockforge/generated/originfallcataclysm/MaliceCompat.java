package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.fml.ModList;

import java.lang.reflect.Method;

/**
 * 莱特兰-恶意（L2Hostility）兼容门面。
 *
 * <p>装有莱特兰-恶意时，主代码经反射加载 l2compat 源码集里的
 * {@code OriginfallMaliceCompat}，由它直连恶意模组的真实能力数据完成
 * 击杀学习、融合升级与首领初始附带；未安装（或兼容层加载失败）时，
 * 本类把恶意特性交给模组内自持的 {@link MaliceLevelSystem} 兜底，
 * 因此莱特兰-恶意永远只是可选增强，绝不构成前置依赖。</p>
 */
public final class MaliceCompat {
    public static final String L2HOSTILITY_MOD_ID = "l2hostility";
    private static final String COMPAT_CLASS =
            "cn.blockforge.generated.originfallcataclysm.OriginfallMaliceCompat";

    private static Boolean modLoaded;
    private static Boolean compatReady;
    private static Method killHook;
    private static Method tickHook;
    private static Method levelHook;
    private static Method inheritHook;
    /** 模组机制复活后按莱特兰机制重掷等级与词条的入口。 */
    private static Method reviveHook;
    /** 强制莱特兰-恶意保留/授予玩家生物词条的配置修正入口。 */
    private static Method forceConfigsHook;
    /** 配置修正是否已成功执行（失败时保留为 false，留待运行期重试）。 */
    private static boolean compatConfigsForced;

    private MaliceCompat() {}

    /** 环境中是否存在莱特兰-恶意（只看模组本体，不代表兼容层加载成功）。 */
    public static boolean modPresent() {
        if (modLoaded == null) {
            modLoaded = ModList.get() != null && ModList.get().isLoaded(L2HOSTILITY_MOD_ID);
        }
        return modLoaded;
    }

    /** 莱特兰兼容形态是否真正生效：模组在场且兼容层类已成功装载。 */
    public static boolean l2Active() {
        if (compatReady == null) {
            boolean ready = modPresent() && loadHooks();
            compatReady = ready;
            if (modPresent() && !ready) {
                com.mojang.logging.LogUtils.getLogger()
                        .error("[源石天灾] 莱特兰-恶意兼容层加载失败，恶意特性退回模组独立形态");
            }
        }
        return compatReady;
    }

    private static synchronized boolean loadHooks() {
        if (compatReady != null) return compatReady;
        try {
            Class<?> compat = Class.forName(COMPAT_CLASS);
            killHook = compat.getMethod("onLearnerKill", LivingEntity.class, LivingEntity.class);
            tickHook = compat.getMethod("onLearnerTick", LivingEntity.class);
            levelHook = compat.getMethod("currentMaliceLevel", LivingEntity.class);
            // 等级继承通道为后加的增强项：缺失时不影响其余兼容形态，届时退回独立等级系统。
            try {
                inheritHook = compat.getMethod("onLearnerKillInheritLevel", LivingEntity.class, LivingEntity.class);
            } catch (NoSuchMethodException ignored) {
                inheritHook = null;
            }
            // 配置修正通道同样为增强项：缺失时仅退化为「不自动改配置」，其余兼容形态不受影响。
            try {
                forceConfigsHook = compat.getMethod("forceCompatConfigs");
            } catch (NoSuchMethodException ignored) {
                forceConfigsHook = null;
            }
            // 复活再随机通道同为增强项：缺失时退回模组独立等级系统的同等工作。
            try {
                reviveHook = compat.getMethod("onRevive", LivingEntity.class);
            } catch (NoSuchMethodException ignored) {
                reviveHook = null;
            }
            return true;
        } catch (ReflectiveOperationException | LinkageError | RuntimeException e) {
            killHook = null;
            tickHook = null;
            levelHook = null;
            inheritHook = null;
            forceConfigsHook = null;
            reviveHook = null;
            return false;
        }
    }

    /**
     * 自动检测并把莱特兰-恶意的 {@code allowTraitOnOwnable} 与 {@code allowPlayerAllies}
     * 修正为 true 并落盘。
     *
     * <p>前者为 false 时，莱特兰会在每 tick 清空「玩家驯服/认主生物」身上的全部恶意词条；
     * 后者为 false 时，它会在生物初始化阶段把「与玩家结盟」的生物直接跳过成 0 级、不生成任何
     * 词条。本模组由玩家驯服、认主或召唤（刷怪蛋/道具/代码）的学习者因此会凭空丢失或永远学不到
     * 词条。这里在配置加载事件、服务器 tick 与学习者 tick 三个时机调用兼容层，
     * 实际只会在第一次成功时执行一次。</p>
     */
    public static void forceCompatConfigs() {
        if (compatConfigsForced || !l2Active()) return;
        if (forceConfigsHook == null) return;
        try {
            forceConfigsHook.invoke(null);
            compatConfigsForced = true;
        } catch (ReflectiveOperationException | RuntimeException e) {
            // 配置尚未加载完成时兼容层会静默跳过；保持未完成状态，下一时机重试。
        }
    }

    /**
     * 生物当前的恶意等级：兼容形态直接读莱特兰-恶意自身挂在它身上的等级；
     * 拿不到（实体未被它接管、cap 尚未初始化）或独立形态时，回退到模组自持的
     * {@link MaliceLevelSystem}。词条数量上限的「每 20 级 +1」加成由此取值。
     */
    public static int maliceLevelOf(LivingEntity entity) {
        if (entity == null) return 0;
        if (l2Active()) {
            try {
                Object value = levelHook.invoke(null, entity);
                if (value instanceof Integer level && level >= 0) return level;
            } catch (ReflectiveOperationException | RuntimeException e) {
                com.mojang.logging.LogUtils.getLogger()
                        .warn("[源石天灾] 读取莱特兰恶意等级失败，回退独立等级系统", e);
            }
        }
        return MaliceLevelSystem.levelOf(entity);
    }

    /**
     * 击杀学习入口（恶意词条通道）。由 CommonEvents 的死亡处理在击杀闸门通过后调用。
     * 兼容形态：把目标身上的莱特兰-恶意词条学给凶手（相同词条融合升级、不占数量，
     * 数量上限为原有学习生物行动逻辑的两倍、恶意等级每提升 20 级再增加 1 个上限；
     * 非标准学习者的模组召唤生物按最小档折算，见 {@link LearnedTraitLogic#maliceKillLimit}）。
     * 独立形态：行为特性学习已在
     * {@link LearnedTraitLogic#learnAfterConversion} 完成，这里无需重复处理。
     */
    public static void onLearnerKill(LivingEntity learner, LivingEntity victim) {
        forceCompatConfigs();
        if (!l2Active() || learner == null || victim == null) return;
        // 击杀链只对本模组生物与本模组召唤生物开放（恶意词条通道口径，含备用学习机制）：
        // 原版与其他模组生物即使击杀了带词条的目标，也不会被“感染”上任何莱特兰恶意词条。
        if (!LearnedTraitLogic.isKillLearningCandidate(learner)) return;
        try {
            killHook.invoke(null, learner, victim);
        } catch (ReflectiveOperationException | RuntimeException e) {
            com.mojang.logging.LogUtils.getLogger()
                    .warn("[源石天灾] 击杀学习莱特兰恶意词条失败，已跳过本次学习", e);
        }
    }

    /**
     * 击杀等级继承入口（两种形态共用）。
     *
     * <p>学习者击杀带恶意等级的目标时，继承对方等级的
     * {@link MaliceLevelSystem#KILL_INHERIT_RATIO}（32.5%），<b>不足整数的零头向上取整</b>，
     * 且只升不降。兼容形态直接读写莱特兰-恶意挂在目标与学习者身上的真实等级；
     * 未安装（或兼容层缺失该通道）时由 {@link MaliceLevelSystem#inheritFromKill} 兜底。
     * 资格口径与恶意词条击杀通道一致：本模组所有生物与本模组所有召唤生物
     * （{@link LearnedTraitLogic#isKillLearningCandidate}）；非候选击杀者不参与继承。</p>
     */
    public static void inheritLevelFromKill(LivingEntity learner, LivingEntity victim) {
        forceCompatConfigs();
        if (learner == null || victim == null || learner.level().isClientSide) return;
        if (!LearnedTraitLogic.isKillLearningCandidate(learner)) return;
        if (l2Active() && inheritHook != null) {
            try {
                inheritHook.invoke(null, learner, victim);
            } catch (ReflectiveOperationException | RuntimeException e) {
                com.mojang.logging.LogUtils.getLogger()
                        .warn("[源石天灾] 击杀继承莱特兰恶意等级失败，已跳过本次继承", e);
            }
            return;
        }
        MaliceLevelSystem.inheritFromKill(learner, MaliceLevelSystem.levelOf(victim));
    }

    /**
     * 每 tick 的兼容层挂接：首领初始生成时按 boss 级别随机附带词条（幂等），
     * 以及学习者按恶意等级的自适应强化。独立形态由 {@link MaliceLevelSystem}
     * 在 {@code LearnedTraitLogic.tick} 内完成同等工作，这里直接返回。
     */
    public static void onLearnerTick(LivingEntity entity) {
        forceCompatConfigs();
        if (!l2Active() || entity == null) return;
        try {
            tickHook.invoke(null, entity);
        } catch (ReflectiveOperationException | RuntimeException e) {
            com.mojang.logging.LogUtils.getLogger()
                    .warn("[源石天灾] 莱特兰恶意等级兼容层 tick 失败，已跳过本 tick", e);
        }
    }

    /**
     * 模组机制复活后的收尾：本模组的复活（复活陨石波次）会把死亡快照重建为实体并复活，
     * 快照里带着死亡前的莱特兰恶意等级与词条；按需求「复活后按照莱特兰机制随机等级和
     * 莱特兰词条」，这里把模组生物的恶意数据丢弃并按莱特兰自身的区域修正链路重掷一次，
     * 使复活体与同区域自然生成的生物一致（首领重新按首领档位附带随机词条）。
     *
     * <p>装有莱特兰-恶意时走兼容层直连它的 {@code deinit} + {@code init}；
     * 未安装（或兼容层缺失该通道）时由 {@link MaliceLevelSystem#rerollOnRevive} 兜底。
     * 只对本模组的学习者生效，原版与其他模组生物经本模组机制复活时不受影响。</p>
     */
    public static void onRevive(LivingEntity entity) {
        forceCompatConfigs();
        if (entity == null || entity.level().isClientSide) return;
        if (!LearnedTraitLogic.isLearner(entity)) return;
        if (l2Active() && reviveHook != null) {
            try {
                reviveHook.invoke(null, entity);
                return;
            } catch (ReflectiveOperationException | RuntimeException e) {
                com.mojang.logging.LogUtils.getLogger()
                        .warn("[源石天灾] 复活后重掷莱特兰恶意等级与词条失败，回退独立等级系统", e);
            }
        }
        MaliceLevelSystem.rerollOnRevive(entity);
    }
}
