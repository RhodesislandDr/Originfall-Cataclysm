package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.GeneratedMod;
import cn.blockforge.generated.originfallcataclysm.UniverseSphereEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

/**
 * 「无下限•内化宇宙」实心结界球体的客户端渲染。
 *
 * 与领域展开的「空心无厚度球面」不同，这里画的是一个「实心半透明球体」：
 * 同一套 UV 球面被画两遍——一遍按外法线朝向（近侧表面），一遍反转环绕方向（远侧内表面），
 * 从而透过近侧也能看到远侧，读起来是填满整个球体体积的紫色光球，而非薄薄一层壳。
 * 中央再叠一层较亮的小球核，让球心更耀眼，强化“实心光球”的观感。
 *
 * 渲染用 entityTranslucent（半透明实体，配合满亮光照，不受昼夜光照影响），
 * 并叠加一层菲涅尔边缘亮化，让球体轮廓更清晰。内化宇宙光效以紫色为主。
 */
public final class UniverseSphereRenderer extends EntityRenderer<UniverseSphereEntity> {

    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "textures/entity/domain_sphere.png");

    // 球面网格密度：纬线分段 × 经线分段。越大越圆滑。
    private static final int LAT = 20;
    private static final int LON = 36;

    // 内化宇宙实心球体：紫色。
    private static final float R = 0.56F;
    private static final float G = 0.16F;
    private static final float B = 0.92F;

    public UniverseSphereRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(UniverseSphereEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        float radius = entity.getCurrentRadius();
        if (radius <= 0.001F) return;

        Vec3 cam = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
        double ex = entity.getX();
        double ey = entity.getY();
        double ez = entity.getZ();

        VertexConsumer consumer = buffer.getBuffer(RenderType.entityTranslucent(TEXTURE));
        PoseStack.Pose pose = poseStack.last();
        // 外层球体：近侧（外法线）一遍 + 远侧（反转环绕）一遍，合起来呈填满的实心光球。
        renderSphereShell(consumer, pose, radius, R, G, B, cam, ex, ey, ez, LightTexture.FULL_BRIGHT, false);
        renderSphereShell(consumer, pose, radius, R, G, B, cam, ex, ey, ez, LightTexture.FULL_BRIGHT, true);
        // 中央小球核：更亮、更不透明，强化“实心”的光心。
        renderSphereShell(consumer, pose, radius * 0.38F, R * 0.85F, G * 0.85F, B * 0.92F,
                cam, ex, ey, ez, LightTexture.FULL_BRIGHT, false);

        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
    }

    /** 生成一个 UV 球面的全部 QUADS，并逐顶点写入颜色（含菲涅尔边缘亮化）。 */
    private void renderSphereShell(VertexConsumer consumer, PoseStack.Pose pose, float radius,
                                   float r, float g, float b, Vec3 cam, double ex, double ey, double ez,
                                   int packedLight, boolean inward) {
        final double baseAlpha = inward ? 0.20D : 0.24D;
        final double rimBoost = 0.26D;

        for (int lat = 0; lat < LAT; lat++) {
            double theta0 = Math.PI * lat / LAT;
            double theta1 = Math.PI * (lat + 1) / LAT;
            double y0 = Math.cos(theta0);
            double y1 = Math.cos(theta1);
            double r0 = Math.sin(theta0);
            double r1 = Math.sin(theta1);
            for (int lon = 0; lon < LON; lon++) {
                double phi0 = 2.0D * Math.PI * lon / LON;
                double phi1 = 2.0D * Math.PI * (lon + 1) / LON;

                // 四个角（从球外看，逆时针）。
                double c00x = r0 * Math.cos(phi0);
                double c00y = y0;
                double c00z = r0 * Math.sin(phi0);
                double c01x = r0 * Math.cos(phi1);
                double c01y = y0;
                double c01z = r0 * Math.sin(phi1);
                double c11x = r1 * Math.cos(phi1);
                double c11y = y1;
                double c11z = r1 * Math.sin(phi1);
                double c10x = r1 * Math.cos(phi0);
                double c10y = y1;
                double c10z = r1 * Math.sin(phi0);

                double u0 = (double) lon / LON;
                double u1 = (double) (lon + 1) / LON;
                double v0 = (double) lat / LAT;
                double v1 = (double) (lat + 1) / LAT;

                if (inward) {
                    // 反转环绕：让远侧内表面朝向相机，使其在剔除打开时也能被绘制。
                    // 法线取反，使菲涅尔在远侧轮廓处仍能正常增亮。
                    vertex(consumer, pose, radius, c00x, c00y, c00z, u0, v0, r, g, b, cam, ex, ey, ez, baseAlpha, rimBoost, packedLight, -1.0D);
                    vertex(consumer, pose, radius, c10x, c10y, c10z, u0, v1, r, g, b, cam, ex, ey, ez, baseAlpha, rimBoost, packedLight, -1.0D);
                    vertex(consumer, pose, radius, c11x, c11y, c11z, u1, v1, r, g, b, cam, ex, ey, ez, baseAlpha, rimBoost, packedLight, -1.0D);
                    vertex(consumer, pose, radius, c01x, c01y, c01z, u1, v0, r, g, b, cam, ex, ey, ez, baseAlpha, rimBoost, packedLight, -1.0D);
                } else {
                    vertex(consumer, pose, radius, c00x, c00y, c00z, u0, v0, r, g, b, cam, ex, ey, ez, baseAlpha, rimBoost, packedLight, 1.0D);
                    vertex(consumer, pose, radius, c01x, c01y, c01z, u1, v0, r, g, b, cam, ex, ey, ez, baseAlpha, rimBoost, packedLight, 1.0D);
                    vertex(consumer, pose, radius, c11x, c11y, c11z, u1, v1, r, g, b, cam, ex, ey, ez, baseAlpha, rimBoost, packedLight, 1.0D);
                    vertex(consumer, pose, radius, c10x, c10y, c10z, u0, v1, r, g, b, cam, ex, ey, ez, baseAlpha, rimBoost, packedLight, 1.0D);
                }
            }
        }
    }

    private void vertex(VertexConsumer consumer, PoseStack.Pose pose, double radius,
                        double nx, double ny, double nz, double u, double v,
                        float r, float g, float b, Vec3 cam, double ex, double ey, double ez,
                        double baseAlpha, double rimBoost, int packedLight, double normalSign) {
        double px = nx * radius;
        double py = ny * radius;
        double pz = nz * radius;

        // 有效法线：外法线单位方向；远侧反转时取反，使其朝相机以便菲涅尔在轮廓处增亮。
        double wx = nx * normalSign;
        double wy = ny * normalSign;
        double wz = nz * normalSign;
        // 顶点到相机的方向（世界系）。
        double dx = cam.x - (ex + px);
        double dy = cam.y - (ey + py);
        double dz = cam.z - (ez + pz);
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double fresnel = 0.0D;
        if (len > 1.0E-4D) {
            double dot = (wx * dx + wy * dy + wz * dz) / len;
            double grazing = 1.0D - Math.max(0.0D, dot);
            fresnel = grazing * grazing;
        }
        double alpha = baseAlpha + rimBoost * fresnel;
        if (alpha > 1.0D) alpha = 1.0D;

        consumer.vertex(pose.pose(), (float) px, (float) py, (float) pz)
                .color(r, g, b, (float) alpha)
                .uv((float) u, (float) v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(packedLight)
                .normal((float) wx, (float) wy, (float) wz)
                .endVertex();
    }

    @Override
    public ResourceLocation getTextureLocation(UniverseSphereEntity entity) {
        return TEXTURE;
    }
}
