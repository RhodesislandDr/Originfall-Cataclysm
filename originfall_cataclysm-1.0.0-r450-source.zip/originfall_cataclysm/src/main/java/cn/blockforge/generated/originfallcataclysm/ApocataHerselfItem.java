package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * 「哈基玖本人」——哈基玖死亡掉落的彩蛋食物，复刻深蓝之树本尊的定义：
 * 食用后受到 32 点（×16）真实伤害（魔法类伤害，无视护甲），
 * 并失去 57 点饥饿值与 114 点饱和度。任何时候都吃得下（alwaysEat），
 * 所以这个奖赏纯粹是坑自己。
 *
 * <p>装有《方块与深蓝之树》时哈基玖死亡优先掉<b>本尊物品</b>
 * （见 {@link CaerulaArborCompat#nativeApocataDropItem()}）；本类只作装有深蓝之树、
 * 但查不到本尊物品时的等价兜底（未装深蓝之树时召唤出的替身死亡不掉「本人」）。
 * 数值完全对齐百科词条。</p>
 */
public final class ApocataHerselfItem extends Item {
    /** 真实伤害 32 点（魔法类别不吃护甲与护盾）。 */
    private static final float TRUE_DAMAGE = 32.0F;
    /** 饥饿值损失 57 点。 */
    private static final int HUNGER_LOSS = 57;
    /** 饱和度损失 114 点。 */
    private static final float SATURATION_LOSS = 114.0F;

    public ApocataHerselfItem() {
        super(new Item.Properties().food(new FoodProperties.Builder()
                .nutrition(0)
                .saturationMod(0.0F)
                .alwaysEat()
                .build()));
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.EAT;
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 16;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip,
                                TooltipFlag flag) {
        tooltip.add(Component.translatable("item.originfall_cataclysm.apocata_herself.desc")
                .withStyle(net.minecraft.ChatFormatting.GRAY));
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity eating) {
        ItemStack result = super.finishUsingItem(stack, level, eating);
        if (!level.isClientSide) {
            eating.hurt(level.damageSources().magic(), TRUE_DAMAGE);
            if (eating instanceof Player player) {
                FoodData food = player.getFoodData();
                food.setFoodLevel(Math.max(0, food.getFoodLevel() - HUNGER_LOSS));
                food.setSaturation(Math.max(0.0F, food.getSaturationLevel() - SATURATION_LOSS));
            }
        }
        return result;
    }
}
