package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.SourceOreGolem;
import cn.blockforge.generated.originfallcataclysm.SourceOreGolemModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;

public final class SourceOreGolemRenderer<T extends SourceOreGolem>
        extends MobRenderer<T, SourceOreGolemModel<T>> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath("originfall_cataclysm", "source_ore_golem"), "main");
    private final ResourceLocation texture;

    public SourceOreGolemRenderer(EntityRendererProvider.Context context, ResourceLocation texture,
                                   ModelLayerLocation layer) {
        super(context, new SourceOreGolemModel<>(context.bakeLayer(layer)), 0.5F);
        this.texture = texture;
        addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return texture;
    }
}
