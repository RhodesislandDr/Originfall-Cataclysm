package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.MeteorEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

public final class MeteorModel extends EntityModel<MeteorEntity> {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("originfall_cataclysm", "textures/entity/meteor.png");
    private final ModelPart root;

    public MeteorModel(ModelPart root) {
        super(RenderType::entityTranslucent);
        this.root = root;
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition core = root.addOrReplaceChild("core", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-5.0F, -5.0F, -5.0F, 10.0F, 10.0F, 10.0F), PartPose.offset(0.0F, 0.0F, 0.0F));
        core.addOrReplaceChild("facet_a", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-7.0F, -6.0F, -4.0F, 5.0F, 12.0F, 8.0F), PartPose.offsetAndRotation(0, 0, 0, 0, 0, -0.21F));
        core.addOrReplaceChild("facet_b", CubeListBuilder.create().texOffs(0, 0)
                .addBox(2.0F, -7.0F, -6.0F, 5.0F, 11.0F, 12.0F), PartPose.offsetAndRotation(0, 0, 0, 0.14F, 0.28F, 0));
        core.addOrReplaceChild("facet_c", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-6.0F, -4.0F, -7.0F, 12.0F, 9.0F, 5.0F), PartPose.offsetAndRotation(0, 0, 0, -0.17F, -0.24F, 0.14F));
        core.addOrReplaceChild("edge", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-8.0F, -3.0F, -3.0F, 4.0F, 6.0F, 6.0F), PartPose.offsetAndRotation(0, 0, 0, 0, 0, 0.49F));
        return LayerDefinition.create(mesh, 32, 32);
    }

    @Override
    public void setupAnim(MeteorEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        root.yRot = ageInTicks * 0.035F;
        root.xRot = ageInTicks * 0.027F;
        root.zRot = ageInTicks * 0.019F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public ResourceLocation texture() {
        return TEXTURE;
    }
}
