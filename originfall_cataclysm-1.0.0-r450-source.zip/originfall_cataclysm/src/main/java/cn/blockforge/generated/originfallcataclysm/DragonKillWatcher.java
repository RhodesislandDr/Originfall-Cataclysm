package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.dimension.end.EndDragonFight;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.AABB;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 「女祭司」普瑞赛斯召唤兼容层。
 *
 * <p>与 Epic Fight 等 Boss 改造模组共存时，末影龙的死亡事件链可能被吞掉
 * （LivingDeathEvent 不再到达本模组），或者巨龙改在离港平台上完成死亡动画，
 * 导致按“死亡事件 + 死亡点向下找地面”的老办法要么不触发、要么把女祭司直接
 * 生在传送门/基岩结构里立刻坠空或卡死。这里改为“事件 + 看门狗”双通道：
 * <ol>
 *   <li>LivingDeathEvent 正常触发时只登记待召唤（含死亡点），不再立即生成；</li>
 *   <li>周期性扫描已加载的龙尸：死亡动画推进到后段仍未登记的（事件被吞）补登记；</li>
 *   <li>EndDragonFight 战况兜底：本会话内曾存活在线、随后实体凭空消失且战况跟踪着
 *       这条龙的，同样补登记（首次击杀同样生效）。</li>
 * </ol>
 * 待召唤条目在延迟足够久（龙的死亡爆炸与传送门结算全部结束）之后，
 * 才在“远离巢穴中心、有可靠落脚地面”的位置生成女祭司；
 * 已处理的龙 UUID 持久化保存，保证每条龙只召唤一次、重启不重复。
 *
 * <p>另带一份“龙战兜底推进”：当龙尸死亡动画进入后段、而 {@code EndDragonFight} 战况仍停在
 * “未击杀”（vanilla 本应在死亡瞬间调用 setDragonKilled，被 Epic Fight 等 Boss 改造模组吞掉
 * 击杀链时才会出现），则安全地调用一次 {@code setDragonKilled} 把龙战收尾到“已击杀”，避免
 * 60 秒后战况重新刷出幻影龙、末地长期卡在龙未死状态。</p>
 */
public final class DragonKillWatcher {
    /** 死亡后到真正召唤女祭司之间的延迟刻数，覆盖巨龙死亡动画与死亡爆炸全程。 */
    private static final long SPAWN_DELAY = 260L;
    /** 处理队列时，尸体动画仍未结束的最长额外等待。 */
    private static final long CORPSE_GRACE = 1200L;
    /** 判定“死亡动画已进入后段”的 dragonDeathTime 阈值。 */
    private static final int DEATH_ANIM_LATE_TICKS = 160;
    /** 判定“死亡动画已结束”的 dragonDeathTime 阈值。 */
    private static final int DEATH_ANIM_DONE_TICKS = 195;
    /** 兜底通道要求：实体消失距最后确认存活至少隔这么多 tick。 */
    private static final long VANISH_GRACE = 100L;
    private static final int LIST_CAP = 32;
    /** 本会话内观察到的“活着且已加载”的龙：UUID -> 最后一次确认存活的 gameTime。 */
    private static final Map<UUID, Long> SEEN_ALIVE = new HashMap<>();

    private DragonKillWatcher() {
    }

    /** LivingDeathEvent 末影龙分支入口：登记待召唤，延迟到安全时机再生成。 */
    public static void onDragonDeathEvent(ServerLevel level, EnderDragon dragon) {
        queue(level, dragon.getUUID(), dragon.blockPosition(), level.getGameTime() + SPAWN_DELAY);
    }

    /** 每个 ServerLevel tick 调用一次，内部自动过滤末地维度。 */
    public static void tick(ServerLevel level) {
        if (!Level.END.equals(level.dimension())) return;
        long now = level.getGameTime();
        if (now % 20L != 0L) return;

        AABB worldBox = new AABB(-3.0E7D, level.getMinBuildHeight(), -3.0E7D,
                3.0E7D, level.getMaxBuildHeight(), 3.0E7D);
        for (EnderDragon dragon : level.getEntitiesOfClass(EnderDragon.class, worldBox)) {
            if (dragon.isAlive()) {
                SEEN_ALIVE.put(dragon.getUUID(), now);
            } else if (dragon.dragonDeathTime >= DEATH_ANIM_LATE_TICKS) {
                // 通道二：死亡事件被吞时，从尸体的死亡动画补登记。
                queue(level, dragon.getUUID(), dragon.blockPosition(),
                        Math.max(now + 60L, level.getGameTime() + SPAWN_DELAY - dragon.dragonDeathTime));
                // 战况兜底推进：若死亡动画已进入后段而战况仍显示“未击杀”（vanilla 在杀死瞬间
                // 本应已经 setDragonKilled，被 Epic Fight 吞掉时这里才补上），则安全地把龙战推
                // 进到“已击杀”，避免 60 秒后 findOrCreateDragon 重新刷出幻影龙、末地长时间卡在
                // 龙未死状态。
                advanceStuckDragonFight(level, dragon);
            }
        }

        // 通道三：战况跟踪着一条本会话曾存活在线、随后实体凭空消失的龙。
        // 不依赖 hasPreviouslyKilledDragon（首次击杀为 false 判定不到），
        // 只要战况记录的龙 UUID 不再对应任何在场实体、且不是重新刷出的活龙，即视为已被击杀。
        EndDragonFight fight = level.getDragonFight();
        if (fight != null && !level.players().isEmpty()) {
            UUID id = fight.getDragonUUID();
            Long lastAlive = id == null ? null : SEEN_ALIVE.get(id);
            if (id != null && lastAlive != null && now - lastAlive >= VANISH_GRACE
                    && level.getEntity(id) == null) {
                queue(level, id, new BlockPos(0, 120, 0), now + 60L);
            }
        }

        processPending(level, now);
    }

    /**
     * 只在“战况确实没推进到已击杀”时才调用 {@link EndDragonFight#setDragonKilled}，把龙战
     * 正常收尾（隐藏血条、放出口传送门与闸门、首次击杀放龙蛋、标记 dragonKilled）。
     *
     * <p>vanilla 在 {@code EnderDragon.kill()}（死亡瞬间）就会调用 setDragonKilled，因此正常
     * 击杀时 {@code saveData().dragonKilled()} 已为 true，此处直接返回；只有被 Epic Fight 等
     * 吞掉击杀链（战况一直停在未击杀）时才会真正推进，且每条龙最多一次，不会重复放传送门/闸门。</p>
     */
    private static void advanceStuckDragonFight(ServerLevel level, EnderDragon dragon) {
        EndDragonFight fight = level.getDragonFight();
        if (fight == null) return;
        if (fight.saveData().dragonKilled()) return;
        UUID tracked = fight.getDragonUUID();
        if (tracked == null || !tracked.equals(dragon.getUUID())) return;
        fight.setDragonKilled(dragon);
    }

    // ---------------- 队列与持久化 ----------------

    private static void queue(ServerLevel level, UUID id, BlockPos pos, long until) {
        if (id == null) return;
        SummonState state = SummonState.get(level);
        if (containsUuid(state.pending, "Id", id) || containsString(state.done, id.toString())) return;
        CompoundTag entry = new CompoundTag();
        entry.putUUID("Id", id);
        entry.putInt("X", pos.getX());
        entry.putInt("Z", pos.getZ());
        entry.putLong("Until", until);
        state.pending.add(state.pending.size(), entry);
        while (state.pending.size() > LIST_CAP) state.pending.remove(0);
        state.setDirty();
    }

    private static void processPending(ServerLevel level, long now) {
        SummonState state = SummonState.get(level);
        for (int i = state.pending.size() - 1; i >= 0; i--) {
            if (!(state.pending.get(i) instanceof CompoundTag entry)) {
                state.pending.remove(i);
                continue;
            }
            long until = entry.getLong("Until");
            if (now < until) continue;
            UUID id = entry.hasUUID("Id") ? entry.getUUID("Id") : null;
            Entity corpse = id == null ? null : level.getEntity(id);
            if (corpse instanceof EnderDragon dragon) {
                boolean animationRunning = dragon.isAlive()
                        || dragon.dragonDeathTime < DEATH_ANIM_DONE_TICKS;
                if (animationRunning && now - until < CORPSE_GRACE) continue;
            }
            state.pending.remove(i);
            state.setDirty();
            if (id != null && !containsString(state.done, id.toString())) {
                state.done.add(state.done.size(), StringTag.valueOf(id.toString()));
                while (state.done.size() > LIST_CAP) state.done.remove(0);
                state.setDirty();
            }
            if (id != null) SEEN_ALIVE.remove(id);
            spawnPriestessAt(level, entry.getInt("X"), entry.getInt("Z"));
        }
    }

    private static boolean containsUuid(ListTag list, String key, UUID id) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i) instanceof CompoundTag tag
                    && tag.hasUUID(key) && tag.getUUID(key).equals(id)) return true;
        }
        return false;
    }

    private static boolean containsString(ListTag list, String value) {
        for (int i = 0; i < list.size(); i++) {
            if (value.equals(list.getString(i))) return true;
        }
        return false;
    }

    // ---------------- 生成 ----------------

    /** 在给定 XZ 附近找一块可靠落脚点并召唤女祭司；先避开巢穴正中的传送门与基岩结构。 */
    private static void spawnPriestessAt(ServerLevel level, int cx, int cz) {
        if (Math.abs(cx) + Math.abs(cz) < 16) {
            cx += 24;
            cz += 24;
        }
        BlockPos spot = findGround(level, cx, cz);
        for (int r = 8; spot == null && r <= 48; r += 8) {
            for (int a = 0; a < 8 && spot == null; a++) {
                double angle = a * Math.PI / 4.0D;
                int rx = cx + (int) Math.round(Math.cos(angle) * r);
                int rz = cz + (int) Math.round(Math.sin(angle) * r);
                if (Math.abs(rx) + Math.abs(rz) < 16) continue;
                spot = findGround(level, rx, rz);
            }
        }
        if (spot == null) return;
        Priestess priestess = GeneratedMod.PRIESTESS.get().create(level);
        if (priestess == null) return;
        double x = spot.getX() + 0.5D + (level.getRandom().nextDouble() - 0.5D) * 2.0D;
        double z = spot.getZ() + 0.5D + (level.getRandom().nextDouble() - 0.5D) * 2.0D;
        priestess.moveTo(x, spot.getY(), z, level.getRandom().nextFloat() * 360.0F, 0.0F);
        priestess.setPersistenceRequired();
        level.addFreshEntity(priestess);
        Component message = Component.literal("巨龙陨灭之处，「女祭司」普瑞赛斯降临了");
        for (ServerPlayer player : level.players()) {
            player.displayClientMessage(message, true);
        }
    }

    /** 自上而下寻找“下方实心、自身与头顶两格为空气”的落脚点。 */
    private static BlockPos findGround(ServerLevel level, int x, int z) {
        int top = Math.min(level.getMaxBuildHeight() - 1, 200);
        for (int y = top; y > level.getMinBuildHeight(); y--) {
            BlockPos pos = new BlockPos(x, y, z);
            BlockState below = level.getBlockState(pos.below());
            if (!below.isSolid()) continue;
            if (level.getBlockState(pos).isAir() && level.getBlockState(pos.above()).isAir()) {
                return pos;
            }
        }
        return null;
    }

    /** 末地维度内的召唤进度：待召唤队列与已处理的龙 UUID 集合。 */
    private static final class SummonState extends SavedData {
        private static final String DATA_NAME = "originfall_priestess_summon";

        final ListTag pending = new ListTag();
        final ListTag done = new ListTag();

        static SummonState load(CompoundTag tag) {
            SummonState state = new SummonState();
            if (tag.contains("Pending", Tag.TAG_LIST)) {
                ListTag list = tag.getList("Pending", Tag.TAG_COMPOUND);
                for (int i = 0; i < list.size(); i++) {
                    state.pending.add(state.pending.size(), list.get(i));
                }
            }
            if (tag.contains("Done", Tag.TAG_LIST)) {
                ListTag list = tag.getList("Done", Tag.TAG_STRING);
                for (int i = 0; i < list.size(); i++) {
                    state.done.add(state.done.size(), list.get(i));
                }
            }
            return state;
        }

        static SummonState get(ServerLevel level) {
            return level.getDataStorage().computeIfAbsent(SummonState::load, SummonState::new, DATA_NAME);
        }

        @Override
        public CompoundTag save(CompoundTag tag) {
            tag.put("Pending", pending.copy());
            tag.put("Done", done.copy());
            return tag;
        }
    }
}
