package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.AABB;

import java.util.Comparator;

public final class ControlItem extends Item {
    public enum Mode { SOURCE, SALVATION, MESSENGER, PLANE_CHILD_XIU_ER }

    private final Mode mode;

    public ControlItem(Mode mode) {
        super(new Item.Properties().stacksTo(1).fireResistant());
        this.mode = mode;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResultHolder.sidedSuccess(stack, true);
        }
        DisasterData data = DisasterData.get(serverLevel);
        boolean changed = false;
        String message;
        if (mode == Mode.SOURCE) {
            if (CalamityLogic.isCivilizationContinuancePlayer(player)) {
                message = "文明的延续模式无法使用灾厄之源";
            } else if (!data.isSourceUsed()) {
                data.activateBySource();
                CalamityLogic.setCalamityModePlayer(player, true);
                changed = true;
                message = "灾厄已启动：陨石坠落开始";
            } else {
                message = "灾厄之源已经记录为已开启";
            }
        } else if (mode == Mode.SALVATION) {
            if (!data.isSalvationUsed()) {
                data.deactivateBySalvation();
                CalamityLogic.disableCalamityModes(serverLevel);
                changed = true;
                message = "救赎已降临：天灾模式与文明的延续模式已关闭";
            } else {
                message = "毁灭与救赎已经记录为已关闭";
            }
        } else if (mode == Mode.MESSENGER) {
            if (data.useMessenger()) {
                if (data.isCalamityActive()) {
                    CalamityLogic.setCalamityModePlayer(player, true);
                    changed = true;
                    message = "巴别塔誓言：灾厄模式开启";
                } else {
                    CalamityLogic.disableCalamityModes(serverLevel);
                    changed = true;
                    message = "巴别塔誓言：天灾模式与文明的延续模式已关闭";
                }
            } else {
                message = "巴别塔誓言已经使用过，无法再次切换";
            }
        } else {
            LivingEntity target = findHighestLivingEntity(serverLevel, player, 32.0D);
            if (target == null) {
                message = "位面之子秀儿：半径32格内没有可锁定的实体";
            } else {
                MeteorEntity meteor = MeteorEntity.createTargeted(serverLevel, target);
                serverLevel.addFreshEntity(meteor);
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                changed = true;
                message = "位面之子秀儿：已锁定最高生命值实体";
            }
        }
        player.displayClientMessage(Component.literal(message), true);
        return changed ? InteractionResultHolder.sidedSuccess(stack, false) : InteractionResultHolder.consume(stack);
    }

    private static LivingEntity findHighestLivingEntity(ServerLevel level, Player source, double radius) {
        AABB area = source.getBoundingBox().inflate(radius);
        return level.getEntitiesOfClass(LivingEntity.class, area,
                        entity -> entity.isAlive() && entity.distanceToSqr(source) <= radius * radius)
                .stream()
                .max(Comparator.comparingDouble(LivingEntity::getHealth))
                .orElse(null);
    }
}
