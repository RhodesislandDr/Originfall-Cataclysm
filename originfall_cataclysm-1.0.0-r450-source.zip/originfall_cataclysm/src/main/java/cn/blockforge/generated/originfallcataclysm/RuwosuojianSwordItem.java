package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * 如我所见：以玩家提供的像素水晶剑图片作为贴图的手持剑。
 * 数值与原版下界合金剑一致（伤害 7、攻速 1.6），但拥有无限耐久：永不损耗、不再显示耐久条。
 * 附魔兼容与原版剑一致（锋利、亡灵杀手、节肢杀手、击退、火焰附加、抢夺、横扫之刃等）。
 */
public final class RuwosuojianSwordItem extends SwordItem {
    public static final String ITEM_ID = "originfall_cataclysm:ruwosuojian";

    /** 下界合金级剑，但耐久设为极大值；实际由 canBeDepleted()==false 保证无限耐久。 */
    private static final Tier RUOWOSUO_TIER = new Tier() {
        @Override
        public int getUses() {
            return Integer.MAX_VALUE;
        }

        @Override
        public float getSpeed() {
            return 9.0F;
        }

        @Override
        public float getAttackDamageBonus() {
            return 4.0F;
        }

        @Override
        public int getLevel() {
            return 4;
        }

        @Override
        public int getEnchantmentValue() {
            return 15;
        }

        @Override
        public Ingredient getRepairIngredient() {
            return Ingredient.of(Items.NETHERITE_INGOT);
        }
    };

    public RuwosuojianSwordItem() {
        // 与原版下界合金剑相同的伤害/攻速修正：总攻击力 7，攻击速度 1.6。
        super(RUOWOSUO_TIER, 3, -2.4F,
                new net.minecraft.world.item.Item.Properties().stacksTo(1).fireResistant());
    }

    /** 无限耐久：永不损耗，也不再显示耐久条。 */
    @Override
    public boolean canBeDepleted() {
        return false;
    }

    @Override
    public boolean isBarVisible(ItemStack stack) {
        return false;
    }

    /** 附魔兼容与原版剑一致：允许所有适用于剑的附魔。 */
    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack, Enchantment enchantment) {
        return enchantment.category.canEnchant(stack.getItem());
    }

    @Override
    public boolean isEnchantable(ItemStack stack) {
        return true;
    }

    /** 能力名（加粗着色）+ 说明（逐行断行，原版提示栏不会自动换行，行宽控制在24字以内）。 */
    private static Component abilityName(String text, ChatFormatting color) {
        return Component.literal(text).withStyle(color, ChatFormatting.BOLD);
    }

    private static Component detail(String text) {
        return Component.literal(text).withStyle(ChatFormatting.GRAY);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("如我所见，如你所愿。").withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.literal("无限耐久 · 水晶质感 · 剑身尺寸为原版剑的1.2倍")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("─────── 如我所见 · 权能 ───────").withStyle(ChatFormatting.DARK_GRAY));

        // 两段伤害
        tooltip.add(abilityName("两段伤害", ChatFormatting.YELLOW));
        tooltip.add(detail("每次攻击造成两段伤害："));
        tooltip.add(detail("第一段=使用者最大生命值的25%"));
        tooltip.add(detail("第二段=原有攻击数值"));

        // 极•源石权柄•阳
        tooltip.add(abilityName("极•源石权柄•阳", ChatFormatting.GOLD));
        tooltip.add(detail("攻击造成伤害按45%恢复自身血量"));
        tooltip.add(detail("自身半径16格内生物的攻击伤害"));
        tooltip.add(detail("按65%恢复自身血量"));
        tooltip.add(detail("血量已满时，溢出部分转化为最大"));
        tooltip.add(detail("生命值上限；本武器携带时生效，"));
        tooltip.add(detail("丢弃或掉落后清除加成"));
        tooltip.add(detail("最大血量削减不计为伤害，时光之"));
        tooltip.add(detail("末溅射伤害同样适用本效果"));

        // 锚定现实
        tooltip.add(abilityName("锚定现实", ChatFormatting.AQUA));
        tooltip.add(detail("每次攻击有3.25%概率锚定敌人："));
        tooltip.add(detail("停滞移动与空间位置，并打断现有"));
        tooltip.add(detail("技能（沉默）——领域、召唤、锁定"));
        tooltip.add(detail("陨石等主动技能无法发动；攻击与"));
        tooltip.add(detail("索敌不受影响，照常进行"));
        tooltip.add(detail("时长10~30秒等概率随机"));
        tooltip.add(detail("对同一目标间隔60秒"));
        tooltip.add(detail("触发时对该生物施加“阳”标记，"));
        tooltip.add(detail("随内置间隔结束而消失"));
        tooltip.add(detail("（阳标记的唯一来源即本效果）"));
        tooltip.add(detail("锚定时触发时光之末溅射判定，"));
        tooltip.add(detail("被溅射单位携带同等锚定效果"));
        tooltip.add(detail("（无需重复判定，等控制时长）"));
        tooltip.add(detail("每次攻击另有16.25%概率施加阳火："));
        tooltip.add(detail("每秒燃烧削减1%×层数的当前最大"));
        tooltip.add(detail("生命值，单次最低削减3点上限"));
        tooltip.add(detail("每层持续32.5秒，至多32层，"));
        tooltip.add(detail("随时间逐层衰减"));
        tooltip.add(detail("阳火可触发时光之末；带火单位碰"));
        tooltip.add(detail("撞无火单位时传染同等层数"));
        tooltip.add(detail("对文明存续阵营单位无效"));
        tooltip.add(detail("玩家目标削减超过现有生命值时立"));
        tooltip.add(detail("刻击杀，无视复活与锁血；复活后"));
        tooltip.add(detail("最大生命值强制降为1，期间武器"));
        tooltip.add(detail("生命加成视为0"));

        // 时光之末
        tooltip.add(abilityName("时光之末", ChatFormatting.DARK_RED));
        tooltip.add(detail("本武器造成的伤害100%溅射至半"));
        tooltip.add(detail("径8格内所有敌方单位；被溅射单"));
        tooltip.add(detail("位再以50%、25%……逐级衰减的"));
        tooltip.add(detail("概率向各自周围8格继续溅射"));
        tooltip.add(detail("伤害均为100%原有伤害"));

        // 昔时我见
        tooltip.add(abilityName("昔时我见", ChatFormatting.LIGHT_PURPLE));
        tooltip.add(detail("使用者濒死时，将生命锚定在现有"));
        tooltip.add(detail("最大生命值的32.5%"));
        tooltip.add(detail("15秒内任意时刻血量超过锚定线，"));
        tooltip.add(detail("则2秒后扣除超出部分生命值和"));
        tooltip.add(detail("50%当前最大生命值"));
        tooltip.add(detail("扣除时生命值不够则死亡"));
        tooltip.add(detail("本效果可循环使用"));

        // 无下限•内化宇宙•阳
        tooltip.add(abilityName("无下限•内化宇宙•阳", ChatFormatting.DARK_PURPLE));
        tooltip.add(detail("自身持有阴标记（来自天堂支点流"));
        tooltip.add(detail("放）且成功对目标施加阳标记时："));
        tooltip.add(detail("全体带阴阳标记生物被拉入虚空，"));
        tooltip.add(detail("原地留下空间锚点，10秒后归来"));
        tooltip.add(detail("每秒判定：5%即死，其余95%在"));
        tooltip.add(detail("+3250、+325、+3.25%、+32.5%、"));
        tooltip.add(detail("-3250、-325、-3.25%、-32.5%"));
        tooltip.add(detail("（上限及血量）八档中平分"));
        tooltip.add(detail("虚空内无法移动与攻击，复活与免"));
        tooltip.add(detail("死效果无效"));
        tooltip.add(detail("同时触发本锚定时，原本的锚定效果"));
        tooltip.add(detail("推迟到10秒判定归来后兑现；造成者"));
        tooltip.add(detail("死亡则不触发，目标在虚空内死亡无"));
        tooltip.add(detail("法复活"));

        // 无下限•内化宇宙•开放
        tooltip.add(abilityName("无下限•内化宇宙•开放", ChatFormatting.DARK_PURPLE));
        tooltip.add(detail("（独立机制）任一生物同时持有阴阳两"));
        tooltip.add(detail("枚印记即触发，判定同内化宇宙"));

        super.appendHoverText(stack, level, tooltip, flag);
    }
}
