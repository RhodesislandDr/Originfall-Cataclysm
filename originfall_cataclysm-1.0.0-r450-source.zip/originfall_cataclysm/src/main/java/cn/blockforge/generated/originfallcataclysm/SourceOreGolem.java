package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.navigation.AmphibiousPathNavigation;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.WallClimberNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;

import java.util.UUID;

/** 源石耄耋与哈气贤者的共同基类；它们属于制造者阵营，不参与天灾转化。 */
public abstract class SourceOreGolem extends IronGolem {
    public static final EntityDataAccessor<String> LEARNED_TRAITS_DATA =
            SynchedEntityData.defineId(SourceOreGolem.class, EntityDataSerializers.STRING);
    public static final EntityDataAccessor<Integer> LEARNED_LIMIT_DATA =
            SynchedEntityData.defineId(SourceOreGolem.class, EntityDataSerializers.INT);
    /** 独立形态的恶意等级同步值：服务端定级时写入，客户端名牌外显只读；
     *  装有莱特兰-恶意时本键闲置，等级与词条外显由恶意模组自身完成。 */
    public static final EntityDataAccessor<Integer> MALICE_LEVEL_DATA =
            SynchedEntityData.defineId(SourceOreGolem.class, EntityDataSerializers.INT);
    private static final String ATTACK_COUNT = "OriginFallAttackCount";
    private static final String MANUFACTURER_UUID = "OriginFallManufacturerUUID";
    private static final String CALAMITY_FACTION = "OriginFallSourceGolemCalamityFaction";
    private static final String OWNER_UUID = "OriginFallSourceGolemOwnerUUID";
    private static final String FOLLOWING_OWNER = "OriginFallSourceGolemFollowingOwner";
    private static final String ORDERED_TO_SIT = "OriginFallSourceGolemOrderedToSit";
    private int attackCount;
    private UUID manufacturerUuid;
    private UUID ownerUuid;
    private boolean calamityFaction;
    private boolean followingOwner = true;
    private boolean orderedToSit;
    private boolean learnedFlightNavigation;
    private boolean learnedWallNavigation;

    protected SourceOreGolem(EntityType<? extends SourceOreGolem> type, Level level) {
        super(type, level);
        moveControl = new AquaticMoveControl(this);
        setPlayerCreated(true);
        setPersistenceRequired();
    }

    protected abstract int infectionInterval();

    protected abstract int infectionLayersPerAttack();

    public static AttributeSupplier.Builder createAttributes(double attackDamage) {
        return IronGolem.createAttributes()
                .add(Attributes.ATTACK_DAMAGE, attackDamage)
                .add(Attributes.FLYING_SPEED, 0.6D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    public final void setManufacturerUUID(UUID uuid) {
        manufacturerUuid = uuid;
        if (uuid != null) getPersistentData().putUUID(MANUFACTURER_UUID, uuid);
    }

    public final UUID getManufacturerUUID() {
        return manufacturerUuid;
    }

    public final void setCalamityFaction(boolean value) {
        calamityFaction = value;
        getPersistentData().putBoolean(CALAMITY_FACTION, value);
    }

    public final boolean isCalamityFaction() {
        return calamityFaction;
    }

    public final UUID getOwnerUUID() {
        return ownerUuid;
    }

    public final Player getOwnerPlayer() {
        if (ownerUuid == null || !(level() instanceof ServerLevel server)) return null;
        return server.getServer().getPlayerList().getPlayer(ownerUuid);
    }

    public final boolean isOwnedBy(Player player) {
        return player != null && ownerUuid != null && ownerUuid.equals(player.getUUID());
    }

    public final boolean isFollowingOwner() {
        return followingOwner;
    }

    public final boolean isOrderedToSit() {
        return orderedToSit;
    }

    private void setOrderedToSit(boolean value) {
        orderedToSit = value;
        followingOwner = !value;
        if (value) {
            setTarget(null);
            getNavigation().stop();
        }
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        AmphibiousPathNavigation navigation = new AmphibiousPathNavigation(this, level);
        navigation.setCanFloat(true);
        return navigation;
    }

    @Override
    public boolean canBreatheUnderwater() {
        return true;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(LEARNED_TRAITS_DATA, "");
        entityData.define(LEARNED_LIMIT_DATA, 0);
        entityData.define(MALICE_LEVEL_DATA, 0);
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        goalSelector.addGoal(0, new AquaticSurfaceGoal(this));
        // IronGolem 原版会注册 FloatGoal；移除它，避免与无目标上浮目标争抢 MOVE 控制权。
        goalSelector.removeAllGoals(goal -> goal instanceof FloatGoal || goal instanceof MeleeAttackGoal);
        goalSelector.addGoal(2, new SourceOreGolemFollowOwnerGoal(this, 1.1D, 10.0F, 2.0F));
        goalSelector.addGoal(3, new AdaptiveCombatGoal(this, 1.0D));
        targetSelector.addGoal(1, new net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal<>(
                this, LivingEntity.class, 10, true, false, this::canAttack));
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return super.mobInteract(player, hand);
        ItemStack stack = player.getItemInHand(hand);
        if (!stack.isEmpty()) return super.mobInteract(player, hand);
        if (level().isClientSide) return InteractionResult.sidedSuccess(true);
        if (isOwnedBy(player)) {
            if (player.isShiftKeyDown()) {
                setOrderedToSit(!orderedToSit);
            } else {
                orderedToSit = false;
                followingOwner = !followingOwner;
            }
            return InteractionResult.CONSUME;
        }
        if (ownerUuid == null) {
            ownerUuid = player.getUUID();
            followingOwner = true;
            orderedToSit = false;
            setPlayerCreated(true);
            return InteractionResult.CONSUME;
        }
        return InteractionResult.PASS;
    }

    @Override
    public boolean isAlliedTo(net.minecraft.world.entity.Entity other) {
        return other instanceof LivingEntity living && CalamityLogic.isFactionAlly(this, living)
                || super.isAlliedTo(other);
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        return !orderedToSit && !(target instanceof Player player && isOwnedBy(player))
                && CalamityLogic.canSourceOreGolemAttack(this, target);
    }

    @Override
    public boolean doHurtTarget(net.minecraft.world.entity.Entity target) {
        if (target instanceof LivingEntity living && !canAttack(living)) return false;
        boolean hurt = super.doHurtTarget(target);
        if (!hurt) return false;
        if (!(target instanceof LivingEntity living) || level().isClientSide) return true;
        attackCount++;
        // 攻击感染概率和叠层由统一事件入口处理，避免近战与投射物规则不一致。
        return true;
    }

    @Override
    public boolean canAttackType(EntityType<?> type) {
        // 是否攻击另一种源石实体由 canAttack(LivingEntity) 按阵营决定，不能在类型层面一概屏蔽。
        return super.canAttackType(type);
    }

    /** 源石耄耋不因陨石强化属性。 */
    public void onMeteorBlast(float damageMultiplier) {
    }

    @Override
    public void die(DamageSource source) {
        // 源石耄耋和哈气贤者死亡不触发 CalamityMob 的死亡陨石路径。
        super.die(source);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.IS_EXPLOSION)) return false;
        return super.hurt(source, amount);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        LearnedTraitLogic.tick(this);
        updateLearnedNavigation();
        if (!AssimilationEquipment.isAssigned(this)) {
            AssimilationEquipment.assign(this);
        }
        removeEffect(GeneratedMod.SOURCE_ORE_INFECTION.get());
        if (tickCount % 20 == 0 && getBlockStateOn().is(GeneratedMod.BLACK_CRYSTAL.get())) {
            heal(healingPerSecond());
        }
    }

    protected float healingPerSecond() {
        return 1.0F;
    }

    @Override
    public boolean onClimbable() {
        return LearnedTraitLogic.has(this, LearnedTraitLogic.WALL_CLIMB) || super.onClimbable();
    }

    /** 学会 flight 后使用飞行移动，落地不应产生原版摔落伤害。 */
    @Override
    public boolean causeFallDamage(float fallDistance, float damageMultiplier, DamageSource source) {
        if (LearnedTraitLogic.has(this, LearnedTraitLogic.FLIGHT)) return false;
        return super.causeFallDamage(fallDistance, damageMultiplier, source);
    }

    private void updateLearnedNavigation() {
        boolean flight = LearnedTraitLogic.has(this, LearnedTraitLogic.FLIGHT);
        boolean wallClimb = LearnedTraitLogic.has(this, LearnedTraitLogic.WALL_CLIMB);
        if (flight && !learnedFlightNavigation) {
            // AttributeSupplier 已预注册该属性；首次学习 flight 时立即创建实体属性实例。
            getAttribute(Attributes.FLYING_SPEED);
            FlyingPathNavigation navigation = new FlyingPathNavigation(this, level());
            navigation.setCanOpenDoors(false);
            navigation.setCanPassDoors(false);
            navigation.setMaxVisitedNodesMultiplier(2.0F);
            this.navigation = navigation;
            moveControl = new FlyingMoveControl(this, 20, true);
            setNoGravity(true);
            learnedFlightNavigation = true;
            learnedWallNavigation = false;
        } else if (!flight && wallClimb && !learnedWallNavigation) {
            this.navigation = new WallClimberNavigation(this, level());
            moveControl = new MoveControl(this);
            setNoGravity(false);
            learnedWallNavigation = true;
            learnedFlightNavigation = false;
        } else if (!flight && !wallClimb && (learnedFlightNavigation || learnedWallNavigation)) {
            this.navigation = createNavigation(level());
            moveControl = new AquaticMoveControl(this);
            setNoGravity(false);
            learnedFlightNavigation = false;
            learnedWallNavigation = false;
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt(ATTACK_COUNT, attackCount);
        if (manufacturerUuid != null) tag.putUUID(MANUFACTURER_UUID, manufacturerUuid);
        if (ownerUuid != null) tag.putUUID(OWNER_UUID, ownerUuid);
        tag.putBoolean(CALAMITY_FACTION, calamityFaction);
        tag.putBoolean(FOLLOWING_OWNER, followingOwner);
        tag.putBoolean(ORDERED_TO_SIT, orderedToSit);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        attackCount = tag.getInt(ATTACK_COUNT);
        manufacturerUuid = tag.hasUUID(MANUFACTURER_UUID) ? tag.getUUID(MANUFACTURER_UUID) : null;
        ownerUuid = tag.hasUUID(OWNER_UUID) ? tag.getUUID(OWNER_UUID) : null;
        calamityFaction = tag.getBoolean(CALAMITY_FACTION);
        followingOwner = !tag.contains(FOLLOWING_OWNER) || tag.getBoolean(FOLLOWING_OWNER);
        orderedToSit = tag.getBoolean(ORDERED_TO_SIT);
    }
}
