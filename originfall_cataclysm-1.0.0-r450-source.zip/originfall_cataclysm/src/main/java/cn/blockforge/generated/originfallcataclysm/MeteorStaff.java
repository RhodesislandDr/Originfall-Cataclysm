package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;

public final class MeteorStaff extends Item {
    private static final int MIN_METEORS = 3;
    private static final int MAX_METEORS = 5;
    private static final double SUMMON_RADIUS = 64.0D;

    public MeteorStaff() {
        super(new Item.Properties().stacksTo(1).durability(5).fireResistant());
    }

    public static int count(ServerLevel level) {
        return MIN_METEORS + level.getRandom().nextInt(MAX_METEORS - MIN_METEORS + 1);
    }

    public static void summon(ServerLevel level, LivingEntity source, int amount) {
        if (!CalamityLogic.canSummonNaturalMeteorFrom(source)) return;
        for (int i = 0; i < amount; i++) {
            level.addFreshEntity(MeteorEntity.createNaturalForPlayer(level, source, SUMMON_RADIUS));
        }
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResultHolder.sidedSuccess(stack, true);
        }

        if (!CalamityLogic.canSummonNaturalMeteorFrom(player)) {
            player.displayClientMessage(Component.literal("文明的延续模式中，玩家不能作为天灾中心召唤陨石"), true);
            return InteractionResultHolder.consume(stack);
        }
        summon(serverLevel, player, count(serverLevel));

        if (!player.getAbilities().instabuild) {
            stack.hurtAndBreak(1, player, brokenPlayer -> brokenPlayer.broadcastBreakEvent(hand));
        }
        return InteractionResultHolder.sidedSuccess(stack, false);
    }
}
