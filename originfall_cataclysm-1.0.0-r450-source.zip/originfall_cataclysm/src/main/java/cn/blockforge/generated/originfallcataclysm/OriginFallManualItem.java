package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;

import java.util.List;

/**
 * 《源石对世界的融合研究及实践》。
 *
 * <p>右击打开说明书，内容由 {@link OriginFallManualContent} 现场生成；
 * 一次性赠送给首次进入世界的玩家，也可用书与圆石左右放置合成。</p>
 */
public final class OriginFallManualItem extends Item {
    private static final String MANUAL_GIVEN = "OriginFallManualGiven";

    public OriginFallManualItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> cn.blockforge.generated.originfallcataclysm.client.OriginFallManualClient.open());
        }
        return InteractionResultHolder.sidedSuccess(stack, false);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip,
                                TooltipFlag flag) {
        tooltip.add(Component.translatable("item.originfall_cataclysm.originfall_manual.desc"));
    }

    /** 该玩家是否已经领过开局说明书。 */
    public static boolean hasReceivedManual(Player player) {
        return player != null && player.getPersistentData().getBoolean(MANUAL_GIVEN);
    }

    /** 记录该玩家已经领过开局说明书。 */
    public static void markManualGiven(Player player) {
        if (player != null) player.getPersistentData().putBoolean(MANUAL_GIVEN, true);
    }
}
