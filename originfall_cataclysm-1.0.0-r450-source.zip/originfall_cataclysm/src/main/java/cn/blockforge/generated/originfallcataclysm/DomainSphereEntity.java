package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.network.NetworkHooks;

import java.util.UUID;

/**
 * 领域展开的结界球体展示实体：空心、无厚度的半透明球体。
 * 出现在施术者展开领域的圆心处，随领域激活从圆心向外扩张至领域半径，之后在领域存在期间持续保持。
 *
 * 服务端负责生命周期与半径推进（球体随着领域激活在圆心生成，领域结束即移除）；
 * 客户端渲染器读取同步的类型与当前半径，画出对应颜色的半透明结界球面。
 * 「预言家」博士的领域球体为白金色，「女祭司」普瑞赛斯的领域球体为暗紫色。
 */
public final class DomainSphereEntity extends Entity {

    public static final int TYPE_PROPHET = 0;
    public static final int TYPE_PRIESTESS = 1;

    /** 领域展开从圆心扩张到领域半径所用的 tick 数；越短扩张越快。 */
    public static final int EXPAND_TICKS = 40;

    private static final EntityDataAccessor<Integer> DATA_TYPE =
            SynchedEntityData.defineId(DomainSphereEntity.class, EntityDataSerializers.INT);
    /** 领域目标半径（恒定，创建时写入）。 */
    private static final EntityDataAccessor<Float> DATA_RADIUS =
            SynchedEntityData.defineId(DomainSphereEntity.class, EntityDataSerializers.FLOAT);
    /** 当前渲染半径（服务端从 0 逐 tick 推进到目标半径）。 */
    private static final EntityDataAccessor<Float> DATA_CURRENT_RADIUS =
            SynchedEntityData.defineId(DomainSphereEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<String> DATA_CASTER =
            SynchedEntityData.defineId(DomainSphereEntity.class, EntityDataSerializers.STRING);

    private static final String TYPE_TAG = "DomainSphereType";
    private static final String RADIUS_TAG = "DomainSphereRadius";
    private static final String CASTER_TAG = "DomainSphereCaster";
    private static final String SPAWN_TAG = "DomainSphereSpawnGameTime";

    /** 服务端记录球体生成时的游戏时间，用于逐 tick 推进扩张半径。 */
    private long spawnGameTime;

    public DomainSphereEntity(EntityType<? extends DomainSphereEntity> type, Level level) {
        super(type, level);
        setNoGravity(true);
    }

    /**
     * 在指定圆心生成一颗领域球体并加入世界（服务端调用）。
     *
     * @param level  服务端维度
     * @param x/y/z  领域圆心（施术者展开领域时的坐标）
     * @param type   领域类型（{@link #TYPE_PROPHET} 白金色 / {@link #TYPE_PRIESTESS} 暗紫色）
     * @param radius 领域半径（格）
     * @param caster 施术者 UUID，用于领域结束时按施术者移除球体
     * @return 生成成功返回实体，否则返回 null
     */
    public static DomainSphereEntity create(ServerLevel level, double x, double y, double z,
                                            int type, double radius, UUID caster) {
        DomainSphereEntity sphere = GeneratedMod.DOMAIN_SPHERE.get().create(level);
        if (sphere == null) return null;
        sphere.moveTo(x, y, z, 0.0F, 0.0F);
        sphere.setSphereType(type);
        sphere.setTargetRadius(radius);
        sphere.setCasterUUID(caster);
        sphere.spawnGameTime = level.getGameTime();
        // 初始半径 0，由服务端逐 tick 扩到目标半径；客户端据此做出“向外扩张”的动画。
        sphere.setCurrentRadius(0.0F);
        level.addFreshEntity(sphere);
        return sphere;
    }

    /** 移除指定施术者的全部领域球体（领域结束时调用，服务端）。 */
    public static void removeForCaster(ServerLevel level, UUID caster) {
        if (caster == null) return;
        // 性能：经实体索引直接拿本维度球体名单，替代全维度实体扫描。
        for (DomainSphereEntity sphere : EntityTrackers.spheres(level)) {
            if (!sphere.isRemoved() && caster.equals(sphere.getCasterUUID())) sphere.discard();
        }
    }

    /** 游离球体清理的执行间隔（tick）：施术者状态以秒级对齐即可，无需每 tick 全查。 */
    private static final long PRUNE_INTERVAL = 10L;

    /**
     * 清理游离的球体：凡其施术者在该维度已不再拥有处于激活状态的对应领域（施术者死亡、离开、
     * 领域已结束、被传送到其它维度等），一律移除，避免球体残留。
     * 每次服务端 LevelTick 结束时调用一次（内部按 {@value #PRUNE_INTERVAL} tick 节流）。
     */
    public static void pruneOrphans(ServerLevel level) {
        if (level.getGameTime() % PRUNE_INTERVAL != 0L) return;
        // 性能：原实现对每个球体再做两次全维度实体扫描；现改为
        // ① 经实体索引取球体名单，② 用 O(1) 的按 UUID 直查取回施术者本体。
        for (DomainSphereEntity sphere : EntityTrackers.spheres(level)) {
            if (sphere.isRemoved()) continue;
            UUID caster = sphere.getCasterUUID();
            if (caster == null) {
                sphere.discard();
                continue;
            }
            Entity casterEntity = level.getEntity(caster);
            boolean active = sphere.getSphereType() == TYPE_PRIESTESS
                    ? casterEntity instanceof Priestess priestess
                            && priestess.isAlive() && PriestessSkillLogic.isDomainActive(priestess)
                    : casterEntity instanceof Prophet prophet
                            && prophet.isAlive() && ProphetSkillLogic.isDomainActive(prophet);
            if (!active) sphere.discard();
        }
    }

    // ---------------- 访问器（客户端渲染与服务器匹配共用） ----------------

    public int getSphereType() {
        return entityData.get(DATA_TYPE);
    }

    public void setSphereType(int type) {
        entityData.set(DATA_TYPE, type);
    }

    public float getCurrentRadius() {
        return entityData.get(DATA_CURRENT_RADIUS);
    }

    public void setCurrentRadius(float radius) {
        entityData.set(DATA_CURRENT_RADIUS, radius);
    }

    public void setTargetRadius(double radius) {
        entityData.set(DATA_RADIUS, (float) radius);
    }

    public UUID getCasterUUID() {
        String id = entityData.get(DATA_CASTER);
        return (id == null || id.isEmpty()) ? null : UUID.fromString(id);
    }

    public void setCasterUUID(UUID caster) {
        entityData.set(DATA_CASTER, caster == null ? "" : caster.toString());
    }

    // ---------------- 行为覆盖 ----------------

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    @Override
    public boolean isSilent() {
        return true;
    }

    /** 客户端剔除判定按整个球体范围计算，避免球体巨大但实体原点太小导致提前被剔除。 */
    @Override
    public AABB getBoundingBoxForCulling() {
        float r = Math.max(0.0F, getCurrentRadius());
        return new AABB(getX() - r, getY() - r, getZ() - r, getX() + r, getY() + r, getZ() + r);
    }

    @Override
    public void tick() {
        super.tick();
        setDeltaMovement(0.0D, 0.0D, 0.0D);
        if (level().isClientSide) return;
        // 服务端推进扩张：从 0 缓慢扩到目标半径，用平滑曲线让“向外扩张”更明显。
        if (!(level() instanceof ServerLevel server)) return;
        float target = entityData.get(DATA_RADIUS);
        if (target <= 0.0F) return;
        long elapsed = server.getGameTime() - spawnGameTime;
        float current;
        if (elapsed >= EXPAND_TICKS) {
            current = target;
        } else {
            double progress = (double) elapsed / (double) EXPAND_TICKS;
            double eased = 1.0D - Math.pow(1.0D - progress, 3.0D);
            current = (float) (target * eased);
        }
        float prev = entityData.get(DATA_CURRENT_RADIUS);
        if (Math.abs(prev - current) > 0.0005F || (current >= target && prev != target)) {
            entityData.set(DATA_CURRENT_RADIUS, current);
        }
    }

    @Override
    public Packet getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(DATA_TYPE, TYPE_PROPHET);
        entityData.define(DATA_RADIUS, 0.0F);
        entityData.define(DATA_CURRENT_RADIUS, 0.0F);
        entityData.define(DATA_CASTER, "");
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        setSphereType(tag.getInt(TYPE_TAG));
        // 读取保存时的目标半径；扩张进度由服务端在下一 tick 按生成时间重新推进。
        entityData.set(DATA_RADIUS, tag.getFloat(RADIUS_TAG));
        setCasterUUID(tag.contains(CASTER_TAG) ? UUID.fromString(tag.getString(CASTER_TAG)) : null);
        spawnGameTime = tag.getLong(SPAWN_TAG);
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt(TYPE_TAG, getSphereType());
        tag.putFloat(RADIUS_TAG, entityData.get(DATA_RADIUS));
        tag.putString(CASTER_TAG, getCasterUUID() == null ? "" : getCasterUUID().toString());
        tag.putLong(SPAWN_TAG, spawnGameTime);
    }
}
