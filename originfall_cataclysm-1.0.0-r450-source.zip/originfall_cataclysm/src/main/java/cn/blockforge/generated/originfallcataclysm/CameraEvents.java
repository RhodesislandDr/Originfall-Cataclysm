package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.client.Minecraft;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class CameraEvents {
    private CameraEvents() {}

    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        Minecraft minecraft = Minecraft.getInstance();
        ClientLevel level = minecraft.level;
        if (level == null || !(event.getCamera().getEntity() instanceof Player)) return;

        // 性能：原实现每帧都做一次 384 格见方的实体查询（大陨石期或掉落场景下逐帧显著掉帧）；
        // 改为遍历客户端跟踪的陨石小集合（EntityTrackers 经实体加入/移除事件维护，
        // 切换世界自动清空、离场自愈），伤害倍率与距离衰减判定仍在循环内按颗计算，画面一致。
        EntityTrackers.syncClientWorld(level);
        if (EntityTrackers.clientMeteors().isEmpty()) return;
        EntityTrackers.pruneClientMeteors();

        Camera camera = event.getCamera();
        Vec3 cameraPosition = camera.getPosition();
        float yawShake = 0.0F;
        float pitchShake = 0.0F;
        float rollShake = 0.0F;
        double partialTick = event.getPartialTick();

        for (MeteorEntity meteor : EntityTrackers.clientMeteors()) {
            if (meteor.isRemoved() || !meteor.isAlive() || meteor.level() != level) continue;
            if (meteor.getDamageMultiplier() < 100.0F) continue;
            double distance = meteor.distanceToSqr(cameraPosition.x, cameraPosition.y, cameraPosition.z);
            if (distance > 192.0D * 192.0D) continue;
            double range = meteor.getDamageMultiplier() >= 1000.0F ? 192.0D : 128.0D;
            double attenuation = 1.0D - Math.sqrt(distance) / range;
            if (attenuation <= 0.0D) continue;

            float strength = (meteor.getDamageMultiplier() >= 1000.0F ? 2.8F : 1.15F) * (float) attenuation;
            float time = (float) (level.getGameTime() + partialTick) * 0.85F + meteor.getId() * 0.37F;
            yawShake += Mth.sin(time * 1.31F) * strength;
            pitchShake += Mth.cos(time * 1.73F) * strength * 0.8F;
            rollShake += Mth.sin(time * 2.07F) * strength * 0.35F;
        }

        event.setYaw(event.getYaw() + yawShake);
        event.setPitch(event.getPitch() + pitchShake);
        event.setRoll(event.getRoll() + rollShake);
    }
}
