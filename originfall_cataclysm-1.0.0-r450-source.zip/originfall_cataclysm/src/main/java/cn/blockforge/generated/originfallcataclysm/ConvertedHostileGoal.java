package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.entity.Mob;

/** 被标记的转化生物使用与独立转化实体相同的自适应战斗动作。 */
public final class ConvertedHostileGoal extends AdaptiveCombatGoal {
    public ConvertedHostileGoal(Mob mob) {
        super(mob, 1.0D);
    }
}
