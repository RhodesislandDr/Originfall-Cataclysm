package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 「预言家」博士的召唤仪式：用张师块围成水池，向其中投入铜块、铁块、钻石块、金块、
 * 远古残骸、黑色晶体、至纯源石与张师块，八种祭品齐备后水池中心响起传送音效，
 * 随后在水池中心凝结出一次性道具「表里之间」。
 *
 * <p><b>本轮找到并修掉了前三轮都没覆盖到的真正根因——「抛出即被吸回」竞争。</b>
 * 玩家最自然的仪式操作是站在池边逐件把祭品丢进水里。旧实现完全依赖低频周期扫描
 * （空扫每 100 tick 才一次），而玩家 Q 键丢出的物品约 20 tick 后就能被扔掷者重新
 * 吸回背包——祭品在「第一次被扫描到」之前就已经回到了玩家手里。八件祭品一件都
 * 不会被记进水池，进度播报也从不出现，于是无论把水池几何判定放宽到什么程度都
 * 「投了没反应」。上一轮加的拾取锁定要等扫描命中才生效，本身就是马后炮。</p>
 *
 * <p>本轮改造：
 * <ol>
 *   <li><b>事件驱动的祭品监视。</b>监听 {@code ItemTossEvent}：八种祭品之一被抛出的
 *       瞬间即获得拾取保护并进入逐 tick 监视，落水当 tick 就被记住并持续锁定拾取。
 *       站在池边连投八件，每一件都从抛出那一刻起被盯死，不再与低频扫描抢时间。
 *       原有的周期扫描保留，兜底接管非抛出途径入水的祭品。</li>
 *   <li><b>水池识别从「固定 2×2」放宽为「任意矩形水面」。</b>以落水格为种子洪泛
 *       连通水面，水面恰好铺满一个矩形（≤64 格）且四周整圈都是张师块（逐块允许
 *       与水面同层/上方一格/上方两格的高度差）即合法。2×2、3×3、1×2 乃至更大的
 *       矩形池都能认出；奖励落在实际水面中心。</li>
 *   <li><b>修复存档重载导致的永久冷却死锁。</b>重载后 gameTime 回到接近 0，冷却表里
 *       「未来时间」的旧条目会让差值恒为负、既不清除也永远判冷却中。现在重载后
 *       检测到即作废。</li>
 *   <li><b>结算检查改为每 tick。</b>第 8 件祭品落水后至多 1 tick 内出结果，
 *       进度播报同样即时。</li>
 * </ol>
 */
public final class ProphetRitual {
    /** 有候选祭品时周期扫描的间隔（兜底通道）。 */
    private static final int SCAN_INTERVAL = 20;
    /** 空扫（玩家附近无任何祭品）时的退避间隔，idle 世界不再每秒全局遍历掉落物。 */
    private static final int SCAN_INTERVAL_IDLE = 100;
    /** 扫描半径：只查每个玩家周边的物品实体，取代旧的整维度 AABB 全量检索。 */
    private static final double PLAYER_SCAN_RADIUS = 96.0D;
    /** 水池结算后的冷却：10 秒内同一池子不再二次触发，防相邻候选重复消耗与重复发奖。 */
    private static final long POOL_COOLDOWN = 200L;
    /** 祭品记忆窗口：同一水池在这么久内累计到过的祭品种类都算有效，容忍分次投放与短暂离水。 */
    private static final long OFFERING_WINDOW = 600L;
    /** 祭品落池后的拾取锁定：监视通道每 tick 续期，兜底扫描每 20 tick 续一次。 */
    private static final int OFFERING_PICKUP_LOCK = 40;
    /** 抛出祭品的监视窗口：覆盖抛物飞行最长时间；监视内每 tick 检查落水。 */
    private static final long WATCH_WINDOW = 100L;
    /** 监视表容量上限，防被大量丢弃祭品类物品刷爆。 */
    private static final int WATCH_CAPACITY = 512;
    /** 进度播报节流：同一水池相邻两次播报至少隔这么多 tick，避免刷屏。 */
    private static final long PROGRESS_INTERVAL = 10L;
    /** 进度播报半径：只提醒水池附近正在操作仪式的玩家。 */
    private static final double PROGRESS_RADIUS = 32.0D;
    /** 合法水池的最大面积（格）：再大的水面是湖泊，不是仪式池。 */
    private static final int MAX_POOL_AREA = 64;
    /** 已结算水池的冷却表：键为「维度@坐标」，值为结算时的 gameTime。 */
    private static final Map<String, Long> RECENT_POOLS = new HashMap<>();
    /** 每维度的自适应扫描排程：命中回快速间隔，空扫退避。 */
    private static final Map<ResourceKey<Level>, ScanSchedule> SCHEDULES = new HashMap<>();
    /** 每个水池的祭品记忆：键为「维度@坐标」，值为窗口内见过的祭品种类。 */
    private static final Map<String, OfferingMemory> OFFERINGS = new HashMap<>();
    /** 刚抛出的祭品监视表：键为实体 id，值持有实体引用与到期 tick。 */
    private static final Map<Integer, WatchedToss> WATCHED = new HashMap<>();

    /** 八种祭品的展示顺序（稳定顺序，用于进度提示里列「尚缺」）。 */
    private static final List<Item> REQUIRED_ORDER = List.of(
            Items.COPPER_BLOCK,
            Items.IRON_BLOCK,
            Items.DIAMOND_BLOCK,
            Items.GOLD_BLOCK,
            Items.ANCIENT_DEBRIS,
            GeneratedMod.BLACK_CRYSTAL_ITEM.get(),
            GeneratedMod.METEOR_BLOCK_ITEM.get(),
            GeneratedMod.ZHANGSHI_BLOCK_ITEM.get());

    private static final Set<Item> REQUIRED_ITEMS = Set.copyOf(REQUIRED_ORDER);

    private ProphetRitual() {
    }

    /**
     * 玩家丢出物品的瞬间回调（服务端）。祭品一被抛出就锁定拾取并纳入逐 tick 监视——
     * 这是站在池边「丢一件吸回一件」的根治点，旧版靠周期扫描永远抢不过 1 秒拾取。
     */
    public static void onToss(Player player, ItemEntity item) {
        Level level = item.level();
        if (level.isClientSide || item.isRemoved()) return;
        if (!REQUIRED_ITEMS.contains(canonical(item.getItem()))) return;
        long now = level.getGameTime();
        if (WATCHED.size() < WATCH_CAPACITY) {
            WATCHED.put(item.getId(), new WatchedToss(item, level, now + WATCH_WINDOW));
        }
        // 抛出即保护：物品飞行约需 10~40 tick，期间若监视表因容量满而未登记，
        // 这层拾取延迟也能保证它至少在池中停留到下一次周期扫描。
        item.setPickUpDelay((int) WATCH_WINDOW);
    }

    /**
     * 服务端每 tick 入口：先推进抛出监视（即时通道），再按排程跑周期扫描（兜底通道），
     * 最后每 tick 结算进度——第 8 件祭品落水后 1 tick 内完成仪式。
     */
    public static void tick(ServerLevel level) {
        long now = level.getGameTime();
        Set<String> touched = new HashSet<>();

        tickWatches(level, now, touched);
        ambientScan(level, now, touched);
        settle(level, now, touched);
    }

    /** 抛出监视：祭品实体逐 tick 检查，落水当 tick 即记住并持续锁定拾取。 */
    private static void tickWatches(ServerLevel level, long now, Set<String> touched) {
        if (WATCHED.isEmpty()) return;
        Iterator<Map.Entry<Integer, WatchedToss>> it = WATCHED.entrySet().iterator();
        while (it.hasNext()) {
            WatchedToss watch = it.next().getValue();
            ItemEntity item = watch.item;
            if (item.isRemoved() || item.level() != watch.ownerLevel) {
                it.remove();
                continue;
            }
            if (watch.ownerLevel != level) {
                // 属于另一维度：等它的 tick 处理；服务器实例已换说明是旧会话残留，直接清掉，
                // 避免跨存档的过期时间戳永远对不上。
                if (watch.ownerLevel.getServer() != level.getServer()) it.remove();
                continue;
            }
            if (now >= watch.expireTick) {
                // 监视到期时若仍合法浮在池中，续一段兜底扫描一定能接管的拾取锁。
                if (inWater(item) && findPool(level, item.blockPosition()) != null) {
                    item.setPickUpDelay(SCAN_INTERVAL_IDLE + SCAN_INTERVAL);
                }
                it.remove();
                continue;
            }
            if (!inWater(item)) continue;
            PoolArea pool = findPool(level, item.blockPosition());
            if (pool == null || onCooldown(level, pool.origin())) continue;
            String key = cooldownKey(level, pool.origin());
            touched.add(key);
            OFFERINGS.computeIfAbsent(key, k -> new OfferingMemory(pool))
                    .remember(canonical(item.getItem()), now);
            // 每 tick 续锁：玩家站在池边也无法把刚投下的祭品吸回，直到结算或离池。
            item.setPickUpDelay(OFFERING_PICKUP_LOCK);
        }
    }

    /**
     * 周期扫描兜底：接管非抛出途径入水的祭品，并持续为池中祭品续拾取锁。
     * 三层守卫不变：空扫退避、玩家半径内检索并按实体 id 去重、水池判定按脚下方块记忆化。
     */
    private static void ambientScan(ServerLevel level, long now, Set<String> touched) {
        ScanSchedule schedule = SCHEDULES.computeIfAbsent(level.dimension(), k -> new ScanSchedule(now));
        if (now < schedule.nextScanTick) return;

        // 守卫 0：无玩家在线时不做实体扫描（祭品必须由玩家投放），并退避到下个粗扫点。
        if (level.players().isEmpty()) {
            schedule.backoff(now);
            return;
        }

        pruneCooldown(level);

        // 守卫 2：只检索每位玩家周边半径内的祭品，跨玩家按实体 id 去重。
        Map<Integer, ItemEntity> candidates = new HashMap<>();
        for (ServerPlayer player : level.players()) {
            AABB box = player.getBoundingBox().inflate(PLAYER_SCAN_RADIUS);
            for (ItemEntity entity : level.getEntitiesOfClass(ItemEntity.class, box,
                    e -> REQUIRED_ITEMS.contains(canonical(e.getItem())))) {
                candidates.putIfAbsent(entity.getId(), entity);
            }
        }
        if (candidates.isEmpty()) {
            schedule.backoff(now);
            return;
        }
        schedule.resume(now);

        // 守卫 3：同格掉落的多个物品共享一次水池判定。
        Map<BlockPos, PoolArea> poolByFeet = new HashMap<>();
        for (ItemEntity entity : candidates.values()) {
            if (!inWater(entity)) continue;
            BlockPos feet = entity.blockPosition();
            PoolArea pool = poolByFeet.get(feet);
            if (pool == null && !poolByFeet.containsKey(feet)) {
                pool = findPool(level, feet);
                if (pool != null) poolByFeet.put(feet, pool);
            }
            if (pool == null) continue;
            final PoolArea found = pool;
            String key = cooldownKey(level, found.origin());
            if (onCooldown(level, found.origin())) continue;
            touched.add(key);
            OFFERINGS.computeIfAbsent(key, k -> new OfferingMemory(found))
                    .remember(canonical(entity.getItem()), now);
            entity.setPickUpDelay(OFFERING_PICKUP_LOCK);
        }
    }

    /** 每 tick 结算：窗口内凑齐八种即施法；进度变化时向池边玩家播报。 */
    private static void settle(ServerLevel level, long now, Set<String> touched) {
        Iterator<Map.Entry<String, OfferingMemory>> it = OFFERINGS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, OfferingMemory> entry = it.next();
            OfferingMemory memory = entry.getValue();
            int count = memory.prune(now, OFFERING_WINDOW);
            if (count == 0) {
                it.remove();
                continue;
            }
            if (memory.complete()) {
                performRitual(level, memory.pool);
                RECENT_POOLS.put(entry.getKey(), now);
                it.remove();
                continue;
            }
            // 只有本 tick 确实有祭品落进/驻留在这口水池里才播报，避免对早已离开的旧池子刷屏。
            if (touched.contains(entry.getKey())) memory.announce(level, count, now);
        }
    }

    /** 刚抛出的祭品监视项：实体引用 + 所属维度 + 监视到期 tick（以所属维度 gameTime 计）。 */
    private static final class WatchedToss {
        private final ItemEntity item;
        private final Level ownerLevel;
        private final long expireTick;

        private WatchedToss(ItemEntity item, Level ownerLevel, long expireTick) {
            this.item = item;
            this.ownerLevel = ownerLevel;
            this.expireTick = expireTick;
        }
    }

    /** 一合法水池：西北角水方块 + 水面矩形宽（x 向格数）深（z 向格数）。 */
    private record PoolArea(BlockPos origin, int width, int depth) {
        double centerX() {
            return origin.getX() + width / 2.0D;
        }

        double centerZ() {
            return origin.getZ() + depth / 2.0D;
        }
    }

    /** 每维度扫描排程：命中时维持快速间隔，空扫时退避到粗间隔。 */
    private static final class ScanSchedule {
        private long nextScanTick;

        private ScanSchedule(long firstScanTick) {
            this.nextScanTick = firstScanTick;
        }

        /** 发现候选祭品：恢复快速扫描，保证仪式结算无感知延迟。 */
        private void resume(long now) {
            nextScanTick = now + SCAN_INTERVAL;
        }

        /** 空扫：推迟到粗间隔之后，idle 维度近乎零开销。 */
        private void backoff(long now) {
            nextScanTick = now + SCAN_INTERVAL_IDLE;
        }
    }

    /**
     * 单个水池的祭品记忆：记录窗口内见过哪些祭品种类，以及最近一次播报时的进度。
     * 祭品的实体可能被玩家捡走或掉出水面，但只要在窗口内投过就算数，因此不会因为
     * 「扫描时恰好少一种」而前功尽弃。
     */
    private static final class OfferingMemory {
        private final PoolArea pool;
        private final Map<Item, Long> seen = new HashMap<>();
        private int announcedCount = -1;
        private long lastAnnounceTick = -PROGRESS_INTERVAL;

        private OfferingMemory(PoolArea pool) {
            this.pool = pool;
        }

        private void remember(Item item, long now) {
            seen.put(item, now);
        }

        /** 丢掉过期祭品，返回窗口内仍有效的祭品种类数。 */
        private int prune(long now, long window) {
            seen.entrySet().removeIf(e -> now - e.getValue() > window);
            return seen.size();
        }

        private boolean complete() {
            return seen.keySet().containsAll(REQUIRED_ITEMS);
        }

        /** 进度变化时节流播报「已献上 x/8，尚缺哪些」，让玩家知道模组已经认出水池。 */
        private void announce(ServerLevel level, int count, long now) {
            if (count == announcedCount) return;
            if (now - lastAnnounceTick < PROGRESS_INTERVAL) return;
            announcedCount = count;
            lastAnnounceTick = now;
            MutableComponent message = Component.literal("仪式祭品 " + count + "/" + REQUIRED_ITEMS.size() + "，尚缺：");
            boolean first = true;
            for (Item item : REQUIRED_ORDER) {
                if (seen.containsKey(item)) continue;
                if (!first) message.append(Component.literal("、"));
                message.append(new ItemStack(item).getHoverName());
                first = false;
            }
            double cx = pool.centerX();
            double cz = pool.centerZ();
            for (ServerPlayer player : level.players()) {
                if (player.distanceToSqr(cx, pool.origin().getY(), cz) <= PROGRESS_RADIUS * PROGRESS_RADIUS) {
                    player.displayClientMessage(message, true);
                }
            }
        }
    }

    /**
     * 物品是否处于水中：完全入水、沉底、或贴着水面漂浮（脚下/脚下两格是水）都算。
     * 漂浮在水面时 blockPosition 往往是水面之上的空气，这是旧版漏判的根源。
     */
    private static boolean inWater(ItemEntity entity) {
        if (entity.isInWater() || entity.isUnderWater()) return true;
        BlockPos base = entity.blockPosition();
        return isWaterFluid(entity.level(), base)
                || isWaterFluid(entity.level(), base.below())
                || isWaterFluid(entity.level(), base.below(2));
    }

    private static boolean isWaterFluid(Level level, BlockPos pos) {
        return level.getFluidState(pos).is(FluidTags.WATER);
    }

    /** 把「黑色晶体/至纯源石/张师块」的多种注册物品归一到同一判断键，避免重复注册导致识别失败。 */
    private static Item canonical(ItemStack stack) {
        if (stack.getItem() instanceof BlockItem blockItem) {
            if (blockItem.getBlock() == GeneratedMod.METEOR_BLOCK.get()) {
                return GeneratedMod.METEOR_BLOCK_ITEM.get();
            }
            if (blockItem.getBlock() == GeneratedMod.BLACK_CRYSTAL.get()) {
                return GeneratedMod.BLACK_CRYSTAL_ITEM.get();
            }
            if (blockItem.getBlock() == GeneratedMod.ZHANGSHI_BLOCK.get()) {
                return GeneratedMod.ZHANGSHI_BLOCK_ITEM.get();
            }
        }
        return stack.getItem();
    }

    /**
     * 给定一块落水方块，判断它是否属于某个合法水池，返回水池矩形。物品可能浮在水面
     * 之上，候选高度取「脚下」以及向下两格——与 {@link #inWater} 认可的三种漂浮状态
     * 一一对应，否则祭品会被 {@code inWater} 判为落水、却被这里返回 null 而静默漏掉。
     */
    private static PoolArea findPool(ServerLevel level, BlockPos feet) {
        for (int y : new int[]{feet.getY(), feet.getY() - 1, feet.getY() - 2}) {
            PoolArea pool = findPoolAt(level, feet.getX(), y, feet.getZ());
            if (pool != null) return pool;
        }
        return null;
    }

    /**
     * 以 (x,y,z) 为种子洪泛连通水面：水面必须恰好铺满一个矩形（≤{@link #MAX_POOL_AREA}
     * 格），且矩形四周整圈相邻方块都是张师块（逐块允许水面同层/上方一格/上方两格），
     * 才算合法水池，返回其西北角与尺寸。不再要求恰好 2×2——手册建法照常命中，
     * 1×2、3×3 乃至更大的封闭矩形池同样能认出来。
     */
    private static PoolArea findPoolAt(ServerLevel level, int x, int y, int z) {
        BlockPos seed = new BlockPos(x, y, z);
        if (!isWater(level, seed)) return null;
        List<BlockPos> cells = new ArrayList<>();
        Set<Long> seen = new HashSet<>();
        Deque<BlockPos> queue = new ArrayDeque<>();
        seen.add(seed.asLong());
        cells.add(seed);
        queue.add(seed);
        int minX = x, maxX = x, minZ = z, maxZ = z;
        while (!queue.isEmpty()) {
            BlockPos cur = queue.poll();
            for (Direction dir : Direction.Plane.HORIZONTAL) {
                BlockPos next = cur.relative(dir);
                if (!seen.add(next.asLong())) continue;
                if (isWater(level, next)) {
                    cells.add(next);
                    if (cells.size() > MAX_POOL_AREA) return null;
                    queue.add(next);
                }
            }
        }
        for (BlockPos cell : cells) {
            if (cell.getX() < minX) minX = cell.getX();
            if (cell.getX() > maxX) maxX = cell.getX();
            if (cell.getZ() < minZ) minZ = cell.getZ();
            if (cell.getZ() > maxZ) maxZ = cell.getZ();
        }
        int width = maxX - minX + 1;
        int depth = maxZ - minZ + 1;
        // 水面必须恰好铺满包围盒：有缺角/异形就不是刻意修的水池。
        if (cells.size() != width * depth || width * depth > MAX_POOL_AREA) return null;
        for (int xi = minX - 1; xi <= maxX + 1; xi++) {
            for (int zi = minZ - 1; zi <= maxZ + 1; zi++) {
                if (xi >= minX && xi <= maxX && zi >= minZ && zi <= maxZ) continue;
                if (!isZhangshiRingCell(level, new BlockPos(xi, y, zi))) return null;
            }
        }
        return new PoolArea(new BlockPos(minX, y, minZ), width, depth);
    }

    /** 单个池沿位置：水面同层、水面上方一格或上方两格任意一处是张师块即可。 */
    private static boolean isZhangshiRingCell(ServerLevel level, BlockPos pos) {
        return isZhangshi(level, pos)
                || isZhangshi(level, pos.above())
                || isZhangshi(level, pos.above(2));
    }

    private static boolean isWater(ServerLevel level, BlockPos pos) {
        return level.getBlockState(pos).is(Blocks.WATER);
    }

    private static boolean isZhangshi(ServerLevel level, BlockPos pos) {
        return level.getBlockState(pos).is(GeneratedMod.ZHANGSHI_BLOCK.get());
    }

    private static void performRitual(ServerLevel level, PoolArea pool) {
        BlockPos origin = pool.origin();
        // 收走水池里的全部祭品（保留可能仍在池中未拾取的「表里之间」）。
        AABB poolArea = new AABB(origin.getX() - 0.5D, origin.getY() - 0.5D, origin.getZ() - 0.5D,
                origin.getX() + pool.width() + 0.5D, origin.getY() + 2.5D,
                origin.getZ() + pool.depth() + 0.5D);
        for (ItemEntity entity : level.getEntitiesOfClass(ItemEntity.class, poolArea)) {
            if (entity.getItem().is(GeneratedMod.BIAOLIZHIJIAN.get())) continue;
            entity.discard();
        }

        double cx = pool.centerX();
        double cz = pool.centerZ();

        // 仪式完成的信号：以传送音效作为完成提示，水池中心响起传送音。
        level.playSound(null, cx, origin.getY(), cz, SoundEvents.CHORUS_FRUIT_TELEPORT,
                SoundSource.PLAYERS, 1.0F, 1.0F);

        // 在水池中心凝结出「表里之间」：落点放到水面之上并延长存续，
        // 实体放置失败（如区块状态异常）时兜底直接交给最近玩家，绝不静默丢失。
        ItemStack rewardStack = new ItemStack(GeneratedMod.BIAOLIZHIJIAN.get());
        ItemEntity reward = new ItemEntity(level, cx, origin.getY() + 1.15D, cz, rewardStack.copy());
        reward.setPickUpDelay(30);
        reward.setExtendedLifetime();
        if (!level.addFreshEntity(reward)) {
            ServerPlayer nearest = null;
            double nearestDistSqr = 64.0D * 64.0D;
            for (ServerPlayer player : level.players()) {
                double distSqr = player.distanceToSqr(cx, origin.getY() + 1.0D, cz);
                if (distSqr < nearestDistSqr) {
                    nearestDistSqr = distSqr;
                    nearest = player;
                }
            }
            if (nearest != null) {
                if (!nearest.getInventory().add(rewardStack)) {
                    nearest.drop(rewardStack, false);
                }
                nearest.displayClientMessage(
                        Component.literal("仪式完成：「表里之间」已放入你的背包"), true);
            }
        }

        // 广而告之本维度玩家。
        Component message = Component.literal("仪式完成：时空传送之声响起，「表里之间」已在水池中凝聚");
        for (ServerPlayer player : level.players()) {
            player.displayClientMessage(message, true);
        }
    }

    private static String cooldownKey(ServerLevel level, BlockPos origin) {
        return level.dimension().location() + "@" + origin.asLong();
    }

    private static boolean onCooldown(ServerLevel level, BlockPos origin) {
        Long until = RECENT_POOLS.get(cooldownKey(level, origin));
        if (until == null) return false;
        long now = level.getGameTime();
        // now < until 说明这条是重载前旧会话留下的（gameTime 已回退），一律作废。
        return now >= until && now - until < POOL_COOLDOWN;
    }

    /** 冷却表顺带清账，避免跨存档常驻膨胀；重载后 gameTime 回退时旧条目直接清除。 */
    private static void pruneCooldown(ServerLevel level) {
        long now = level.getGameTime();
        Iterator<Map.Entry<String, Long>> it = RECENT_POOLS.entrySet().iterator();
        while (it.hasNext()) {
            long until = it.next().getValue();
            if (now < until || now - until >= POOL_COOLDOWN) it.remove();
        }
    }
}
