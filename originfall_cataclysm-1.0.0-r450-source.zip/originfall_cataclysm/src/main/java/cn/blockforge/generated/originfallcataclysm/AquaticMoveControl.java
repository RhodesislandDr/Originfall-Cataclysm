package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.control.SmoothSwimmingMoveControl;

/** 陆地保持原版移动，进入水中后切换为可沿三个轴游动的控制器。 */
public final class AquaticMoveControl extends MoveControl {
    private final SmoothSwimmingMoveControl swimmingControl;

    public AquaticMoveControl(Mob mob) {
        super(mob);
        // 水中速度倍率：SmoothSwimmingMoveControl 的水平速度 = speedModifier × MOVEMENT_SPEED × 该倍率。
        // 源石魔像 MOVEMENT_SPEED≈0.25，0.02 会让它在水里几乎冻住（速度≈0.005），
        // 显然异常；这里把水中速度提到约为陆地速度的两倍，使其能正常追击水中目标并游泳。
        swimmingControl = new SmoothSwimmingMoveControl(mob, 85, 10, 2.0F, 1.0F, true);
    }

    @Override
    public void setWantedPosition(double x, double y, double z, double speed) {
        super.setWantedPosition(x, y, z, speed);
        swimmingControl.setWantedPosition(x, y, z, speed);
    }

    @Override
    public void strafe(float forwards, float right) {
        super.strafe(forwards, right);
        swimmingControl.strafe(forwards, right);
    }

    @Override
    public void tick() {
        if (mob.isInWater()) {
            swimmingControl.tick();
        } else {
            super.tick();
        }
    }
}
