package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * 天堂支点：以玩家提供的水晶剑图片作为贴图的手持剑。
 * 数值与原版下界合金剑一致（伤害 7、攻速 1.6），但拥有无限耐久：永不损耗、不再显示耐久条。
 * 附魔兼容与原版剑一致（锋利、亡灵杀手、节肢杀手、击退、火焰附加、抢夺、横扫之刃等）。
 */
public final class TiantangzhidianSwordItem extends SwordItem {
    public static final String ITEM_ID = "originfall_cataclysm:tiantangzhidian";

    /** 下界合金级剑，但耐久设为极大值；实际由 canBeDepleted()==false 保证无限耐久。 */
    private static final Tier TIANTANG_TIER = new Tier() {
        @Override
        public int getUses() {
            return Integer.MAX_VALUE;
        }

        @Override
        public float getSpeed() {
            return 9.0F;
        }

        @Override
        public float getAttackDamageBonus() {
            return 4.0F;
        }

        @Override
        public int getLevel() {
            return 4;
        }

        @Override
        public int getEnchantmentValue() {
            return 15;
        }

        @Override
        public Ingredient getRepairIngredient() {
            return Ingredient.of(Items.NETHERITE_INGOT);
        }
    };

    public TiantangzhidianSwordItem() {
        // 与原版下界合金剑相同的伤害/攻速修正：总攻击力 7，攻击速度 1.6。
        super(TIANTANG_TIER, 3, -2.4F,
                new net.minecraft.world.item.Item.Properties().stacksTo(1).fireResistant());
    }

    /** 无限耐久：永不损耗，也不再显示耐久条。 */
    @Override
    public boolean canBeDepleted() {
        return false;
    }

    @Override
    public boolean isBarVisible(ItemStack stack) {
        return false;
    }

    /** 附魔兼容与原版剑一致：允许所有适用于剑的附魔。 */
    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack, Enchantment enchantment) {
        return enchantment.category.canEnchant(stack.getItem());
    }

    @Override
    public boolean isEnchantable(ItemStack stack) {
        return true;
    }

    /** 能力名（加粗着色）+ 说明（逐行断行，原版提示栏不会自动换行，行宽控制在24字以内）。 */
    private static Component abilityName(String text, ChatFormatting color) {
        return Component.literal(text).withStyle(color, ChatFormatting.BOLD);
    }

    private static Component detail(String text) {
        return Component.literal(text).withStyle(ChatFormatting.GRAY);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("以天堂为支点，撬动整个世界。").withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.literal("无限耐久 · 水晶质感 · 剑身尺寸为原版剑的1.2倍")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("─────── 天堂支点 · 权能 ───────").withStyle(ChatFormatting.DARK_GRAY));

        // 两段伤害
        tooltip.add(abilityName("两段伤害", ChatFormatting.YELLOW));
        tooltip.add(detail("每次攻击造成两段伤害："));
        tooltip.add(detail("第一段=使用者最大生命值的25%"));
        tooltip.add(detail("第二段=原有攻击数值"));

        // 极•源石权柄•阴
        tooltip.add(abilityName("极•源石权柄•阴", ChatFormatting.LIGHT_PURPLE));
        tooltip.add(detail("攻击造成伤害的50%恢复自身血量"));
        tooltip.add(detail("半径32格内死亡的生物，按死前最大"));
        tooltip.add(detail("生命值的40%恢复自身血量"));
        tooltip.add(detail("血量已满时，溢出部分转化为最大"));
        tooltip.add(detail("生命值上限；本武器携带时生效，"));
        tooltip.add(detail("丢弃或掉落后清除加成"));

        // 流放虚空
        tooltip.add(abilityName("流放虚空", ChatFormatting.DARK_AQUA));
        tooltip.add(detail("每次攻击有3.25%概率将敌人流放"));
        tooltip.add(detail("至虚空，时长10~60秒等概率随机"));
        tooltip.add(detail("期间每秒受使用者最大生命值1%的伤害"));
        tooltip.add(detail("同一目标30秒内置冷却，期间目标"));
        tooltip.add(detail("携带阴标记（阳标记改由如我所见授予）"));

        // 源石之始
        tooltip.add(abilityName("源石之始", ChatFormatting.RED));
        tooltip.add(detail("每次造成伤害32.5%概率削减目标"));
        tooltip.add(detail("最大生命值上限（削减量=伤害×32.5%，"));
        tooltip.add(detail("目标带阴标记时提升50%）"));
        tooltip.add(detail("削减后再判0.325%源石之始：造成"));
        tooltip.add(detail("敌方100%最大生命上限的真实伤害"));
        tooltip.add(detail("玩家目标削减量达到其现有血量时立"));
        tooltip.add(detail("刻击杀，复活后生命上限锁定为1"));

        // 咫尺天堂
        tooltip.add(abilityName("咫尺天堂", ChatFormatting.GOLD));
        tooltip.add(detail("致命伤害时拒绝死亡并保留血量，"));
        tooltip.add(detail("获得10秒无敌，随后现有最大生命"));
        tooltip.add(detail("值降低50%"));
        tooltip.add(detail("冷却以1000血为基准32.5秒，血量每"));
        tooltip.add(detail("翻十倍（一层）降低初始时间20%，最高降"));
        tooltip.add(detail("低80%"));

        // 无下限•内化宇宙•阴
        tooltip.add(abilityName("无下限•内化宇宙•阴", ChatFormatting.DARK_PURPLE));
        tooltip.add(detail("自身持有阳标记（来自如我所见）且"));
        tooltip.add(detail("对目标施加阴标记（流放虚空）时："));
        tooltip.add(detail("周围所有带阴阳标记的生物"));
        tooltip.add(detail("被拉入虚空10秒"));
        tooltip.add(detail("期间每秒判定：5%即死，其余在八档"));
        tooltip.add(detail("生命增减中平分；免死效果无效"));
        tooltip.add(detail("同时触发本流放时，原本效果推迟到"));
        tooltip.add(detail("10秒判定归来后兑现；造成者死亡则"));
        tooltip.add(detail("不触发，目标在虚空内死亡无法复活"));

        // 无下限•内化宇宙•开放
        tooltip.add(abilityName("无下限•内化宇宙•开放", ChatFormatting.DARK_PURPLE));
        tooltip.add(detail("（独立机制）任一生物同时持有阴阳两"));
        tooltip.add(detail("枚印记即触发，判定同内化宇宙"));

        super.appendHoverText(stack, level, tooltip, flag);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
