package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.DomainSphereEntity;
import cn.blockforge.generated.originfallcataclysm.GeneratedMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

/**
 * 领域结界球体的客户端渲染：把一个空心、无厚度的半透明球面画在领域圆心上。
 * 球面随领域激活从圆心向外扩张到领域半径，然后在领域存在期间保持。
 * 「预言家」博士的球体为白金色，「女祭司」普瑞赛斯的球体为暗紫色。
 *
 * 渲染用 entityTranslucent（半透明实体，配合满亮光照，不受昼夜光照影响，渲染成结界光幕），
 * 并叠加一层简单的菲涅尔边缘亮化，让球面外缘更明显、内部更通透，读起来是“空心球壳”。
 */
public final class DomainSphereRenderer extends EntityRenderer<DomainSphereEntity> {

    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "textures/entity/domain_sphere.png");

    // 球面网格密度：纬线分段 × 经线分段。越大越圆滑。
    private static final int LAT = 18;
    private static final int LON = 32;

    // 「预言家」博士领域球体：白金色。
    private static final float PROPHET_R = 1.00F;
    private static final float PROPHET_G = 0.93F;
    private static final float PROPHET_B = 0.62F;
    // 「女祭司」普瑞赛斯领域球体：暗紫色。
    private static final float PRIESTESS_R = 0.52F;
    private static final float PRIESTESS_G = 0.16F;
    private static final float PRIESTESS_B = 0.78F;

    public DomainSphereRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0F;
    }

    @Override
    public void render(DomainSphereEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        float radius = entity.getCurrentRadius();
        if (radius <= 0.001F) return;

        float r;
        float g;
        float b;
        if (entity.getSphereType() == DomainSphereEntity.TYPE_PRIESTESS) {
            r = PRIESTESS_R;
            g = PRIESTESS_G;
            b = PRIESTESS_B;
        } else {
            r = PROPHET_R;
            g = PROPHET_G;
            b = PROPHET_B;
        }

        // 得到相机世界坐标，用于菲涅尔边缘亮化（越靠近球面切向的地方越亮）。
        Vec3 cam = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
        double ex = entity.getX();
        double ey = entity.getY();
        double ez = entity.getZ();

        VertexConsumer consumer = buffer.getBuffer(RenderType.entityTranslucent(TEXTURE));
        PoseStack.Pose pose = poseStack.last();
        // 结界光幕使用满亮光照，避免昼夜光照把它压暗；颜色由顶点颜色决定。
        renderSphere(consumer, pose, radius, r, g, b, cam, ex, ey, ez, LightTexture.FULL_BRIGHT);

        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
    }

    /** 生成一个 UV 球面的全部 QUADS，并逐顶点写入颜色（含菲涅尔边缘亮化）。 */
    private void renderSphere(VertexConsumer consumer, PoseStack.Pose pose, float radius,
                              float r, float g, float b, Vec3 cam, double ex, double ey, double ez,
                              int packedLight) {
        final double baseAlpha = 0.16D;
        final double rimBoost = 0.30D;

        for (int lat = 0; lat < LAT; lat++) {
            double theta0 = Math.PI * lat / LAT;
            double theta1 = Math.PI * (lat + 1) / LAT;
            double y0 = Math.cos(theta0);
            double y1 = Math.cos(theta1);
            double r0 = Math.sin(theta0);
            double r1 = Math.sin(theta1);
            for (int lon = 0; lon < LON; lon++) {
                double phi0 = 2.0D * Math.PI * lon / LON;
                double phi1 = 2.0D * Math.PI * (lon + 1) / LON;

                // 四个角（逆时针，从球外看）。
                double c00x = r0 * Math.cos(phi0);
                double c00y = y0;
                double c00z = r0 * Math.sin(phi0);
                double c01x = r0 * Math.cos(phi1);
                double c01y = y0;
                double c01z = r0 * Math.sin(phi1);
                double c11x = r1 * Math.cos(phi1);
                double c11y = y1;
                double c11z = r1 * Math.sin(phi1);
                double c10x = r1 * Math.cos(phi0);
                double c10y = y1;
                double c10z = r1 * Math.sin(phi0);

                double u0 = (double) lon / LON;
                double u1 = (double) (lon + 1) / LON;
                double v0 = (double) lat / LAT;
                double v1 = (double) (lat + 1) / LAT;

                vertex(consumer, pose, radius, c00x, c00y, c00z, u0, v0, r, g, b, cam, ex, ey, ez, baseAlpha, rimBoost, packedLight);
                vertex(consumer, pose, radius, c01x, c01y, c01z, u1, v0, r, g, b, cam, ex, ey, ez, baseAlpha, rimBoost, packedLight);
                vertex(consumer, pose, radius, c11x, c11y, c11z, u1, v1, r, g, b, cam, ex, ey, ez, baseAlpha, rimBoost, packedLight);
                vertex(consumer, pose, radius, c10x, c10y, c10z, u0, v1, r, g, b, cam, ex, ey, ez, baseAlpha, rimBoost, packedLight);
            }
        }
    }

    private void vertex(VertexConsumer consumer, PoseStack.Pose pose, double radius,
                        double nx, double ny, double nz, double u, double v,
                        float r, float g, float b, Vec3 cam, double ex, double ey, double ez,
                        double baseAlpha, double rimBoost, int packedLight) {
        double px = nx * radius;
        double py = ny * radius;
        double pz = nz * radius;

        // 外法线即单位方向。
        double wx = nx;
        double wy = ny;
        double wz = nz;
        // 顶点到相机的方向（世界系）。
        double dx = cam.x - (ex + px);
        double dy = cam.y - (ey + py);
        double dz = cam.z - (ez + pz);
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double fresnel = 0.0D;
        if (len > 1.0E-4D) {
            double dot = (wx * dx + wy * dy + wz * dz) / len;
            double grazing = 1.0D - Math.max(0.0D, dot);
            fresnel = grazing * grazing;
        }
        double alpha = baseAlpha + rimBoost * fresnel;
        if (alpha > 1.0D) alpha = 1.0D;

        consumer.vertex(pose.pose(), (float) px, (float) py, (float) pz)
                .color(r, g, b, (float) alpha)
                .uv((float) u, (float) v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(packedLight)
                .normal((float) wx, (float) wy, (float) wz)
                .endVertex();
    }

    @Override
    public ResourceLocation getTextureLocation(DomainSphereEntity entity) {
        return TEXTURE;
    }
}
