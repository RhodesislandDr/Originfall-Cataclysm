package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

/** 被源石天灾同化后的信使形态；仅使用弓、弩或三叉戟进行远程攻击。 */
public final class CalamityMessenger extends CalamityMob {
    public CalamityMessenger(EntityType<? extends CalamityMessenger> type, Level level) {
        super(type, level);
        moveControl = new FlyingMoveControl(this, 20, true);
        setNoGravity(true);
    }

    public static net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder createAttributes() {
        return CalamityMob.createAttributes(20.0D, 0.0D, CalamityLogic.CALAMITY_MESSENGER_TARGET_RADIUS)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.FLYING_SPEED, 0.6D);
    }

    /** 将原生飞行生物替换为信使，并保留同化后的属性快照。 */
    public static CalamityMessenger convertFrom(Mob original, double health, double currentHealth,
                                                  double shield, double attack) {
        Mob convertedMob = original.convertTo(GeneratedMod.CALAMITY_MESSENGER.get(), true);
        if (!(convertedMob instanceof CalamityMessenger converted)) return null;
        converted.getPersistentData().putBoolean("OriginFallCalamityHostile", true);
        converted.setOwnerUUID(null);
        converted.setTame(false);
        converted.initializeConvertedStats(health, currentHealth, shield, attack);
        converted.clearEquipment();
        converted.randomizeEquipment();
        // 随机装备护甲后重新计算基础护盾，避免把装备护甲重复计入转化快照。
        converted.setBaseShield(Math.max(0.0D, shield - converted.getArmorValue()));
        converted.resetShield();
        converted.setPersistenceRequired();
        converted.setNoGravity(true);
        converted.setTarget(null);
        return converted;
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation navigation = new FlyingPathNavigation(this, level);
        navigation.setCanOpenDoors(false);
        navigation.setCanPassDoors(false);
        return navigation;
    }

    @Override
    protected double followRange() {
        return CalamityLogic.CALAMITY_MESSENGER_TARGET_RADIUS;
    }

    @Override
    protected boolean canTeleportAcrossDimensions() {
        return false;
    }

    @Override
    protected boolean shouldFollowOwner() {
        return false;
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new AdaptiveCombatGoal(this, 1.15D));
        goalSelector.addGoal(7, new WaterAvoidingRandomFlyingGoal(this, 0.9D));
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 12.0F));
        goalSelector.addGoal(9, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal<>(
                this, LivingEntity.class, 10, true, false, this::canAttack));
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        return target != this && CalamityLogic.canConvertedHostileAttack(this, target);
    }

    @Override
    public boolean isAlliedTo(net.minecraft.world.entity.Entity other) {
        return other instanceof LivingEntity living && CalamityLogic.isFactionAlly(this, living)
                || super.isAlliedTo(other);
    }

    @Override
    protected void serverAbilityTick(ServerLevel level) {
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && (!getMainHandItem().is(Items.BOW)
                && !getMainHandItem().is(Items.CROSSBOW))) {
            getPersistentData().remove("OriginFallEquipmentAssigned");
            AssimilationEquipment.assign(this);
        }
    }

    @Override
    public void travel(net.minecraft.world.phys.Vec3 travelVector) {
        if (isNoGravity()) setNoGravity(true);
        super.travel(travelVector);
    }

    /** 信使是空中单位，摔落不应转化为任何伤害。 */
    @Override
    public boolean causeFallDamage(float fallDistance, float damageMultiplier, DamageSource source) {
        return false;
    }

    @Override
    protected void onCalamityDeath(ServerLevel level, LivingEntity killer, net.minecraft.nbt.CompoundTag snapshot) {
        CalamityLogic.summonConvertedDeathMeteors(level, this, killer);
    }
}
