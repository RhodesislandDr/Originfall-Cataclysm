package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** 独立的转化敌对生物，保留被转化生物的生命、护盾和攻击属性。 */
public final class EndWalker extends CalamityMob {
    public EndWalker(EntityType<? extends EndWalker> type, Level level) {
        super(type, level);
    }

    public static net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder createAttributes() {
        return CalamityMob.createAttributes(20.0D, 0.0D, 32.0D)
                .add(Attributes.FLYING_SPEED, 0.6D);
    }

    public static EndWalker convertFrom(Mob original) {
        double health = original.getMaxHealth();
        double currentHealth = original.getHealth();
        double shield = original.getArmorValue() + original.getPersistentData().getDouble("CalamityCurrentShield");
        double attack = original.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE);
        return convertFrom(original, health, currentHealth, shield, attack);
    }

    /** 使用伤害前快照完成转化，适用于陨石已经判定击杀原生生物的场景。 */
    public static EndWalker convertFrom(Mob original, double health, double currentHealth,
                                                    double shield, double attack) {
        Mob convertedMob = original.convertTo(GeneratedMod.END_WALKER.get(), true);
        if (!(convertedMob instanceof EndWalker converted)) return null;
        converted.getPersistentData().putBoolean("OriginFallCalamityHostile", true);
        converted.setOwnerUUID(null);
        converted.setTame(false);
        converted.initializeConvertedStats(health, currentHealth, shield, attack);
        converted.clearEquipment();
        converted.randomizeEquipment();
        converted.setBaseShield(Math.max(0.0D, shield - converted.getArmorValue()));
        converted.resetShield();
        converted.setPersistenceRequired();
        converted.setTarget(null);
        return converted;
    }

    @Override
    protected double followRange() {
        return 16.0D;
    }

    @Override
    protected boolean canTeleportAcrossDimensions() {
        return false;
    }

    @Override
    protected boolean shouldFollowOwner() {
        return false;
    }

    @Override
    protected void registerGoals() {
        // 转化实体与两种原生天灾生物保持一致：无目标时从水下主动回到水面。
        goalSelector.addGoal(0, new AquaticSurfaceGoal(this));
        goalSelector.addGoal(3, new AdaptiveCombatGoal(this, 1.05D));
        goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 12.0F));
        goalSelector.addGoal(9, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal<>(
                this, LivingEntity.class, 10, true, false, this::canAttack));
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        return target != this && CalamityLogic.canConvertedHostileAttack(this, target);
    }

    @Override
    public boolean isAlliedTo(net.minecraft.world.entity.Entity other) {
        return other instanceof LivingEntity living && CalamityLogic.isFactionAlly(this, living)
                || super.isAlliedTo(other);
    }

    @Override
    protected void serverAbilityTick(ServerLevel level) {
    }

    @Override
    protected void onCalamityDeath(ServerLevel level, LivingEntity killer, net.minecraft.nbt.CompoundTag snapshot) {
        CalamityLogic.summonConvertedDeathMeteors(level, this, killer);
    }
}
