package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHealEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * 「女祭司」普瑞赛斯的自身技能：
 * 1. 熵增宇宙：与自身有关的持续时间能力在现有判定后优化 32.5%——持续时间类延长（×1.325），
 *    冷却/周期时间类缩短（÷1.325），覆盖自身领域持续时间与女祭司之眼召唤间隔。
 * 2. 领域展开•矢量偏移：以普瑞赛斯当前位置为圆心展开 64 格领域；全部指向她的近战/远程/实体挤压伤害
 *    随机转移至范围内随机生物，无法转移控制、负面效果和传送效果，3.25% 概率转移失败；领域内自身攻速与
 *    移速 +50%（学会飞行时同时 +50% 飞行速度）；持续 30~90 秒等概率随机；发动者死亡、沉默或离开该区域
 *    结束领域；多领域重叠时领域对抗、转移失败概率提升 10%；受伤前已损失生命值百分比即本次受伤后发动领域
 *    概率；在对话栏输入「领域展开•矢量偏移」可发动；领域结束进入熔断，单次回血超过 6.5% 视为恢复。
 * 3. 女祭司之眼：出现时召唤一次，此后每 10 秒召唤一次；召唤类型包括天灾信使与终焉行者（10 只）、
 *    初生的魔王（8 只）、源石耄耋（6 只）、哈气贤者（4 只）与天灾的王女（2 只），各自按当前普瑞赛斯
 *    数值的指定倍率缩放。
 * 4. 源石强化理论：半径 32 格内每有一个生物死亡自身属性增加 1%；自身或自身机制杀死生物提升 3.25%
 *    （提升幅度已按需求降至原值的 10%）。
 * 5. 天灾学者：每 10 次攻击召唤一颗 10 倍锁定陨石，每 50 次召唤一颗 100 倍，每 100 次召唤一颗 1000 倍，
 *    锁定半径 64 格内敌方生命值最高单位，可横向追踪、可叠加同时触发。
 */
public final class PriestessSkillLogic {

    // ---------------- 数值常量 ----------------
    public static final double ENTROPY_DURATION_AMP = 1.325D;
    public static final double DOMAIN_BASE_RADIUS = 64.0D;
    public static final double DOMAIN_SPEED_BOOST = 0.50D;
    public static final double TRANSFER_FAIL_RATE = 0.0325D;
    public static final double OVERLAP_FAIL_BONUS = 0.10D;
    public static final int DOMAIN_MIN_TICKS = 30 * 20;
    public static final int DOMAIN_SPAN_TICKS = 60 * 20 + 1;
    public static final double FUSED_HEAL_RATIO = 0.065D;
    public static final int EYE_INTERVAL = 10 * 20;
    public static final double STRENGTHEN_RADIUS = 32.0D;
    /** 源石强化理论原始幅度：附近每有 1 个生物死亡 +10%。 */
    private static final double STRENGTHEN_DEATH_GAIN_ORIGINAL = 0.10D;
    /** 源石强化理论原始幅度：自身或自身机制击杀 +32.5%。 */
    private static final double STRENGTHEN_KILL_GAIN_ORIGINAL = 0.325D;
    /** 按需求降为原值的 10%：+1%（统一经 {@link BoostTuning#PERCENT_SCALE} 缩放）。 */
    public static final double STRENGTHEN_DEATH_GAIN = BoostTuning.scaled(STRENGTHEN_DEATH_GAIN_ORIGINAL);
    /** 按需求降为原值的 10%：+3.25%（统一经 {@link BoostTuning#PERCENT_SCALE} 缩放）。 */
    public static final double STRENGTHEN_KILL_GAIN = BoostTuning.scaled(STRENGTHEN_KILL_GAIN_ORIGINAL);
    public static final double SCHOLAR_RADIUS = 64.0D;
    public static final int SCHOLAR_ATTACK_10 = 10;
    public static final int SCHOLAR_ATTACK_50 = 50;
    public static final int SCHOLAR_ATTACK_100 = 100;

    // ---------------- 属性修饰符 UUID ----------------
    private static final UUID BOOST_MOVE_UUID = UUID.fromString("c05a1e2d-3b0d-4a6c-9f10-1a2b3c4d5e01");
    private static final UUID BOOST_FLY_UUID = UUID.fromString("c05a1e2d-3b0d-4a6c-9f10-1a2b3c4d5e02");
    private static final UUID BOOST_ATTACK_SPEED_UUID = UUID.fromString("c05a1e2d-3b0d-4a6c-9f10-1a2b3c4d5e03");

    // ---------------- persistent data 键 ----------------
    private static final String DOMAIN_ACTIVE = "OfcPriestessDomainActive";
    private static final String DOMAIN_UNTIL = "OfcPriestessDomainUntil";
    private static final String DOMAIN_CX = "OfcPriestessDomainCX";
    private static final String DOMAIN_CY = "OfcPriestessDomainCY";
    private static final String DOMAIN_CZ = "OfcPriestessDomainCZ";
    private static final String DOMAIN_RADIUS = "OfcPriestessDomainRadius";
    private static final String DOMAIN_FUSED = "OfcPriestessDomainFused";
    private static final String EYE_INITIAL = "OfcPriestessEyeInitial";
    private static final String EYE_NEXT = "OfcPriestessEyeNext";
    private static final String ATTACK_COUNT = "OfcPriestessAttackCount";
    /** 被女祭司之眼召唤的生物携带「召唤者 UUID」，用于源石强化理论判定“自身或自身机制击杀”。 */
    public static final String SUMMON_BY = "OfcPriestessSummonBy";

    /** 领域触发语。 */
    private static final String DOMAIN_TRIGGER = "领域展开•矢量偏移";

    private static final AABB WORLD_BOUNDS = new AABB(-3.0E7D, -20000.0D, -3.0E7D,
            3.0E7D, 20000.0D, 3.0E7D);

    private static final Attribute[] STRENGTHEN_ATTRIBUTES = {
            Attributes.MAX_HEALTH, Attributes.ATTACK_DAMAGE, Attributes.MOVEMENT_SPEED,
            Attributes.ATTACK_SPEED, Attributes.ARMOR, Attributes.KNOCKBACK_RESISTANCE,
            Attributes.FOLLOW_RANGE, Attributes.FLYING_SPEED
    };

    private PriestessSkillLogic() {
    }

    // ================= 周期入口 =================

    /** 每个服务器 tick 调用：处理所有普瑞赛斯的技能状态。 */
    public static void tick(ServerLevel level) {
        // 性能：原实现每 tick 做一次全维度实体扫描，现改经实体索引直接取本维度在场名单。
        for (Priestess priestess : EntityTrackers.priestesses(level)) {
            if (priestess.isAlive()) tickPriestess(level, priestess);
        }
    }

    private static void tickPriestess(ServerLevel level, Priestess priestess) {
        // 3. 女祭司之眼：出现即召唤，之后每 10 秒召唤。
        tickEyeSummon(level, priestess);
        // 2. 领域存在期间维持发动者自身增速，并处理结束条件。
        tickDomain(level, priestess);
    }

    // ================= 1. 熵增宇宙 =================

    /** 返回被熵增宇宙延长后的持续时间（tick）：持续时间类 ×1.325。
     * 「源石计划进度」需求 1：32.5% 的优化幅度按档位缩放（有效倍率 = 1 + 0.325 × 进度系数）。 */
    public static long entropyExtended(long ticks, net.minecraft.world.level.Level level) {
        return (long) Math.ceil(ticks * OriginiumPlanProgress.boosted(ENTROPY_DURATION_AMP, level));
    }

    /** 返回被熵增宇宙缩短后的冷却/周期时间（tick）：冷却时间类 ÷1.325（幅度同样随进度缩放）。 */
    public static long entropyShortened(long ticks, net.minecraft.world.level.Level level) {
        return (long) Math.ceil(ticks / OriginiumPlanProgress.boosted(ENTROPY_DURATION_AMP, level));
    }

    // ================= 2. 领域展开•矢量偏移 =================

    public static boolean isDomainActive(Priestess priestess) {
        CompoundTag d = priestess.getPersistentData();
        if (!d.getBoolean(DOMAIN_ACTIVE)) return false;
        if (priestess.level() instanceof ServerLevel level) {
            return d.getLong(DOMAIN_UNTIL) > level.getGameTime();
        }
        return true;
    }

    public static boolean isDomainFused(Priestess priestess) {
        return priestess.getPersistentData().getBoolean(DOMAIN_FUSED);
    }

    public static boolean canActivateDomain(Priestess priestess) {
        // 沉默（锚定现实的打断效果）期间领域无法发动。
        return priestess.isAlive() && !isDomainActive(priestess) && !isDomainFused(priestess)
                && !isSilenced(priestess);
    }

    /** 激活领域：以普瑞赛斯当前坐标为圆心，随机抽取 30~90 秒持续（经熵增宇宙判定后延长 32.5%）。 */
    public static boolean activateDomain(Priestess priestess) {
        if (!canActivateDomain(priestess)) return false;
        if (!(priestess.level() instanceof ServerLevel level)) return false;
        long now = level.getGameTime();
        long baseDuration = DOMAIN_MIN_TICKS + level.getRandom().nextInt(DOMAIN_SPAN_TICKS);
        long duration = entropyExtended(baseDuration, level);
        double cx = priestess.getX();
        double cy = priestess.getY();
        double cz = priestess.getZ();
        CompoundTag d = priestess.getPersistentData();
        d.putBoolean(DOMAIN_ACTIVE, true);
        d.putBoolean(DOMAIN_FUSED, false);
        d.putLong(DOMAIN_UNTIL, now + duration);
        d.putDouble(DOMAIN_CX, cx);
        d.putDouble(DOMAIN_CY, cy);
        d.putDouble(DOMAIN_CZ, cz);
        d.putDouble(DOMAIN_RADIUS, DOMAIN_BASE_RADIUS);
        applyCasterBoost(priestess);
        // 在领域圆心生成空心结界球体（暗紫色），从圆心向外扩张至领域边缘。
        DomainSphereEntity.create(level, cx, cy, cz, DomainSphereEntity.TYPE_PRIESTESS,
                DOMAIN_BASE_RADIUS, priestess.getUUID());
        announce(level, priestess, "领域展开•矢量偏移：以「女祭司」普瑞赛斯为中心，领域已展开",
                ChatFormatting.LIGHT_PURPLE);
        return true;
    }

    private static void tickDomain(ServerLevel level, Priestess priestess) {
        if (!isDomainActive(priestess)) return;
        long now = level.getGameTime();
        if (!priestess.isAlive() || isSilenced(priestess)
                || outsideDomain(priestess) || now >= getDomainUntil(priestess)) {
            endDomain(priestess, level);
            return;
        }
        applyCasterBoost(priestess);
    }

    private static void endDomain(Priestess priestess, ServerLevel level) {
        CompoundTag d = priestess.getPersistentData();
        d.putBoolean(DOMAIN_ACTIVE, false);
        d.putBoolean(DOMAIN_FUSED, true);
        clearCasterBoost(priestess);
        // 领域结束：移除该施术者的结界球体。
        DomainSphereEntity.removeForCaster(level, priestess.getUUID());
        announce(level, priestess, "领域展开•矢量偏移：领域结束，进入熔断状态（单次回血超过6.5%视为恢复）",
                ChatFormatting.GRAY);
    }

    private static boolean outsideDomain(Priestess priestess) {
        CompoundTag d = priestess.getPersistentData();
        double cx = d.getDouble(DOMAIN_CX);
        double cy = d.getDouble(DOMAIN_CY);
        double cz = d.getDouble(DOMAIN_CZ);
        double r = d.getDouble(DOMAIN_RADIUS);
        return priestess.distanceToSqr(cx, cy, cz) > r * r;
    }

    private static long getDomainUntil(Priestess priestess) {
        return priestess.getPersistentData().getLong(DOMAIN_UNTIL);
    }

    /** 沉默判定：被锚定（锚定现实的附加效果）、被流放虚空或进入无 AI 状态视为“沉默”，结束领域。 */
    private static boolean isSilenced(Priestess priestess) {
        return RuwosuojianLogic.isSilenced(priestess);
    }

    /** 发动者自身增速：+50%（或与其它领域重叠时领域对抗，攻速/移速加成不因对抗衰减）。
     * 「源石计划进度」需求 1：+50% 的提升幅度按档位缩放。 */
    private static void applyCasterBoost(Priestess priestess) {
        double boost = OriginiumPlanProgress.amplify(DOMAIN_SPEED_BOOST, priestess);
        OfcAttributes.set(priestess.getAttribute(Attributes.MOVEMENT_SPEED), BOOST_MOVE_UUID,
                "领域•矢量偏移", boost, AttributeModifier.Operation.MULTIPLY_TOTAL);
        OfcAttributes.set(priestess.getAttribute(Attributes.FLYING_SPEED), BOOST_FLY_UUID,
                "领域•矢量偏移", boost, AttributeModifier.Operation.MULTIPLY_TOTAL);
        OfcAttributes.set(priestess.getAttribute(Attributes.ATTACK_SPEED), BOOST_ATTACK_SPEED_UUID,
                "领域•矢量偏移", boost, AttributeModifier.Operation.MULTIPLY_TOTAL);
    }

    private static void clearCasterBoost(Priestess priestess) {
        OfcAttributes.clear(priestess.getAttribute(Attributes.MOVEMENT_SPEED), BOOST_MOVE_UUID);
        OfcAttributes.clear(priestess.getAttribute(Attributes.FLYING_SPEED), BOOST_FLY_UUID);
        OfcAttributes.clear(priestess.getAttribute(Attributes.ATTACK_SPEED), BOOST_ATTACK_SPEED_UUID);
    }

    /** 普瑞赛斯自身的领域与其它领域（另一位普瑞赛斯或「预言家」博士的领域）发生重叠时返回 true。 */
    private static boolean isInDomainOverlap(Priestess priestess, ServerLevel level) {
        CompoundTag d = priestess.getPersistentData();
        double cx = d.getDouble(DOMAIN_CX);
        double cy = d.getDouble(DOMAIN_CY);
        double cz = d.getDouble(DOMAIN_CZ);
        double r = d.getDouble(DOMAIN_RADIUS);
        for (Priestess other : EntityTrackers.priestesses(level)) {
            if (other == priestess || !other.isAlive() || !isDomainActive(other)) continue;
            CompoundTag od = other.getPersistentData();
            double ox = od.getDouble(DOMAIN_CX);
            double oy = od.getDouble(DOMAIN_CY);
            double oz = od.getDouble(DOMAIN_CZ);
            double or = od.getDouble(DOMAIN_RADIUS);
            double dx = cx - ox;
            double dy = cy - oy;
            double dz = cz - oz;
            double sum = r + or;
            if (dx * dx + dy * dy + dz * dz <= sum * sum) return true;
        }
        return ProphetSkillLogic.pointWithinActiveDomain(level, cx, cy, cz);
    }

    /** 在领域范围内挑选一个随机的受击转移目标（排除普瑞赛斯自身）。 */
    private static LivingEntity pickRedirectionTarget(ServerLevel level, Priestess priestess, double radius) {
        List<LivingEntity> candidates = level.getEntitiesOfClass(LivingEntity.class,
                priestess.getBoundingBox().inflate(radius),
                entity -> entity.isAlive() && entity != priestess
                        && entity.distanceToSqr(priestess) <= radius * radius);
        if (candidates.isEmpty()) return null;
        return candidates.get(level.getRandom().nextInt(candidates.size()));
    }

    // ================= 3. 女祭司之眼 =================

    private static void tickEyeSummon(ServerLevel level, Priestess priestess) {
        // 女祭司之眼是主动召唤技能：沉默（锚定现实打断效果）期间无法发动，解除后照常续召。
        if (isSilenced(priestess)) return;
        CompoundTag d = priestess.getPersistentData();
        long now = level.getGameTime();
        // 熵增宇宙：女祭司之眼每 10 秒一次的召唤属于“自身冷却/周期时间”，在现有判定后缩短 32.5%。
        long interval = entropyShortened(EYE_INTERVAL, level);
        if (!d.getBoolean(EYE_INITIAL)) {
            summonEye(level, priestess);
            d.putBoolean(EYE_INITIAL, true);
            d.putLong(EYE_NEXT, now + interval);
            return;
        }
        if (now >= d.getLong(EYE_NEXT)) {
            summonEye(level, priestess);
            d.putLong(EYE_NEXT, now + interval);
        }
    }

    private static void summonEye(ServerLevel level, Priestess priestess) {
        int roll = level.getRandom().nextInt(5);
        switch (roll) {
            case 0 -> summonMessengerAndWalker(level, priestess);
            case 1 -> summonYoungDemonLords(level, priestess, 8, 1.0D);
            case 2 -> summonSourceOreElders(level, priestess, 6, 1.5D);
            case 3 -> summonSages(level, priestess, 4, 2.5D);
            case 4 -> summonPrincesses(level, priestess, 2, 3.25D);
            default -> { /* unreachable */ }
        }
    }

    /** 1. 随机召唤 10 只等同于普瑞赛斯各项数值的天灾信使与终焉行者（随机比例）。 */
    private static void summonMessengerAndWalker(ServerLevel level, Priestess priestess) {
        int total = 10;
        int walkers = level.getRandom().nextInt(total + 1);
        int messengers = total - walkers;
        for (int i = 0; i < walkers; i++) {
            EndWalker walker = GeneratedMod.END_WALKER.get().create(level);
            if (walker != null) {
                placeAndScale(level, walker, priestess, 1.0D);
                walker.getPersistentData().putString(SUMMON_BY, priestess.getUUID().toString());
                level.addFreshEntity(walker);
            }
        }
        for (int i = 0; i < messengers; i++) {
            CalamityMessenger messenger = GeneratedMod.CALAMITY_MESSENGER.get().create(level);
            if (messenger != null) {
                placeAndScale(level, messenger, priestess, 1.0D);
                messenger.getPersistentData().putString(SUMMON_BY, priestess.getUUID().toString());
                level.addFreshEntity(messenger);
            }
        }
    }

    private static void summonYoungDemonLords(ServerLevel level, Priestess priestess, int count, double multiplier) {
        for (int i = 0; i < count; i++) {
            YoungDemonLord lord = GeneratedMod.YOUNG_DEMON_LORD.get().create(level);
            if (lord == null) continue;
            placeAndScale(level, lord, priestess, multiplier);
            lord.getPersistentData().putString(SUMMON_BY, priestess.getUUID().toString());
            level.addFreshEntity(lord);
        }
    }

    private static void summonSourceOreElders(ServerLevel level, Priestess priestess, int count, double multiplier) {
        for (int i = 0; i < count; i++) {
            SourceOreGolemEntity elder = GeneratedMod.SOURCE_ORE_GOLEM.get().create(level);
            if (elder == null) continue;
            placeAndScale(level, elder, priestess, multiplier);
            elder.getPersistentData().putString(SUMMON_BY, priestess.getUUID().toString());
            setSourceOreFaction(elder);
            level.addFreshEntity(elder);
        }
    }

    private static void summonSages(ServerLevel level, Priestess priestess, int count, double multiplier) {
        for (int i = 0; i < count; i++) {
            PureSourceOreGolem sage = GeneratedMod.PURE_SOURCE_ORE_GOLEM.get().create(level);
            if (sage == null) continue;
            placeAndScale(level, sage, priestess, multiplier);
            sage.getPersistentData().putString(SUMMON_BY, priestess.getUUID().toString());
            setSourceOreFaction(sage);
            level.addFreshEntity(sage);
        }
    }

    private static void summonPrincesses(ServerLevel level, Priestess priestess, int count, double multiplier) {
        for (int i = 0; i < count; i++) {
            CalamityPrincess princess = GeneratedMod.CALAMITY_PRINCESS.get().create(level);
            if (princess == null) continue;
            placeAndScale(level, princess, priestess, multiplier);
            princess.getPersistentData().putString(SUMMON_BY, priestess.getUUID().toString());
            level.addFreshEntity(princess);
        }
    }

    private static void setSourceOreFaction(SourceOreGolem golem) {
        golem.setCalamityFaction(true);
        golem.setPlayerCreated(true);
    }

    /** 把召唤生物放到普瑞赛斯身旁，并按乘数将其各项基础属性拉到普瑞赛斯的对应数值。 */
    private static void placeAndScale(ServerLevel level, LivingEntity summoned, Priestess priestess, double multiplier) {
        double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
        double distance = 2.0D + level.getRandom().nextDouble() * 4.0D;
        summoned.moveTo(priestess.getX() + Math.cos(angle) * distance, priestess.getY(),
                priestess.getZ() + Math.sin(angle) * distance,
                level.getRandom().nextFloat() * 360.0F, 0.0F);
        applyScaledStats(level, summoned, priestess, multiplier);
        summoned.setHealth(summoned.getMaxHealth());
    }

    private static void applyScaledStats(ServerLevel level, LivingEntity target, Priestess source, double multiplier) {
        setScaledBase(target, Attributes.MAX_HEALTH, source.getAttributeValue(Attributes.MAX_HEALTH), multiplier);
        setScaledBase(target, Attributes.ATTACK_DAMAGE, source.getAttributeValue(Attributes.ATTACK_DAMAGE), multiplier);
        setScaledBase(target, Attributes.MOVEMENT_SPEED, source.getAttributeValue(Attributes.MOVEMENT_SPEED), multiplier);
        setScaledBase(target, Attributes.ATTACK_SPEED, source.getAttributeValue(Attributes.ATTACK_SPEED), multiplier);
        setScaledBase(target, Attributes.ARMOR, source.getAttributeValue(Attributes.ARMOR), multiplier);
        setScaledBase(target, Attributes.KNOCKBACK_RESISTANCE, source.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE), multiplier);
        setScaledBase(target, Attributes.FOLLOW_RANGE, source.getAttributeValue(Attributes.FOLLOW_RANGE), multiplier);
        setScaledBase(target, Attributes.FLYING_SPEED, source.getAttributeValue(Attributes.FLYING_SPEED), multiplier);
    }

    private static void setScaledBase(LivingEntity entity, Attribute attribute, double sourceValue, double multiplier) {
        AttributeInstance instance = entity.getAttribute(attribute);
        if (instance != null) instance.setBaseValue(sourceValue * multiplier);
    }

    // ================= 4. 源石强化理论 =================

    /** 一名普瑞赛斯附近有生物死亡：默认 +1%；若为其自身或自身机制杀死则 +3.25%。 */
    private static void onCreatureDeath(Priestess priestess, LivingEntity victim, LivingEntity killer, ServerLevel level) {
        double gain = STRENGTHEN_DEATH_GAIN;
        if (killer == priestess || (killer != null && isPriestessMechanism(priestess, killer))) {
            gain = STRENGTHEN_KILL_GAIN;
        }
        // 「源石计划进度」需求 1：源石强化理论的 +1% / +3.25% 提升幅度按档位缩放。
        gain = OriginiumPlanProgress.amplify(gain, priestess);
        applyStrengthening(priestess, gain);
        announce(level, priestess, "源石强化理论：增强 " + percentText(gain) + "%",
                ChatFormatting.GOLD);
    }

    /** 把 0.01 / 0.0325 这类比例格式化为百分比文本：整数不带小数，非整数保留两位。 */
    private static String percentText(double ratio) {
        double pct = ratio * 100.0D;
        double rounded = Math.rint(pct);
        if (Math.abs(pct - rounded) < 1.0E-9D) return String.valueOf((long) rounded);
        return String.format(java.util.Locale.ROOT, "%.2f", pct);
    }

    private static boolean isPriestessMechanism(Priestess priestess, LivingEntity killer) {
        String by = killer.getPersistentData().getString(SUMMON_BY);
        return by != null && by.equals(priestess.getUUID().toString());
    }

    private static void applyStrengthening(Priestess priestess, double gain) {
        double multiplier = 1.0D + gain;
        for (Attribute attribute : STRENGTHEN_ATTRIBUTES) {
            AttributeInstance instance = priestess.getAttribute(attribute);
            if (instance == null) continue;
            instance.setBaseValue(instance.getBaseValue() * multiplier);
        }
        float newMax = (float) priestess.getMaxHealth();
        priestess.setHealth(Math.min(newMax, priestess.getHealth() * (float) multiplier));
    }

    // ================= 5. 天灾学者 =================

    /** 普瑞赛斯每次成功近战命中后调用：累计攻击并按 10/50/100 次召唤对应倍率锁定陨石。 */
    public static void onPriestessAttack(Priestess priestess, ServerLevel level, LivingEntity target) {
        CompoundTag d = priestess.getPersistentData();
        int count = d.getInt(ATTACK_COUNT) + 1;
        d.putInt(ATTACK_COUNT, count);
        if (count % SCHOLAR_ATTACK_100 == 0) {
            summonScholarMeteor(level, priestess, 1000.0F, 200.0F);
        }
        if (count % SCHOLAR_ATTACK_50 == 0) {
            summonScholarMeteor(level, priestess, 100.0F, 100.0F);
        }
        if (count % SCHOLAR_ATTACK_10 == 0) {
            summonScholarMeteor(level, priestess, 10.0F, 10.0F);
        }
    }

    private static void summonScholarMeteor(ServerLevel level, Priestess priestess, float damage, float size) {
        // 天灾学者的锁定陨石是主动技能：沉默期间不释放。
        if (isSilenced(priestess)) return;
        LivingEntity highest = highestEnemy(level, priestess, SCHOLAR_RADIUS);
        if (highest == null) return;
        level.addFreshEntity(MeteorEntity.createScaledTargeted(level, highest, damage, size));
    }

    /** 半径内可被普瑞赛斯索敌的“敌方生命值最高单位”（含敌对玩家、对立阵营首领与可攻击生物）。 */
    private static LivingEntity highestEnemy(ServerLevel level, Priestess priestess, double radius) {
        return level.getEntitiesOfClass(LivingEntity.class, priestess.getBoundingBox().inflate(radius),
                        entity -> entity.isAlive() && entity != priestess
                                && !(entity instanceof Priestess)
                                && priestess.canAttack(entity)
                                && entity.distanceToSqr(priestess) <= radius * radius)
                .stream().max(Comparator.comparingDouble(LivingEntity::getMaxHealth)).orElse(null);
    }

    // ================= 工具 =================

    private static void announce(ServerLevel level, LivingEntity source, String message, ChatFormatting color) {
        Component component = Component.literal(message).withStyle(color);
        for (ServerPlayer player : level.players()) {
            if (player.distanceToSqr(source) <= 128.0D * 128.0D) {
                player.displayClientMessage(component, false);
            }
        }
    }

    private static LivingEntity resolveAttacker(net.minecraft.world.damagesource.DamageSource source) {
        if (source == null) return null;
        Entity attacker = source.getEntity();
        if (attacker instanceof LivingEntity living) return living;
        Entity direct = source.getDirectEntity();
        if (direct instanceof LivingEntity living) return living;
        if (direct instanceof net.minecraft.world.entity.projectile.Projectile projectile
                && projectile.getOwner() instanceof LivingEntity living) return living;
        return null;
    }

    /** 是否为可被矢量偏移转移的伤害来源：近战/远程（有实体攻击者）或实体挤压碰撞。 */
    private static boolean isRedirectable(Priestess priestess, net.minecraft.world.damagesource.DamageSource source) {
        if (source == null) return false;
        if (source.is(net.minecraft.world.damagesource.DamageTypes.CRAMMING)) return true;
        LivingEntity attacker = resolveAttacker(source);
        return attacker != null && attacker != priestess;
    }

    // ================= 事件 =================

    // 注意：嵌套类简单名必须全局唯一（与 ProphetSkillLogic/RuwosuojianLogic 同理）。
    public static final class PriestessSkillEvents {

        public PriestessSkillEvents() {
        }

        /** 领域展开•矢量偏移：把指向普瑞赛斯的可转移伤害重定向到范围内随机生物。 */
        @SubscribeEvent
        public void onLivingHurt(LivingHurtEvent event) {
            LivingEntity victim = event.getEntity();
            if (victim.level().isClientSide || !(victim.level() instanceof ServerLevel level)
                    || !(victim instanceof Priestess priestess)) return;
            if (!isDomainActive(priestess)) return;
            float amount = event.getAmount();
            if (amount <= 0.0F) return;
            if (!isRedirectable(priestess, event.getSource())) return;
            // 3.25% 概率转移失败；多领域重叠时领域对抗，失败概率提升 10%。
            double failChance = TRANSFER_FAIL_RATE
                    + (isInDomainOverlap(priestess, level) ? OVERLAP_FAIL_BONUS : 0.0D);
            if (level.getRandom().nextDouble() < failChance) return;
            LivingEntity target = pickRedirectionTarget(level, priestess, DOMAIN_BASE_RADIUS);
            if (target == null) return;
            // 只转移伤害本身；原攻击的控制、负面效果与传送效果不落到目标身上（目标仅承受原始伤害）。
            event.setCanceled(true);
            target.hurt(event.getSource(), amount);
            announce(level, priestess, "领域展开•矢量偏移：伤害转移至 " + target.getType().getDescription().getString(),
                    ChatFormatting.AQUA);
        }

        @SubscribeEvent
        public void onLivingDamage(LivingDamageEvent event) {
            LivingEntity victim = event.getEntity();
            if (victim.level().isClientSide || !(victim.level() instanceof ServerLevel level)) return;
            if (!(victim instanceof Priestess priestess) || !priestess.isAlive()) return;
            // 2. 领域被动发动：受伤前已损失生命值百分比即为本次受伤后发动领域概率。
            double hpLostBefore = 1.0D - priestess.getHealth() / Math.max(1.0D, priestess.getMaxHealth());
            if (canActivateDomain(priestess) && hpLostBefore > 0.0D
                    && level.getRandom().nextDouble() < hpLostBefore) {
                activateDomain(priestess);
            }
        }

        @SubscribeEvent
        public void onLivingHeal(LivingHealEvent event) {
            LivingEntity entity = event.getEntity();
            if (entity.level().isClientSide || !(entity instanceof Priestess priestess)) return;
            // 2. 熔断恢复：单次回血超过6.5%视为领域恢复，可继续发动领域。
            if (isDomainFused(priestess) && priestess.isAlive()
                    && event.getAmount() > priestess.getMaxHealth() * FUSED_HEAL_RATIO) {
                priestess.getPersistentData().putBoolean(DOMAIN_FUSED, false);
                if (entity.level() instanceof ServerLevel level) {
                    announce(level, priestess, "领域展开•矢量偏移：熔断恢复，可再次发动领域",
                            ChatFormatting.GREEN);
                }
            }
        }

        /** 1. 熵增宇宙：普瑞赛斯自身持续时间能力（领域持续时间）在现有判定后延长 32.5%。 */
        // 熵增宇宙对“持续时间”的延长统一在领域激活时结算（activateDomain 中 duration×1.325），
        // 不在此改动附着于她的外部状态效果，避免在效果添加事件里重加效果引发重入/崩溃。

        /** 4. 源石强化理论：半径 32 格内生物死亡强化普瑞赛斯。 */
        @SubscribeEvent
        public void onLivingDeath(LivingDeathEvent event) {
            LivingEntity victim = event.getEntity();
            if (victim.level().isClientSide || !(victim.level() instanceof ServerLevel level)) return;
            if (victim instanceof Priestess) return;
            LivingEntity killer = resolveAttacker(event.getSource());
            for (Priestess priestess : level.getEntitiesOfClass(Priestess.class,
                    victim.getBoundingBox().inflate(STRENGTHEN_RADIUS), Entity::isAlive)) {
                if (priestess.distanceToSqr(victim) > STRENGTHEN_RADIUS * STRENGTHEN_RADIUS) continue;
                onCreatureDeath(priestess, victim, killer, level);
            }
        }

        @SubscribeEvent
        public void onServerChat(ServerChatEvent event) {
            ServerPlayer player = event.getPlayer();
            if (player == null || !(player.level() instanceof ServerLevel level)) return;
            if (!DOMAIN_TRIGGER.equals(normalize(event.getRawText()))) return;
            Priestess nearest = level.getEntitiesOfClass(Priestess.class, WORLD_BOUNDS, Entity::isAlive)
                    .stream().min(Comparator.comparingDouble(p -> p.distanceToSqr(player))).orElse(null);
            if (nearest == null) return;
            activateDomain(nearest);
        }

        /** 归一化触发语：去除空白与各类引号/括号，并把不同中点符号统一为「•」。 */
        private static String normalize(String text) {
            return text == null ? ""
                    : text.replace(" ", "").replace("\u3000", "")
                    .replace("「", "").replace("」", "").replace("『", "").replace("』", "")
                    .replace("“", "").replace("”", "").replace("\"", "").replace("'", "")
                    .replace("(", "").replace(")", "").replace("（", "").replace("）", "")
                    .replace("·", "•").replace("・", "•");
        }
    }
}
