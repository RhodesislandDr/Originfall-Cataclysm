package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.client.extensions.common.IClientMobEffectExtensions;

import java.util.UUID;
import java.util.function.Consumer;

/**
 * 坍缩：被邪魔侵蚀的新状态，最多 {@link CalamityLogic#MAX_COLLAPSE_LAYERS} 层。
 *
 * <p>效果本身只负责两件事：</p>
 * <ul>
 *   <li><b>属性加成</b>：每层 +20% 移动速度、+10% 攻击力（乘法总量）。</li>
 *   <li><b>无粒子</b>：效果实例以 {@code visible=false} 附加，世界里不显示药水粒子。</li>
 * </ul>
 *
 * <p>层数成长、邪魔传播、攻击附加、玩家掉血、邪魔阵营一律由
 * {@link CalamityLogic} 在服务端驱动；效果时长固定为无限，保证「无法以任何形式清除」。
 * 攻击力的加成覆写 {@link #getAttributeModifierValue(int, AttributeModifier)} 按层数动态计算。</p>
 */
public final class CollapseEffect extends MobEffect {
    static final UUID SPEED_MODIFIER = UUID.fromString("f3a1c2d4-5b6e-4a7c-8d9f-0a1b2c3d4e50");
    static final UUID ATTACK_MODIFIER = UUID.fromString("f3a1c2d4-5b6e-4a7c-8d9f-0a1b2c3d4e51");

    public CollapseEffect() {
        // 邪魔色：偏冷的惨白紫，图标贴在 HUD 上时更容易与源石感染的暗红区分。
        super(MobEffectCategory.HARMFUL, 0xE6E1FF);
        // 实际数值由 getAttributeModifierValue 按层数覆盖，这里只登记修饰符本身。
        addAttributeModifier(Attributes.MOVEMENT_SPEED, SPEED_MODIFIER.toString(), 0.0D,
                AttributeModifier.Operation.MULTIPLY_TOTAL);
        addAttributeModifier(Attributes.ATTACK_DAMAGE, ATTACK_MODIFIER.toString(), 0.0D,
                AttributeModifier.Operation.MULTIPLY_TOTAL);
    }

    @Override
    public double getAttributeModifierValue(int amplifier, AttributeModifier modifier) {
        int layers = CalamityLogic.collapseLayersFromAmplifier(amplifier);
        // 「源石计划进度」需求 7：邪魔每层的移速/攻击加成幅度按档位缩放。
        // 属性修饰符计算没有世界上下文，读取每 tick 刷新的缓存系数（两端同步）。
        double progress = OriginiumPlanProgress.cachedFactor();
        if (SPEED_MODIFIER.equals(modifier.getId())) {
            return CalamityLogic.COLLAPSE_SPEED_PER_LAYER * layers * progress;
        }
        if (ATTACK_MODIFIER.equals(modifier.getId())) {
            return CalamityLogic.COLLAPSE_ATTACK_PER_LAYER * layers * progress;
        }
        return 0.0D;
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        // 坍缩的成长与掉血由 CommonEvents 逐 tick 驱动，效果自身不做周期结算。
        return false;
    }

    @Override
    public void initializeClient(Consumer<IClientMobEffectExtensions> consumer) {
        consumer.accept(new cn.blockforge.generated.originfallcataclysm.client.CollapseClientExtension());
    }
}
