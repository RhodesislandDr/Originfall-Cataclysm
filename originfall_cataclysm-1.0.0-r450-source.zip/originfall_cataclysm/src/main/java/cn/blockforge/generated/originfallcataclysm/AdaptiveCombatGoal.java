package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.function.Predicate;

/** 根据主手武器在近战、弓弩和三叉戟远程攻击之间切换，并触发原版生物攻击动画。 */
public class AdaptiveCombatGoal extends Goal {
    /**
     * Epic Fight（史诗战斗）接管钩子：由兼容层在 Epic Fight 存在时安装，
     * 判断某个生物的近战普通攻击是否已交给史诗战斗的 AnimatedAttackGoal
     * （连段动画、硬直、破防等攻击逻辑全部由史诗战斗驱动）。返回 true 时
     * 本目标让出 MOVE/LOOK 控制权、不再执行普通近战，只保留剑气等技能型
     * 攻击；未安装 Epic Fight 时恒为 false，一切行为与原先完全一致，
     * 模组可脱离史诗战斗独立运行。
     */
    public static volatile Predicate<Mob> EPICFIGHT_MELEE_TAKEOVER = mob -> false;

    /** 技能型攻击的动作类别（供史诗战斗动作桥使用，与史诗战斗无关的场合不引用）。 */
    public enum SkillMotion { SWORD_SWING, RANGED_SHOT, TRIDENT_THROW }

    /**
     * 技能动作的史诗战斗广播器：由兼容层在 Epic Fight 存在时安装。
     * 生物由史诗战斗的骨骼动画渲染后，原版摆臂（swing）在模型上不可见，
     * 需要把剑气/射击/投叉等技能释放额外广播为史诗战斗的对应攻击动画。
     * 默认空实现，未安装史诗战斗时行为与原先完全一致。
     */
    public interface SkillMotionBroadcaster {
        void broadcast(Mob mob, SkillMotion motion);
    }

    public static volatile SkillMotionBroadcaster EPICFIGHT_SKILL_MOTION = (mob, motion) -> {};

    private final Mob mob;
    private final double speed;
    private int attackCooldown;
    private int useTicks;
    private boolean usingRangedItem;
    private Item activeWeapon;

    public AdaptiveCombatGoal(Mob mob, double speed) {
        this.mob = mob;
        this.speed = speed;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    /**
     * 「源石计划进度」需求 4：战斗追击的移速加成（构造时传入的倍率中超出 1.0 的部分）
     * 按档位幅度缩放——1.15 倍在 0 档约 1.0015 倍、18 档约 1.215 倍。
     * 倍率本就是 1.0 的调用方（{@link ConvertedHostileGoal}）不受影响。
     */
    private double combatSpeed() {
        return OriginiumPlanProgress.boosted(speed, mob.level());
    }

    @Override
    public boolean canUse() {
        if (!mob.isAlive() || mob.isNoAi() || !validTarget()) return false;
        // 「扒臀长舞」期间不参战：舞蹈的站位与朝向由 BossTauntLogic 全权驱动。
        // 这里若继续追击/索敌（尤其史诗战斗接管后由它的 TargetChasingGoal 追击），
        // 会把首领从舞蹈位置与背对朝向拽走，正是「装了史诗战斗就不对」的那处偏差。
        if (mob instanceof CalamityMob dancing && BossTauntLogic.isActive(dancing)) return false;
        // 被史诗战斗接管近战时不占用 MOVE/LOOK，以便与其攻击、追击目标并存，只跑技能分支。
        setFlags(EPICFIGHT_MELEE_TAKEOVER.test(mob)
                ? EnumSet.noneOf(Flag.class)
                : EnumSet.of(Flag.MOVE, Flag.LOOK));
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void stop() {
        // 被史诗战斗接管时不动导航：追击由它的 TargetChasingGoal 负责，避免互相踩停。
        if (!EPICFIGHT_MELEE_TAKEOVER.test(mob)) mob.getNavigation().stop();
        mob.stopUsingItem();
        mob.setAggressive(false);
        useTicks = 0;
        usingRangedItem = false;
        activeWeapon = null;
    }

    /**
     * 索敌全量扫描的最小间隔（tick）。
     * FOLLOW_RANGE 级别的大 AABB 查询原本在目标缺失时每 tick 都要做（canUse 的 validTarget
     * 与 tick 各一次），多生物场景里是最重的实体检索开销之一；原版目标选择器本身也是
     * 10 tick 一级的节奏，这里限到 5 tick，感知上无差别、开销成倍下降。
     */
    private static final long TARGET_SCAN_INTERVAL = 5L;
    /** 下一次允许全量索敌的游戏时间；同一 tick 内 validTarget 与 tick 共用它去重。 */
    private long nextTargetScanTick = Long.MIN_VALUE;

    /**
     * 经 {@link #TARGET_SCAN_INTERVAL} 节流的索敌：冷却未到返回 {@code null}。
     * 注意返回 null 而不是现有目标——调用方均在「现有目标已判无效」之后才走这里，
     * 回吐旧目标会让 {@code validTarget()} 误判为真、带着失效目标进入攻击分支。
     */
    private LivingEntity findTargetThrottled(net.minecraft.server.level.ServerLevel server) {
        long now = server.getGameTime();
        if (now < nextTargetScanTick) return null;
        nextTargetScanTick = now + TARGET_SCAN_INTERVAL;
        return findTarget(server);
    }

    @Override
    public void tick() {
        if (!(mob.level() instanceof net.minecraft.server.level.ServerLevel server)) return;
        LivingEntity target = mob.getTarget();
        if (!canUseTarget(target)) {
            mob.setTarget(findTargetThrottled(server));
            target = mob.getTarget();
        }
        if (target == null) return;

        mob.getLookControl().setLookAt(target, 30.0F, 30.0F);
        boolean messengerSpacing = mob instanceof CalamityMessenger;
        boolean messengerTooClose = messengerSpacing
                && maintainMessengerSpacing((CalamityMessenger) mob, target);
        ItemStack weapon = mob.getMainHandItem();
        Item currentWeapon = weapon.getItem();
        if (activeWeapon != currentWeapon) {
            mob.stopUsingItem();
            useTicks = 0;
            usingRangedItem = false;
            activeWeapon = currentWeapon;
        }
        if (weapon.is(Items.BOW) || weapon.is(Items.CROSSBOW)) {
            tickRanged(target, weapon, messengerSpacing, messengerTooClose);
        } else if (weapon.is(Items.TRIDENT)) {
            tickTrident(target, weapon);
        } else {
            if (usingRangedItem) {
                mob.stopUsingItem();
                usingRangedItem = false;
                useTicks = 0;
            }
            mob.setAggressive(true);
            if (isSwordQiAttack()) {
                if (EPICFIGHT_MELEE_TAKEOVER.test(mob)) {
                    tickSwordQiEpicFight(target);
                } else {
                    tickSwordQi(target);
                }
            } else if (!EPICFIGHT_MELEE_TAKEOVER.test(mob)) {
                // 未被史诗战斗接管：按原版方式追击并普通近战；接管后这两者由史诗战斗执行。
                mob.getNavigation().moveTo(target, combatSpeed());
                if (attackCooldown > 0) attackCooldown--;
                if (mob.isWithinMeleeAttackRange(target) && attackCooldown <= 0) {
                    performMeleeAttack(target);
                    attackCooldown = attackCooldownFor(mob);
                }
            }
        }
    }

    /**
     * 近战伤害完成后统一广播挥舞事件；把挥舞放在伤害调用之后，避免自定义实体
     * 在 doHurtTarget 内再次触发动作时被同一 tick 的第二次挥舞请求吞掉。
     *
     * <p>本方法只在史诗战斗没有接管该生物近战时被调用（持弓/弩/三叉戟、被转化的
     * 原版生物、以及傀儡等特殊结算），因此这里额外做两件事：把这次挥击广播成
     * 史诗战斗的攻击动画（生物被史诗战斗的补丁渲染器接管后，原版摆臂在骨骼模型上
     * 不可见），并把命中上报给 {@link SkillCombatHooks}，让目标进入史诗战斗的硬直。
     * 未安装史诗战斗时两处调用都是空实现，与原先完全一致。</p>
     */
    private void performMeleeAttack(LivingEntity target) {
        boolean hurt = mob.doHurtTarget(target);
        if (!hurt) return;
        mob.swing(InteractionHand.MAIN_HAND, true);
        EPICFIGHT_SKILL_MOTION.broadcast(mob, SkillMotion.SWORD_SWING);
        SkillCombatHooks.impact(target, meleeDamageHint(),
                mob instanceof SourceOreGolem ? SkillCombatHooks.Impact.HEAVY : SkillCombatHooks.Impact.LIGHT);
    }

    /** 本次近战的名义伤害值，用于换算史诗战斗的硬直强度（取不到攻击力属性时给保守值）。 */
    private float meleeDamageHint() {
        return (float) (mob.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE)
                ? mob.getAttributeValue(Attributes.ATTACK_DAMAGE) : 2.0D);
    }

    private int attackCooldownFor(Mob attacker) {
        double attackSpeed = attacker.getAttributes().hasAttribute(Attributes.ATTACK_SPEED)
                ? attacker.getAttributeValue(Attributes.ATTACK_SPEED) : 1.0D;
        return Math.max(1, (int) Math.round(20.0D / Math.max(0.1D, attackSpeed)));
    }

    private void tickRanged(LivingEntity target, ItemStack weapon, boolean messengerSpacing, boolean messengerTooClose) {
        mob.setAggressive(true);
        if (messengerTooClose) {
            mob.stopUsingItem();
            usingRangedItem = false;
            useTicks = 0;
        } else if (!usingRangedItem) {
            mob.startUsingItem(InteractionHand.MAIN_HAND);
            usingRangedItem = true;
        }
        double distance = mob.distanceToSqr(target);
        if (!messengerSpacing && distance > 256.0D) {
            mob.getNavigation().moveTo(target, combatSpeed());
        } else if (!messengerSpacing || (distance >= 16.0D && distance <= 36.0D)) {
            mob.getNavigation().stop();
        }
        if (messengerTooClose) return;
        if (attackCooldown > 0) attackCooldown--;
        if (weapon.getItem() instanceof CrossbowItem) {
            // 弩必须先由 CrossbowItem 装填箭矢，再进入原版上弦/保持姿势。
            if (CrossbowItem.isCharged(weapon)) {
                mob.stopUsingItem();
                usingRangedItem = false;
                useTicks = 0;
                if (attackCooldown <= 0) {
                    CrossbowItem.performShooting(mob.level(), mob, InteractionHand.MAIN_HAND, weapon, 1.6F, 14.0F);
                    CrossbowItem.setCharged(weapon, false);
                    mob.swing(InteractionHand.MAIN_HAND);
                    EPICFIGHT_SKILL_MOTION.broadcast(mob, SkillMotion.RANGED_SHOT);
                    attackCooldown = 40;
                }
            } else {
                if (useTicks < CrossbowItem.getChargeDuration(weapon)) {
                    useTicks++;
                } else {
                    // 让 CrossbowItem 自己装填弹体并写入 charged 标记；仅手动写
                    // 标记会导致 performShooting 没有弹体可发射。
                    CrossbowItem crossbow = (CrossbowItem) weapon.getItem();
                    crossbow.releaseUsing(weapon, mob.level(), mob,
                            crossbow.getUseDuration(weapon) - useTicks);
                    mob.stopUsingItem();
                    usingRangedItem = false;
                    useTicks = 0;
                    attackCooldown = 5;
                }
            }
        } else {
            // 弓每次射击都结束一次拉弓，再重新进入使用状态，保持玩家式攻击姿态。
            if (useTicks < 20) useTicks++;
            if (useTicks >= 20 && attackCooldown <= 0) {
                shootArrow(target);
                resetRangedUse(30);
            }
        }
    }

    private void tickTrident(LivingEntity target, ItemStack weapon) {
        mob.setAggressive(true);
        if (!usingRangedItem) {
            mob.startUsingItem(InteractionHand.MAIN_HAND);
            usingRangedItem = true;
        }
        double distance = mob.distanceToSqr(target);
        if (distance > 196.0D) mob.getNavigation().moveTo(target, combatSpeed());
        else mob.getNavigation().stop();
        if (attackCooldown > 0) attackCooldown--;
        // 三叉戟至少蓄力 10 tick 后才投出，动作与玩家的投掷节奏一致。
        if (useTicks < 10) useTicks++;
        if (useTicks >= 10 && attackCooldown <= 0) {
            ThrownTrident trident = new ThrownTrident(mob.level(), mob, weapon.copy());
            Vec3 start = mob.getEyePosition();
            double dx = target.getX() - start.x;
            double dy = target.getY(0.3333333333333333D) - start.y;
            double dz = target.getZ() - start.z;
            trident.setBaseDamage(Math.max(4.0D, mob.getAttributeValue(Attributes.ATTACK_DAMAGE) * 0.75D));
            trident.setEnchantmentEffectsFromEntity(mob, 1.0F);
            trident.shoot(dx, dy + Math.sqrt(dx * dx + dz * dz) * 0.2D, dz, 1.6F, 1.0F);
            mob.level().addFreshEntity(trident);
            mob.swing(InteractionHand.MAIN_HAND);
            EPICFIGHT_SKILL_MOTION.broadcast(mob, SkillMotion.TRIDENT_THROW);
            resetRangedUse(45);
        }
    }

    private void resetRangedUse(int cooldown) {
        mob.stopUsingItem();
        usingRangedItem = false;
        useTicks = 0;
        attackCooldown = cooldown;
    }

    /** 是否应使用剑气作远程攻击：已学到远程攻击行为逻辑，且主手是近战武器（非弓/弩/三叉戟）。 */
    private boolean isSwordQiAttack() {
        if (!LearnedTraitLogic.has(mob, LearnedTraitLogic.RANGED_ATTACK)) return false;
        if (isBlackSwordQiHolder()) return true;
        ItemStack weapon = mob.getMainHandItem();
        if (weapon.isEmpty()) return false;
        return !weapon.is(Items.BOW) && !weapon.is(Items.CROSSBOW) && !weapon.is(Items.TRIDENT);
    }

    /** 黑色月牙剑气的指定首领：「女祭司」普瑞赛斯 / 特蕾西娅 / 「预言家」博士。 */
    private boolean isBlackSwordQiHolder() {
        return mob instanceof Priestess || mob instanceof Theresia || mob instanceof Prophet;
    }

    /** 剑气远程攻击：贴脸近战，中距离停下放剑气，更远则追近目标。 */
    private void tickSwordQi(LivingEntity target) {
        double distSqr = mob.distanceToSqr(target);
        double followRange = Math.max(16.0D, mob.getAttributeValue(Attributes.FOLLOW_RANGE));
        if (mob.isWithinMeleeAttackRange(target)) {
            mob.getNavigation().stop();
            if (attackCooldown > 0) attackCooldown--;
            if (attackCooldown <= 0) {
                performMeleeAttack(target);
                attackCooldown = attackCooldownFor(mob);
            }
            return;
        }
        if (distSqr > followRange * followRange) {
            mob.getNavigation().moveTo(target, combatSpeed());
            return;
        }
        mob.getNavigation().stop();
        if (attackCooldown > 0) attackCooldown--;
        if (attackCooldown <= 0) {
            fireSwordQi(target);
            attackCooldown = 20;
        }
    }

    /**
     * 史诗战斗接管下的剑气技能：移动与贴脸普攻都归史诗战斗的攻击逻辑处理，
     * 本方法只负责在射程内、非贴脸时补充发射剑气，且不触碰导航以免打断它的追击。
     */
    private void tickSwordQiEpicFight(LivingEntity target) {
        if (mob.isWithinMeleeAttackRange(target)) return;
        double followRange = Math.max(16.0D, mob.getAttributeValue(Attributes.FOLLOW_RANGE));
        if (mob.distanceToSqr(target) > followRange * followRange) return;
        if (attackCooldown > 0) attackCooldown--;
        if (attackCooldown <= 0) {
            fireSwordQi(target);
            attackCooldown = 20;
        }
    }

    /** 投出对应颜色的月牙形剑气：三位指定首领为黑，其余持近战武器者为白。 */
    private void fireSwordQi(LivingEntity target) {
        boolean black = mob instanceof Priestess || mob instanceof Theresia || mob instanceof Prophet;
        SwordQiEntity.shoot(mob.level(), mob, target, black);
        mob.swing(InteractionHand.MAIN_HAND);
        EPICFIGHT_SKILL_MOTION.broadcast(mob, SkillMotion.SWORD_SWING);
    }

    private boolean maintainMessengerSpacing(CalamityMessenger messenger, LivingEntity target) {
        double distanceSqr = messenger.distanceToSqr(target);
        if (distanceSqr >= 16.0D && distanceSqr <= 36.0D) {
            messenger.getNavigation().stop();
            return false;
        }
        Vec3 delta = messenger.position().subtract(target.position());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        if (horizontal < 0.001D) horizontal = 0.001D;
        // 先拉开水平距离；同样满足距离时优先把信使抬到目标上方。
        double desiredX = target.getX() + delta.x / horizontal * 6.0D;
        double desiredZ = target.getZ() + delta.z / horizontal * 6.0D;
        double desiredY = Math.max(messenger.getY(),
                target.getY() + Math.max(4.0D, target.getBbHeight() + 2.0D));
        messenger.getNavigation().moveTo(desiredX, desiredY, desiredZ, combatSpeed());
        return distanceSqr < 16.0D;
    }

    private void shootArrow(LivingEntity target) {
        AbstractArrow arrow = ProjectileUtil.getMobArrow(mob, new ItemStack(Items.ARROW), 1.0F);
        Vec3 start = mob.getEyePosition();
        double dx = target.getX() - start.x;
        double dy = target.getY(0.3333333333333333D) - start.y;
        double dz = target.getZ() - start.z;
        arrow.setBaseDamage(Math.max(2.0D, mob.getAttributeValue(Attributes.ATTACK_DAMAGE) * 0.5D));
        arrow.setEnchantmentEffectsFromEntity(mob, 1.0F);
        arrow.shoot(dx, dy + Math.sqrt(dx * dx + dz * dz) * 0.2D, dz, 1.6F, 14.0F);
        mob.level().addFreshEntity(arrow);
        mob.swing(InteractionHand.MAIN_HAND);
        EPICFIGHT_SKILL_MOTION.broadcast(mob, SkillMotion.RANGED_SHOT);
    }

    private boolean validTarget() {
        return canUseTarget(mob.getTarget())
                || mob.level() instanceof net.minecraft.server.level.ServerLevel server && findTargetThrottled(server) != null;
    }

    private boolean canUseTarget(LivingEntity target) {
        if (target == null || !target.isAlive() || CalamityLogic.isSameConvertedFaction(mob, target)) return false;
        if (mob instanceof SourceOreGolem golem) return golem.canAttack(target);
        if (CalamityLogic.isConvertedHostile(mob)
                && mob.distanceToSqr(target) > CalamityLogic.CONVERTED_TARGET_RADIUS
                        * CalamityLogic.CONVERTED_TARGET_RADIUS) return false;
        if (mob instanceof CalamityMob calamity && !(mob instanceof EndWalker)) {
            return calamity.canAttack(target);
        }
        // 转化实体只能使用转化阵营的目标规则，不能因为目标是普通敌对生物
        // 就绕过 32 格索敌范围和源石实体保护。
        return CalamityLogic.canConvertedHostileAttack(mob, target);
    }

    private LivingEntity findTarget(net.minecraft.server.level.ServerLevel server) {
        LivingEntity convertedTarget = CalamityLogic.findConvertedHostileTarget(server, mob,
                CalamityLogic.CONVERTED_TARGET_RADIUS);
        if (convertedTarget != null && canUseTarget(convertedTarget)) return convertedTarget;
        return server.getEntitiesOfClass(LivingEntity.class, mob.getBoundingBox().inflate(mob.getAttributeValue(
                        Attributes.FOLLOW_RANGE)),
                        this::canUseTarget).stream().min(Comparator.comparingDouble(mob::distanceToSqr)).orElse(null);
    }
}
