package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.OriginFallManualContent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.screens.inventory.BookViewScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;

import java.util.ArrayList;
import java.util.List;

/**
 * 《源石对世界的融合研究及实践》的客户端展示。
 *
 * <p>打开时从 {@link OriginFallManualContent} 现场取行，并依据真实字体宽度
 * 把内容动态切分成若干书页（遇到分页标记开新页），因此内容始终反映当前
 * 模组机制，随模组调整而自动更新，且不会因中文字符宽度而溢出被裁切。</p>
 */
public final class OriginFallManualClient {
    /** 书籍正文绘制区宽度/高度（与 {@link BookViewScreen} 一致）。 */
    private static final int TEXT_WIDTH = 114;
    private static final int TEXT_HEIGHT = 180;

    private OriginFallManualClient() {}

    /** 打开说明书书籍界面（只在客户端调用）。 */
    public static void open() {
        Minecraft minecraft = Minecraft.getInstance();
        List<List<String>> pages = paginate(minecraft.font, OriginFallManualContent.buildLines());
        minecraft.setScreen(new BookViewScreen(new ManualAccess(pages)));
    }

    /** 依据字体宽度把扁平行切分为若干物理书页。 */
    private static List<List<String>> paginate(Font font, List<String> rawLines) {
        int maxLines = Math.max(1, (TEXT_HEIGHT / Math.max(1, font.lineHeight)) - 3);
        List<List<String>> pages = new ArrayList<>();
        List<String> current = new ArrayList<>();
        int usedLines = 0;
        for (String raw : rawLines) {
            if (OriginFallManualContent.PAGE_BREAK.equals(raw)) {
                if (!current.isEmpty()) {
                    pages.add(current);
                    current = new ArrayList<>();
                    usedLines = 0;
                }
                continue;
            }
            int wrapped = Math.max(1, font.split(Component.literal(raw), TEXT_WIDTH).size());
            if (!current.isEmpty() && usedLines + wrapped > maxLines) {
                pages.add(current);
                current = new ArrayList<>();
                usedLines = 0;
            }
            current.add(raw);
            usedLines += wrapped;
        }
        if (!current.isEmpty()) pages.add(current);
        return pages;
    }

    /** 把分好的书页包装成原版书籍界面可读的页面访问器。 */
    private static final class ManualAccess implements BookViewScreen.BookAccess {
        private final List<FormattedText> pages;

        private ManualAccess(List<List<String>> pages) {
            this.pages = new ArrayList<>();
            for (List<String> page : pages) {
                this.pages.add(Component.literal(String.join("\n", page)));
            }
        }

        @Override
        public int getPageCount() {
            return pages.size();
        }

        @Override
        public FormattedText getPageRaw(int index) {
            return pages.get(index);
        }
    }
}
