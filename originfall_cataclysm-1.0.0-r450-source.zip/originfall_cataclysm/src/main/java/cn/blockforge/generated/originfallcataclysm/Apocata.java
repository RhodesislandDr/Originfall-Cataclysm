package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.Locale;

/**
 * 哈基玖（Apocata）——《方块与深蓝之树》联动彩蛋生物。
 *
 * <p>原型定义取自深蓝之树本尊：生命 114 点（×57）、无护甲、不主动攻击，
 * 死亡掉落「哈基玖本人」；击败者名字含 Goodsquid/goodsquid 时生成潮曦奇美拉
 * （本尊在场时直接生成<b>本尊</b>的 tide_chimera，见 {@link CaerulaArborCompat}）。
 * 皮肤为玩家上传的 64×64「蕾缪安」，建模沿用特蕾西娅的玩家型骨架
 * （{@link CalamityHumanoidModel}，原版 64×64 皮肤 UV 一律不动）。</p>
 *
 * <p>在本模组中它是<b>中立生物</b>：谁对它造成伤害就追击谁，每次打 1 点；
 * 除此之外永不先出手。它同时接入了两位首领的「扒臀长舞」队列——被枪械或魔法
 * 击中即入队起舞（机制与首领完全一致：首击免疫、舞曲期间免疫一切伤害、
 * 弹开一切弹射物、出手伤害归零），规则细节见 {@link BossTauntLogic}。</p>
 *
 * <p>召唤方式仿雪傀儡的「下侧身体减一层」：一个张师块＋顶上一个南瓜头
 * （普通/雕刻/南瓜灯皆可），判定见 {@code CommonEvents#trySummonApocata}。
 * 召唤仪式不依赖深蓝之树在场：<b>未安装深蓝之树时召唤同样生效</b>，产出本类型
 * 作等价替身，但死亡不掉「哈基玖本人」；装有深蓝之树时召唤优先产出<b>本尊实体</b>，
 * 本类型只在本尊查不到时作兜底，并保留给旧存档与 /give 入口。</p>
 */
public final class Apocata extends CalamityMob {
    /** 死亡结算（掉落＋奇美拉钩子）只跑一次的去重标记，仅服务端持久数据。 */
    private static final String DEATH_SETTLED = "OfcApocataDeathSettled";

    public Apocata(EntityType<? extends Apocata> type, Level level) {
        super(type, level);
        // 彩蛋生物不吃认主机制：无主人、不跟随、无绑定武器。
        setTame(false);
        setFollowingOwner(false);
    }

    /**
     * 血量和防御按深蓝之树设定：生命 114（×57），护甲 0；
     * 反击「每次一点伤害」→ 攻击 1.0；索敌按中立反击需要给到 32。
     */
    public static AttributeSupplier.Builder createAttributes() {
        return CalamityMob.createAttributes(114.0D, 0.0D, 32.0D)
                .add(Attributes.ATTACK_DAMAGE, 1.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D);
    }

    @Override
    protected double followRange() {
        return 32.0D;
    }

    @Override
    protected boolean canTeleportAcrossDimensions() {
        return false;
    }

    /** 彩蛋生物没有主人，也就没有跟随与跨维度追主一说。 */
    @Override
    protected boolean shouldFollowOwner() {
        return false;
    }

    /** 没有任何主动技能轮。 */
    @Override
    protected void serverAbilityTick(ServerLevel level) {
    }

    /**
     * 中立行为：只有「谁打了它」才会还手（伤害 1.0 点由属性保证），
     * 从不挂主动索敌目标；跳舞期间 {@link BossTauntLogic} 会接管位移与索敌。
     */
    @Override
    protected void registerGoals() {
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, true));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        // 报复性索敌：只把刚才伤害过自己的个体当目标。
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
    }

    /** 只允许打「最后伤害过它的生物」；舞蹈期间一律不出手（与首领同规则）。 */
    @Override
    public boolean canAttack(LivingEntity target) {
        if (target == null || target == this || !target.isAlive()) return false;
        if (BossTauntLogic.isActive(this)) return false;
        // 邪魔（坍缩）个体与所有生物敌对，不再局限于反击最后伤害者。
        if (CalamityLogic.isCollapsed(this)) return CalamityLogic.canFactionCombatantAttack(this, target);
        return target == getLastHurtByMob();
    }

    /** 右键不认主、不骑乘、无任何交互：彩蛋生物只可远观。 */
    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        return InteractionResult.PASS;
    }

    /** 不会在普攻里摇自然陨石。 */
    @Override
    public void maybeCallMeteorOnAttack(LivingEntity target) {
    }

    /**
     * 死亡结算：掉落与潮曦奇美拉钩子。该机制是深蓝之树联动彩蛋的一部分，
     * <b>未安装深蓝之树时不生效</b>——召唤仪式本身照常产出替身，但替身被击杀
     * 不掉「哈基玖本人」，也不触发潮曦奇美拉。装有深蓝之树时：
     *
     * <ol>
     *   <li>击败者（伤害来源生物或直接来源）名字含 goodsquid：
     *       在原地生成本尊的潮曦奇美拉——与原模组「被击败后召唤怪物」的钩子同语义；</li>
     *   <li>掉落「哈基玖本人」：优先掉本尊的物品，查不到才掉本模组的等价复刻
     *       （食用受 32 点真实伤害、饥饿 -57、饱和度 -114）。</li>
     * </ol>
     */
    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (level().isClientSide || !(level() instanceof ServerLevel server)) return;
        // 未安装深蓝之树：掉落与召唤生物机制都不生效，这里直接结束结算。
        if (!CaerulaArborCompat.isLoaded()) return;
        // 死亡结算只跑一次：个别外部路径（斩杀、锁血兑现等）会二次调入 die。
        if (getPersistentData().getBoolean(DEATH_SETTLED)) return;
        getPersistentData().putBoolean(DEATH_SETTLED, true);
        if (isGoodsquidKill(source)) {
            CaerulaArborCompat.summonNativeTideChimera(server, position());
        }
        ItemStack theirs = CaerulaArborCompat.nativeApocataDropItem();
        if (!theirs.isEmpty()) {
            spawnAtLocation(theirs);
        } else {
            spawnAtLocation(new ItemStack(GeneratedMod.APOCATA_HIMSELF.get()));
        }
    }

    /** 伤害来源（或其直接来源）名字里含 goodsquid（不区分大小写）即为「凶手彩蛋」。 */
    private static boolean isGoodsquidKill(DamageSource source) {
        return nameContainsGoodsquid(source.getEntity())
                || nameContainsGoodsquid(source.getDirectEntity());
    }

    private static boolean nameContainsGoodsquid(Entity entity) {
        if (entity == null) return false;
        String name;
        if (entity instanceof Player player) {
            name = player.getGameProfile().getName();
        } else {
            name = entity.getDisplayName().getString();
        }
        return name != null && name.toLowerCase(Locale.ROOT).contains("goodsquid");
    }

    /** 供召唤逻辑复用：在指定位置放出一只野生哈基玖（本模组替身）。 */
    public static Apocata spawnStandIn(ServerLevel level, Vec3 pos) {
        Apocata apocata = GeneratedMod.APOCATA.get().create(level);
        if (apocata == null) return null;
        apocata.moveTo(pos.x, pos.y, pos.z, level.getRandom().nextFloat() * 360.0F, 0.0F);
        apocata.setPersistenceRequired();
        level.addFreshEntity(apocata);
        return apocata;
    }
}
