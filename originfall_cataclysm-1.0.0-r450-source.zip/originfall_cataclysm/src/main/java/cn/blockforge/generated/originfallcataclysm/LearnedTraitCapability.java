package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraft.world.entity.LivingEntity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
/**
 * 生物吞噬学习数据；服务端以 Capability 持久化，实体数据负责客户端只读同步。
 *
 * <p>词条按「词条名 → 等级」存储：重复获得同一词条时走 {@link #upgrade} 融合升级，
 * 只提升等级、不新增条目，因此不会占用词条数量；{@link #putAtLevel} 供首领初始生成
 * 直接按指定等级附带词条。</p>
 */
public final class LearnedTraitCapability {
    public static final Capability<LearnedTraitCapability> CAPABILITY = CapabilityManager.get(new CapabilityToken<>() {});
    private final Map<String, Integer> traits = new LinkedHashMap<>();
    private int limit;
    private Runnable dirtyListener = () -> {};
    /**
     * 同步编码串的惰性缓存：词条内容不变时复用同一个字符串实例。
     * 服务端每 tick 要对每只模组生物做一次「客户端同步串与本地数据是否一致」的兜底比对，
     * 原实现每次都重新拼一遍 {@link StringBuilder}，在生物数量大时是纯粹的 GC 压力；
     * 这里改为内容不变即复用，任何一次写入都会置空缓存。
     */
    private String encodedCache;

    public void setDirtyListener(Runnable listener) {
        dirtyListener = listener == null ? () -> {} : listener;
    }

    /** 词条与等级的只读快照（保持获得顺序）。 */
    public Map<String, Integer> getTraitLevels() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(traits));
    }

    public List<String> getTraits() {
        return Collections.unmodifiableList(new ArrayList<>(traits.keySet()));
    }

    public boolean has(String trait) {
        return traits.containsKey(trait);
    }

    /** 词条等级；未拥有返回 0。 */
    public int levelOf(String trait) {
        Integer level = traits.get(trait);
        return level == null ? 0 : level;
    }

    public int size() {
        return traits.size();
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int value) {
        int newLimit = Math.max(0, value);
        if (limit == newLimit) return;
        limit = newLimit;
        while (traits.size() > limit) {
            String last = null;
            for (String trait : traits.keySet()) last = trait;
            if (last == null) break;
            traits.remove(last);
        }
        markDirty();
    }

    public boolean add(String trait) {
        return putAtLevel(trait, 1);
    }

    /**
     * 以指定等级写入词条：已有词条时只融合升等级（不占新名额），
     * 新词条受数量上限约束。实际等级不超过 {@link LearnedTraitLogic#baseMaxLevel}。
     */
    public boolean putAtLevel(String trait, int level) {
        if (trait == null || trait.isBlank()) return false;
        int wanted = Math.max(1, Math.min(level, LearnedTraitLogic.baseMaxLevel(trait)));
        boolean known = traits.containsKey(trait);
        if (!known && traits.size() >= limit) return false;
        int current = known ? traits.get(trait) : 0;
        if (known && current >= wanted) return false;
        traits.put(trait, wanted);
        markDirty();
        return true;
    }

    /**
     * 融合升级：已拥有该词条且未达等级上限时提升 1 级，不占用词条数量。
     * @return 是否发生了升级
     */
    public boolean upgrade(String trait, int maxLevel) {
        Integer current = traits.get(trait);
        if (current == null || current >= LearnedTraitLogic.baseMaxLevel(trait)) return false;
        int cap = Math.min(maxLevel, LearnedTraitLogic.baseMaxLevel(trait));
        if (current >= cap) return false;
        traits.put(trait, current + 1);
        markDirty();
        return true;
    }

    public void clear() {
        if (traits.isEmpty()) return;
        traits.clear();
        markDirty();
    }

    /** 序列化为 "trait:level,trait:level"；等级为 1 时省略后缀。 */
    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putInt("Limit", limit);
        tag.putString("Traits", encode());
        return tag;
    }

    public void deserializeNBT(CompoundTag tag) {
        limit = Math.max(0, tag.getInt("Limit"));
        traits.clear();
        encodedCache = null;
        decode(tag.getString("Traits"));
    }

    /** 供实体数据同步使用的编码串；内容未变化时返回缓存实例。 */
    public String encoded() {
        if (encodedCache == null) encodedCache = encode();
        return encodedCache;
    }

    /** 词条内容发生变化的统一出口：先让编码缓存失效，再通知持久化监听器。 */
    private void markDirty() {
        encodedCache = null;
        dirtyListener.run();
    }

    private String encode() {
        StringBuilder builder = new StringBuilder();
        for (Map.Entry<String, Integer> entry : traits.entrySet()) {
            if (builder.length() > 0) builder.append(',');
            builder.append(entry.getKey());
            if (entry.getValue() > 1) builder.append(':').append(entry.getValue());
        }
        return builder.toString();
    }

    private void decode(String encoded) {
        if (encoded == null || encoded.isBlank()) return;
        for (String token : encoded.split(",")) {
            if (token.isBlank()) continue;
            int sep = token.indexOf(':');
            String name = sep < 0 ? token : token.substring(0, sep);
            int level = 1;
            if (sep >= 0) {
                try {
                    level = Math.max(1, Integer.parseInt(token.substring(sep + 1)));
                } catch (NumberFormatException ignored) {
                    level = 1;
                }
            }
            if (traits.size() < limit) {
                traits.put(name, Math.min(level, LearnedTraitLogic.baseMaxLevel(name)));
            }
        }
    }

    public static LearnedTraitCapability get(LivingEntity entity) {
        return entity.getCapability(CAPABILITY).orElseThrow(IllegalStateException::new);
    }

    public static LearnedTraitCapability getOrNull(LivingEntity entity) {
        return entity.getCapability(CAPABILITY).orElse(null);
    }
}
