package cn.blockforge.generated.originfallcataclysm;

import cn.blockforge.generated.originfallcataclysm.client.NativeApocataDanceState;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.SwordItem;

/**
 * 博士 / 普瑞赛斯等人形首领的模型：<b>原版玩家骨架 + 可弯的肘与膝</b>。
 *
 * <p>躯干、头、脚这些部件完全沿用 {@link HumanoidModel#createMesh} 的原版骨架（轴心、立方体、
 * 64×64 贴图 UV 一律不动），只在两条手臂的中段加了一节「小臂」、两条腿的中段加了一节
 * 「小腿」，让舞蹈能做出完整的屈肘与屈膝：</p>
 * <ul>
 *   <li>{@code right_arm}/{@code left_arm} 只画上半截（肩到肘，7 像素高），
 *       下半截挂成它的子骨骼 {@code right_fore_arm}/{@code left_fore_arm}，轴心落在肘上；</li>
 *   <li>{@code right_leg}/{@code left_leg} 只画大腿（胯到膝，6 像素高），
 *       小腿挂成子骨骼 {@code right_shin}/{@code left_shin}，轴心落在膝上；</li>
 *   <li>两截的贴图 UV 按原版 64×64 布局对齐（上臂用纹理 20~27 行、小臂用 27~32 行，
 *       大腿 20~26 行、小腿 26~32 行），关节角为 0 时两截严丝合缝，看起来和原版
 *       整条手臂/腿完全一样。</li>
 * </ul>
 *
 * <p><b>历史教训（本轮以受控方式恢复衔接块）。</b>更早一版曾在每个转轴处加过一圈
 * 「十字」填缝块并且<b>常显</b>：关节只要一转（走路摆臂、回头都会转）填块就从缝里
 * 戳出来，一块身体贴图浮到头、脖子旁边，连不跳舞的生物也一起遭殃，于是全部撤掉。
 * 本轮需求「肢体与躯干平滑链接」：深蹲、趴地、收势 62° 交叉伸腿这些大角度姿势里
 * 胯/肩/颈确实会张出楔形缺口。折中做法是再把这些衔接块加回来，但<b>默认
 * {@code skipDraw=true} 完全不参与渲染</b>，只有 {@link BossTauntPose} 在跳舞期间才
 * 点亮；舞停立即熄灭，普通走位/攻击/待机与加块之前逐像素一致。块的尺寸都收在
 * 相邻骨骼的包络内（内缩 0.02 防共面闪烁），静止姿势下即使点亮也全部藏在体内。</p>
 *
 * <p>舞蹈姿势只驱动本骨架自带的部件，见 {@link BossTauntPose}；躯干改为绕胯轴旋转，
 * 因此弯腰时躯干与腿始终连在一起。</p>
 *
 * <p>泛型上界取 {@link LivingEntity} 而非 {@link CalamityMob}：自家生物之外，这套骨架还
 * 兼任深蓝之树本尊哈基玖（外部实体）的「扒臀长舞」代跳渲染——本尊拿不到模组的同步实体
 * 数据，setupAnim 按实体类型分流到 {@link NativeApocataDanceState} 的舞程倒计时
 * （见 {@code NativeApocataAppearanceEvents} 的渲染接管）。</p>
 */
public final class CalamityHumanoidModel<T extends LivingEntity> extends HumanoidModel<T> {
    /** 根骨骼：整段舞蹈的原地旋转与下蹲位移挂在它上面。 */
    private final ModelPart rootPart;
    /** 小臂（肘关节），相对上臂旋转。 */
    private final ModelPart rightForeArm;
    private final ModelPart leftForeArm;
    /** 小腿（膝关节），相对大腿旋转。 */
    private final ModelPart rightShin;
    private final ModelPart leftShin;
    /** 舞蹈衔接填缝块（颈/骨盆/双肩/双髋）。默认 {@code skipDraw=true} 完全不渲染，
     *  只有 {@link BossTauntPose#apply} 在跳舞期间调 {@link #setDanceJunctionsVisible}
     *  点亮；任何非跳舞状态下与没有这些块时逐像素一致（见类注释的历史教训）。 */
    private final ModelPart[] danceJunctions;
    /** 眨眼眼睑（仅身体层有）：睁眼 skipDraw，闭眼按节律沿眉线向下生长，见 {@link BlinkLids}。 */
    private final ModelPart blinkLidRight;
    private final ModelPart blinkLidLeft;

    public CalamityHumanoidModel(ModelPart root) {
        super(root);
        this.rootPart = root;
        this.rightForeArm = root.getChild("right_arm").getChild("right_fore_arm");
        this.leftForeArm = root.getChild("left_arm").getChild("left_fore_arm");
        this.rightShin = root.getChild("right_leg").getChild("right_shin");
        this.leftShin = root.getChild("left_leg").getChild("left_shin");
        ModelPart[] junctions = new ModelPart[] {
            root.getChild("head").getChild("dance_neck"),
            root.getChild("body").getChild("dance_pelvis"),
            root.getChild("right_arm").getChild("dance_shoulder"),
            root.getChild("left_arm").getChild("dance_shoulder"),
            root.getChild("right_leg").getChild("dance_hip"),
            root.getChild("left_leg").getChild("dance_hip"),
        };
        int n = 0;
        for (ModelPart p : junctions) {
            if (p != null) {
                junctions[n++] = p;
            }
        }
        this.danceJunctions = java.util.Arrays.copyOf(junctions, n);
        for (ModelPart p : this.danceJunctions) {
            p.skipDraw = true;
        }
        ModelPart headPart = root.getChild("head");
        this.blinkLidRight = BlinkLids.find(headPart, "blink_lid_right");
        this.blinkLidLeft = BlinkLids.find(headPart, "blink_lid_left");
        if (this.blinkLidRight != null) this.blinkLidRight.skipDraw = true;
        if (this.blinkLidLeft != null) this.blinkLidLeft.skipDraw = true;
    }

    /**
     * 舞蹈姿势的躯干衔接块开关：跳舞期间 {@code true}（深蹲、趴地、收势 62° 交叉伸腿
     * 这些大角度里补上胯/肩/颈张开的楔形缺口，肢体与躯干平滑连接）；舞停 {@code false}，
     * 普通走位、攻击、待机一切照旧。
     */
    public void setDanceJunctionsVisible(boolean visible) {
        for (ModelPart p : danceJunctions) {
            p.skipDraw = !visible;
        }
    }

    public ModelPart rootPart() {
        return rootPart;
    }

    public ModelPart foreArm(HumanoidArm arm) {
        return arm == HumanoidArm.RIGHT ? rightForeArm : leftForeArm;
    }

    public ModelPart shin(HumanoidArm arm) {
        return arm == HumanoidArm.RIGHT ? rightShin : leftShin;
    }

    @Override
    public void prepareMobModel(T entity, float limbSwing, float limbSwingAmount, float partialTick) {
        super.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTick);
        applyRangedArmPoses(entity);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        if (entity instanceof CalamityMob mob) {
            // 「扒臀长舞」：跳舞倒计时生效期间用 Blockbench 关键帧动画覆盖常规肢体动画。
            // netHeadYaw / headPitch 一并传下去——那是原版算好的「生物按现有方向的扭头」，
            // 关键帧只覆盖头会把它抹掉（原「原有扭头未生效」），合成见 BossTauntPose。
            BossTauntPose.apply(this, mob, ageInTicks, netHeadYaw, headPitch);
        } else {
            // 深蓝之树本尊代跳（外部实体，无同步实体数据）：舞程取客户端舞蹈会话表，
            // 姿势与替身同一通道；无会话时 BossTauntPose 自行复位本类动过的量。
            BossTauntPose.applyNative(this, NativeApocataDanceState.remaining(entity.getId()),
                    NativeApocataDanceState.total(entity.getId()), ageInTicks);
        }
        // 眨眼（纯外貌）：随头骨骼走，睁眼时两块眼睑完全 skipDraw。
        BlinkLids.apply(blinkLidRight, blinkLidLeft, entity, ageInTicks);
    }

    /**
     * 手持物的锚点：原版只把手交付到<b>肩轴</b>，物品层再沿手臂方向补 10 像素（0.625 格）
     * 落到手上。手臂拆成两节之后，那 10 像素必须从小臂末端往回量，否则肘一弯物品就会
     * 脱在手外面；所以这里先补上小臂自己的旋转，再沿小臂方向退回 5 像素（0.3125 格，
     * 等于「肩到肘 5 像素 + 肘到手 5 像素」里多出来的那一段），让物品层固定的
     * 「10 像素」正好落回小臂末端。
     */
    @Override
    public void translateToHand(HumanoidArm arm, PoseStack poseStack) {
        ModelPart upper = getArm(arm);
        upper.translateAndRotate(poseStack);
        foreArm(arm).translateAndRotate(poseStack);
        poseStack.translate(0.0F, -0.3125F, 0.0F);
    }

    private void applyRangedArmPoses(T entity) {
        leftArmPose = ArmPose.EMPTY;
        rightArmPose = ArmPose.EMPTY;
        ItemStack weapon = entity.getMainHandItem();
        HumanoidArm weaponArm = entity.getMainArm();
        if (isSwordWeapon(weapon)) {
            // 影霄、如我所见、天堂支点等剑类武器统一按原版单手持剑姿势（同钻石剑）适配。
            setPose(weaponArm, ArmPose.ITEM);
        } else if (weapon.getItem() instanceof BowItem && entity.isUsingItem()
                && entity.getUsedItemHand() == InteractionHand.MAIN_HAND) {
            setPose(weaponArm, ArmPose.BOW_AND_ARROW);
        } else if (weapon.getItem() instanceof CrossbowItem) {
            ArmPose pose = CrossbowItem.isCharged(weapon) ? ArmPose.CROSSBOW_HOLD : ArmPose.CROSSBOW_CHARGE;
            setPose(weaponArm, pose);
        } else if (weapon.is(Items.TRIDENT) && entity.isUsingItem()
                && entity.getUsedItemHand() == InteractionHand.MAIN_HAND) {
            setPose(weaponArm, ArmPose.THROW_SPEAR);
        }
    }

    /** 是否为剑类武器：模组三把剑（影霄/如我所见/天堂支点）及所有原版剑统一按钻石剑的持握动作适配。 */
    private static boolean isSwordWeapon(ItemStack weapon) {
        return weapon.getItem() instanceof SwordItem;
    }

    private void setPose(HumanoidArm arm, ArmPose pose) {
        if (arm == HumanoidArm.RIGHT) {
            rightArmPose = pose;
        } else {
            leftArmPose = pose;
        }
    }

    public static LayerDefinition createBodyLayer() {
        return createLayer(CubeDeformation.NONE);
    }

    public static LayerDefinition createInnerArmorLayer() {
        return createLayer(new CubeDeformation(0.5F));
    }

    public static LayerDefinition createOuterArmorLayer() {
        return createLayer(new CubeDeformation(1.0F));
    }

    /**
     * 从原版玩家人形网格出发，只把四条肢体各换成「上段 + 下段」两节，其余一律照抄原版。
     *
     * <p>UV 说明（以右臂为例，原版整条手臂是 {@code texOffs(40,16)} 的 4×12×4 立方体）：
     * 侧面贴图占纹理 20~32 行，上臂取 {@code texOffs(40,16)} 的 7 像素高立方体 → 侧面正好
     * 落在 20~27 行；小臂取 {@code texOffs(40,23)} 的 5 像素高立方体 → 侧面落在 27~32 行。
     * 上下两段的顶/底面被压在关节内部，取到的是相邻的皮肤像素，看不出破绽。</p>
     */
    private static LayerDefinition createLayer(CubeDeformation deformation) {
        MeshDefinition mesh = HumanoidModel.createMesh(deformation, 0.0F);
        PartDefinition root = mesh.getRoot();

        // 右臂：肩到肘 + 肘到手。
        PartDefinition rightArm = root.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(40, 16)
                        .addBox(-3.0F, -2.0F, -2.0F, 4.0F, 7.0F, 4.0F, deformation),
                PartPose.offset(-5.0F, 2.0F, 0.0F));
        rightArm.addOrReplaceChild("right_fore_arm",
                CubeListBuilder.create().texOffs(40, 23)
                        .addBox(-3.0F, 0.0F, -2.0F, 4.0F, 5.0F, 4.0F, deformation),
                PartPose.offset(0.0F, 5.0F, 0.0F));

        // 左臂（原版用 mirror 复用同一块贴图）。
        PartDefinition leftArm = root.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(40, 16).mirror()
                        .addBox(-1.0F, -2.0F, -2.0F, 4.0F, 7.0F, 4.0F, deformation),
                PartPose.offset(5.0F, 2.0F, 0.0F));
        leftArm.addOrReplaceChild("left_fore_arm",
                CubeListBuilder.create().texOffs(40, 23).mirror()
                        .addBox(-1.0F, 0.0F, -2.0F, 4.0F, 5.0F, 4.0F, deformation),
                PartPose.offset(0.0F, 5.0F, 0.0F));

        // 右腿：胯到膝 + 膝到脚。
        PartDefinition rightLeg = root.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(0, 16)
                        .addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, deformation),
                PartPose.offset(-1.9F, 12.0F, 0.0F));
        rightLeg.addOrReplaceChild("right_shin",
                CubeListBuilder.create().texOffs(0, 22)
                        .addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, deformation),
                PartPose.offset(0.0F, 6.0F, 0.0F));

        // 左腿。
        PartDefinition leftLeg = root.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(0, 16).mirror()
                        .addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, deformation),
                PartPose.offset(1.9F, 12.0F, 0.0F));
        leftLeg.addOrReplaceChild("left_shin",
                CubeListBuilder.create().texOffs(0, 22).mirror()
                        .addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, deformation),
                PartPose.offset(0.0F, 6.0F, 0.0F));

        // 舞蹈衔接填缝块（只在身体层加；装甲层变形网格一律不带，见类注释）。
        // 每组是挂在转轴「下游骨骼」上的十字对：两块互垂直射的板以轴心为中心，
        // 并集近似半径 2（肢宽一半）的圆柱——肢体绕该轴转到任何角度，圆柱都留在
        // 缺口里，把躯干与肢节之间张开的楔形缝填满；直臂垂手时两块都收在四肢与
        // 躯干方块自身的包络内（边缘内缩 0.02 防共面闪烁），静止站姿看不出多块。
        // 默认 skipDraw=true，只有跳舞期间由 BossTauntPose 点亮。
        if (deformation == CubeDeformation.NONE) {
            PartDefinition head = root.getChild("head");
            PartDefinition body = root.getChild("body");

            BlinkLids.addEyelids(head, deformation);

            head.addOrReplaceChild("dance_neck",
                    CubeListBuilder.create().texOffs(16, 16)
                            .addBox(-2.9F, 0.02F, -1.9F, 5.8F, 2.5F, 3.8F, deformation),
                    PartPose.offset(0.0F, 0.0F, 0.0F));
            body.addOrReplaceChild("dance_pelvis",
                    CubeListBuilder.create().texOffs(16, 16)
                            .addBox(-3.88F, 11.98F, -1.98F, 7.76F, 2.06F, 3.96F, deformation),
                    PartPose.offset(0.0F, 0.0F, 0.0F));
            rightArm.addOrReplaceChild("dance_shoulder",
                    CubeListBuilder.create().texOffs(40, 16)
                            .addBox(-3.0F, -1.98F, -0.98F, 5.98F, 3.96F, 1.96F, deformation)
                            .addBox(-3.0F, -0.98F, -1.98F, 5.98F, 1.96F, 3.96F, deformation),
                    PartPose.offset(0.0F, 0.0F, 0.0F));
            leftArm.addOrReplaceChild("dance_shoulder",
                    CubeListBuilder.create().texOffs(40, 16).mirror()
                            .addBox(-2.98F, -1.98F, -0.98F, 5.98F, 3.96F, 1.96F, deformation)
                            .addBox(-2.98F, -0.98F, -1.98F, 5.98F, 1.96F, 3.96F, deformation),
                    PartPose.offset(0.0F, 0.0F, 0.0F));
            rightLeg.addOrReplaceChild("dance_hip",
                    CubeListBuilder.create().texOffs(0, 16)
                            .addBox(-1.98F, -1.98F, -0.98F, 3.96F, 3.96F, 1.96F, deformation)
                            .addBox(-1.98F, -0.98F, -1.98F, 3.96F, 1.96F, 3.96F, deformation),
                    PartPose.offset(0.0F, 0.0F, 0.0F));
            leftLeg.addOrReplaceChild("dance_hip",
                    CubeListBuilder.create().texOffs(0, 16).mirror()
                            .addBox(-1.98F, -1.98F, -0.98F, 3.96F, 3.96F, 1.96F, deformation)
                            .addBox(-1.98F, -0.98F, -1.98F, 3.96F, 1.96F, 3.96F, deformation),
                    PartPose.offset(0.0F, 0.0F, 0.0F));
        }

        return LayerDefinition.create(mesh, 64, 64);
    }
}
