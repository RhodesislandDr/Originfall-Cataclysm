package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.level.GameRules;

/**
 * 本模组的世界级游戏规则。规则值随存档保存，可通过 /gamerule 修改。
 * 必须在模组构造阶段完成注册，因此由 GeneratedMod 的构造函数主动加载本类。
 */
public final class OriginFallGameRules {
    /** 转化生物密度：3*3 区块内允许同时存在的最高数量，范围 1~100，默认 15。 */
    public static final int CONVERSION_DENSITY_MIN = 1;
    public static final int CONVERSION_DENSITY_MAX = 100;
    public static final int CONVERSION_DENSITY_DEFAULT = 15;

    public static final GameRules.Key<GameRules.IntegerValue> CONVERSION_MOB_DENSITY =
            GameRules.register("originfallConversionMobDensity", GameRules.Category.MOBS,
                    GameRules.IntegerValue.create(CONVERSION_DENSITY_DEFAULT,
                            OriginFallGameRules::clampConversionDensity));
    /**
     * 初始转化概率：源石感染期间被源石阵营实体击杀时参与转化判定的基础概率（百分比数值）。
     * 1~100，必须为整数，初始数值 32；每层感染另加 3.25%（见 CalamityLogic）。
     */
    public static final int INITIAL_CONVERSION_CHANCE_MIN = 1;
    public static final int INITIAL_CONVERSION_CHANCE_MAX = 100;
    public static final int INITIAL_CONVERSION_CHANCE_DEFAULT = 32;

    public static final GameRules.Key<GameRules.IntegerValue> INITIAL_CONVERSION_CHANCE =
            GameRules.register("originfallInitialConversionChance", GameRules.Category.MOBS,
                    GameRules.IntegerValue.create(INITIAL_CONVERSION_CHANCE_DEFAULT,
                            OriginFallGameRules::clampInitialConversionChance));
    /** 巴别塔行动模式：开启后源石阵营攻击所有非源石阵营生物，默认关闭。 */
    public static final GameRules.Key<GameRules.BooleanValue> BABEL_ACTION_MODE =
            GameRules.register("originfallBabelActionMode", GameRules.Category.MOBS,
                    GameRules.BooleanValue.create(false));
    /**
     * 源石计划进度：难度分级规则，0~18 共十九档，依次对应 -99、-95、-90、-80、-70、
     * -60、-50、-40、-30、-20、-10、0、10、20、30、40、50、60、70 百分比，默认 11 档（0%）。
     * 按档位等比放大（或缩小）首领的各种提升幅度、陨石的爆炸伤害（向下取整）、
     * 转化生物与复活时原数值之外的提升、生物的战斗与机制提升、源石感染的削弱幅度，
     * 以及邪魔（坍缩）的感染强化与各项机制加成幅度；其中对地形感染（陨石晶化替换半径）
     * 的影响降为原影响比例的 10%；对邪魔区域累计感染时间，负比例为延长比例、
     * 正比例为缩短比例（基准 10 秒）。换算与接入点见 {@link OriginiumPlanProgress}。
     */
    public static final int ORIGINIUM_PLAN_PROGRESS_MIN = OriginiumPlanProgress.MIN_TIER;
    public static final int ORIGINIUM_PLAN_PROGRESS_MAX = OriginiumPlanProgress.MAX_TIER;
    public static final int ORIGINIUM_PLAN_PROGRESS_DEFAULT = OriginiumPlanProgress.DEFAULT_TIER;

    public static final GameRules.Key<GameRules.IntegerValue> ORIGINIUM_PLAN_PROGRESS =
            GameRules.register("originfallOriginiumPlanProgress", GameRules.Category.MOBS,
                    GameRules.IntegerValue.create(ORIGINIUM_PLAN_PROGRESS_DEFAULT,
                            OriginFallGameRules::clampOriginiumPlanProgress));
    /**
     * 规则改写：控制源石能否侵染「无法破坏」类型的方块（基岩、屏障这类破坏速度为负的方块）。
     * 默认关闭——感染地块与陨石晶化都会跳过这类方块；开启后源石改写规则，
     * 连无法破坏的方块都会被晶化为黑色晶体。判定见 {@link CalamityLogic#infectedBlockAllowed}。
     */
    public static final GameRules.Key<GameRules.BooleanValue> RULE_REWRITE =
            GameRules.register("originfallRuleRewrite", GameRules.Category.MOBS,
                    GameRules.BooleanValue.create(false));
    /**
     * 坍缩渗透：开启后每个晚上 0 点（游戏时间，即 18000 刻）判定一次，
     * 以 32.5% 为基础概率感染一只随机生物；当天未感染则次日概率增加 32.5%，
     * 最高 100%，直到成功感染时回到 32.5%。默认关闭。
     */
    public static final GameRules.Key<GameRules.BooleanValue> COLLAPSE_INFILTRATION =
            GameRules.register("originfallCollapseInfiltration", GameRules.Category.MOBS,
                    GameRules.BooleanValue.create(false));
    /** 全舰防御系统：开启时特蕾西娅以初生魔王生成机制 1% 的概率自然刷新，默认开启。 */
    public static final GameRules.Key<GameRules.BooleanValue> FULL_SHIP_DEFENSE_SYSTEM =
            GameRules.register("originfallFullShipDefenseSystem", GameRules.Category.SPAWNING,
                    GameRules.BooleanValue.create(true));
    /** “这片大地”的传承：生物持有的模组武器必定掉落（玩家除外），默认开启。 */
    public static final GameRules.Key<GameRules.BooleanValue> LAND_INHERITANCE =
            GameRules.register("originfallLandInheritance", GameRules.Category.DROPS,
                    GameRules.BooleanValue.create(true));

    private OriginFallGameRules() {
    }

    /** 主动触发一次类加载，保证八条规则在模组构造阶段完成注册。 */
    public static void bootstrap() {
        // 引用常量即可触发静态初始化；规则注册本身在静态字段中完成。
        Object ignored = CONVERSION_MOB_DENSITY;
        ignored = INITIAL_CONVERSION_CHANCE;
        ignored = BABEL_ACTION_MODE;
        ignored = ORIGINIUM_PLAN_PROGRESS;
        ignored = RULE_REWRITE;
        ignored = COLLAPSE_INFILTRATION;
        ignored = FULL_SHIP_DEFENSE_SYSTEM;
        ignored = LAND_INHERITANCE;
    }

    private static void clampConversionDensity(MinecraftServer server, GameRules.IntegerValue value) {
        int clamped = Mth.clamp(value.get(), CONVERSION_DENSITY_MIN, CONVERSION_DENSITY_MAX);
        if (clamped != value.get()) value.set(clamped, server);
    }

    /** 存档里的越界值同样按 1~100 处理；命令入口本就是整数，无需再截断小数。 */
    private static void clampInitialConversionChance(MinecraftServer server, GameRules.IntegerValue value) {
        int clamped = Mth.clamp(value.get(), INITIAL_CONVERSION_CHANCE_MIN, INITIAL_CONVERSION_CHANCE_MAX);
        if (clamped != value.get()) value.set(clamped, server);
    }

    /** 进度档位命令入口同样夹紧到 0~18，防止越界档位进入换算表。 */
    private static void clampOriginiumPlanProgress(MinecraftServer server, GameRules.IntegerValue value) {
        int clamped = Mth.clamp(value.get(), ORIGINIUM_PLAN_PROGRESS_MIN, ORIGINIUM_PLAN_PROGRESS_MAX);
        if (clamped != value.get()) value.set(clamped, server);
    }

    /**
     * 读取「源石计划进度」档位（0~18）。规则是服务器级的，客户端世界同样持有同步副本，
     * 因此这里接受任意 {@link net.minecraft.world.level.Level}。
     */
    public static int originiumPlanProgressTier(net.minecraft.world.level.Level level) {
        if (level == null) return ORIGINIUM_PLAN_PROGRESS_DEFAULT;
        return Mth.clamp(level.getGameRules().getInt(ORIGINIUM_PLAN_PROGRESS),
                ORIGINIUM_PLAN_PROGRESS_MIN, ORIGINIUM_PLAN_PROGRESS_MAX);
    }

    /** 读取并夹紧密度上限；存档里的越界值同样按 1~100 处理。 */
    public static int conversionMobDensity(ServerLevel level) {
        if (level == null) return CONVERSION_DENSITY_DEFAULT;
        return Mth.clamp(level.getGameRules().getInt(CONVERSION_MOB_DENSITY),
                CONVERSION_DENSITY_MIN, CONVERSION_DENSITY_MAX);
    }

    /** 读取「初始转化概率」规则值（百分比数值，1~100 的整数）；存档越界值同样先夹紧。 */
    public static int initialConversionChance(ServerLevel level) {
        if (level == null) return INITIAL_CONVERSION_CHANCE_DEFAULT;
        return Mth.clamp(level.getGameRules().getInt(INITIAL_CONVERSION_CHANCE),
                INITIAL_CONVERSION_CHANCE_MIN, INITIAL_CONVERSION_CHANCE_MAX);
    }

    public static boolean isBabelActionMode(ServerLevel level) {
        return level != null && level.getGameRules().getBoolean(BABEL_ACTION_MODE);
    }

    public static boolean isCollapseInfiltration(ServerLevel level) {
        return level != null && level.getGameRules().getBoolean(COLLAPSE_INFILTRATION);
    }

    /** 「规则改写」：源石能否侵染破坏速度为负（无法破坏）的方块。 */
    public static boolean isRuleRewrite(ServerLevel level) {
        return level != null && level.getGameRules().getBoolean(RULE_REWRITE);
    }

    public static boolean isFullShipDefenseSystem(ServerLevel level) {
        return level != null && level.getGameRules().getBoolean(FULL_SHIP_DEFENSE_SYSTEM);
    }

    public static boolean isLandInheritance(ServerLevel level) {
        return level != null && level.getGameRules().getBoolean(LAND_INHERITANCE);
    }

    /** 生物实体上取不到等级时按默认值处理，避免客户端路径抛异常。 */
    public static int conversionMobDensity(net.minecraft.world.entity.LivingEntity entity) {
        return entity != null && entity.level() instanceof ServerLevel level
                ? conversionMobDensity(level) : CONVERSION_DENSITY_DEFAULT;
    }

    public static boolean isBabelActionMode(net.minecraft.world.entity.LivingEntity entity) {
        return entity != null && entity.level() instanceof ServerLevel level && isBabelActionMode(level);
    }

    public static boolean isLandInheritance(net.minecraft.world.entity.LivingEntity entity) {
        return entity != null && entity.level() instanceof ServerLevel level && isLandInheritance(level);
    }
}
