package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.CalamityLogic;
import cn.blockforge.generated.originfallcataclysm.GeneratedMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.EffectRenderingInventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraftforge.client.extensions.common.IClientMobEffectExtensions;

/** 以阿拉伯数字显示坍缩层数，避免原版药水效果使用罗马数字。 */
public final class CollapseClientExtension implements IClientMobEffectExtensions {
    @Override
    public boolean renderInventoryText(MobEffectInstance effect, EffectRenderingInventoryScreen screen,
                                       GuiGraphics graphics, int x, int y, int blitOffset) {
        if (effect.getEffect() != GeneratedMod.COLLAPSE.get()) return false;
        int layers = CalamityLogic.collapseLayersFromAmplifier(effect.getAmplifier());
        Minecraft minecraft = Minecraft.getInstance();
        graphics.drawString(minecraft.font,
                Component.literal("坍缩 " + layers), x + 28, y + 6, 0xFFFFFFFF);
        return true;
    }
}
