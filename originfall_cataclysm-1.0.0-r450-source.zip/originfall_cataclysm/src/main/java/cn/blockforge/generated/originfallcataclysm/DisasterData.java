package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.saveddata.SavedData;

/** 每个维度独立保存灾难控制状态。 */
public final class DisasterData extends SavedData {
    private static final String DATA_NAME = "originfall_disaster_state";
    private boolean calamityActive;
    private boolean sourceUsed;
    private boolean salvationUsed;
    private boolean messengerUsed;
    private boolean hardcoreInitialized;
    private boolean continuanceOpeningMeteorsSpawned;
    private long nextMeteorTick = -1L;
    /** 「坍缩渗透」当前的判定概率（0~1）；未命中时每天增加一档，命中后回到基础值。 */
    private double collapseInfiltrationChance = CollapseInfiltration.BASE_CHANCE;
    /** 已经完成过「坍缩渗透」判定的夜晚编号（游戏日），保证每夜只判定一次。 */
    private long collapseInfiltrationLastNight = -1L;

    public static DisasterData load(CompoundTag tag) {
        DisasterData data = new DisasterData();
        data.calamityActive = tag.getBoolean("CalamityActive");
        data.sourceUsed = tag.getBoolean("SourceUsed");
        data.salvationUsed = tag.getBoolean("SalvationUsed");
        data.messengerUsed = tag.getBoolean("MessengerUsed");
        data.hardcoreInitialized = tag.getBoolean("HardcoreInitialized");
        data.continuanceOpeningMeteorsSpawned = tag.getBoolean("ContinuanceOpeningMeteorsSpawned");
        data.nextMeteorTick = tag.contains("NextMeteorTick") ? tag.getLong("NextMeteorTick") : -1L;
        data.collapseInfiltrationChance = tag.contains("CollapseInfiltrationChance")
                ? tag.getDouble("CollapseInfiltrationChance") : CollapseInfiltration.BASE_CHANCE;
        data.collapseInfiltrationLastNight = tag.contains("CollapseInfiltrationLastNight")
                ? tag.getLong("CollapseInfiltrationLastNight") : -1L;
        return data;
    }

    public static DisasterData get(net.minecraft.server.level.ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(DisasterData::load, DisasterData::new, DATA_NAME);
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("CalamityActive", calamityActive);
        tag.putBoolean("SourceUsed", sourceUsed);
        tag.putBoolean("SalvationUsed", salvationUsed);
        tag.putBoolean("MessengerUsed", messengerUsed);
        tag.putBoolean("HardcoreInitialized", hardcoreInitialized);
        tag.putBoolean("ContinuanceOpeningMeteorsSpawned", continuanceOpeningMeteorsSpawned);
        tag.putLong("NextMeteorTick", nextMeteorTick);
        tag.putDouble("CollapseInfiltrationChance", collapseInfiltrationChance);
        tag.putLong("CollapseInfiltrationLastNight", collapseInfiltrationLastNight);
        return tag;
    }

    public boolean isCalamityActive() { return calamityActive; }
    public boolean isSourceUsed() { return sourceUsed; }
    public boolean isSalvationUsed() { return salvationUsed; }
    public boolean isMessengerUsed() { return messengerUsed; }
    public boolean isHardcoreInitialized() { return hardcoreInitialized; }
    public boolean isContinuanceOpeningMeteorsSpawned() { return continuanceOpeningMeteorsSpawned; }
    public void markContinuanceOpeningMeteorsSpawned() {
        if (!continuanceOpeningMeteorsSpawned) {
            continuanceOpeningMeteorsSpawned = true;
            setDirty();
        }
    }
    public long getNextMeteorTick() { return nextMeteorTick; }
    public void scheduleNextMeteor(long tick) {
        nextMeteorTick = tick;
        setDirty();
    }

    public void initializeHardcore() {
        if (!hardcoreInitialized) {
            hardcoreInitialized = true;
            setDirty();
        }
    }

    public void activateHardcore() {
        if (!calamityActive || !sourceUsed) {
            calamityActive = true;
            sourceUsed = true;
            setDirty();
        }
    }

    public void activateBySource() {
        if (!sourceUsed) {
            sourceUsed = true;
            calamityActive = true;
            setDirty();
        }
    }

    public void activateByContinuance() {
        if (!calamityActive || !sourceUsed) {
            sourceUsed = true;
            calamityActive = true;
            setDirty();
        }
    }

    public void deactivateBySalvation() {
        if (!salvationUsed) {
            salvationUsed = true;
            calamityActive = false;
            setDirty();
        }
    }

    /** 强制关闭天灾状态；用于已经开启文明延续后的双模式终止。 */
    public void deactivateCalamity() {
        if (calamityActive) {
            calamityActive = false;
            setDirty();
        }
    }

    public boolean useMessenger() {
        if (messengerUsed) return false;
        messengerUsed = true;
        calamityActive = !calamityActive;
        setDirty();
        return true;
    }

    /** 「坍缩渗透」当前判定概率（0~1）。 */
    public double getCollapseInfiltrationChance() {
        return collapseInfiltrationChance;
    }

    public void setCollapseInfiltrationChance(double chance) {
        double clamped = Math.max(0.0D, Math.min(1.0D, chance));
        if (clamped != collapseInfiltrationChance) {
            collapseInfiltrationChance = clamped;
            setDirty();
        }
    }

    /** 已完成判定的最后一个夜晚编号；{@code -1} 表示尚未判定过。 */
    public long getCollapseInfiltrationLastNight() {
        return collapseInfiltrationLastNight;
    }

    /** 记录本夜已经判定过，避免同一夜重复触发。 */
    public void markCollapseInfiltrationNight(long night) {
        if (collapseInfiltrationLastNight != night) {
            collapseInfiltrationLastNight = night;
            setDirty();
        }
    }
}
