package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.UUID;

/**
 * 生命值上限归零的死亡结算（纯原版实现，不依赖史诗战斗等任何外部模组）：
 * 1. 本逻辑此前为兜住削减给所有实体设“生存下限”修饰符，把生效上限钉回 1：削减再狠，
 *    生物也只是卡在 1/1 半心、永不倒下，死亡之后还会被“击杀即转化”复活成灾厄生物——
 *    这就是“扣除生命上限死后仍保留实体”的根源（原版 1.20.1 MAX_HEALTH 生效值下限是
 *    2.0E-10，并不会把它钉在 1）。本类按原版 calculateValue 的公式还原
 *    未经截断的原始上限总值：(base + Σ加值) × (1 + Σ基乘) × Π(1 + 总乘)；
 *    原始总值降到 0 及以下，即“生命值上限降低为 0”。
 * 2. 归零即视为正常死亡：直接走原版死亡管线（死亡事件、掉落、统计），实体必定被移除。
 * 3. 这类死亡一律“无法复活”：并入 TiantangzhidianLogic.isNoRevive 判定，天灾复活波次、
 *    死亡陨石及其衍生链全部阻断；“击杀后转化为天灾生物”“陨石致命转化”同样被拒绝。
 * 4. 玩家按“保底 2 点”口径处理，正常情况下不会走到本结算：天堂支点的属性同步把
 *    玩家生效上限最低钉到 2 点（上限削减最多降到 2，削不进的部分在削减入口转为
 *    真实伤害），旧存档残留的归零状态同样被保底抬回。仅当外部模组在两次同步之间
 *    把上限削到归零时才按正常死亡兜底：玩家死过一次后置“钉”标记，复活重生不再
 *    重复结算（修复“削减上限死亡后重复死亡、无法复活”的死循环），并复用“阴”
 *    处刑的 5 分钟处刑锁定，锁定期间武器生命加成视为 0。
 * 5. 创造/旁观玩家不因上限归零死亡。
 */
public final class MaxHealthZeroLogic {

    /** 归零结算前写入；所有复活、转化与死亡衍生链读取它并据此阻断。 */
    public static final String CAP_ZERO_DEATH = "OfcCapZeroDeath";
    /** 玩家归零死亡后的“复活上限为 1”状态：跨重生保留，阻止对同一玩家重复归零结算。 */
    public static final String CAP_ZERO_PIN = "OfcCapZeroPin";
    /** 把上限削减到 0 的最后一位削减者；归零死亡按击杀者归属结算，供掉落与统计使用。 */
    private static final String CAP_ZERO_KILLER = "OfcCapZeroKiller";

    /** 原始上限总值的归零判定阈值（浮点误差容限）。 */
    private static final double DEPLETED_THRESHOLD = 1.0E-6D;

    private MaxHealthZeroLogic() {
    }

    /** 是否已经按“上限归零”结算过死亡（阻断复活、转化与重复结算）。 */
    public static boolean isCapZeroDeath(LivingEntity entity) {
        return entity != null && entity.getPersistentData().getBoolean(CAP_ZERO_DEATH);
    }

    /** 玩家是否已因归零死过一次（复活后上限为 1，不再重复结算）。 */
    public static boolean isCapZeroPinned(LivingEntity entity) {
        return entity != null && entity.getPersistentData().getBoolean(CAP_ZERO_PIN);
    }

    /**
     * 「巴别塔回忆」按需求无视彻底死亡，从死亡快照重建博士时清除归零结算标记：
     * 新实体已继承被献祭特蕾西娅的生命上限，不应再被当作“已结算过归零死亡”的实体，
     * 否则 {@link #settleIfZeroCap} 会一直跳过它、其它复活/转化链也会持续拒绝它。
     */
    public static void clearCapZero(LivingEntity entity) {
        if (entity == null) return;
        entity.getPersistentData().remove(CAP_ZERO_DEATH);
        entity.getPersistentData().remove(CAP_ZERO_KILLER);
    }

    /**
     * 未经原版下限截断的生命上限原始总值：完全复刻 1.20.1 AttributeInstance#calculateValue
     * 在 sanitizeValue 之前的三步（加值 → 基乘 → 总乘），用于识别“生效值被钉在 1.0、
     * 但真实上限早已归零”的垂死实体。
     */
    public static double rawMaxHealth(LivingEntity entity) {
        if (entity == null) return 20.0D;
        AttributeInstance attr = entity.getAttribute(Attributes.MAX_HEALTH);
        if (attr == null) return 20.0D;
        double sum = attr.getBaseValue();
        for (AttributeModifier m : attr.getModifiers(AttributeModifier.Operation.ADDITION)) {
            sum += m.getAmount();
        }
        double result = sum;
        for (AttributeModifier m : attr.getModifiers(AttributeModifier.Operation.MULTIPLY_BASE)) {
            result += sum * m.getAmount();
        }
        for (AttributeModifier m : attr.getModifiers(AttributeModifier.Operation.MULTIPLY_TOTAL)) {
            result *= 1.0D + m.getAmount();
        }
        return result;
    }

    /** 生命上限是否已被削减到归零（原始总值 ≤ 0，不看原版截断后的生效值）。 */
    public static boolean isCapDepleted(LivingEntity entity) {
        return rawMaxHealth(entity) <= DEPLETED_THRESHOLD;
    }

    /** 记录本轮上限削减的归属者；真正触发归零结算时按他计为击杀来源。 */
    public static void markCutAttribution(LivingEntity victim, LivingEntity holder) {
        if (victim == null || holder == null || victim.level().isClientSide) return;
        victim.getPersistentData().putString(CAP_ZERO_KILLER, holder.getUUID().toString());
    }

    /**
     * 上限归零结算入口：削减生效后由属性同步与周期 tick 双通道调用。
     * 已结算过的实体直接返回，绝不在死亡链里重入。
     */
    public static void settleIfZeroCap(LivingEntity entity) {
        if (entity == null || entity.level().isClientSide || entity.isRemoved()) return;
        CompoundTag d = entity.getPersistentData();
        if (d.getBoolean(CAP_ZERO_DEATH) || !isCapDepleted(entity)) return;
        if (isCreativeLike(entity)) return;
        if (entity instanceof Player) {
            // 归零玩家：第一次照常正常死亡；复活后上限钉 1，不再反复归零处死。
            if (d.getBoolean(CAP_ZERO_PIN)) return;
            d.putBoolean(CAP_ZERO_PIN, true);
            TiantangzhidianLogic.markExecutionPending(entity);
        }
        d.putBoolean(CAP_ZERO_DEATH, true);
        if (entity.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.SOUL,
                    entity.getX(), entity.getY() + entity.getBbHeight() * 0.5D, entity.getZ(),
                    24, 0.35D, 0.5D, 0.35D, 0.02D);
        }
        entity.setHealth(0.0F);
        entity.die(capZeroSource(entity));
    }

    /** 归零死亡的伤害来源：优先记名最后把上限削空的削减者，其余按魔法伤害正常结算。 */
    private static DamageSource capZeroSource(LivingEntity entity) {
        Level level = entity.level();
        String killerUuid = entity.getPersistentData().getString(CAP_ZERO_KILLER);
        if (!killerUuid.isEmpty() && level instanceof ServerLevel serverLevel) {
            try {
                if (serverLevel.getEntity(UUID.fromString(killerUuid)) instanceof LivingEntity killer
                        && killer.isAlive()) {
                    return killer instanceof Player player
                            ? level.damageSources().playerAttack(player)
                            : level.damageSources().mobAttack(killer);
                }
            } catch (IllegalArgumentException ignored) {
            }
        }
        return level.damageSources().magic();
    }

    private static boolean isCreativeLike(LivingEntity entity) {
        return entity instanceof ServerPlayer player && (player.isCreative() || player.isSpectator());
    }

    // 注意：嵌套类简单名必须全局唯一，原因见 RuwosuojianLogic.RuwosuojianEvents 的注释。
    public static final class MaxHealthZeroEvents {

        public MaxHealthZeroEvents() {
        }

        /** 兜底通道：任何来源（含外部模组）把生命上限削到归零，最迟下一 tick 正常死亡。 */
        @SubscribeEvent
        public void onLivingTick(LivingEvent.LivingTickEvent event) {
            settleIfZeroCap(event.getEntity());
        }
    }
}
