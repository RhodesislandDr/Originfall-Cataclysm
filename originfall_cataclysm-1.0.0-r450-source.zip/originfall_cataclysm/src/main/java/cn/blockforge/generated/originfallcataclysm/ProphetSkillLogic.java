package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingHealEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;

/**
 * 「预言家」博士的五个自身技能：
 * 1. 游刃有余：与自身有关的范围能力判定范围扩大 32.5%——已接入领域半径、伤害光环半径与
 *    如我所见（武器）的溅射/吸血范围。
 * 2. 领域展开•无我时序：以博士当前位置为圆心展开领域，除领域白名单外所有生物的运动速度
 *    与攻击速度均降低 99%（非生物实体的飞行速度同样压缩），
 *    且白名单外的生物在领域内「无法攻击」——任何由它们发起、或从领域外射入领域的弹射物
 *    造成的伤害都会被压制成 0（见 {@link #isAttackSuppressedByDomain}），只有白名单成员
 *    （发动者本人与其弹射物）能在领域内正常出手。
 *    发动者自身速度提升 20%（移速/飞行/攻速），持续 10~20 秒等概率随机；发动者死亡、沉默或离开
 *    区域结束领域；多领域重叠时领域对抗、效果降低 32.5%；受伤前已损失生命值百分比即本次受伤后发动
 *    领域概率；在对话栏输入「领域展开•无我时序」可发动；领域结束进入熔断，单次回血超过 6.5% 视为恢复。
 *    领域期间发动者自身的速度（移动/飞行/攻速）与索敌全部不受领域影响：领域自带一份
 *    「领域白名单」，成员为发动者本人与以他为归属者的弹射物（月牙剑气、箭矢等），
 *    白名单成员绝不会被本领域减速或压攻速，也绝不挨「无法攻击」的压制；技能期间还持续主动维持
 *    有效索敌目标（详见 {@link #tickSkillTargeting}）。
 * 3. 精锐集结：出现时召唤 2 个 1 倍当前博士属性的特蕾西娅（50% 概率手持影霄，50% 概率走终焉行者
 *    武器生成机制），之后每 20 秒再召唤一次；该机制独立于召唤与自然生成。
 * 4. 我是一有原则且自制力很强的人：半径 16 格（经游刃有余放大）内生物每次造成伤害（含溅射，不含
 *    最大生命值削弱伤害）时，博士提升 0.65% 现有数值（乘算，提升幅度由需求单独指定）；
 *    半径按生物所在位置计算。
 * 5. 我将无我：初次血量低于 30% 时领悟「黑闪」，于对话框打出黑闪并在被击中处触发雷击；
 *    领悟后 1.05625% 概率攻击时本次伤害按 2.5 次方结算，且自身属性增强为现有属性 1.1 次方
 *    （触发概率已按需求取原始设定 0.325% 的 325%）。黑闪仅在博士主动攻击其当前锁定的
 *    攻击目标、且该目标就是本次受击者时才会对该目标触发：溅射/范围伤害波及到的非目标生物、
 *    以及任何并非由博士发起的伤害都不会触发（详见 {@link #isBlackFlashTarget}）。
 * 6. 巴别塔回忆：博士死亡后 20 tick（正好是原版死亡动画时长），若死亡地点周围 64 格内有存活的
 *    「特蕾西娅」或「天灾的王女」，献祭其中离得最近的那一只并把博士从死亡快照中复活，
 *    祭品不分来源：自然刷新、张师块结构召唤、博士「精锐集结」召出的特蕾西娅、普瑞赛斯
 *    「女祭司之眼」召出的天灾的王女、刷怪蛋与认主个体一律可用；64 格内没有时，还会兜底
 *    献祭博士自己的召唤随从或带召唤标记的祭品（见 {@link #findBabelSacrifice}）。
 *    复活后继承被献祭者「死亡前」的全部属性；若这份属性的最大生命值已被削到 0 及以下，
 *    则改用最初博士召唤数值的 60% 复活。复活成功后有 3 秒无敌（60 tick），期间免疫一切伤害，
 *    避免刚归来就被集火秒杀。该技能没有初始冷却（首次死亡即可发动），
 *    发动后固定冷却 600 tick（30 秒）。该技能无视「彻底死亡」（影霄斩杀 / 天堂支点 / 生命上限归零）
 *    的复活阻断，一律照常发动；复活体入世界失败时换新 UUID 重试，确保真实复活而不是假播报，
 *    并立刻重新外显 boss 血条；献祭时播放专属音乐，该音乐在其它音乐（内化宇宙 / 陨石坠落）
 *    播放时被打断（详见 {@link BabelMemoryMusic}）。
 *    博士自身持有的「如我所见·昔时我见」优先于本技能：昔时我见可用时它先保命，
 *    博士不会真死，本技能因此等不到死亡登记、主动让位；只有昔时我见不可用
 *    （未携带如我所见 / 被流放，或已处于其 15 秒保命窗口内）时，博士才真正死亡，
 *    由本技能献祭复活——保命不再吞掉本该触发的死亡复活。
 */
public final class ProphetSkillLogic {

    // ---------------- 数值常量 ----------------
    public static final double RANGE_AMP = 1.325D;
    public static final double DOMAIN_BASE_RADIUS = 64.0D;
    public static final double DOMAIN_SLOW_RATIO = 0.99D;
    public static final double DOMAIN_SELF_BOOST = 0.20D;
    public static final double OVERLAP_REDUCTION = 0.325D;
    public static final int DOMAIN_MIN_TICKS = 10 * 20;
    public static final int DOMAIN_SPAN_TICKS = 10 * 20 + 1;
    public static final double FUSED_HEAL_RATIO = 0.065D;
    public static final double DAMAGE_AURA_RADIUS = 16.0D;
    /**
     * 「我是一有原则且自制力很强的人」每次触发的提升幅度：需求单独指定为 +0.65%（乘算累积）。
     * 注意该值不再经 {@link BoostTuning#PERCENT_SCALE} 缩放——统一降幅需求只作用于
     * 普瑞赛斯的「源石强化理论」，本技能已由后续需求单独改为 0.65%。
     */
    public static final double DAMAGE_AURA_RATIO = 0.0065D;
    /** 「我将无我（黑闪）」的原始设定触发概率：0.325%。 */
    private static final double BLACK_FLASH_CHANCE_ORIGINAL = 0.00325D;
    /** 需求指定的倍率：博士的黑闪概率取原值的 325%。 */
    private static final double BLACK_FLASH_CHANCE_SCALE = 3.25D;
    /** 实际触发概率：0.325% × 325% = 1.05625%。 */
    public static final double BLACK_FLASH_CHANCE = BLACK_FLASH_CHANCE_ORIGINAL * BLACK_FLASH_CHANCE_SCALE;
    public static final double BLACK_FLASH_HP_THRESHOLD = 0.30D;
    public static final double BLACK_FLASH_POWER = 2.5D;
    public static final double BLACK_FLASH_ATTRIBUTE_POWER = 1.1D;
    public static final int ELITE_SUMMON_INTERVAL = 20 * 20;
    public static final int ELITE_INITIAL_COUNT = 2;
    /** 精锐集结同时存活的个体上限，避免无限堆叠拖垮服务器。 */
    public static final int ELITE_MAX_CONCURRENT = 8;
    // ---------------- 6. 巴别塔回忆 ----------------
    /** 献祭判定半径（格）。 */
    public static final double BABEL_RADIUS = 64.0D;
    /** 巴别塔回忆发动后的固定冷却：30 秒（600 tick，没有初始冷却，首次死亡即可发动）。 */
    public static final int BABEL_COOLDOWN_TICKS = 30 * 20;
    /** 死亡后到巴别塔回忆触发的延迟：20 tick（与原版死亡动画时长一致）。 */
    public static final int BABEL_REVIVE_DELAY_TICKS = 20;
    /** 复活后的无敌窗口：3 秒（60 tick），期间免疫一切伤害，避免刚归来就被集火秒杀。 */
    public static final int REVIVE_GRACE_TICKS = 3 * 20;

    // ---------------- 属性修饰符 UUID ----------------
    private static final UUID FOLLOW_RANGE_UUID = UUID.fromString("c04a1e2d-3b0d-4a6c-9f10-1a2b3c4d5e01");
    private static final UUID BOOST_MOVE_UUID = UUID.fromString("c04a1e2d-3b0d-4a6c-9f10-1a2b3c4d5e02");
    private static final UUID BOOST_FLY_UUID = UUID.fromString("c04a1e2d-3b0d-4a6c-9f10-1a2b3c4d5e03");
    private static final UUID BOOST_ATTACK_SPEED_UUID = UUID.fromString("c04a1e2d-3b0d-4a6c-9f10-1a2b3c4d5e04");
    private static final UUID DOMAIN_SLOW_UUID = UUID.fromString("c04a1e2d-3b0d-4a6c-9f10-1a2b3c4d5e05");
    private static final UUID PRINCIPLED_MULT_UUID = UUID.fromString("c04a1e2d-3b0d-4a6c-9f10-1a2b3c4d5e06");

    // ---------------- persistent data 键 ----------------
    private static final String DOMAIN_ACTIVE = "OfcProphetDomainActive";
    private static final String DOMAIN_UNTIL = "OfcProphetDomainUntil";
    private static final String DOMAIN_CX = "OfcProphetDomainCX";
    private static final String DOMAIN_CY = "OfcProphetDomainCY";
    private static final String DOMAIN_CZ = "OfcProphetDomainCZ";
    private static final String DOMAIN_RADIUS = "OfcProphetDomainRadius";
    private static final String DOMAIN_FUSED = "OfcProphetDomainFused";
    private static final String BLACK_FLASH = "OfcProphetBlackFlash";
    private static final String ELITE_INITIAL = "OfcProphetEliteInitial";
    private static final String ELITE_NEXT = "OfcProphetEliteNext";
    private static final String ELITE_BY = "OfcProphetEliteBy";
    /** 巴别塔回忆的冷却账本条目：只记在该博士自己身上，多只博士各记各的、不共用。 */
    private static final String BABEL_CD_ABILITY = "prophet_babel_memory";
    /** 复活无敌窗口的截止 tick：写在博士自己的持久化数据上，到期由 tickProphet 清除。 */
    private static final String REVIVE_GRACE_UNTIL = "OfcProphetReviveGraceUntil";
    private static final String STAT_PREFIX = "OfcProphetBlackFlashBase_";
    /**
     * 博士「最初召唤数值」的持久化前缀：实体第一次 tick 时记下全部属性的基础值。
     * 巴别塔回忆的复活保底使用它——若死亡前继承到的最大生命值已被削到 0 及以下，
     * 复活改用最初召唤数值的 60%（见 {@link #applyOriginFallback}）。
     */
    private static final String ORIGIN_PREFIX = "OfcProphetOrigin_";
    private static final String ORIGIN_READY = "OfcProphetOriginReady";
    /** 上限被打崩时的复活保底倍率：最初召唤数值的 60%。 */
    private static final double REVIVE_FALLBACK_SCALE = 0.6D;
    /** 「我是一有原则且自制力很强的人」的累积乘算倍率（每次触发 ×1.0065）。 */
    private static final String PRINCIPLED_MULT = "OfcProphetPrincipledMult";
    /**
     * 「锚定现实」的执行窗口到期时刻：博士成功施加一次锚定时写入该次锚定的结束 tick
     * （被内化宇宙推迟兑现的，顺延虚空停留时长）。窗口内视为他正在发动锚定现实，
     * 期间索敌照常维持（详见 {@link #tickSkillTargeting}）。
     */
    private static final String ANCHOR_EXEC_UNTIL = "OfcProphetAnchorExecUntil";

    /** 领域触发语。 */
    private static final String DOMAIN_TRIGGER = "领域展开•无我时序";

    private static final AABB WORLD_BOUNDS = new AABB(-3.0E7D, -20000.0D, -3.0E7D,
            3.0E7D, 20000.0D, 3.0E7D);

    /** 各维度上一 tick 被领域减速的生物（维度 -> (UUID -> 实体)），用于离开领域后回收减速修饰符。 */
    private static final Map<String, Map<UUID, LivingEntity>> PREVIOUS_SLOWED = new HashMap<>();
    /** 各维度上一 tick 被领域减速弹射物/非生物实体的原始速度（维度 -> (UUID -> 原速度)），用于还原。 */
    private static final Map<String, Map<UUID, Vec3>> PREVIOUS_SLOWED_VELOCITY = new HashMap<>();

    /** 已登记、等待死亡后 20 tick 触发的巴别塔回忆。 */
    private static final List<PendingBabel> PENDING_BABEL = new ArrayList<>();
    /** 已登记待触发的博士 UUID，避免同一次死亡被重复登记（无论走哪条死亡入口）。 */
    private static final Set<UUID> SCHEDULED_BABEL = new HashSet<>();

    private static final Attribute[] BLACK_FLASH_ATTRIBUTES = {
            Attributes.MAX_HEALTH, Attributes.ATTACK_DAMAGE, Attributes.MOVEMENT_SPEED,
            Attributes.ATTACK_SPEED, Attributes.FLYING_SPEED, Attributes.FOLLOW_RANGE
    };

    /** 「我是一有原则且自制力很强的人」提升的各项属性。 */
    private static final Attribute[] PRINCIPLED_ATTRIBUTES = {
            Attributes.MAX_HEALTH, Attributes.ATTACK_DAMAGE, Attributes.MOVEMENT_SPEED,
            Attributes.ATTACK_SPEED, Attributes.ARMOR, Attributes.KNOCKBACK_RESISTANCE,
            Attributes.FOLLOW_RANGE, Attributes.FLYING_SPEED
    };

    private ProphetSkillLogic() {
    }

    // ================= 周期入口 =================

    /** 每个服务器 tick 调用：处理所有博士的技能状态。 */
    public static void tick(ServerLevel level) {
        // 性能：原实现每 tick 做一次全维度实体扫描，现改经实体索引直接取本维度在场名单。
        List<Prophet> prophets = EntityTrackers.prophets(level);
        List<ActiveDomain> domains = new ArrayList<>();
        for (Prophet prophet : prophets) {
            if (!prophet.isAlive()) continue;
            tickProphet(level, prophet);
            if (isDomainActive(prophet) && prophet.isAlive()) {
                domains.add(activeDomainOf(prophet));
            }
        }
        reconcileMovementSlow(level, domains);
        // 6. 巴别塔回忆：死亡满 20 tick 的博士在此统一结算献祭与复活。
        tickBabelRevives(level);
    }

    private static void tickProphet(ServerLevel level, Prophet prophet) {
        // 1. 游刃有余：范围能力判定范围扩大 32.5%（幂等同步索敌范围修饰符）。
        // 「源石计划进度」需求 1：32.5% 的提升幅度按档位缩放（0 档几乎不加、18 档 ×1.7）。
        AttributeInstance follow = prophet.getAttribute(Attributes.FOLLOW_RANGE);
        OfcAttributes.set(follow, FOLLOW_RANGE_UUID, "游刃有余",
                OriginiumPlanProgress.amplify(RANGE_AMP - 1.0D, level),
                AttributeModifier.Operation.MULTIPLY_TOTAL);
        // 记录「最初召唤数值」：必须早于「我将无我」的属性改写，作为复活保底基准。
        ensureOriginStats(prophet);
        // 「我将无我」属性成长跨重载还原。
        ensureBlackFlashStats(prophet);
        // 「我是一有原则且自制力很强的人」跨重载还原（属性修饰符，不影响当前生命比例）。
        ensurePrincipledBoost(prophet);
        // 「我将无我」初见黑闪：血量低于30%即领悟（伤害路径之外的上限削减同样能触发）。
        maybeComprehendBlackFlash(prophet);
        // 6. 巴别塔回忆：复活后的 3 秒无敌窗口到期即解除。
        tickReviveGrace(prophet);
        // 3. 精锐集结：出现即召唤，之后每 20 秒召唤。
        tickEliteSummon(level, prophet);
        // 2. 领域存在期间维持发动者自身增速，并处理结束条件。
        tickDomain(level, prophet);
        // 技能状态（领域展开 / 锚定现实执行窗口）期间的索敌保障。
        tickSkillTargeting(level, prophet);
    }

    // ================= 1. 游刃有余 =================

    /**
     * 「源石计划进度」需求 1：游刃有余的 32.5% 放大幅度按档位缩放——
     * 有效倍率 = 1 + (RANGE_AMP - 1) × 进度系数。
     */
    public static double amplifiedRange(net.minecraft.world.level.Level level, double base) {
        return base * OriginiumPlanProgress.boosted(RANGE_AMP, level);
    }

    /** 供武器技能使用：当施术者为「预言家」博士时，其范围判定扩大 32.5%（幅度随进度缩放）；否则原样返回。 */
    public static double amplifiedRange(LivingEntity user, double base) {
        return user instanceof Prophet ? amplifiedRange(user.level(), base) : base;
    }

    // ================= 2. 领域展开•无我时序 =================

    public static boolean isDomainActive(Prophet prophet) {
        CompoundTag d = prophet.getPersistentData();
        if (!d.getBoolean(DOMAIN_ACTIVE)) return false;
        if (prophet.level() instanceof ServerLevel level) {
            return d.getLong(DOMAIN_UNTIL) > level.getGameTime();
        }
        return true;
    }

    public static boolean isDomainFused(Prophet prophet) {
        return prophet.getPersistentData().getBoolean(DOMAIN_FUSED);
    }

    public static boolean canActivateDomain(Prophet prophet) {
        // 沉默（被锚定/被流放/无 AI）期间领域无法发动：锚定现实的“打断现有技能（沉默）”同样拦住起手。
        return prophet.isAlive() && !isDomainActive(prophet) && !isDomainFused(prophet)
                && !isSilenced(prophet);
    }

    /** 激活领域：以博士当前坐标为圆心，随机抽取 10~20 秒等概率的持续时间。 */
    public static boolean activateDomain(Prophet prophet) {
        if (!canActivateDomain(prophet)) return false;
        if (!(prophet.level() instanceof ServerLevel level)) return false;
        long now = level.getGameTime();
        long duration = DOMAIN_MIN_TICKS + level.getRandom().nextInt(DOMAIN_SPAN_TICKS);
        double cx = prophet.getX();
        double cy = prophet.getY();
        double cz = prophet.getZ();
        // 1. 游刃有余：领域半径判定范围扩大 32.5%（幅度随「源石计划进度」缩放）。
        double radius = amplifiedRange(level, DOMAIN_BASE_RADIUS);
        CompoundTag d = prophet.getPersistentData();
        d.putBoolean(DOMAIN_ACTIVE, true);
        d.putBoolean(DOMAIN_FUSED, false);
        d.putLong(DOMAIN_UNTIL, now + duration);
        d.putDouble(DOMAIN_CX, cx);
        d.putDouble(DOMAIN_CY, cy);
        d.putDouble(DOMAIN_CZ, cz);
        d.putDouble(DOMAIN_RADIUS, radius);
        applyCasterBoost(prophet, level);
        // 在领域圆心生成空心结界球体（白金色），从圆心向外扩张至领域边缘。
        DomainSphereEntity.create(level, cx, cy, cz, DomainSphereEntity.TYPE_PROPHET,
                radius, prophet.getUUID());
        announce(level, prophet, "领域展开•无我时序：以「预言家」博士为中心，领域已展开", ChatFormatting.LIGHT_PURPLE);
        return true;
    }

    private static void tickDomain(ServerLevel level, Prophet prophet) {
        if (!isDomainActive(prophet)) return;
        long now = level.getGameTime();
        if (!prophet.isAlive() || isSilenced(prophet)
                || outsideDomain(prophet) || now >= getDomainUntil(prophet)) {
            endDomain(prophet, level);
            return;
        }
        applyCasterBoost(prophet, level);
    }

    private static void endDomain(Prophet prophet, ServerLevel level) {
        CompoundTag d = prophet.getPersistentData();
        d.putBoolean(DOMAIN_ACTIVE, false);
        d.putBoolean(DOMAIN_FUSED, true);
        clearCasterBoost(prophet);
        // 领域结束：移除该施术者的结界球体。
        DomainSphereEntity.removeForCaster(level, prophet.getUUID());
        announce(level, prophet, "领域展开•无我时序：领域结束，进入熔断状态（单次回血超过6.5%视为恢复）",
                ChatFormatting.GRAY);
    }

    private static boolean outsideDomain(Prophet prophet) {
        CompoundTag d = prophet.getPersistentData();
        double cx = d.getDouble(DOMAIN_CX);
        double cy = d.getDouble(DOMAIN_CY);
        double cz = d.getDouble(DOMAIN_CZ);
        double r = d.getDouble(DOMAIN_RADIUS);
        return prophet.distanceToSqr(cx, cy, cz) > r * r;
    }

    private static long getDomainUntil(Prophet prophet) {
        return prophet.getPersistentData().getLong(DOMAIN_UNTIL);
    }

    /** 沉默判定：被锚定（锚定现实的附加效果）、被流放虚空或进入无 AI 状态视为“沉默”，结束领域。 */
    private static boolean isSilenced(Prophet prophet) {
        return RuwosuojianLogic.isSilenced(prophet);
    }

    private static ActiveDomain activeDomainOf(Prophet prophet) {
        CompoundTag d = prophet.getPersistentData();
        return new ActiveDomain(d.getDouble(DOMAIN_CX), d.getDouble(DOMAIN_CY), d.getDouble(DOMAIN_CZ),
                d.getDouble(DOMAIN_RADIUS), prophet.getUUID());
    }

    /** 发动者自身增速：+20%（或与其它领域重叠时被领域对抗削弱 32.5%）。
     * 「源石计划进度」需求 1：+20% 的提升幅度按档位缩放；领域对抗的削弱比例保持固定。 */
    private static void applyCasterBoost(Prophet prophet, ServerLevel level) {
        double boost = OriginiumPlanProgress.amplify(DOMAIN_SELF_BOOST, level);
        if (isCasterInOverlap(prophet, level)) boost *= (1.0D - OVERLAP_REDUCTION);
        OfcAttributes.set(prophet.getAttribute(Attributes.MOVEMENT_SPEED), BOOST_MOVE_UUID,
                "领域•无我时序", boost, AttributeModifier.Operation.MULTIPLY_TOTAL);
        OfcAttributes.set(prophet.getAttribute(Attributes.FLYING_SPEED), BOOST_FLY_UUID,
                "领域•无我时序", boost, AttributeModifier.Operation.MULTIPLY_TOTAL);
        OfcAttributes.set(prophet.getAttribute(Attributes.ATTACK_SPEED), BOOST_ATTACK_SPEED_UUID,
                "领域•无我时序", boost, AttributeModifier.Operation.MULTIPLY_TOTAL);
    }

    private static boolean isCasterInOverlap(Prophet prophet, ServerLevel level) {
        if (!(prophet.level() instanceof ServerLevel server)) return false;
        for (Prophet other : EntityTrackers.prophets(server)) {
            if (other == prophet || !other.isAlive() || !isDomainActive(other)) continue;
            CompoundTag d = other.getPersistentData();
            double cx = d.getDouble(DOMAIN_CX);
            double cy = d.getDouble(DOMAIN_CY);
            double cz = d.getDouble(DOMAIN_CZ);
            double r = d.getDouble(DOMAIN_RADIUS);
            if (prophet.distanceToSqr(cx, cy, cz) <= r * r) return true;
        }
        return false;
    }

    /** 供其它领域逻辑查询：某个点是否落在任一处于激活状态的博士领域内（用于跨领域对抗判定）。 */
    public static boolean pointWithinActiveDomain(ServerLevel level, double x, double y, double z) {
        for (Prophet prophet : EntityTrackers.prophets(level)) {
            if (!prophet.isAlive() || !isDomainActive(prophet)) continue;
            CompoundTag d = prophet.getPersistentData();
            double cx = d.getDouble(DOMAIN_CX);
            double cy = d.getDouble(DOMAIN_CY);
            double cz = d.getDouble(DOMAIN_CZ);
            double r = d.getDouble(DOMAIN_RADIUS);
            double dx = x - cx;
            double dy = y - cy;
            double dz = z - cz;
            if (dx * dx + dy * dy + dz * dz <= r * r) return true;
        }
        return false;
    }

    private static void clearCasterBoost(Prophet prophet) {
        OfcAttributes.clear(prophet.getAttribute(Attributes.MOVEMENT_SPEED), BOOST_MOVE_UUID);
        OfcAttributes.clear(prophet.getAttribute(Attributes.FLYING_SPEED), BOOST_FLY_UUID);
        OfcAttributes.clear(prophet.getAttribute(Attributes.ATTACK_SPEED), BOOST_ATTACK_SPEED_UUID);
    }

    /**
     * 所有领域覆盖范围内的实体应用 99% 减速（领域重叠时对抗削弱），并回收不再被覆盖者的减速。
     * 覆盖四类：
     * 1. 生物走/跑与游泳：MOVEMENT_SPEED 属性修饰符；
     * 2. 生物飞行：FLYING_SPEED 属性修饰符；
     * 3. 生物攻击速度：ATTACK_SPEED 属性修饰符（同样 99% 压制）；
     * 4. 弹射物与其它非生物实体的飞行：按“进入领域前的原始速度”等比缩放其 deltaMovement（不逐 tick 累乘）。
     *
     * <p>减速只作用于“领域白名单之外”的目标：白名单成员为该领域的发动者本人，
     * 以及以他为归属者的弹射物（月牙剑气、箭矢、三叉戟这类由他亲手打出去的东西）。
     * 否则发动者一开领域，自己的剑气就被压到 1% 速度——以剑气 80 tick 的寿命算
     * 连一两格都飞不出去，中距离攻击全部停在半空，看上去就成了“发动领域时不索敌、不打人”。</p>
     */
    private static void reconcileMovementSlow(ServerLevel level, List<ActiveDomain> domains) {
        String dimension = level.dimension().location().toString();
        Map<UUID, Integer> count = new HashMap<>();
        Map<UUID, Entity> entities = new HashMap<>();
        for (ActiveDomain domain : domains) {
            AABB aabb = new AABB(domain.cx - domain.radius, domain.cy - domain.radius,
                    domain.cz - domain.radius, domain.cx + domain.radius, domain.cy + domain.radius,
                    domain.cz + domain.radius);
            for (Entity e : level.getEntities(
                    net.minecraft.world.level.entity.EntityTypeTest.forClass(Entity.class), aabb,
                    en -> en.isAlive() && !isOnDomainWhitelist(en, domain.caster))) {
                count.merge(e.getUUID(), 1, Integer::sum);
                entities.put(e.getUUID(), e);
            }
        }
        // 领域白名单的“正向豁免”：常规回收只覆盖“上一 tick 记录在案、这一 tick 不再被
        // 覆盖”的目标，若发动者身上残留着世界重载、旧版本存档迁移等原因留下的减速修饰符
        // （它不在上一 tick 的快照里，回收链路够不着），领域激活期间由白名单每 tick 直接
        // 抹掉。仅当发动者不在本次减速名单里（未被其它领域合法减速）时清理——他若同时
        // 站在别人的领域里且不在那边白名单内，那边的减速照常结算。
        for (ActiveDomain domain : domains) {
            if (domain.caster == null || count.containsKey(domain.caster)) continue;
            if (level.getEntity(domain.caster) instanceof LivingEntity casterEntity) {
                OfcAttributes.clear(casterEntity.getAttribute(Attributes.MOVEMENT_SPEED), DOMAIN_SLOW_UUID);
                OfcAttributes.clear(casterEntity.getAttribute(Attributes.FLYING_SPEED), DOMAIN_SLOW_UUID);
                OfcAttributes.clear(casterEntity.getAttribute(Attributes.ATTACK_SPEED), DOMAIN_SLOW_UUID);
            }
        }
        Map<UUID, Vec3> prevVelocity = PREVIOUS_SLOWED_VELOCITY.computeIfAbsent(dimension, k -> new HashMap<>());
        for (Map.Entry<UUID, Integer> entry : count.entrySet()) {
            Entity e = entities.get(entry.getKey());
            if (e == null) continue;
            int covers = entry.getValue();
            // factor 是目标速度的“剩余比例”（单领域 0.01，即保持 1%）。
            // MULTIPLY_TOTAL 的金额是“增减比例”，为 1.0 + amount，故此处换算为 factor - 1.0D，
            // 这样单领域才会真正把速度压到 1%（99% 减速），而不是误加 1% 增速。
            double factor = covers >= 2
                    ? 1.0D - DOMAIN_SLOW_RATIO * (1.0D - OVERLAP_REDUCTION)
                    : 1.0D - DOMAIN_SLOW_RATIO;
            if (e instanceof LivingEntity living) {
                // 走/跑 + 游泳（MOVEMENT_SPEED）、飞行（FLYING_SPEED）与攻击速度（ATTACK_SPEED）。
                OfcAttributes.set(living.getAttribute(Attributes.MOVEMENT_SPEED), DOMAIN_SLOW_UUID,
                        "领域•无我时序", factor - 1.0D, AttributeModifier.Operation.MULTIPLY_TOTAL);
                OfcAttributes.set(living.getAttribute(Attributes.FLYING_SPEED), DOMAIN_SLOW_UUID,
                        "领域•无我时序", factor - 1.0D, AttributeModifier.Operation.MULTIPLY_TOTAL);
                OfcAttributes.set(living.getAttribute(Attributes.ATTACK_SPEED), DOMAIN_SLOW_UUID,
                        "领域•无我时序", factor - 1.0D, AttributeModifier.Operation.MULTIPLY_TOTAL);
            } else {
                // 弹射物/物品等非生物实体：以进入领域瞬间的原始速度为基准，每 tick 缩放到 factor，
                // 而非在已有减速上累乘，避免随停留时间指数衰减到 0。
                Vec3 original = prevVelocity.get(e.getUUID());
                if (original == null) {
                    original = e.getDeltaMovement();
                    prevVelocity.put(e.getUUID(), original);
                }
                e.setDeltaMovement(original.scale(factor));
            }
        }
        // 回收不再被领域覆盖的生物的减速修饰符（走/跑、游泳、飞行、攻击速度）。
        Map<UUID, LivingEntity> previous = PREVIOUS_SLOWED.computeIfAbsent(dimension, k -> new HashMap<>());
        for (Map.Entry<UUID, LivingEntity> prev : previous.entrySet()) {
            if (!count.containsKey(prev.getKey()) && prev.getValue() != null) {
                OfcAttributes.clear(prev.getValue().getAttribute(Attributes.MOVEMENT_SPEED), DOMAIN_SLOW_UUID);
                OfcAttributes.clear(prev.getValue().getAttribute(Attributes.FLYING_SPEED), DOMAIN_SLOW_UUID);
                OfcAttributes.clear(prev.getValue().getAttribute(Attributes.ATTACK_SPEED), DOMAIN_SLOW_UUID);
            }
        }
        previous.clear();
        for (Map.Entry<UUID, Entity> entry : entities.entrySet()) {
            if (entry.getValue() instanceof LivingEntity living) {
                previous.put(entry.getKey(), living);
            }
        }
        // 回收离开领域的非生物实体：还原其原始速度，并清掉映射。
        for (Map.Entry<UUID, Vec3> pv : prevVelocity.entrySet()) {
            if (!count.containsKey(pv.getKey())) {
                Entity event = level.getEntity(pv.getKey());
                if (event != null && event.isAlive()) {
                    event.setDeltaMovement(pv.getValue());
                }
            }
        }
        prevVelocity.keySet().removeIf(id -> !count.containsKey(id));
        if (previous.isEmpty() && prevVelocity.isEmpty() && domains.isEmpty()) {
            PREVIOUS_SLOWED.remove(dimension);
            PREVIOUS_SLOWED_VELOCITY.remove(dimension);
        }
    }

    /**
     * 领域白名单判定：实体是否为「该领域发动者本人或他自己的攻击」——
     * 发动者本体，以及以发动者为归属者的弹射物（月牙剑气、箭矢、三叉戟这类由他
     * 亲手打出去的东西）。白名单成员一律不受该领域减速，且由
     * {@link #reconcileMovementSlow} 提供正向豁免（残留减速也会被抹掉）。
     * 本判定按领域逐个进行：同一实体若还被别的领域覆盖且不在那边白名单内，那边的减速照常结算。
     */
    private static boolean isOnDomainWhitelist(Entity entity, UUID caster) {
        if (caster == null) return false; // 无发动者标记的领域不做任何豁免（与原判定一致：一律减速）
        if (caster.equals(entity.getUUID())) return true;
        if (entity instanceof Projectile projectile) {
            Entity owner = projectile.getOwner();
            return owner != null && caster.equals(owner.getUUID());
        }
        return false;
    }

    /**
     * 领域「无法攻击」判定：某个伤害来源是否被任一激活领域的白名单之外压制。
     *
     * <p>领域覆盖范围内的攻击来源只要不在该领域白名单里就被压制（伤害被取消、归零）：
     * <ul>
     *   <li>造成伤害的生物本体落在任一激活领域的球体内（近战与炮台式远程都按本体定位）；</li>
     *   <li>或直接造成伤害的弹射物落在领域球体内（从领域外射入的箭矢 / 剑气等同样被压制），
     *       这样即使射手站在领域外，攻击也无法越过领域边界出手。</li>
     * </ul>
     * 白名单成员（发动者本人与以他为归属者的弹射物）一律不被压制。多个领域重叠时按各自的
     * 白名单分别判定：只要攻击命中任一领域且不在该领域白名单即被压制，语义与
     * {@link #reconcileMovementSlow} 的减速判定保持一致。</p>
     */
    private static boolean isAttackSuppressedByDomain(ServerLevel level, DamageSource source) {
        Entity direct = source.getDirectEntity();
        LivingEntity attacker = resolveAttacker(source);
        for (Prophet prophet : EntityTrackers.prophets(level)) {
            if (!prophet.isAlive() || !isDomainActive(prophet)) continue;
            CompoundTag d = prophet.getPersistentData();
            double cx = d.getDouble(DOMAIN_CX);
            double cy = d.getDouble(DOMAIN_CY);
            double cz = d.getDouble(DOMAIN_CZ);
            double r = d.getDouble(DOMAIN_RADIUS);
            UUID caster = prophet.getUUID();
            if (domainSuppressesEntity(attacker, caster, cx, cy, cz, r)) return true;
            if (direct instanceof Projectile && domainSuppressesEntity(direct, caster, cx, cy, cz, r)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 领域「无法攻击」对<b>攻击发起生物本体</b>的判定（Epic Fight 攻击事件钩子复用）：
     * 生物本体落在任一激活领域球体内且不在该领域白名单即被压制。
     * 与 {@link #isAttackSuppressedByDomain(ServerLevel, DamageSource)} 的「本体」判定完全一致，
     * 但直接以攻击者实体判定、无需构造 DamageSource——Epic Fight 的 {@code attack()} 钩子
     * 先于伤害结算、拿到的正是攻击者本体。
     */
    public static boolean isAttackSuppressedByDomain(ServerLevel level, LivingEntity attacker) {
        if (attacker == null) return false;
        for (Prophet prophet : EntityTrackers.prophets(level)) {
            if (!prophet.isAlive() || !isDomainActive(prophet)) continue;
            CompoundTag d = prophet.getPersistentData();
            if (domainSuppressesEntity(attacker, prophet.getUUID(),
                    d.getDouble(DOMAIN_CX), d.getDouble(DOMAIN_CY), d.getDouble(DOMAIN_CZ),
                    d.getDouble(DOMAIN_RADIUS))) {
                return true;
            }
        }
        return false;
    }

    /** 单个领域是否压制该实体：实体落在该领域球体内且不在白名单（发动者本人或其弹射物）。 */
    private static boolean domainSuppressesEntity(Entity entity, UUID caster,
                                                  double cx, double cy, double cz, double r) {
        if (entity == null || isOnDomainWhitelist(entity, caster)) return false;
        double dx = entity.getX() - cx;
        double dy = entity.getY() - cy;
        double dz = entity.getZ() - cz;
        return dx * dx + dy * dy + dz * dz <= r * r;
    }

    // ================= 索敌保障：领域展开与锚定现实期间 =================

    /**
     * 博士发动「领域展开•无我时序」与「锚定现实」期间的索敌维持。
     *
     * <p>这两个技能状态下，博士的索敌必须照常进行，而不是原地站着：
     * <ul>
     *   <li>领域把覆盖范围内的所有其它单位压到 1% 速度（移速与攻速同压），被锚定的单位
     *       更是被钉死在原地，当前目标很容易在同一 tick 里失效（死亡、被溅射带走、
     *       被内化宇宙拉进虚空），
     *       而原版目标选择器按随机间隔轮询，两者之间存在「没有目标」的空档；</li>
     *   <li>安装史诗战斗时，其接管逻辑还会替换生物的部分动作目标，索敌节奏更不由模组决定。</li>
     * </ul>
     * 因此在两个技能状态下主动维持目标：当前目标仍然有效时什么都不做，
     * 失效时按注册目标选择器的同一优先级（「女祭司」普瑞赛斯最高，其余就近）
     * 在自身索敌半径（128 格，经游刃有余放大）内重选，重选最快每 4 tick 一次。
     * 领域被真正沉默（无 AI）时不接管，
     * 让停滞状态自己说了算。</p>
     */
    private static void tickSkillTargeting(ServerLevel level, Prophet prophet) {
        boolean skillRunning = isDomainActive(prophet) || isAnchorExecuting(prophet, level);
        if (!skillRunning) return;
        if (!prophet.isAlive() || prophet.isNoAi()) return;
        LivingEntity target = prophet.getTarget();
        if (target != null && target.isAlive() && prophet.canAttack(target)) return;
        // 目标失效时才需要全图搜索一次：按 4 tick 的节奏补，既补得住原版选择器的随机轮询空档，
        // 也不会把 128 格范围的实体扫描变成每 tick 一次的固定开销。
        if (prophet.tickCount % 4 != 0) return;
        prophet.setTarget(findSkillCombatTarget(level, prophet));
    }

    /** 本次「锚定现实」的执行窗口是否仍在生效（停滞结束前都算博士正在发动锚定现实）。 */
    private static boolean isAnchorExecuting(Prophet prophet, ServerLevel level) {
        return prophet.getPersistentData().getLong(ANCHOR_EXEC_UNTIL) > level.getGameTime();
    }

    /**
     * 由「如我所见」的锚定现实在成功施加时回调：把本次锚定的执行窗口登记到博士身上，
     * 多次施加取最晚到期时刻。施加者不是博士时不做任何事（该武器为博士专属，
     * 其余持有者维持原有行为）。
     */
    public static void markAnchorExecution(LivingEntity holder, long until) {
        if (!(holder instanceof Prophet prophet)) return;
        if (!(prophet.level() instanceof ServerLevel level)) return;
        CompoundTag d = prophet.getPersistentData();
        if (d.getLong(ANCHOR_EXEC_UNTIL) < until) d.putLong(ANCHOR_EXEC_UNTIL, until);
    }

    /** 技能期间的主动索敌：与 {@code Prophet#registerGoals} 的目标优先级完全一致。 */
    private static LivingEntity findSkillCombatTarget(ServerLevel level, Prophet prophet) {
        double radius = prophet.getAttributeValue(Attributes.FOLLOW_RANGE);
        if (!(radius > 0.0D)) radius = Prophet.FOLLOW_RANGE;
        AABB box = prophet.getBoundingBox().inflate(radius);
        Comparator<LivingEntity> nearest = Comparator.comparingDouble(prophet::distanceToSqr);
        LivingEntity priestess = level.getEntitiesOfClass(LivingEntity.class, box,
                        entity -> entity instanceof Priestess && prophet.canAttack(entity))
                .stream().min(nearest).orElse(null);
        if (priestess != null) return priestess;
        return level.getEntitiesOfClass(LivingEntity.class, box, entity -> prophet.canAttack(entity))
                .stream().min(nearest).orElse(null);
    }

    // ================= 3. 精锐集结 =================

    private static void tickEliteSummon(ServerLevel level, Prophet prophet) {
        // 精锐集结是主动召唤技能：沉默（锚定现实打断效果）期间无法发动，解除后照常续召。
        if (isSilenced(prophet)) return;
        CompoundTag d = prophet.getPersistentData();
        long now = level.getGameTime();
        if (!d.getBoolean(ELITE_INITIAL)) {
            summonElite(level, prophet, ELITE_INITIAL_COUNT);
            d.putBoolean(ELITE_INITIAL, true);
            d.putLong(ELITE_NEXT, now + ELITE_SUMMON_INTERVAL);
            return;
        }
        if (now >= d.getLong(ELITE_NEXT)) {
            summonElite(level, prophet, 1);
            d.putLong(ELITE_NEXT, now + ELITE_SUMMON_INTERVAL);
        }
    }

    private static void summonElite(ServerLevel level, Prophet prophet, int count) {
        for (int i = 0; i < count; i++) {
            if (countLiveElites(level, prophet) >= ELITE_MAX_CONCURRENT) return;
            Theresia theresia = GeneratedMod.THERESIA.get().create(level);
            if (theresia == null) continue;
            double x = prophet.getX() + (level.getRandom().nextDouble() - 0.5D) * 3.0D;
            double z = prophet.getZ() + (level.getRandom().nextDouble() - 0.5D) * 3.0D;
            double y = prophet.getY();
            theresia.moveTo(x, y, z, level.getRandom().nextFloat() * 360.0F, 0.0F);
            applyEliteStats(theresia, prophet);
            // 先写标记再上主手武器，主手绑定逻辑会拒绝非绑定武器写入。
            theresia.getPersistentData().putBoolean(Theresia.ELITE_SUMMONED, true);
            theresia.getPersistentData().putString(ELITE_BY, prophet.getUUID().toString());
            AssimilationEquipment.markAssigned(theresia);
            boolean yingsiao = level.getRandom().nextFloat() < 0.50F;
            if (yingsiao) {
                putEliteWeapon(theresia, GeneratedMod.YINGSIAO.get());
                theresia.setItemSlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND,
                        new ItemStack(GeneratedMod.YINGSIAO.get()));
            } else {
                // 博士召唤的特蕾西娅使用随机武器均为近战武器（meleeOnly），不再出现弓/弩。
                ItemStack weapon = AssimilationEquipment.buildRandomWeapon(theresia, true);
                putEliteWeapon(theresia, weapon.getItem());
                theresia.setItemSlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND, weapon);
            }
            theresia.setPersistenceRequired();
            level.addFreshEntity(theresia);
        }
    }

    private static void putEliteWeapon(Theresia theresia, net.minecraft.world.item.Item item) {
        ResourceLocation key = net.minecraftforge.registries.ForgeRegistries.ITEMS.getKey(item);
        theresia.getPersistentData().putString(Theresia.ELITE_WEAPON_ID,
                key == null ? "" : key.toString());
    }

    private static int countLiveElites(ServerLevel level, Prophet prophet) {
        String id = prophet.getUUID().toString();
        int n = 0;
        for (Theresia t : level.getEntitiesOfClass(Theresia.class, WORLD_BOUNDS, Entity::isAlive)) {
            if (id.equals(t.getPersistentData().getString(ELITE_BY))) n++;
        }
        return n;
    }

    /** 把召唤的特蕾西娅各项基础属性设为当前博士的 1 倍。 */
    private static void applyEliteStats(Theresia theresia, Prophet prophet) {
        setBase(theresia, Attributes.MAX_HEALTH, prophet.getAttributeValue(Attributes.MAX_HEALTH));
        setBase(theresia, Attributes.ATTACK_DAMAGE, prophet.getAttributeValue(Attributes.ATTACK_DAMAGE));
        setBase(theresia, Attributes.MOVEMENT_SPEED, prophet.getAttributeValue(Attributes.MOVEMENT_SPEED));
        setBase(theresia, Attributes.ATTACK_SPEED, prophet.getAttributeValue(Attributes.ATTACK_SPEED));
        setBase(theresia, Attributes.ARMOR, prophet.getAttributeValue(Attributes.ARMOR));
        setBase(theresia, Attributes.FOLLOW_RANGE, prophet.getAttributeValue(Attributes.FOLLOW_RANGE));
        setBase(theresia, Attributes.KNOCKBACK_RESISTANCE, prophet.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE));
        setBase(theresia, Attributes.FLYING_SPEED, prophet.getAttributeValue(Attributes.FLYING_SPEED));
        theresia.setHealth(theresia.getMaxHealth());
    }

    private static void setBase(LivingEntity entity, Attribute attribute, double value) {
        AttributeInstance instance = entity.getAttribute(attribute);
        if (instance != null) instance.setBaseValue(value);
    }

    // ================= 4. 我是一有原则且自制力很强的人 =================

    /** 命中判定范围内（经「游刃有余」放大后）的存活博士列表：半径按生物所在位置计算，含博士自身。 */
    private static List<Prophet> prophetsNear(LivingEntity attacker) {
        if (attacker == null || !(attacker.level() instanceof ServerLevel level)) return List.of();
        double radius = amplifiedRange(level, DAMAGE_AURA_RADIUS);
        List<Prophet> result = new ArrayList<>();
        for (Prophet p : level.getEntitiesOfClass(Prophet.class,
                attacker.getBoundingBox().inflate(radius), Entity::isAlive)) {
            if (p.distanceToSqr(attacker) <= radius * radius) {
                result.add(p);
            }
        }
        return result;
    }

    /** 附近生物造成伤害时：把博士各项现有数值 ×1.0065（乘算累积），并等比放大生命。 */
    private static void applyPrincipledBoost(Prophet prophet) {
        CompoundTag d = prophet.getPersistentData();
        double m = d.getDouble(PRINCIPLED_MULT);
        if (!(m >= 1.0D)) m = 1.0D;
        // 「源石计划进度」需求 1：每次触发 +0.65% 的提升幅度按档位缩放；
        // 已累积的历史倍率原样保留，只有新增部分随进度变化。
        m *= 1.0D + OriginiumPlanProgress.amplify(DAMAGE_AURA_RATIO, prophet);
        d.putDouble(PRINCIPLED_MULT, m);
        double oldMax = prophet.getMaxHealth();
        float oldHealth = prophet.getHealth();
        double multValue = m - 1.0D;
        for (Attribute attribute : PRINCIPLED_ATTRIBUTES) {
            AttributeInstance instance = prophet.getAttribute(attribute);
            if (instance == null) continue;
            OfcAttributes.set(instance, PRINCIPLED_MULT_UUID, "我是一有原则", multValue,
                    AttributeModifier.Operation.MULTIPLY_TOTAL);
        }
        double newMax = prophet.getMaxHealth();
        if (newMax > 0.0D && oldMax > 0.0D) {
            prophet.setHealth((float) (newMax * (oldHealth / oldMax)));
        }
    }

    /** 跨重载/卸载还原「我是一有原则」的乘算修饰符（仅还原修饰符，不改变当前生命比例）。 */
    private static void ensurePrincipledBoost(Prophet prophet) {
        double m = prophet.getPersistentData().getDouble(PRINCIPLED_MULT);
        if (m <= 1.0D) return;
        double multValue = m - 1.0D;
        for (Attribute attribute : PRINCIPLED_ATTRIBUTES) {
            AttributeInstance instance = prophet.getAttribute(attribute);
            if (instance == null) continue;
            OfcAttributes.set(instance, PRINCIPLED_MULT_UUID, "我是一有原则", multValue,
                    AttributeModifier.Operation.MULTIPLY_TOTAL);
        }
    }

    // ================= 5. 我将无我（黑闪） =================

    public static boolean hasComprehendedBlackFlash(LivingEntity entity) {
        return entity != null && entity.getPersistentData().getBoolean(BLACK_FLASH);
    }

    private static void ensureBlackFlashStats(Prophet prophet) {
        for (Attribute attribute : BLACK_FLASH_ATTRIBUTES) {
            String key = statKey(attribute);
            if (!prophet.getPersistentData().contains(key)) continue;
            double stored = prophet.getPersistentData().getDouble(key);
            AttributeInstance instance = prophet.getAttribute(attribute);
            if (instance != null && Math.abs(instance.getBaseValue() - stored) > 1.0E-6D) {
                instance.setBaseValue(stored);
            }
        }
    }

    /** 初次血量低于 30% 时领悟黑闪：对话框打出黑闪，并在被击中处触发雷击。 */
    private static void maybeComprehendBlackFlash(Prophet prophet) {
        if (!hasComprehendedBlackFlash(prophet) && prophet.isAlive()
                && prophet.getHealth() <= BLACK_FLASH_HP_THRESHOLD * prophet.getMaxHealth()) {
            comprehendBlackFlash(prophet);
        }
    }

    private static void comprehendBlackFlash(Prophet prophet) {
        CompoundTag d = prophet.getPersistentData();
        if (d.getBoolean(BLACK_FLASH)) return;
        d.putBoolean(BLACK_FLASH, true);
        if (!(prophet.level() instanceof ServerLevel level)) return;
        LightningBolt bolt = new LightningBolt(EntityType.LIGHTNING_BOLT, level);
        bolt.setVisualOnly(true);
        bolt.moveTo(prophet.getX(), prophet.getY(), prophet.getZ(), 0.0F, 0.0F);
        level.addFreshEntity(bolt);
        announce(level, prophet, "黑闪", ChatFormatting.DARK_PURPLE);
    }

    public static boolean shouldBlackFlash(Prophet prophet) {
        return hasComprehendedBlackFlash(prophet)
                && prophet.getRandom().nextDouble() < BLACK_FLASH_CHANCE;
    }

    /**
     * 黑闪的触发对象判定：只有博士主动攻击其当前锁定的攻击目标、且该目标正是本次受击者时成立。
     * 以此把触发严格限制在「博士对目标」这一条路径上——溅射/范围伤害波及到的非目标生物、
     * 环境伤害以及并非博士发起的攻击都不会触发黑闪，也不会消耗触发概率。
     */
    public static boolean isBlackFlashTarget(Prophet prophet, LivingEntity victim) {
        if (prophet == null || victim == null || prophet == victim) return false;
        LivingEntity target = prophet.getTarget();
        return target != null && target == victim && target.isAlive();
    }

    /** 黑闪触发后的自身属性增强：各项现有属性取其 1.1 次方（跨重载持久化）。 */
    public static void onBlackFlashEmpower(Prophet prophet) {
        for (Attribute attribute : BLACK_FLASH_ATTRIBUTES) {
            AttributeInstance instance = prophet.getAttribute(attribute);
            if (instance == null) continue;
            boolean preserveHealth = attribute == Attributes.MAX_HEALTH;
            double oldMax = prophet.getMaxHealth();
            float healthBefore = prophet.getHealth();
            double ratio = preserveHealth ? healthBefore / Math.max(1.0D, oldMax) : 1.0D;
            double oldBase = prophet.getAttributeBaseValue(attribute);
            // 「源石计划进度」需求 1：1.1 次方的属性增强指数中，超出 1 的增幅按档位缩放
            // （有效指数 = 1 + 0.1 × 进度系数）。
            double power = OriginiumPlanProgress.boosted(BLACK_FLASH_ATTRIBUTE_POWER, prophet);
            double newBase = Math.pow(Math.max(1.0D, oldBase), power);
            instance.setBaseValue(newBase);
            prophet.getPersistentData().putDouble(statKey(attribute), newBase);
            if (preserveHealth) {
                prophet.setHealth((float) Math.min(prophet.getMaxHealth(), newBase * ratio));
            }
        }
    }

    private static String statKey(Attribute attribute) {
        return attributeKey(STAT_PREFIX, attribute);
    }

    private static String originKey(Attribute attribute) {
        return attributeKey(ORIGIN_PREFIX, attribute);
    }

    private static String attributeKey(String prefix, Attribute attribute) {
        ResourceLocation key = net.minecraft.core.registries.BuiltInRegistries.ATTRIBUTE.getKey(attribute);
        String name = key == null ? attribute.getDescriptionId() : key.toString();
        return prefix + name.replace(':', '_').replace('/', '_');
    }

    /**
     * 记录「最初召唤数值」：首次 tick 把全部属性基础值写进 persistent data，之后不再改写。
     * 必须早于「我将无我」的黑闪属性改写执行，才能拿到真正的召唤基准。
     */
    private static void ensureOriginStats(Prophet prophet) {
        CompoundTag d = prophet.getPersistentData();
        if (d.getBoolean(ORIGIN_READY)) return;
        for (Attribute attribute : net.minecraft.core.registries.BuiltInRegistries.ATTRIBUTE) {
            AttributeInstance instance = prophet.getAttribute(attribute);
            if (instance == null) continue;
            d.putDouble(originKey(attribute), instance.getBaseValue());
        }
        d.putBoolean(ORIGIN_READY, true);
    }

    /**
     * 复活保底：死亡前继承到的最大生命值小于 0（被阳火/天堂支点削到归零）时，
     * 放弃继承值，改用最初博士召唤数值的 60%，并同步黑闪的持久化基准，
     * 避免复活体上限为 0 而下一 tick 立刻再次死亡。
     */
    private static void applyOriginFallback(Prophet prophet) {
        CompoundTag d = prophet.getPersistentData();
        for (Attribute attribute : net.minecraft.core.registries.BuiltInRegistries.ATTRIBUTE) {
            AttributeInstance instance = prophet.getAttribute(attribute);
            if (instance == null) continue;
            String key = originKey(attribute);
            if (!d.contains(key)) continue;
            double value = d.getDouble(key) * REVIVE_FALLBACK_SCALE;
            instance.setBaseValue(value);
            String statKey = statKey(attribute);
            if (d.contains(statKey)) d.putDouble(statKey, value);
        }
    }

    // ================= 6. 巴别塔回忆 =================

    /**
     * 死亡登记：博士死亡时调用，留下死亡快照与死亡地点，20 tick 后统一结算巴别塔回忆。
     *
     * <p>与原实现不同，这里不再于致命伤害阶段拦截死亡，而是让博士照常走完死亡流程（原版死亡动画
     * 恰好 20 tick），延迟到死亡动画结束后再触发技能，触发时机与需求「死亡后 20 tick」完全一致。</p>
     *
     * <p>登记阶段只校验冷却；「彻底死亡」（影霄斩杀 / 天堂支点 / 生命上限归零）不再阻断登记，
     * 对应需求里的「无视彻底死亡」。冷却记在该博士自己的冷却账本上（默认没有记录，即没有初始冷却），
     * 所以首次死亡就能登记，多只博士也各记各的、不共用。同一只博士的死亡会被 {@link #SCHEDULED_BABEL} 去重：
     * {@code Prophet#die} 与死亡事件两条入口都调用本方法也不会重复登记。</p>
     */
    public static void onProphetDeath(Prophet prophet, ServerLevel level) {
        if (prophet == null || level == null || prophet.level() != level) return;
        // 坍缩个体失去死亡后效果：「巴别塔回忆」不再登记，博士不会被复活。
        if (CalamityLogic.isCollapsed(prophet)) return;
        long now = level.getGameTime();
        // 固定 30 秒冷却：未到下一次可用时刻则不登记（账本无记录时 ready 恒为 true，即无初始冷却）。
        if (!AbilityCooldowns.ready(prophet, now, BABEL_CD_ABILITY)) return;
        UUID id = prophet.getUUID();
        if (!SCHEDULED_BABEL.add(id)) return;
        PENDING_BABEL.add(new PendingBabel(level, prophet.createRevivalSnapshot(), id,
                prophet.getX(), prophet.getY(), prophet.getZ(), now + BABEL_REVIVE_DELAY_TICKS));
    }

    /** 每个服务器 tick 结算到期的巴别塔回忆：献祭最近的祭品，并把博士从死亡快照中复活。 */
    private static void tickBabelRevives(ServerLevel level) {
        if (PENDING_BABEL.isEmpty()) return;
        Iterator<PendingBabel> iterator = PENDING_BABEL.iterator();
        while (iterator.hasNext()) {
            PendingBabel pending = iterator.next();
            if (pending.level != level || level.getGameTime() < pending.readyTick) continue;
            iterator.remove();
            SCHEDULED_BABEL.remove(pending.uuid);
            triggerBabelMemory(level, pending);
        }
    }

    /**
     * 开启复活无敌窗口：把截止 tick 写进博士自己的持久化数据。
     * 无需缓存在静态表里，实体随存档/跨维度保留标记，到期由 {@link #tickReviveGrace} 清除。
     */
    private static void startReviveGrace(Prophet prophet, long now) {
        prophet.getPersistentData().putLong(REVIVE_GRACE_UNTIL, now + REVIVE_GRACE_TICKS);
    }

    /** 该博士是否仍处于复活后的无敌窗口内（供受击事件判定）。 */
    private static boolean isReviveGraceActive(LivingEntity entity, long now) {
        return entity.getPersistentData().getLong(REVIVE_GRACE_UNTIL) > now;
    }

    /** 每个 tick 检查无敌窗口：到期后清掉标记，博士重新可被伤害（正常就没有标记，零开销）。 */
    private static void tickReviveGrace(Prophet prophet) {
        CompoundTag d = prophet.getPersistentData();
        long until = d.getLong(REVIVE_GRACE_UNTIL);
        if (until == 0L || prophet.level().getGameTime() < until) return;
        d.remove(REVIVE_GRACE_UNTIL);
    }

    /**
     * 触发巴别塔回忆：死亡地点 64 格内最近的「特蕾西娅」或「天灾的王女」被献祭，
     * 博士从死亡快照中以新实体复活，继承被献祭者的全部属性（覆盖基础值），
     * 随后回满到继承后的新上限并写入 600 tick（30 秒）冷却。
     *
     * <p>复活后立刻进入 3 秒（60 tick）无敌窗口：期间该博士免疫一切伤害，
     * 由 {@link #startReviveGrace} 写入截止 tick、受击事件取消伤害、{@link #tickReviveGrace} 到期解除。
     * 两类祭品同等对待、按距离择优，且不区分召唤来源（见 {@link #findBabelSacrifice}）；
     * 属性一律取「献祭前」的生效值，因为献祭后目标会被杀死、属性可能被清零。
     * 这里是「博士死亡后未触发技能」问题的收尾：只要死亡登记成功，
     * 无论博士原本是否被「彻底死亡」标记过，都照常走完整条复活链。</p>
     */
    private static void triggerBabelMemory(ServerLevel level, PendingBabel pending) {
        LivingEntity sacrifice = findBabelSacrifice(level, pending.uuid, pending.x, pending.y, pending.z);
        // 死亡地点 64 格内没有存活的祭品时技能不发动，博士维持死亡（也不写入冷却，下次死亡可再试）。
        if (sacrifice == null) return;
        // 先取属性快照，再献祭：死亡后属性可能被清空/移除，继承的是献祭前的全部属性。
        List<Map.Entry<Attribute, Double>> inherited = snapshotAttributes(sacrifice);
        // 「死亡前属性最大生命值小于0」：祭品上限被阳火/天堂支点削到归零时，继承值不可用，
        // 复活改用最初博士召唤数值的 60%（见 applyOriginFallback）。
        double inheritedMax = attributeValue(inherited, Attributes.MAX_HEALTH);
        boolean depleted = inheritedMax <= 0.0D || MaxHealthZeroLogic.rawMaxHealth(sacrifice) <= 0.0D;
        Entity entity = EntityType.loadEntityRecursive(pending.snapshot.copy(), level, loaded -> loaded);
        if (!(entity instanceof Prophet prophet)) return;
        prophet.moveTo(pending.x, pending.y, pending.z, prophet.getYRot(), prophet.getXRot());
        // 清掉死亡快照带回的彻底死亡残留（复活阻断、生命上限削减、彻底击败标记），
        // 否则重建出的博士会被重新削到上限归零而立刻再次死亡，见 TiantangzhidianLogic。
        TiantangzhidianLogic.clearThoroughDefeatState(prophet);
        if (depleted) {
            applyOriginFallback(prophet);
        } else {
            applyInheritedAttributes(prophet, inherited);
        }
        // 保险：继承/保底之后上限仍不可用，再兜一次底，避免复活体下一 tick 二次死亡。
        if (prophet.getMaxHealth() <= 0.0F) applyOriginFallback(prophet);
        // 影霄斩杀标记只是单次攻击内的临时标记，重建的实体不应带着它；其余彻底死亡标记一并清空。
        YingsiaoSwordItem.clearExecution(prophet);
        prophet.setPersistenceRequired();
        float max = prophet.getMaxHealth();
        if (max > 0.0F) prophet.setHealth(max);
        // 真实复活：复活恰好发生在原版尸体移除的同刻，旧尸体若仍在场，同 UUID 的新实体会被
        // 原版实体管理器拒绝入世界（表现为「触发后没有真实复活」）。先沿用旧 UUID，
        // 失败时换一枚新 UUID 再入世界，绝不留下「只有播报、没有实体」的假复活。
        if (!level.addFreshEntity(prophet)) {
            prophet.setUUID(UUID.randomUUID());
            if (!level.addFreshEntity(prophet)) return;
        }
        // 复活体从死亡快照重建，冷却账本重开；写入 30 秒冷却，防止同一只博士连续发动。
        AbilityCooldowns.arm(prophet, level.getGameTime(), BABEL_COOLDOWN_TICKS, BABEL_CD_ABILITY);
        // 复活后的 3 秒无敌：写入截止 tick，期间由受击事件取消一切伤害。
        startReviveGrace(prophet, level.getGameTime());
        // 重建实体的 boss 血条是全新的，入世界后立刻广播一次，保证「复活后保留 boss 血条」。
        prophet.refreshBossBar();
        sacrificeOffering(level, prophet, sacrifice);
        // 复活由死亡快照重建：恶意等级与词条会随快照带回旧值，按莱特兰机制重掷一次。
        MaliceCompat.onRevive(prophet);
        BabelMemoryMusic.play(level);
        announce(level, prophet, "巴别塔回忆：献祭" + offeringName(sacrifice) + "，博士自回忆中归来",
                ChatFormatting.DARK_PURPLE);
    }

    /** 读取属性快照中某项属性的生效值；缺失时返回 0。 */
    private static double attributeValue(List<Map.Entry<Attribute, Double>> values, Attribute attribute) {
        for (Map.Entry<Attribute, Double> entry : values) {
            if (entry.getKey() == attribute) return entry.getValue();
        }
        return 0.0D;
    }

    /**
     * 取本次献祭的祭品：优先死亡地点半径 64 格内最近的「特蕾西娅」或「天灾的王女」，
     * 两者同等对待、按距离取近；两类祭品不区分召唤来源，自然刷新、张师块结构召唤、
     * 博士「精锐集结」召出的特蕾西娅、普瑞赛斯「女祭司之眼」召出的天灾的王女、
     * 刷怪蛋与认主个体一律可用（判定只看实体类型，见 {@link #isBabelOffering}）。
     *
     * <p>兜底：当 64 格内一只祭品也没有时，再在这一维度内寻找博士自己的「精锐集结」随从
     * （按 {@code ELITE_BY} 归属该博士）以及任何带召唤标记（{@code ELITE_SUMMONED} /
     * {@code SUMMON_BY}）的特蕾西娅或天灾的王女，允许它们即使跟随走散、超出 64 格也照常献祭，
     * 对应需求「召唤的特蕾西娅与召唤的天灾的王女也可以用作献祭」。</p>
     */
    private static LivingEntity findBabelSacrifice(ServerLevel level, UUID summoner,
                                                   double x, double y, double z) {
        AABB box = new AABB(x - BABEL_RADIUS, y - BABEL_RADIUS, z - BABEL_RADIUS,
                x + BABEL_RADIUS, y + BABEL_RADIUS, z + BABEL_RADIUS);
        LivingEntity nearby = nearestBabelOffering(level, box, BABEL_RADIUS * BABEL_RADIUS,
                entity -> true, x, y, z);
        if (nearby != null) return nearby;
        // 召唤的祭品是博士的直属随从（精锐集结）或任意女祭司之眼的召唤体：不受 64 格半径限制。
        return nearestBabelOffering(level, WORLD_BOUNDS, Double.MAX_VALUE,
                entity -> isEliteOf(entity, summoner) || isSummonedOffering(entity), x, y, z);
    }

    /** 在给定范围内取离死亡地点最近的可用祭品；范围内没有时返回 null。 */
    private static LivingEntity nearestBabelOffering(ServerLevel level, AABB box, double maxSqr,
                                                     Predicate<LivingEntity> extra,
                                                     double x, double y, double z) {
        LivingEntity best = null;
        double bestSqr = maxSqr;
        for (LivingEntity candidate : level.getEntitiesOfClass(LivingEntity.class, box,
                entity -> entity.isAlive() && isBabelOffering(entity) && extra.test(entity))) {
            double dx = x - candidate.getX();
            double dy = y - candidate.getY();
            double dz = z - candidate.getZ();
            double distance = dx * dx + dy * dy + dz * dz;
            if (distance <= bestSqr) {
                bestSqr = distance;
                best = candidate;
            }
        }
        return best;
    }

    /**
     * 是否可作为「巴别塔回忆」的祭品：特蕾西娅或天灾的王女。
     * 只看实体类型，因此自然生成、结构召唤、技能召唤（精锐集结 / 女祭司之眼）、
     * 刷怪蛋与认主的个体全部适用，补上了「召唤的也算献祭」这一项。
     */
    private static boolean isBabelOffering(LivingEntity entity) {
        return entity instanceof Theresia || entity instanceof CalamityPrincess;
    }

    /** 该特蕾西娅是否为这名博士「精锐集结」召唤的直属随从（按召唤者 UUID 归属）。 */
    private static boolean isEliteOf(LivingEntity entity, UUID prophetId) {
        return entity instanceof Theresia && prophetId != null
                && prophetId.toString().equals(entity.getPersistentData().getString(ELITE_BY));
    }

    /** 该祭品是否带有召唤来源标记：精锐集结召出的特蕾西娅，或女祭司之眼召出的任意生物。 */
    private static boolean isSummonedOffering(LivingEntity entity) {
        CompoundTag d = entity.getPersistentData();
        return d.getBoolean(Theresia.ELITE_SUMMONED) || d.contains(PriestessSkillLogic.SUMMON_BY);
    }

    /** 献祭对象的展示名，用于播报文案。 */
    private static String offeringName(LivingEntity offering) {
        return offering instanceof CalamityPrincess ? "天灾的王女" : "特蕾西娅";
    }

    /** 属性快照：被献祭者（特蕾西娅或天灾的王女）当前全部属性的生效值。 */
    private static List<Map.Entry<Attribute, Double>> snapshotAttributes(LivingEntity source) {
        List<Map.Entry<Attribute, Double>> values = new ArrayList<>();
        for (Attribute attribute : net.minecraft.core.registries.BuiltInRegistries.ATTRIBUTE) {
            AttributeInstance instance = source.getAttribute(attribute);
            if (instance == null) continue;
            values.add(Map.entry(attribute, instance.getValue()));
        }
        return values;
    }

    /** 把被献祭生物的全部属性写进博士（覆盖基础值），并同步黑闪的持久化基准。 */
    private static void applyInheritedAttributes(Prophet prophet, List<Map.Entry<Attribute, Double>> values) {
        CompoundTag d = prophet.getPersistentData();
        for (Map.Entry<Attribute, Double> entry : values) {
            AttributeInstance target = prophet.getAttribute(entry.getKey());
            if (target == null) continue;
            double value = entry.getValue();
            target.setBaseValue(value);
            // 「我将无我」把部分属性基准写进 persistent data 并每 tick 还原；
            // 同步该基准，避免继承值下一 tick 被旧值覆盖。
            String key = statKey(entry.getKey());
            if (d.contains(key)) d.putDouble(key, value);
        }
    }

    /** 特效：在祭品与博士位置释放献祭粒子；随后杀死被献祭的特蕾西娅或天灾的王女。 */
    private static void sacrificeOffering(ServerLevel level, Prophet prophet, LivingEntity offering) {
        double sx = offering.getX();
        double sy = offering.getY() + offering.getBbHeight() * 0.5D;
        double sz = offering.getZ();
        level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, sx, sy, sz, 40, 0.4D, 0.6D, 0.4D, 0.02D);
        level.sendParticles(ParticleTypes.SOUL, sx, sy, sz, 30, 0.4D, 0.6D, 0.4D, 0.03D);
        // 先标记为祭品再抹除：否则献祭天灾的王女会触发她自身的死亡陨石，波及刚复活的博士。
        CalamityMob.markSacrificed(offering);
        offering.kill();
        double px = prophet.getX();
        double py = prophet.getY() + prophet.getBbHeight() * 0.5D;
        double pz = prophet.getZ();
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, px, py, pz, 60, 0.5D, 0.9D, 0.5D, 0.05D);
        level.sendParticles(ParticleTypes.END_ROD, px, py, pz, 30, 0.4D, 0.7D, 0.4D, 0.02D);
    }

    /** 一笔待触发的巴别塔回忆：死亡快照、死亡地点与到期 tick。 */
    private record PendingBabel(ServerLevel level, CompoundTag snapshot, UUID uuid,
                                double x, double y, double z, long readyTick) {
    }

    /** 服务端停止时清空待处理的死亡登记（静态表跨世界复用，避免残留过期 ServerLevel 引用）。 */
    private static void clearScheduledBabel() {
        PENDING_BABEL.clear();
        SCHEDULED_BABEL.clear();
    }

    // ================= 工具 =================

    private static void announce(ServerLevel level, LivingEntity source, String message, ChatFormatting color) {
        Component component = Component.literal(message).withStyle(color);
        for (ServerPlayer player : level.players()) {
            if (player.distanceToSqr(source) <= 128.0D * 128.0D) {
                player.displayClientMessage(component, false);
            }
        }
    }

    private static LivingEntity resolveAttacker(net.minecraft.world.damagesource.DamageSource source) {
        if (source == null) return null;
        Entity attacker = source.getEntity();
        if (attacker instanceof LivingEntity living) return living;
        Entity direct = source.getDirectEntity();
        if (direct instanceof LivingEntity living) return living;
        if (direct instanceof net.minecraft.world.entity.projectile.Projectile projectile
                && projectile.getOwner() instanceof LivingEntity living) return living;
        return null;
    }

    private static final class ActiveDomain {
        final double cx;
        final double cy;
        final double cz;
        final double radius;
        final UUID caster;

        ActiveDomain(double cx, double cy, double cz, double radius, UUID caster) {
            this.cx = cx;
            this.cy = cy;
            this.cz = cz;
            this.radius = radius;
            this.caster = caster;
        }
    }

    // ================= 事件 =================

    // 注意：嵌套类简单名必须全局唯一（与 RuwosuojianLogic/TiantangzhidianLogic 同理）。
    public static final class ProphetSkillEvents {

        public ProphetSkillEvents() {
        }

        @SubscribeEvent
        public void onLivingAttack(LivingAttackEvent event) {
            LivingEntity victim = event.getEntity();
            if (victim.level().isClientSide || event.isCanceled()) return;
            // 无我时序领域：领域内白名单之外的生物「无法攻击」——攻击来源被领域压制即刻取消，
            //    白名单成员（发动者本人与其弹射物）不受影响，普通生物/玩家在领域内一律出不了手。
            if (victim.level() instanceof ServerLevel level
                    && isAttackSuppressedByDomain(level, event.getSource())) {
                event.setCanceled(true);
                return;
            }
            // 6. 巴别塔回忆复活后的 3 秒无敌：窗口内该博士免疫一切伤害。
            //    取消受击事件即可挡住全部走原版伤害链的来源（近战/弹射物/火焰/摔落等）。
            if (victim instanceof Prophet
                    && isReviveGraceActive(victim, victim.level().getGameTime())) {
                event.setCanceled(true);
            }
        }

        @SubscribeEvent
        public void onLivingDamage(LivingDamageEvent event) {
            LivingEntity victim = event.getEntity();
            if (victim.level().isClientSide || !(victim.level() instanceof ServerLevel level)) return;

            // 4. 我是一有原则且自制力很强的人：半径16格（经游刃有余放大）内生物每次造成伤害时，
            //    博士提升 0.65% 现有数值（乘算）。半径按生物所在位置计算，含博士自身。
            //    最大生命值削弱伤害走 applyMaxHpCut 的上限削减通道，不经由受击事件，天然被排除。
            LivingEntity attacker = resolveAttacker(event.getSource());
            if (attacker != null && attacker != victim && event.getAmount() > 0.0F) {
                for (Prophet prophet : prophetsNear(attacker)) {
                    applyPrincipledBoost(prophet);
                }
            }

            // 5. 我将无我：领悟黑闪后 1.05625% 概率本次攻击伤害结果按 2.5 次方结算，
            //    并将自身属性增强为现有属性 1.1 次方；近战与剑气路径均经由此处生效。
            //    仅在博士攻击其当前锁定的攻击目标、且该目标就是本次受击者时才判定与触发，
            //    溅射/范围伤害波及到的非目标生物不会触发。
            if (attacker instanceof Prophet prophet
                    && ProphetSkillLogic.isBlackFlashTarget(prophet, victim)
                    && event.getAmount() > 0.0F
                    && ProphetSkillLogic.shouldBlackFlash(prophet)) {
                // 「源石计划进度」需求 1：2.5 次方的伤害增幅中，超出 1 的部分按档位缩放
                // （有效指数 = 1 + 1.5 × 进度系数）。
                double power = OriginiumPlanProgress.boosted(BLACK_FLASH_POWER, prophet);
                event.setAmount((float) Math.pow(Math.max(1.0D, event.getAmount()), power));
                ProphetSkillLogic.onBlackFlashEmpower(prophet);
            }

            if (victim instanceof Prophet prophet && prophet.isAlive()) {
                // 2. 领域被动发动：受伤前已损失生命值百分比即为本次受伤后发动领域概率。
                double hpLostBefore = 1.0D - prophet.getHealth() / Math.max(1.0D, prophet.getMaxHealth());
                if (canActivateDomain(prophet) && hpLostBefore > 0.0D
                        && level.getRandom().nextDouble() < hpLostBefore) {
                    activateDomain(prophet);
                }
                // 5. 初见黑闪：初次血量将低于30%时领悟，仅一次。
                if (!hasComprehendedBlackFlash(prophet)
                        && prophet.getHealth() - event.getAmount()
                        <= BLACK_FLASH_HP_THRESHOLD * prophet.getMaxHealth()) {
                    comprehendBlackFlash(prophet);
                }
            }

            // 6. 巴别塔回忆不再于受击事件里拦截致命伤害：博士照常死亡，由 {@link Prophet#die}
            //    登记、死亡后 20 tick 统一结算献祭与复活（见 ProphetSkillLogic.onProphetDeath）。
        }

        @SubscribeEvent
        public void onLivingHeal(LivingHealEvent event) {
            LivingEntity entity = event.getEntity();
            if (entity.level().isClientSide || !(entity instanceof Prophet prophet)) return;
            // 2. 熔断恢复：单次回血超过6.5%视为领域恢复，可继续发动领域。
            if (isDomainFused(prophet) && prophet.isAlive()
                    && event.getAmount() > prophet.getMaxHealth() * FUSED_HEAL_RATIO) {
                prophet.getPersistentData().putBoolean(DOMAIN_FUSED, false);
                if (entity.level() instanceof ServerLevel level) {
                    announce(level, prophet, "领域展开•无我时序：熔断恢复，可再次发动领域",
                            ChatFormatting.GREEN);
                }
            }
        }

        @SubscribeEvent
        public void onServerStopped(ServerStoppedEvent event) {
            // 静态待触发表跨世界复用，停机时清空，避免残留指向旧 ServerLevel 的过期登记。
            clearScheduledBabel();
        }

        @SubscribeEvent
        public void onServerChat(ServerChatEvent event) {
            ServerPlayer player = event.getPlayer();
            if (player == null || !(player.level() instanceof ServerLevel level)) return;
            if (!DOMAIN_TRIGGER.equals(normalize(event.getRawText()))) return;
            Prophet nearest = level.getEntitiesOfClass(Prophet.class, WORLD_BOUNDS, Entity::isAlive)
                    .stream().min(Comparator.comparingDouble(p -> p.distanceToSqr(player))).orElse(null);
            if (nearest == null) return;
            activateDomain(nearest);
        }

        /** 归一化触发语：去除空白与各类引号/括号，并把不同中点符号统一为「•」。 */
        private static String normalize(String text) {
            return text == null ? ""
                    : text.replace(" ", "").replace("\u3000", "")
                    .replace("「", "").replace("」", "").replace("『", "").replace("』", "")
                    .replace("“", "").replace("”", "").replace("\"", "").replace("'", "")
                    .replace("(", "").replace(")", "").replace("（", "").replace("）", "")
                    .replace("·", "•").replace("・", "•");
        }
    }
}
