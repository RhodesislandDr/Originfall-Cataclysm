package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** 开启单人文明延续模式的一次性身份牌。 */
public final class CivilizationContinuanceItem extends Item {
    public CivilizationContinuanceItem() {
        super(new Item.Properties().stacksTo(1).fireResistant());
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResultHolder.sidedSuccess(stack, true);
        }
        if (!serverLevel.getServer().isSingleplayer()) {
            player.displayClientMessage(Component.literal("文明的存续只能在单人存档中使用"), true);
            return InteractionResultHolder.consume(stack);
        }
        if (CalamityLogic.isCivilizationContinuancePlayer(player)) {
            player.displayClientMessage(Component.literal("文明的延续模式已经开启"), true);
            return InteractionResultHolder.consume(stack);
        }

        CalamityLogic.enableCivilizationContinuance(player);
        CalamityLogic.setCalamityModePlayer(player, true);
        DisasterData disasterData = DisasterData.get(serverLevel);
        disasterData.activateByContinuance();
        if (!disasterData.isContinuanceOpeningMeteorsSpawned()) {
            disasterData.markContinuanceOpeningMeteorsSpawned();
            for (int i = 0; i < 10; i++) {
                serverLevel.addFreshEntity(MeteorEntity.createNaturalPrioritizingNonPlayer(
                        serverLevel, player, 128.0D));
            }
        }
        stack.shrink(1);
        player.displayClientMessage(Component.literal("文明的延续模式已开启：天灾正在苏醒"), true);
        return InteractionResultHolder.sidedSuccess(stack, false);
    }
}
