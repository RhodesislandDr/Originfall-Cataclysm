package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.LevelData;

import java.util.ArrayList;
import java.util.List;

/**
 * 独立实现的「恶意等级」系统，规则风格与莱特兰-恶意（L2Hostility）一致，
 * 但完全自持：不读它的类、不反射它的数据，脱离莱特兰恶意也能正常运行。
 *
 * <p>装有莱特兰-恶意时本类不生效，恶意等级与词条一律走
 * {@code OriginfallMaliceCompat}（l2compat 源码集）直连它的真实数据；
 * 未安装时由本类兜底，特性表现与兼容形态一致。</p>
 *
 * <p>等级来源：普通学习者按与世界出生点的距离累积，再叠加当前难度修正；
 * 首领（「女祭司」普瑞赛斯与「预言家」博士）固定按首领级别。</p>
 *
 * <p>等级的用途：决定词条可融合到的等级上限（40/80 两级门槛，封顶 3 级）；
 * 决定恶意词条数量上限的扩容（每提升 20 级增加 1 个上限，见
 * {@link LearnedTraitLogic#maliceLimit}）；首领在初始生成时按首领级别随机附带词条
 * （2~3 级、2~3 条）。</p>
 */
public final class MaliceLevelSystem {
    /** 首领级别的恶意等级基准；普通生物永远不会自然达到这个档位。 */
    public static final int BOSS_LEVEL = 120;
    /** 词条融合的全局封顶等级。 */
    public static final int GLOBAL_MAX_TRAIT_LEVEL = 3;
    /** 击杀继承比例：学习者击杀带恶意等级的目标时，继承对方等级的 32.5%。 */
    public static final double KILL_INHERIT_RATIO = 0.325D;

    public static final String LEVEL_TAG = "OriginFallMaliceLevel";
    public static final String BOSS_TRAITS_TAG = "OriginFallBossTraitsGranted";
    /** 首领初始随机词条池：排除无实际行为落点的游泳与首领本就自带的远程攻击。 */
    private static final String[] BOSS_TRAIT_POOL = {
            LearnedTraitLogic.TELEPORT, LearnedTraitLogic.FIRE_ATTACK, LearnedTraitLogic.WALL_CLIMB,
            LearnedTraitLogic.FLIGHT, LearnedTraitLogic.SPEED, LearnedTraitLogic.REGENERATION,
            LearnedTraitLogic.RESISTANCE, LearnedTraitLogic.KNOCKBACK, LearnedTraitLogic.JUMP,
            LearnedTraitLogic.EXPLOSION, LearnedTraitLogic.MAGNET,
    };
    /** 首领初始词条的条数区间。 */
    private static final int BOSS_TRAIT_COUNT_MIN = 2;
    private static final int BOSS_TRAIT_COUNT_MAX = 3;
    /** 每 8 格出生点距离折算 1 级恶意等级；难度（0~3）每档附加 8 级。 */
    private static final double BLOCKS_PER_LEVEL = 8.0D;
    private static final int DIFFICULTY_BONUS_PER_LEVEL = 8;

    private MaliceLevelSystem() {}

    /** 「女祭司」普瑞赛斯与「预言家」博士按首领级别接入等级系统。 */
    public static boolean isBoss(LivingEntity entity) {
        return entity instanceof Priestess || entity instanceof Prophet;
    }

    /**
     * 幂等入口：首次调用时给学习者定级；首领若尚未附带初始词条则在此随机附带。
     * 由每 tick 的学习逻辑触发，覆盖自然刷怪与代码召唤两条路径。
     */
    public static void ensureAssigned(LivingEntity entity) {
        if (entity == null || entity.level().isClientSide || !(entity instanceof Mob mob)) return;
        if (!LearnedTraitLogic.isLearner(mob)) return;
        if (!mob.getPersistentData().contains(LEVEL_TAG)) {
            mob.getPersistentData().putInt(LEVEL_TAG, isBoss(mob) ? BOSS_LEVEL : computeFieldLevel(mob));
        }
        if (isBoss(mob)) grantBossTraits(mob);
    }

    /**
     * 独立形态的复活再随机：模组机制（复活陨石波次）复活出的模组生物同样丢弃
     * 死亡快照带回的旧等级与旧词条，按复活位置的区域难度重新定级；
     * 首领清除附带标记后重新随机高级词条。与莱特兰在场时的
     * {@code OriginfallMaliceCompat.onRevive} 行为对齐。
     *
     * <p>只对本模组的学习者生效，且幂等（随后每 tick 的 {@link #ensureAssigned}
     * 会因标记已就绪而不再改动）。</p>
     */
    public static void rerollOnRevive(net.minecraft.world.entity.LivingEntity entity) {
        if (entity == null || entity.level().isClientSide || !(entity instanceof Mob mob)) return;
        if (!LearnedTraitLogic.isLearner(mob)) return;
        var tag = mob.getPersistentData();
        tag.remove(LEVEL_TAG);
        tag.remove(BOSS_TRAITS_TAG);
        ensureAssigned(mob);
    }

    /** 读取恶意等级；未定级的首领按首领档位回退，未定级的普通生物回退为 0。 */
    public static int levelOf(LivingEntity entity) {
        if (entity == null) return 0;
        var tag = entity.getPersistentData();
        if (tag.contains(LEVEL_TAG)) return tag.getInt(LEVEL_TAG);
        return isBoss(entity) ? BOSS_LEVEL : 0;
    }

    /** 恶意等级映射到词条可融合的等级上限：40 级解锁 2 级词条，80 级解锁 3 级词条。 */
    public static int maxTraitLevel(int maliceLevel) {
        int cap = 1 + maliceLevel / 40;
        return Math.max(1, Math.min(GLOBAL_MAX_TRAIT_LEVEL, cap));
    }

    /**
     * 击杀继承的等级：被击杀者恶意等级的 {@value #KILL_INHERIT_RATIO} 比例，
     * <b>不足整数的零头一律向上取整</b>。
     * 例：10 级 → 3.25 → 4 级；1 级 → 0.325 → 1 级；0 级不继承。
     */
    public static int inheritedLevel(int victimLevel) {
        if (victimLevel <= 0) return 0;
        return (int) Math.ceil(victimLevel * KILL_INHERIT_RATIO);
    }

    /**
     * 独立形态的击杀继承：学习者击杀带恶意等级的目标后，
     * 其恶意等级至少提升到对方等级的 32.5%（向上取整），<b>只升不降</b>。
     *
     * <p>首领固定停在首领档位，不参与继承；非本模组学习者（原版与其他模组生物）
     * 一律不读取、不施加，避免恶意等级扩散到击杀链之外。</p>
     */
    public static void inheritFromKill(LivingEntity learner, int victimLevel) {
        if (learner == null || learner.level().isClientSide || !(learner instanceof Mob mob)) return;
        // 与莱特兰兼容形态同一放宽口径：本模组生物 + 本模组召唤生物；
        // 首领停在首领档位不参与继承，玩家与一切非模组生物依旧完全走不进来。
        if (!LearnedTraitLogic.isKillLearningCandidate(mob) || isBoss(mob)) return;
        int inherited = inheritedLevel(victimLevel);
        if (inherited <= 0) return;
        int current = levelOf(mob);
        if (inherited <= current) return;
        int capped = Math.min(inherited, BOSS_LEVEL - 1);
        mob.getPersistentData().putInt(LEVEL_TAG, capped);
        LearnedTraitLogic.syncMaliceLevel(mob, capped);
    }

    /** 原版恶意机制的等价规则：距离出生点越远、难度越高，恶意等级越高。 */
    private static int computeFieldLevel(Mob mob) {
        Level level = mob.level();
        LevelData data = level.getLevelData();
        double dx = mob.getX() - data.getXSpawn();
        double dz = mob.getZ() - data.getZSpawn();
        double distance = Math.sqrt(dx * dx + dz * dz);
        int difficulty = level.getDifficulty().getId();
        int computed = (int) (distance / BLOCKS_PER_LEVEL) + difficulty * DIFFICULTY_BONUS_PER_LEVEL;
        return Math.max(0, Math.min(BOSS_LEVEL - 1, computed));
    }

    /**
     * 首领初始生成时按首领级别随机附带词条：
     * 从词条池随机取 2~3 条互不重复的词条，等级在首领档位（{@value #BOSS_LEVEL} 级）
     * 对应的 2~3 级区间内逐条随机；本身封顶 1 级的词条按其上限给 1 级。
     * 幂等：同一实体只附带一次；重复获得由击杀学习路径走融合升级。
     */
    private static void grantBossTraits(Mob mob) {
        if (mob.getPersistentData().getBoolean(BOSS_TRAITS_TAG)) return;
        LearnedTraitCapability data = LearnedTraitCapability.getOrNull(mob);
        if (data == null) return; // 能力尚未附加（极早期构造阶段），下个 tick 会重试。
        List<String> pool = new ArrayList<>();
        for (String trait : BOSS_TRAIT_POOL) {
            if (!data.has(trait)) pool.add(trait);
        }
        shuffleWithMobRandom(pool, mob);
        int wanted = BOSS_TRAIT_COUNT_MIN
                + mob.getRandom().nextInt(BOSS_TRAIT_COUNT_MAX - BOSS_TRAIT_COUNT_MIN + 1);
        int count = Math.min(wanted, pool.size());
        int bossCap = maxTraitLevel(BOSS_LEVEL);
        for (int i = 0; i < count; i++) {
            String trait = pool.get(i);
            int cap = Math.min(bossCap, LearnedTraitLogic.baseMaxLevel(trait));
            int tierMin = Math.min(2, cap);
            int roll = tierMin + mob.getRandom().nextInt(Math.max(1, cap - tierMin + 1));
            data.putAtLevel(trait, roll);
        }
        if (count > 0) {
            LearnedTraitLogic.sync(mob, data);
            LearnedTraitLogic.applyImmediateTraitState(mob, null);
        }
        mob.getPersistentData().putBoolean(BOSS_TRAITS_TAG, true);
    }

    /** 用实体自带的随机源做 Fisher–Yates 洗牌（{@code Collections.shuffle} 只接受 java.util.Random）。 */
    private static void shuffleWithMobRandom(List<String> list, Mob mob) {
        for (int i = list.size() - 1; i > 0; i--) {
            int j = mob.getRandom().nextInt(i + 1);
            String tmp = list.get(i);
            list.set(i, list.get(j));
            list.set(j, tmp);
        }
    }
}
