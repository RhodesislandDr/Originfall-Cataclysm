package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;

/**
 * 模组生物速度治理（纯原版实现，不依赖任何第三方模组，模组独立性不受影响）。
 *
 * <p>规则：当一只模组生物的<b>实际移动速度</b>被词条、效果、击杀成长等机制推得
 * 过快（每秒移动 8 格以上）时，这份上限速度只在索敌追击时生效；没有索敌目标时，
 * 生物恢复每秒 6 格的正常移动速度。实现方式：</p>
 * <ul>
 *   <li>用逐 tick 水平位移的滑动平均测速，且<b>只在治理修正未生效时更新测量值</b>
 *       ——量到的永远是生物“不加治理”的真实上限速度，不会被自己压出的 6 格/秒
 *       干扰，也不依赖任何移速单位换算（行走、冲刺、飞行、游泳同一套）；</li>
 *   <li>压速用本类独占的隐藏乘算修正（{@code MULTIPLY_TOTAL}）按 {@code 6 / 实测速度}
 *       动态折算，并周期性开一个“探针窗口”补测真实上限：速度加成继续增长时系数
 *       自动收紧，加成消退后自动解除。原有速度加成与速度提升机制完全不动——
 *       所有加成照常累积在属性上，重新索敌到目标的瞬间治理修正被移除，
 *       上限速度立即恢复；原有速度上限、击杀成长、SPEED 词条等同样原样保留；</li>
 *   <li>本就不快（≤每秒 8 格）与未索敌停着的生物不受任何影响；</li>
 *   <li>地面与飞行速度（{@code MOVEMENT_SPEED}/{@code FLYING_SPEED}）用同一系数一起治理。</li>
 * </ul>
 *
 * <p>另外在这里为「预言家」博士与「女祭司」普瑞赛斯做索敌半径保底：两者的
 * {@code FOLLOW_RANGE} 达到 128 格（新注册属性已按 128 构建；旧存档实体通过一个
 * 加值修正补齐差额，同样不覆盖原有基础值与击杀成长等修正）。</p>
 */
public final class MovementGovernor {
    private MovementGovernor() {}

    /** 实际每秒移动超过该格数即视为「速度过快」，触发本治理机制。 */
    public static final double TOO_FAST_BPS = 8.0D;
    /** 过快生物在未索敌时的正常移动速度（格/秒）。 */
    public static final double ROAMING_BPS = 6.0D;
    /** 首领级生物的索敌半径（格）。 */
    public static final double BOSS_FOLLOW_RANGE = 128.0D;

    private static final double TICKS_PER_SECOND = 20.0D;
    /** 位移超过该格数视为传送/跨维度，不计入测速。 */
    private static final double TELEPORT_DISCARD = 12.0D;
    /** 治理生效期间，每 400 tick 留 40 tick 的“探针窗口”：暂时放开上限补测一次真实速度。 */
    private static final int PROBE_PERIOD = 400;
    private static final int PROBE_WINDOW = 40;

    private static final UUID SPEED_CAP_ID =
            UUID.fromString("6b2f5c41-9d3e-4a7b-8c54-2e17f0a93d61");
    private static final UUID BOSS_FOLLOW_ID =
            UUID.fromString("6b2f5c41-9d3e-4a7b-8c54-2e17f0a93d63");

    /** 单只生物的测速状态；仅服务端单线程访问。 */
    private static final class Observation {
        double lastX;
        double lastZ;
        double uncappedBps;
        boolean primed;
        /** 上一 tick 结束时治理修正是否生效：决定本 tick 量到的位移是否可信（未受压速影响）。 */
        boolean wasGoverning;
    }

    private static final Map<Mob, Observation> OBSERVATIONS = new WeakHashMap<>();

    /** 服务端每 tick 调用；只作用于本模组生物（含两个源石傀儡），其余实体直接返回。 */
    public static void tick(LivingEntity living) {
        if (!(living instanceof Mob mob)) return;
        if (!(mob instanceof CalamityMob || mob instanceof SourceOreGolem)) return;
        if (mob instanceof Prophet || mob instanceof Priestess) {
            ensureBossFollowRange(mob);
        }
        govern(mob);
    }

    private static void govern(Mob mob) {
        AttributeInstance instance = mob.getAttribute(Attributes.MOVEMENT_SPEED);
        if (instance == null) return;
        Observation observation = OBSERVATIONS.computeIfAbsent(mob, key -> new Observation());
        double dx = mob.getX() - observation.lastX;
        double dz = mob.getZ() - observation.lastZ;
        observation.lastX = mob.getX();
        observation.lastZ = mob.getZ();
        double displacement = Math.sqrt(dx * dx + dz * dz);
        boolean governing = instance.getModifier(SPEED_CAP_ID) != null;
        // 只在“上一 tick 未被压速”时采样：量到的始终是生物不加治理的真实上限速度；
        // 压速生效期间冻结旧值，避免被自己压出的 6 格/秒拉低读数又误解除。
        if (observation.primed && !observation.wasGoverning && mob.isAlive()) {
            if (displacement <= TELEPORT_DISCARD) {
                double sample = displacement * TICKS_PER_SECOND;
                observation.uncappedBps = observation.uncappedBps * 0.92D + sample * 0.08D;
            } else {
                observation.uncappedBps = 0.0D; // 传送/跨维度级位移：丢弃读数重新开始
            }
        }
        observation.primed = true;
        boolean pursuing = mob.getTarget() != null && mob.getTarget().isAlive();
        boolean tooFast = observation.uncappedBps > TOO_FAST_BPS;
        // 探针窗口：即便治理在生效，也周期性放开一小段补测真实上限——速度加成继续增长时
        // 系数会随之收紧；加成消退、不再过快时也会自动解除，全程不改写任何原有加成。
        boolean probing = mob.tickCount % PROBE_PERIOD >= PROBE_PERIOD - PROBE_WINDOW;
        if (!pursuing && tooFast && !probing) {
            // 未索敌且实测过快：按 6 / 实测 折算乘算修正，把无目标时的实际移速压回每秒 6 格。
            double amount = ROAMING_BPS / observation.uncappedBps - 1.0D;
            AttributeModifier cap = instance.getModifier(SPEED_CAP_ID);
            if (cap == null || Math.abs(cap.getAmount() - amount) >= 0.02D) {
                applyCap(instance, SPEED_CAP_ID, amount, "movement_speed");
                AttributeInstance flight = mob.getAttribute(Attributes.FLYING_SPEED);
                if (flight != null) applyCap(flight, SPEED_CAP_ID, amount, "flying_speed");
            }
            observation.wasGoverning = true;
            return;
        }
        // 索敌追击、本就不快、探针窗口或未索敌静停：一律不加限制。
        if (governing) {
            instance.removeModifier(SPEED_CAP_ID);
            removeFlightCap(mob);
        }
        observation.wasGoverning = false;
    }

    private static void applyCap(AttributeInstance instance, UUID id, double amount, String name) {
        instance.removeModifier(id);
        instance.addTransientModifier(new AttributeModifier(id, GeneratedMod.MOD_ID + ":roaming_" + name + "_cap",
                Math.max(-0.99D, amount), AttributeModifier.Operation.MULTIPLY_TOTAL));
    }

    private static void removeFlightCap(Mob mob) {
        AttributeInstance flight = mob.getAttribute(Attributes.FLYING_SPEED);
        if (flight != null && flight.getModifier(SPEED_CAP_ID) != null) {
            flight.removeModifier(SPEED_CAP_ID);
        }
    }

    private static void ensureBossFollowRange(Mob mob) {
        AttributeInstance instance = mob.getAttribute(Attributes.FOLLOW_RANGE);
        if (instance == null) return;
        if (instance.getModifier(BOSS_FOLLOW_ID) != null) {
            instance.removeModifier(BOSS_FOLLOW_ID);
        }
        double deficit = BOSS_FOLLOW_RANGE - instance.getValue();
        if (deficit > 1.0E-6D) {
            instance.addTransientModifier(new AttributeModifier(BOSS_FOLLOW_ID,
                    GeneratedMod.MOD_ID + ":boss_follow_range",
                    deficit, AttributeModifier.Operation.ADDITION));
        }
    }
}
