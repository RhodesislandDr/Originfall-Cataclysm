package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.SwordItem;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** 两种源石生物共用的角色骨架，保留原版 humanoid 动作并增加晶体冠、肩饰和胸口核心。 */
public final class SourceOreGolemModel<T extends SourceOreGolem> extends HumanoidModel<T> {
    /** 眨眼眼睑（仅身体层有）：见 {@link BlinkLids}。 */
    private final ModelPart blinkLidRight;
    private final ModelPart blinkLidLeft;

    public SourceOreGolemModel(ModelPart root) {
        super(root);
        this.blinkLidRight = BlinkLids.find(root.getChild("head"), "blink_lid_right");
        this.blinkLidLeft = BlinkLids.find(root.getChild("head"), "blink_lid_left");
        if (this.blinkLidRight != null) this.blinkLidRight.skipDraw = true;
        if (this.blinkLidLeft != null) this.blinkLidLeft.skipDraw = true;
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        // 眨眼（纯外貌）：随头骨骼走，睁眼时两块眼睑完全 skipDraw。
        BlinkLids.apply(blinkLidRight, blinkLidLeft, entity, ageInTicks);
    }

    @Override
    public void prepareMobModel(T entity, float limbSwing, float limbSwingAmount, float partialTick) {
        super.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTick);
        leftArmPose = ArmPose.EMPTY;
        rightArmPose = ArmPose.EMPTY;
        ItemStack weapon = entity.getMainHandItem();
        HumanoidArm weaponArm = entity.getMainArm();
        if (isSwordWeapon(weapon)) {
            // 影霄、如我所见、天堂支点等剑类武器按原版单手持剑姿势（同钻石剑）适配。
            setPose(weaponArm, ArmPose.ITEM);
        } else if (weapon.getItem() instanceof BowItem && entity.isUsingItem()
                && entity.getUsedItemHand() == InteractionHand.MAIN_HAND) {
            setPose(weaponArm, ArmPose.BOW_AND_ARROW);
        } else if (weapon.getItem() instanceof CrossbowItem) {
            setPose(weaponArm, CrossbowItem.isCharged(weapon)
                    ? ArmPose.CROSSBOW_HOLD : ArmPose.CROSSBOW_CHARGE);
        } else if (weapon.is(Items.TRIDENT) && entity.isUsingItem()
                && entity.getUsedItemHand() == InteractionHand.MAIN_HAND) {
            setPose(weaponArm, ArmPose.THROW_SPEAR);
        }
    }

    /** 是否为剑类武器：模组三把剑（影霄/如我所见/天堂支点）及所有原版剑统一按钻石剑的持握动作适配。 */
    private static boolean isSwordWeapon(ItemStack weapon) {
        return weapon.getItem() instanceof SwordItem;
    }

    private void setPose(HumanoidArm arm, ArmPose pose) {
        if (arm == HumanoidArm.RIGHT) {
            rightArmPose = pose;
        } else {
            leftArmPose = pose;
        }
    }

    public static LayerDefinition createBodyLayer() {
        return createLayer(CubeDeformation.NONE);
    }

    public static LayerDefinition createInnerArmorLayer() {
        return createLayer(new CubeDeformation(0.5F));
    }

    public static LayerDefinition createOuterArmorLayer() {
        return createLayer(new CubeDeformation(1.0F));
    }

    private static LayerDefinition createLayer(CubeDeformation deformation) {
        MeshDefinition mesh = HumanoidModel.createMesh(deformation, 0.0F);
        PartDefinition root = mesh.getRoot();
        PartDefinition head = root.getChild("head");
        PartDefinition body = root.getChild("body");

        head.addOrReplaceChild("crown_center", CubeListBuilder.create().texOffs(8, 0)
                .addBox(-1.5F, -2.0F, -3.0F, 3.0F, 2.0F, 2.0F, deformation),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        head.addOrReplaceChild("crown_left", CubeListBuilder.create().texOffs(12, 0)
                .addBox(-3.5F, -2.0F, -2.5F, 2.0F, 2.0F, 2.0F, deformation),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        head.addOrReplaceChild("crown_right", CubeListBuilder.create().texOffs(14, 0)
                .addBox(1.5F, -2.0F, -2.5F, 2.0F, 2.0F, 2.0F, deformation),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        body.addOrReplaceChild("shoulder_right", CubeListBuilder.create().texOffs(44, 32)
                .addBox(-7.5F, -3.0F, -2.5F, 4.0F, 3.5F, 3.5F, deformation),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        body.addOrReplaceChild("shoulder_left", CubeListBuilder.create().texOffs(36, 32)
                .addBox(3.5F, -3.0F, -2.5F, 4.0F, 3.5F, 3.5F, deformation),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        body.addOrReplaceChild("chest_core", CubeListBuilder.create().texOffs(28, 32)
                .addBox(-2.0F, -8.0F, -2.8F, 4.0F, 5.0F, 1.0F, deformation),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        // 眨眼眼睑只加在身体层（deformation==NONE）：装甲层网格没有这两块，构造时取到 null 跳过。
        if (deformation == CubeDeformation.NONE) {
            BlinkLids.addEyelids(head, deformation);
        }
        return LayerDefinition.create(mesh, 64, 64);
    }
}
