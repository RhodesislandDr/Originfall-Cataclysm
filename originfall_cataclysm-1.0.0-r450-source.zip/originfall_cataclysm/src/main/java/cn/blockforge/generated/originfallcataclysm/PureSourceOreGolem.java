package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;

/** 哈气贤者：攻击和范围感染能力更强，并会吸收陨石规格强化。 */
public final class PureSourceOreGolem extends SourceOreGolem {
    public PureSourceOreGolem(EntityType<? extends PureSourceOreGolem> type, Level level) {
        super(type, level);
    }

    public static net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder createAttributes() {
        return SourceOreGolem.createAttributes(15.0D);
    }

    @Override
    protected int infectionInterval() {
        return 1;
    }

    @Override
    protected int infectionLayersPerAttack() {
        return 1;
    }

    @Override
    protected float healingPerSecond() {
        return 2.0F;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        // 被流放虚空/内化宇宙期间不再进行感染判定：身处虚空不应继续对周围目标施放判定。
        if (TiantangzhidianLogic.isExiled(this)) return;
        ServerLevel server = (ServerLevel) level();
        // 半径 4 格内的非本模组生物每 tick 独立进行 0.00325% 的感染判定。
        for (LivingEntity living : server.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(4.0D),
                entity -> entity.isAlive() && entity != this
                        && entity.distanceToSqr(this) <= 16.0D)) {
            if (server.getRandom().nextDouble() < 0.0000325D) {
                int layers = 5 + CalamityLogic.pureSourceOreGolemHealthBonus(this);
                CalamityLogic.addSourceOreInfectionLayer(living, layers, 0);
            }
        }
    }

    @Override
    public void onMeteorBlast(float damageMultiplier) {
        if (damageMultiplier <= 0.0F) return;
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(getMaxHealth() + damageMultiplier * 10.0D);
        getAttribute(Attributes.ARMOR).setBaseValue(getAttribute(Attributes.ARMOR).getBaseValue() + damageMultiplier);
        setHealth(Math.min(getMaxHealth(), getHealth() + damageMultiplier * 10.0F));
    }
}
