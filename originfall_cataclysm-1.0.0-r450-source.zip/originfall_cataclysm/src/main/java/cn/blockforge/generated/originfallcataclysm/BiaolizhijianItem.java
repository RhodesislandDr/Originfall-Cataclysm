package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * 「表里之间」：通过「预言家」博士召唤仪式（2*2 张师块水池投掷八种祭品，传送音效为完成信号）获得的
 * 一次性道具。右键地面时在原地召唤「预言家」博士，使用后该道具消失。
 */
public final class BiaolizhijianItem extends Item {
    public BiaolizhijianItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (!(level instanceof ServerLevel server)) {
            // 客户端侧返回成功：既播放挥动动画，也把使用指令发给服务器结算。
            return InteractionResult.sidedSuccess(true);
        }
        BlockPos clicked = context.getClickedPos();
        Direction face = context.getClickedFace();
        BlockPos spawn = findSpawn(server, clicked, face);
        if (spawn == null) {
            if (context.getPlayer() != null) {
                context.getPlayer().displayClientMessage(
                        Component.literal("表里之间：此处空间不足，无法召唤「预言家」博士"), true);
            }
            return InteractionResult.FAIL;
        }

        Prophet prophet = GeneratedMod.PROPHET.get().create(server);
        if (prophet == null) return InteractionResult.FAIL;

        float yaw = server.getRandom().nextFloat() * 360.0F;
        if (context.getPlayer() != null && (Math.abs(context.getPlayer().getX() - spawn.getX()) > 0.01D
                || Math.abs(context.getPlayer().getZ() - spawn.getZ()) > 0.01D)) {
            double dx = context.getPlayer().getX() - (spawn.getX() + 0.5D);
            double dz = context.getPlayer().getZ() - (spawn.getZ() + 0.5D);
            yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        }
        prophet.moveTo(spawn.getX() + 0.5D, spawn.getY(), spawn.getZ() + 0.5D, yaw, 0.0F);
        prophet.finalizeSpawn(server, server.getCurrentDifficultyAt(spawn),
                MobSpawnType.MOB_SUMMONED, null, new CompoundTag());
        prophet.setPersistenceRequired();
        server.addFreshEntity(prophet);

        // 一次性道具：使用后消失。
        context.getItemInHand().shrink(1);
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("右键地面召唤「预言家」博士，使用后消失"));
    }

    /** 在点击面旁找一个可容纳 2 格高生物的位置：优先点击面相邻格，其次点击块上方，最后向上搜索。 */
    private static BlockPos findSpawn(ServerLevel server, BlockPos clicked, Direction face) {
        BlockPos beside = clicked.relative(face);
        if (clearance(server, beside)) return beside;
        BlockPos above = clicked.above();
        if (clearance(server, above)) return above;
        for (int i = 1; i < 8; i++) {
            BlockPos candidate = beside.above(i);
            if (clearance(server, candidate)) return candidate;
        }
        return null;
    }

    private static boolean clearance(ServerLevel server, BlockPos pos) {
        return passable(server, pos) && passable(server, pos.above());
    }

    private static boolean passable(ServerLevel server, BlockPos pos) {
        return server.getBlockState(pos).isAir();
    }
}
