package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundUpdateMobEffectPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;

public final class CalamityLogic {
    private static final String CALAMITY_HOSTILE_TAG = "OriginFallCalamityHostile";
    public static final String REVIVAL_SCHEDULED_TAG = "RevivalScheduled";
    /** 普通转化生物在半径 32 格内寻找目标。 */
    public static final double CONVERTED_TARGET_RADIUS = 32.0D;
    /** 天灾信使的索敌半径为 64 格。 */
    public static final double CALAMITY_MESSENGER_TARGET_RADIUS = 64.0D;
    private static final long REVIVAL_RESULT_DELAY_TICKS = 400L;
    private static final long REVIVAL_AFTER_RESULT_DELAY_TICKS = 100L;
    private static final long FRIENDLY_REVIVAL_DELAY_TICKS = 200L;
    private static final Set<Mob> CONVERTED_GOAL_MOBS = Collections.newSetFromMap(new WeakHashMap<>());
    private static final java.util.Map<net.minecraft.server.MinecraftServer, Recipe<?>> DISABLED_SOURCE_RECIPES =
            new WeakHashMap<>();
    private static final Set<java.util.UUID> SCHEDULED_REVIVALS = new java.util.HashSet<>();
    private static final List<PendingRevival> PENDING_REVIVALS = new ArrayList<>();
    private static final java.util.Map<java.util.UUID, RevivalWave> REVIVAL_WAVES = new java.util.HashMap<>();
    private static final String INFECTION_DEATH = "OriginFallInfectionDeath";
    private static final String INFECTION_EXPOSURE_TICKS = "OriginFallInfectionExposureTicks";
    private static final String INFECTION_LAST_EXPOSURE = "OriginFallInfectionLastExposure";
    private static final String CALAMITY_MODE = "OriginFallCalamityMode";
    private static final String CIVILIZATION_CONTINUANCE = "OriginFallCivilizationContinuance";
    private static final String CIVILIZATION_GIFT_GIVEN = "OriginFallCivilizationGiftGiven";
    private static final String INFECTION_MAX_HEALTH = "OriginFallInfectionMaxHealth";
    private static final String INFECTION_ATTACK_DAMAGE = "OriginFallInfectionAttackDamage";
    private static final String INFECTION_ARMOR = "OriginFallInfectionArmor";
    private static final String INFECTION_HUNT_UNTIL = "OriginFallInfectionHuntUntil";
    private static final String INFECTION_PENDING_DOWNGRADE = "OriginFallInfectionPendingDowngrade";
    // ---------------- 坍缩（邪魔）状态的数据键 ----------------
    /** 在邪魔领域内累计停留的 tick 数（节流记账，每 10 tick 累计一次）。 */
    private static final String COLLAPSE_EXPOSURE_TICKS = "OriginFallCollapseExposureTicks";
    /** 上一次累计曝光的游戏刻，用于判定中断与同 tick 去重。 */
    private static final String COLLAPSE_EXPOSURE_LAST = "OriginFallCollapseExposureLast";
    /** 当前层数下一次升级的游戏刻；到达第 5 层后移除该键。 */
    private static final String COLLAPSE_NEXT_UPGRADE = "OriginFallCollapseNextUpgrade";
    /**
     * 已挂载「邪魔索敌」目标的<i>个体</i>集合。
     *
     * <p>索敌只加在感染坍缩的这一个个体身上：没有坍缩的同类不会被改动。用内存里的弱引用集合
     * 而不是持久化标记，是因为目标本身不会随存档保存——区块卸载后重新加载会得到新的 Mob 实例，
     * 旧标记会让它永远拿不到索敌目标。weak 集合让卸载后的实例自然被回收。</p>
     */
    private static final Set<Mob> COLLAPSE_GOAL_MOBS = Collections.newSetFromMap(new WeakHashMap<>());
    /** 源石美化包使用时只标记原实体，避免进入死亡、复活或原个体衍生链。 */
    private static final String BEAUTIFICATION_KILL = "OriginFallBeautificationKill";
    /** 源石感染最多 255 层；药水效果的 amplifier 使用层数减一表示。 */
    public static final int MAX_SOURCE_ORE_INFECTION_LAYERS = 255;
    /** 源石感染每层的标准持续时间：20 秒。 */
    public static final int SOURCE_ORE_INFECTION_DURATION_TICKS = 20 * 20;
    /** 坍缩层数上限：第 1~4 层按时间成长，第 5 层不再增长且永久保持。 */
    public static final int MAX_COLLAPSE_LAYERS = 5;
    /** 坍缩传播（邪魔领域 / 邪魔范围）半径：4 格。 */
    public static final double COLLAPSE_SPREAD_RADIUS = 4.0D;
    /**
     * 无坍缩生物在邪魔领域内累计待满 10 秒（200 tick，基准值）后附加一层坍缩。
     * 实际所需时长受「源石计划进度」调控：难度负比例按同幅度延长、正比例按同幅度缩短，
     * 见 {@link OriginiumPlanProgress#zoneInfectionTimeFactor}。
     */
    public static final long COLLAPSE_EXPOSURE_REQUIRED_TICKS = 200L;
    /** 坍缩源的传播扫描间隔（tick），同时作为曝光记账的最小粒度。 */
    private static final long COLLAPSE_SPREAD_INTERVAL = 10L;
    /** 每层坍缩经过「层数 × 1 分钟」后升一层。 */
    public static final long COLLAPSE_UPGRADE_TICKS = 20L * 60L;
    /** 每层坍缩提供的移动速度加成：+20%。 */
    public static final double COLLAPSE_SPEED_PER_LAYER = 0.20D;
    /** 每层坍缩提供的攻击力加成：+10%。 */
    public static final double COLLAPSE_ATTACK_PER_LAYER = 0.10D;
    /** 被坍缩生物攻击时附加一层坍缩的概率：10%。 */
    public static final double COLLAPSE_ATTACK_LAYER_CHANCE = 0.10D;
    /** 每次邪魔区域扫描冒出的黑点数量下限（含）。 */
    private static final int COLLAPSE_FIELD_PARTICLES_MIN = 3;
    /** 在上限之外随机追加的数量：每秒冒出十来颗，散在半径 4 格里是「咕嘟冒泡」而不是连成一片。 */
    private static final int COLLAPSE_FIELD_PARTICLES_RANDOM = 3;
    /** 区域粒子只在地表与坍缩源高度差不超过该值（格）时喷出，避免洞穴/高空的源错位。 */
    private static final double COLLAPSE_FIELD_VERTICAL_LIMIT = 6.0D;
    /** 陨石每点伤害倍率折算的感染层数期望（32.5%/点，零头概率取整）；与「初始转化概率」规则无关。 */
    private static final double BASE_INFECTION_CHANCE = 0.325D;

    private CalamityLogic() {}

    /**
     * 中立与敌对生物判定：原版 Enemy/NeutralMob 接口之外，再按 MONSTER 分类兜底，
     * 覆盖未实现接口的第三方模组敌对生物。友好生物（动物、村民、铁傀儡等）不属于此列。
     */
    public static boolean isNaturalHostile(LivingEntity entity) {
        return entity instanceof Enemy || entity instanceof NeutralMob
                || entity.getType().getCategory() == net.minecraft.world.entity.MobCategory.MONSTER;
    }

    public static boolean isConvertedHostile(LivingEntity entity) {
        return entity instanceof EndWalker || entity instanceof CalamityMessenger
                || entity != null && !(entity instanceof Player) && !(entity instanceof CalamityMob)
                && !(entity instanceof SourceOreGolem)
                && entity.getPersistentData().getBoolean(CALAMITY_HOSTILE_TAG);
    }

    /** 转化生物密度统计口径：终焉行者、天灾信使以及被打上转化标记的生物。 */
    public static boolean isConvertedCreature(LivingEntity entity) {
        return entity instanceof EndWalker || entity instanceof CalamityMessenger
                || isConvertedHostile(entity);
    }

    /**
     * 转化生物密度上限按受害者所在区块的 3*3 区块范围统计。
     * 达到上限后，被转化生物击杀和源石感染致杀都不再触发转化；陨石转化不受此限制。
     */
    public static boolean isConversionDensitySaturated(ServerLevel level, LivingEntity victim) {
        if (level == null || victim == null) return false;
        int limit = OriginFallGameRules.conversionMobDensity(level);
        net.minecraft.world.level.ChunkPos center = new net.minecraft.world.level.ChunkPos(victim.blockPosition());
        double minX = (center.x - 1) * 16.0D;
        double minZ = (center.z - 1) * 16.0D;
        double maxX = (center.x + 2) * 16.0D;
        double maxZ = (center.z + 2) * 16.0D;
        AABB area = new AABB(minX, level.getMinBuildHeight(), minZ,
                maxX, level.getMaxBuildHeight(), maxZ);
        long count = level.getEntitiesOfClass(LivingEntity.class, area,
                entity -> entity != victim && entity.isAlive() && isConvertedCreature(entity)).size();
        return count >= limit;
    }

    /**
     * 转化生物、天灾生物、源石耄耋和哈气贤者不受陨石（含其爆炸伤害）、陨石块及黑色晶体影响。
     * 「哈基玖」按中立生物口径结算：替身与本尊都不享受这层免疫，陨石的爆炸伤害与
     * 感染附加照常命中它。
     */
    public static boolean isMeteorAndCrystalImmune(LivingEntity entity) {
        return entity instanceof CalamityMob && !(entity instanceof Theresia)
                && !(entity instanceof Apocata)
                || entity instanceof SourceOreGolem || isConvertedHostile(entity);
    }

    public static boolean isCivilizationContinuancePlayer(Player player) {
        return player != null && player.getPersistentData().getBoolean(CIVILIZATION_CONTINUANCE);
    }

    /** 文明延续是单人存档的全局阵营开关；多人或普通模式下源石实体保持友好。 */
    public static boolean isCivilizationContinuanceActive(ServerLevel level) {
        return level != null && DisasterData.get(level).isCalamityActive()
                && level.getServer().getPlayerList().getPlayers().stream()
                .anyMatch(CalamityLogic::isCivilizationContinuancePlayer);
    }

    public static boolean isCivilizationContinuanceActive(LivingEntity entity) {
        return entity != null && entity.level() instanceof ServerLevel level
                && isCivilizationContinuanceActive(level);
    }

    /** 文明延续中，只有初生魔王和天灾王女可以作为周期陨石的天灾中心。 */
    public static boolean canSummonNaturalMeteorFrom(LivingEntity source) {
        if (source == null || !(source.level() instanceof ServerLevel level)
                || !isCivilizationContinuanceActive(level)) return true;
        return source instanceof YoungDemonLord || source instanceof CalamityPrincess;
    }

    /** 文明延续玩家造成的击杀不触发任何生物同化。 */
    public static boolean isCivilizationContinuancePlayerAttack(LivingEntity attacker) {
        return attacker instanceof Player player && isCivilizationContinuancePlayer(player);
    }

    /** 源石耄耋和哈气贤者始终属于源石阵营，不因召唤者或当前模式改变。 */
    public static boolean isSourceOreGolemHostile(SourceOreGolem golem) {
        return golem != null;
    }

    public static void enableCivilizationContinuance(Player player) {
        player.getPersistentData().putBoolean(CIVILIZATION_CONTINUANCE, true);
        removeSourceOfRuinFromInventory(player);
        if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
            removeSourceOfRuinRecipe(serverPlayer);
            disableSourceOfRuinRecipe(serverPlayer.getServer());
        }
    }

    /** 清除玩家所有栏位中的毁灭之源，包括背包、快捷栏、盔甲栏和副手。 */
    public static void removeSourceOfRuinFromInventory(Player player) {
        if (player == null) return;
        for (int slot = 0; slot < player.getInventory().getContainerSize(); slot++) {
            ItemStack stack = player.getInventory().getItem(slot);
            if (stack.is(GeneratedMod.SOURCE_OF_RUIN.get())) {
                player.getInventory().setItem(slot, ItemStack.EMPTY);
            }
        }
        if (player.getOffhandItem().is(GeneratedMod.SOURCE_OF_RUIN.get())) {
            player.setItemInHand(net.minecraft.world.InteractionHand.OFF_HAND, ItemStack.EMPTY);
        }
    }

    /** 文明延续期间撤销毁灭之源配方的配方书解锁状态。 */
    public static void removeSourceOfRuinRecipe(net.minecraft.server.level.ServerPlayer player) {
        if (player == null) return;
        ResourceLocation recipeId = ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "source_of_ruin");
        java.util.Optional<? extends Recipe<?>> loadedRecipe = player.getServer().getRecipeManager().byKey(recipeId);
        Recipe<?> recipe = loadedRecipe.isPresent() ? loadedRecipe.get()
                : DISABLED_SOURCE_RECIPES.get(player.getServer());
        if (recipe != null) {
            @SuppressWarnings({"rawtypes", "unchecked"})
            java.util.Collection recipes = new java.util.ArrayList();
            recipes.add(recipe);
            player.getRecipeBook().removeRecipes(recipes, player);
        }
    }

    /** 从当前服务端配方管理器中移除毁灭之源配方；资源重载后会在下一 tick 再次执行。 */
    private static void disableSourceOfRuinRecipe(net.minecraft.server.MinecraftServer server) {
        RecipeManager manager = server.getRecipeManager();
        ResourceLocation recipeId = ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "source_of_ruin");
        Recipe<?> recipe = manager.byKey(recipeId).orElse(null);
        if (recipe == null) return;
        DISABLED_SOURCE_RECIPES.putIfAbsent(server, recipe);
        manager.replaceRecipes(manager.getRecipes().stream()
                .filter(candidate -> !candidate.getId().equals(recipeId))
                .toList());
    }

    /** 文明延续结束后恢复原本被临时移除的配方。 */
    public static void restoreSourceOfRuinRecipe(net.minecraft.server.MinecraftServer server) {
        if (server == null) return;
        Recipe<?> recipe = DISABLED_SOURCE_RECIPES.remove(server);
        if (recipe == null) return;
        RecipeManager manager = server.getRecipeManager();
        if (manager.byKey(recipe.getId()).isEmpty()) {
            java.util.List<Recipe<?>> recipes = new java.util.ArrayList<>(manager.getRecipes());
            recipes.add(recipe);
            manager.replaceRecipes(recipes);
        }
    }

    /** 文明延续在任意维度生效时，清理所有在线玩家和地面掉落物中的毁灭之源。 */
    public static void enforceCivilizationContinuanceRestrictions(net.minecraft.server.MinecraftServer server) {
        if (server == null) return;
        boolean active = server.getPlayerList().getPlayers().stream()
                .anyMatch(CalamityLogic::isCivilizationContinuancePlayer);
        if (!active) return;
        // 先从配方书撤销解锁，再从服务端配方管理器移除配方，避免 byKey() 已为空而漏清理客户端配方书。
        for (net.minecraft.server.level.ServerPlayer player : server.getPlayerList().getPlayers()) {
            removeSourceOfRuinFromInventory(player);
            removeSourceOfRuinRecipe(player);
        }
        disableSourceOfRuinRecipe(server);
        for (ServerLevel level : server.getAllLevels()) {
            for (ItemEntity item : level.getEntities(EntityType.ITEM,
                    entity -> entity.getItem().is(GeneratedMod.SOURCE_OF_RUIN.get()))) {
                item.discard();
            }
        }
    }

    public static boolean hasReceivedCivilizationGift(Player player) {
        return player != null && player.getPersistentData().getBoolean(CIVILIZATION_GIFT_GIVEN);
    }

    public static void markCivilizationGiftGiven(Player player) {
        player.getPersistentData().putBoolean(CIVILIZATION_GIFT_GIVEN, true);
    }

    /** 天灾关闭后，文明延续选择随存档永久保留，但玩家恢复普通阵营和保护状态。 */
    public static void clearCivilizationContinuance(Player player) {
        player.getPersistentData().remove(CIVILIZATION_CONTINUANCE);
    }

    /** 关闭本维度的天灾与文明延续，并立即撤销天灾生物对玩家的旧目标。 */
    public static void disableCalamityModes(ServerLevel level) {
        for (ServerLevel dimension : level.getServer().getAllLevels()) {
            DisasterData.get(dimension).deactivateCalamity();
            for (Player player : dimension.players()) {
                setCalamityModePlayer(player, false);
                clearCivilizationContinuance(player);
            }
            for (Mob mob : dimension.getEntitiesOfClass(Mob.class,
                    new net.minecraft.world.phys.AABB(-3.0E7D, dimension.getMinBuildHeight(), -3.0E7D,
                            3.0E7D, dimension.getMaxBuildHeight(), 3.0E7D), Entity::isAlive)) {
                if ((mob instanceof CalamityMob || mob instanceof SourceOreGolem || isConvertedHostile(mob))
                        && mob.getTarget() instanceof Player) {
                    mob.setTarget(null);
                }
            }
        }
        restoreSourceOfRuinRecipe(level.getServer());
    }

    public enum Faction {
        SOURCE_ORE,
        CONTINUANCE,
        /** 邪魔：感染坍缩后进入的新阵营，与所有非同阵营生物敌对。 */
        COLLAPSE,
        NEUTRAL
    }

    /** 返回实体的明确阵营；未选择模式的玩家和原版生物保持中立。 */
    public static Faction getFaction(LivingEntity entity) {
        if (entity == null) return Faction.NEUTRAL;
        // 坍缩（邪魔）先于一切：感染个体立刻脱离原阵营，成为所有生物的公敌。
        if (isCollapsed(entity)) return Faction.COLLAPSE;
        if (entity instanceof Player player) {
            // 文明的延续开启时会同时保留天灾开关，但玩家应优先归入存续阵营。
            if (isCivilizationContinuancePlayer(player)) return Faction.CONTINUANCE;
            if (isCalamityModePlayer(player)) return Faction.SOURCE_ORE;
            return Faction.NEUTRAL;
        }
        if (entity instanceof Theresia) return Faction.CONTINUANCE;
        if (entity instanceof Prophet) return Faction.CONTINUANCE;
        // 哈基玖：深蓝之树联动彩蛋生物，性质等同本尊——不属于源石也不属于存续，
        // 两阵营都不会把它当友军或敌军索敌，只有它自己被打了才还手。
        if (entity instanceof Apocata) return Faction.NEUTRAL;
        if (entity instanceof CalamityMob || entity instanceof SourceOreGolem
                || isConvertedHostile(entity)
                || entity.getPersistentData().getBoolean("OriginFallSourceOreFaction")) {
            return Faction.SOURCE_ORE;
        }
        return Faction.NEUTRAL;
    }

    public static boolean isSourceOreFactionMember(LivingEntity entity) {
        return getFaction(entity) == Faction.SOURCE_ORE;
    }

    public static boolean isContinuanceFactionMember(LivingEntity entity) {
        return getFaction(entity) == Faction.CONTINUANCE;
    }

    /** 两个实体只有在明确属于同一阵营时才互为友好；中立不等于友好。 */
    public static boolean isFactionAlly(LivingEntity first, LivingEntity second) {
        if (first == null || second == null || first == second) return false;
        Faction firstFaction = getFaction(first);
        Faction secondFaction = getFaction(second);
        return firstFaction != Faction.NEUTRAL && firstFaction == secondFaction;
    }

    /** 不同明确阵营相互敌对；中立实体只按原版敌对关系处理。邪魔与一切非同阵营者敌对。 */
    public static boolean isOpposingFaction(LivingEntity first, LivingEntity second) {
        if (first == null || second == null || first == second) return false;
        Faction firstFaction = getFaction(first);
        Faction secondFaction = getFaction(second);
        // 邪魔阵营：与所有生物敌对，中立生物（动物、村民等）同样纳入敌对范围。
        if (firstFaction == Faction.COLLAPSE || secondFaction == Faction.COLLAPSE) {
            return firstFaction != secondFaction;
        }
        return firstFaction != Faction.NEUTRAL && secondFaction != Faction.NEUTRAL
                && firstFaction != secondFaction;
    }

    /**
     * 巴别塔行动模式：开启后源石阵营在原有索敌（对营阵营、中立与敌对生物）之外，
     * 额外索敌友好生物，即攻击一切非源石阵营生物。
     * 友伤判定仍然先行生效，源石阵营内部不会因为该模式互相攻击。
     */
    public static boolean isBabelAssault(LivingEntity source, LivingEntity target) {
        if (source == null || target == null || source == target || !target.isAlive()) return false;
        if (!(source.level() instanceof ServerLevel level)
                || !OriginFallGameRules.isBabelActionMode(level)) return false;
        return isSourceOreFactionMember(source) && getFaction(target) != Faction.SOURCE_ORE;
    }

    /** 判断效果是否由本模组注册；Mixin 用此入口覆盖所有本模组负面效果。 */
    public static boolean isOriginFallModEffect(MobEffectInstance effect) {
        if (effect == null || effect.getEffect() == null) return false;
        ResourceLocation key = net.minecraft.core.registries.BuiltInRegistries.MOB_EFFECT
                .getKey(effect.getEffect());
        return key != null && GeneratedMod.MOD_ID.equals(key.getNamespace());
    }

    // ================= 坍缩（邪魔）状态 =================

    /** 效果实例是否为本模组的坍缩效果。 */
    public static boolean isCollapseEffect(MobEffectInstance effect) {
        return effect != null && effect.getEffect() == GeneratedMod.COLLAPSE.get();
    }

    /** 实体是否感染坍缩（效果无法被清除，因此该判定在存活期间恒定）。 */
    public static boolean isCollapsed(LivingEntity entity) {
        return entity != null && entity.getEffect(GeneratedMod.COLLAPSE.get()) != null;
    }

    /** amplifier 与层数相差 1，并收敛到 1~{@link #MAX_COLLAPSE_LAYERS}。 */
    public static int collapseLayersFromAmplifier(int amplifier) {
        return Math.min(MAX_COLLAPSE_LAYERS, Math.max(1, amplifier + 1));
    }

    /** 当前坍缩层数；未感染返回 0。 */
    public static int collapseLayers(LivingEntity entity) {
        MobEffectInstance effect = entity.getEffect(GeneratedMod.COLLAPSE.get());
        return effect == null ? 0 : collapseLayersFromAmplifier(effect.getAmplifier());
    }

    /**
     * 附加指定层数的坍缩：封顶 {@link #MAX_COLLAPSE_LAYERS}，效果时长固定为无限，
     * 且不显示药水粒子。升级后按新层数重排下一次升级时间；到达第 5 层后不再计时。
     *
     * <p>两件附加动作都只作用于<i>被感染的这一个个体</i>：</p>
     * <ul>
     *   <li>把效果实例<b>主动同步给正在跟踪它的玩家</b>——原版只把效果下发给玩家自己的
     *       客户端（见 {@code ServerEntity}），其它生物的效果根本不会同步，客户端上的
     *       {@code getEffect(COLLAPSE)} 永远是 null，头部标志贴图因此什么都画不出来。
     *       这里补发 {@link ClientboundUpdateMobEffectPacket}，贴图与层数才能被客户端看到。</li>
     *   <li>给这一个 Mob 补上「邪魔索敌」目标；不改同类其它个体，也不改实体类型本身。</li>
     * </ul>
     */
    public static void addCollapseLayer(LivingEntity entity, int layers) {
        if (entity == null || layers <= 0 || entity.level().isClientSide) return;
        int current = collapseLayers(entity);
        if (current >= MAX_COLLAPSE_LAYERS) return;
        int target = Math.min(MAX_COLLAPSE_LAYERS, current + layers);
        if (target <= current) return;
        MobEffectInstance instance = new MobEffectInstance(GeneratedMod.COLLAPSE.get(),
                MobEffectInstance.INFINITE_DURATION, target - 1, false, false, true);
        forceAddModEffect(entity, instance);
        // 感染当刻即注销邪魔领域的曝光账本：坍缩效果不可清除，此后该生物与被感染的
        // 坍缩层数都不再由邪魔领域驱动（领域既不能再加层、也不能给它加速）。
        entity.getPersistentData().remove(COLLAPSE_EXPOSURE_TICKS);
        entity.getPersistentData().remove(COLLAPSE_EXPOSURE_LAST);
        if (target < MAX_COLLAPSE_LAYERS && entity.level() instanceof ServerLevel level) {
            entity.getPersistentData().putLong(COLLAPSE_NEXT_UPGRADE,
                    level.getGameTime() + (long) target * COLLAPSE_UPGRADE_TICKS);
        } else {
            entity.getPersistentData().remove(COLLAPSE_NEXT_UPGRADE);
        }
        syncCollapseToWatchers(entity, instance);
        // 邪魔之约账本：新感染者记入并触发「情绪实体」复制，升级者更新层数。
        CollapseCovenant.onLayersChanged(entity, target, current == 0);
    }

    /**
     * 把坍缩效果实例补发给正在跟踪该实体的玩家。
     *
     * <p>原版在 1.20.1 只对玩家自己、以及骑乘中的乘客下发 {@code ClientboundUpdateMobEffectPacket}，
     * 普通生物身上的效果从不离开服务端。客户端因此无法在渲染时判断「这只生物是不是坍缩了」，
     * 头部标志与其层数也就无从显示。这里用区块跟踪广播补上这一包：只发给看得见该实体的玩家，
     * 数量等于实体数 × 跟踪者数，且只在加层时发一次。</p>
     */
    private static void syncCollapseToWatchers(LivingEntity entity, MobEffectInstance instance) {
        if (!(entity.level() instanceof ServerLevel level)) return;
        level.getChunkSource().broadcast(entity,
                new ClientboundUpdateMobEffectPacket(entity.getId(), instance));
    }

    /**
     * 只给「感染坍缩的这一个个体」挂上邪魔索敌目标：它与一切非同阵营活体敌对。
     *
     * <p>旧实现是在 {@code EntityJoinLevelEvent} 里给世界里<i>每一只</i>生物都塞一个同款目标，
     * 结果是随便一只生物坍缩，整类生物（乃至全部生物）的索敌都跟着变了。现在改成感染后按
     * 个体追加：没有坍缩的同类完全不受影响，实体类型本身也不被改动。</p>
     */
    private static void ensureCollapseHunterGoal(Mob mob) {
        if (!COLLAPSE_GOAL_MOBS.add(mob)) return;
        mob.targetSelector.addGoal(0, new NearestAttackableTargetGoal<>(mob, LivingEntity.class,
                10, true, false,
                candidate -> candidate != mob && canFactionCombatantAttack(mob, candidate)));
        // 「无差别攻击」要真能出手：原版被动生物（牛、村民以外的动物等）没有近战 Goal，
        // 只挂索敌目标它们永远不打。自身已有近战攻击目标的生物不重复添加（避免双倍出手）；
        // 近战 Goal 只对可寻路的 PathfinderMob 有意义。
        if (mob instanceof net.minecraft.world.entity.PathfinderMob pathfinder) {
            boolean hasMeleeAttack = mob.goalSelector.getAvailableGoals().stream()
                    .anyMatch(wrapped -> wrapped.getGoal() instanceof net.minecraft.world.entity.ai.goal.MeleeAttackGoal);
            if (!hasMeleeAttack) {
                mob.goalSelector.addGoal(2, new net.minecraft.world.entity.ai.goal.MeleeAttackGoal(pathfinder, 1.1D, true));
            }
        }
    }

    /** 每 tick 驱动坍缩：传播邪魔、按层数计时升级、玩家按层数掉血。 */
    public static void tickCollapse(LivingEntity entity) {
        if (entity == null || entity.level().isClientSide
                || !(entity.level() instanceof ServerLevel level)) return;
        MobEffectInstance effect = entity.getEffect(GeneratedMod.COLLAPSE.get());
        if (effect == null) return;
        long now = level.getGameTime();
        int layers = collapseLayersFromAmplifier(effect.getAmplifier());
        // 索敌：只保证「这一只坍缩个体」拥有邪魔索敌目标。放在逐 tick 路径里而不是只在
        // addCollapseLayer 里做，是为了覆盖区块重载：目标不会随存档保存，重新加载出来的
        // 新实例要在下一 tick 重新拿到目标；已在集合里的实例直接跳过，不重复添加。
        if (entity instanceof Mob mob) ensureCollapseHunterGoal(mob);
        // 传播：每 10 tick 扫描半径 4 格，为领域内的无坍缩生物累计曝光。
        if (now % COLLAPSE_SPREAD_INTERVAL == 0L) {
            spreadCollapse(level, entity);
            // 邪魔区域：同一扫描节奏里让半径 4 格内的地面冒出黑点。
            spawnCollapseFieldParticles(level, entity);
        }
        // 成长：每层经过「层数 × 1 分钟」升一层，第 5 层封顶且永久保持。
        if (layers < MAX_COLLAPSE_LAYERS) {
            long next = entity.getPersistentData().getLong(COLLAPSE_NEXT_UPGRADE);
            if (next <= 0L) {
                entity.getPersistentData().putLong(COLLAPSE_NEXT_UPGRADE,
                        now + (long) layers * COLLAPSE_UPGRADE_TICKS);
            } else if (now >= next) {
                addCollapseLayer(entity, 1);
            }
        }
        // 玩家感染坍缩后每秒按「层数 × 1 点」掉血。
        // 「源石计划进度」需求 7：掉血幅度按档位缩放，零头概率取整（与追加层数同一套换算）。
        if (entity instanceof Player player && now % 20L == 0L) {
            int damage = OriginiumPlanProgress.scaleInt(layers, level, entity.getRandom());
            if (damage > 0) player.hurt(player.damageSources().magic(), damage);
        }
        // 邪魔之约加成：非线性移速/狂暴、亚空间传送、气压失序、实质性坍缩的感染空间。
        CollapseCovenant.onCollapseTick(level, entity);
    }

    /**
     * 坍缩源在邪魔领域（基础 4 格，「坍缩范式」加成按层数放大）内传播邪魔：
     * 对领域内每个无坍缩生物累计曝光；「一抹黑」加成同时给进入领域的生物附加限时失明。
     */
    private static void spreadCollapse(ServerLevel level, LivingEntity source) {
        double radius = CollapseCovenant.fieldRadius();
        double radiusSq = radius * radius;
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class,
                source.getBoundingBox().inflate(radius),
                entity -> entity != source && entity.isAlive() && !isCollapsed(entity)
                        && !(entity instanceof Player player && isFactionExemptPlayer(player)))) {
            if (target.distanceToSqr(source) <= radiusSq) {
                markCollapseExposure(target, level);
                CollapseCovenant.applyAreaBlindness(target);
            }
        }
    }

    /**
     * 邪魔区域的地面视觉：在坍缩生物半径 {@link #COLLAPSE_SPREAD_RADIUS 4 格} 的范围内，
     * 让 {@code gravity_core} 黑点从地面冒出来。
     *
     * <p>范围与「邪魔领域」的传播半径完全一致（同用 {@link #COLLAPSE_SPREAD_RADIUS}），
     * 圆心是坍缩生物自己的位置：肉眼看到的冒泡范围，就是实际会被领域感染的范围。</p>
     *
     * <p>冒出节奏按扫描间隔（{@link #COLLAPSE_SPREAD_INTERVAL}）走：每 10 tick 一次扫描，
     * 一次在 4 格里随机撒 {@link #COLLAPSE_FIELD_PARTICLES_MIN} 到
     * {@code MIN + RANDOM} 颗，一秒合计十来颗，贴着坍缩生物脚边咕嘟冒泡。</p>
     *
     * <p>高度按「与源同高」筛：从源脚下逐格向下找真正的地板（洞穴、室内照样找得到），
     * 高度差不超过 {@code COLLAPSE_FIELD_VERTICAL_LIMIT} 格才落子。旧实现用 {@code getHeightmapPos}
     * 取到的是洞口上方的地表，洞里的邪魔因此一滴粒子都看不到。</p>
     */
    private static void spawnCollapseFieldParticles(ServerLevel level, LivingEntity source) {
        int count = COLLAPSE_FIELD_PARTICLES_MIN
                + source.getRandom().nextInt(COLLAPSE_FIELD_PARTICLES_RANDOM);
        // 粒子范围与邪魔领域同缩放（「坍缩范式」加大时视觉同步加大）。
        double radius = CollapseCovenant.fieldRadius();
        for (int i = 0; i < count; i++) {
            spawnOneFieldParticle(level, source, radius);
        }
    }

    /**
     * 在源周围半径 {@code sampleRadius} 的圆盘内取一点，找到地板后冒出一粒重力核。
     *
     * <p>初速不在这里给：{@code sendParticles} 的 speed 只能产生随机方向的速度，黑点会朝四面八方
     * 乱飞。冒出用的上抛初速由客户端粒子自己设定（见 {@code GravityCoreParticle}），
     * 服务端只负责把点落在真实地板上。</p>
     */
    private static void spawnOneFieldParticle(ServerLevel level, LivingEntity source, double sampleRadius) {
        // 圆盘内均匀取点（sqrt 让采样不向圆心堆积）。
        double angle = source.getRandom().nextDouble() * Math.PI * 2.0D;
        double distance = sampleRadius * Math.sqrt(source.getRandom().nextDouble());
        double x = source.getX() + Math.cos(angle) * distance;
        double z = source.getZ() + Math.sin(angle) * distance;
        int blockX = net.minecraft.util.Mth.floor(x);
        int blockZ = net.minecraft.util.Mth.floor(z);
        int startY = net.minecraft.util.Mth.floor(source.getY());
        // 区块未加载时不要顺手把区块读进来：先确认已加载再找地面。
        if (!level.hasChunkAt(new BlockPos(blockX, startY, blockZ))) return;
        BlockPos ground = findCollapseGround(level, blockX, startY, blockZ);
        if (ground == null) return;
        level.sendParticles(GravityCoreParticles.GRAVITY_CORE.get(), x, ground.getY() + 0.10D, z,
                1, 0.0D, 0.0D, 0.0D, 0.0D);
    }

    /**
     * 在 (x,z) 这一列上、以源所在高度为中心上下各 {@code COLLAPSE_FIELD_VERTICAL_LIMIT} 格内，
     * 找一格「下方有碰撞、上方可站」的地板；找不到（源悬空、或脚下是深坑）时返回 null。
     */
    private static BlockPos findCollapseGround(ServerLevel level, int x, int startY, int z) {
        int limit = (int) COLLAPSE_FIELD_VERTICAL_LIMIT;
        for (int y = startY + 1; y >= startY - limit; y--) {
            BlockPos pos = new BlockPos(x, y, z);
            if (!level.hasChunkAt(pos)) return null;
            BlockState state = level.getBlockState(pos);
            if (!state.getCollisionShape(level, pos).isEmpty()) continue;
            BlockPos below = pos.below();
            if (level.getBlockState(below).getCollisionShape(level, below).isEmpty()) continue;
            return pos;
        }
        return null;
    }

    /**
     * 记录一次邪魔领域曝光：同一 tick 只记一次（多源重叠不加速），
     * <b>离开领域不清零</b>——中断后再回来接着上次的进度累加；累计满所需时长附加一层坍缩，
     * 余数保留给下一次。所需时长以 {@link #COLLAPSE_EXPOSURE_REQUIRED_TICKS 200 tick} 为基准，
     * 受「源石计划进度」调控：难度负比例即延长比例、正比例即缩短比例。
     * 曝光账本只在感染坍缩当刻被 {@link #addCollapseLayer} 清空，
     * 此后该生物被领域剔除，坍缩层数不会再由领域加速。
     */
    private static void markCollapseExposure(LivingEntity target, ServerLevel level) {
        long now = level.getGameTime();
        CompoundTag data = target.getPersistentData();
        long last = data.getLong(COLLAPSE_EXPOSURE_LAST);
        if (last == now) return;
        long ticks = data.getLong(COLLAPSE_EXPOSURE_TICKS);
        if (last > 0L) {
            // 只按本次扫描的间隔累加（上限一个扫描周期）：领域外的时间不记账，
            // 但已累计的部分原样保留，中断不清零。
            ticks += Math.min(COLLAPSE_SPREAD_INTERVAL, now - last);
        }
        long required = requiredCollapseExposureTicks(level);
        if (ticks >= required) {
            addCollapseLayer(target, 1);
            ticks -= required;
        }
        data.putLong(COLLAPSE_EXPOSURE_TICKS, ticks);
        data.putLong(COLLAPSE_EXPOSURE_LAST, now);
    }

    /**
     * 当前难度档位下邪魔区域累计感染一次所需的 tick 数：基准 200 tick（10 秒）
     * 乘以 {@link OriginiumPlanProgress#zoneInfectionTimeFactor(Level)}——
     * 负比例延长（0 档约 398 tick）、正比例缩短（18 档 60 tick），默认档恒为 200；
     * 四舍五入并保底 1 tick。难度中途改动时，已累计的进度原样保留、按新阈值续算。
     */
    private static long requiredCollapseExposureTicks(ServerLevel level) {
        double scaled = COLLAPSE_EXPOSURE_REQUIRED_TICKS
                * OriginiumPlanProgress.zoneInfectionTimeFactor(level);
        return Math.max(1L, Math.round(scaled));
    }

    /**
     * 被坍缩生物攻击时，有 10% 概率附加一层坍缩。
     *
     * <p>该机制只对<b>尚未坍缩</b>的受害者生效（即附加的是「第一次坍缩」）；
     * 受害者一经感染坍缩便立即失效——被坍缩生物再攻击它也不会增加层数。
     * 此后的层数只能由「层数 × 1 分钟」的时间升级或邪魔领域曝光推进。</p>
     *
     * <p>「触发性危殆」加成在此基础上按层追加传染概率（每层 +32.5%，上限 2 层），
     * 追加后的总概率再按「源石计划进度」幅度缩放并以 100% 封顶。</p>
     */
    public static void applyCollapseFromAttack(LivingEntity attacker, LivingEntity victim) {
        if (attacker == null || victim == null || attacker == victim) return;
        if (victim.level().isClientSide || !isCollapsed(attacker) || isCollapsed(victim)) return;
        if (victim instanceof Player player && isFactionExemptPlayer(player)) return;
        // 「源石计划进度」需求 7：邪魔攻击传染坍缩的概率（感染强化幅度）按档位缩放。
        double chance = COLLAPSE_ATTACK_LAYER_CHANCE + CollapseCovenant.triggerChanceBonus();
        if (victim.getRandom().nextDouble() < OriginiumPlanProgress.chance(chance, victim.level())) {
            addCollapseLayer(victim, 1);
        }
    }

    /**
     * 源石感染免疫白名单：
     * 「预言家」博士与「女祭司」普瑞赛斯显式免疫；其余本模组生物默认免疫，
     * 仅「特蕾西娅」例外（她需要靠感染层数叠加移速/飞行速度加成）与
     * 「哈基玖」（替身与本尊同源：中立生物，不享阵营级免疫，会照常感染）；
     * 源石耄耋、转化生物以及持有毁灭之源的玩家同样免疫。
     */
    public static boolean isSourceOreInfectionImmune(LivingEntity entity) {
        return entity instanceof Priestess || entity instanceof Prophet
                || entity instanceof CalamityMob && !(entity instanceof Theresia)
                && !(entity instanceof Apocata)
                || entity instanceof SourceOreGolem || isConvertedHostile(entity)
                || entity instanceof Player player && hasSourceOfRuin(player);
    }

    /** 模组附加的负面效果必须绕过目标的原版或模组免疫检查。 */
    public static void forceAddModEffect(LivingEntity entity, MobEffectInstance effect) {
        if (entity != null && effect != null) entity.forceAddEffect(effect, null);
    }

    /**
     * 每秒伤害：第 1 层 1 点，每增加 1 层增加 0.5 点；此计算本身不设上限。
     * 「源石计划进度」按档位幅度缩放该伤害（走每 tick 刷新的缓存系数，属性与伤害两端一致）。
     */
    public static double sourceOreInfectionDamage(int layers) {
        return layers > 0
                ? (1.0D + (layers - 1) * 0.5D) * OriginiumPlanProgress.cachedFactor() : 0.0D;
    }

    /** 每项削弱比例：第 1 层 5%，每增加 1 层增加 1%，最多 100%；同样按进度幅度缩放。 */
    public static double sourceOreInfectionReduction(int layers) {
        return Math.min(1.0D,
                (layers > 0 ? 0.04D + layers * 0.01D : 0.0D) * OriginiumPlanProgress.cachedFactor());
    }

    public static int sourceOreInfectionLayers(LivingEntity entity) {
        MobEffectInstance effect = entity.getEffect(GeneratedMod.SOURCE_ORE_INFECTION.get());
        if (effect == null) return 0;
        return Math.min(MAX_SOURCE_ORE_INFECTION_LAYERS,
                effect.getAmplifier() == Integer.MAX_VALUE
                        ? MAX_SOURCE_ORE_INFECTION_LAYERS : Math.max(1, effect.getAmplifier() + 1));
    }

    /** 被天灾生物主动击杀时：原有属性 ×（1 + 每层 10%）。 */
    public static double conversionScaleFromInfection(LivingEntity entity) {
        int layers = sourceOreInfectionLayers(entity);
        return layers > 0 ? 1.0D + layers * 0.10D : 1.0D;
    }

    /** 源石感染伤害致死时：原有属性 ×（25% × 层数）。 */
    private static double infectionDeathScale(int layers) {
        return Math.max(0.25D, 0.25D * layers);
    }

    /** 感染者被击杀时，每一层感染在规则「初始转化概率」之上追加的转化概率（3.25%）。 */
    public static final double INFECTION_LAYER_CONVERSION_CHANCE = 0.0325D;

    /**
     * 感染者被击杀时的转化概率判定。感染伤害致死与陨石击杀各有必定转化的独立
     * 路径，不经过这里；这里只处理"源石感染期间被其他生物或伤害来源击杀"：
     * <ul>
     * <li>凶手属于源石阵营：概率 = 规则「初始转化概率」百分比（1~100 整数，默认 32）
     * + 3.25% × 感染层数；</li>
     * <li>其他生物或伤害来源（含无实体来源）：概率 = 3.25% × 感染层数；</li>
     * <li>未处于感染期间（0 层）：沿用原有的击杀即转化规则，恒为真。</li>
     * </ul>
     */
    public static boolean rollInfectionKillConversion(ServerLevel level, LivingEntity victim, LivingEntity killer) {
        int layers = sourceOreInfectionLayers(victim);
        if (layers <= 0) return true;
        double chance = INFECTION_LAYER_CONVERSION_CHANCE * layers;
        if (killer != null && isSourceOreFactionMember(killer)) {
            chance += OriginFallGameRules.initialConversionChance(level) / 100.0D;
        }
        return level.getRandom().nextDouble() < chance;
    }

    private static int saturatedLayers(int current, int added) {
        long result = (long) Math.max(0, current) + Math.max(0, added);
        return (int) Math.min(MAX_SOURCE_ORE_INFECTION_LAYERS, Math.max(1L, result));
    }

    private static int durationForLayers(int layers) {
        long duration = (long) SOURCE_ORE_INFECTION_DURATION_TICKS
                * Math.min(MAX_SOURCE_ORE_INFECTION_LAYERS, Math.max(1, layers));
        return (int) Math.min(Integer.MAX_VALUE, duration);
    }

    public static void applySourceOreInfection(LivingEntity entity, int layers, int duration) {
        if (entity == null || layers <= 0) return;
        // 白名单实体和持有毁灭之源的玩家不接受本模组负面效果；清理旧版本可能残留的感染。
        if (isSourceOreInfectionImmune(entity)) {
            entity.removeEffect(GeneratedMod.SOURCE_ORE_INFECTION.get());
            clearSourceOreInfectionExposure(entity);
            return;
        }
        MobEffectInstance current = entity.getEffect(GeneratedMod.SOURCE_ORE_INFECTION.get());
        int currentLayers = sourceOreInfectionLayers(entity);
        int requestedLayers = Math.min(MAX_SOURCE_ORE_INFECTION_LAYERS, Math.max(1, layers));
        int finalLayers = Math.max(currentLayers, requestedLayers);
        int amplifier = finalLayers - 1;
        if (current == null) {
            entity.getPersistentData().putDouble(INFECTION_MAX_HEALTH, entity.getMaxHealth());
            entity.getPersistentData().putDouble(INFECTION_ATTACK_DAMAGE,
                    entity.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE)
                            ? entity.getAttributeValue(Attributes.ATTACK_DAMAGE) : 2.0D);
            entity.getPersistentData().putDouble(INFECTION_ARMOR, entity.getArmorValue());
        }
        entity.getPersistentData().remove(INFECTION_PENDING_DOWNGRADE);
        // 传入的 duration 仅兼容旧调用点；实际持续时间始终按最终层数计算。
        int effectDuration = durationForLayers(finalLayers);
        if (current != null && finalLayers == currentLayers && current.getDuration() >= effectDuration) return;
        forceAddModEffect(entity, new MobEffectInstance(GeneratedMod.SOURCE_ORE_INFECTION.get(),
                effectDuration, amplifier, false, true, true));
    }

    /** 追加指定层数；已感染目标的层数始终继续叠加。 */
    public static void addSourceOreInfectionLayer(LivingEntity entity, int layers, int duration) {
        if (entity == null || layers <= 0) return;
        int currentLayers = sourceOreInfectionLayers(entity);
        applySourceOreInfection(entity, saturatedLayers(currentLayers, layers), duration);
    }

    /**
     * 移除一层源石感染：层数大于 1 时保留效果并按剩余层数重新计时，
     * 只剩最后一层时连同曝光记录一并清除；效果已到期但仍有待降层数据时按一层递减。
     * 返回是否确实移除了一层。
     */
    public static boolean removeOneSourceOreInfectionLayer(LivingEntity entity) {
        if (entity == null || entity.level().isClientSide) return false;
        MobEffectInstance current = entity.getEffect(GeneratedMod.SOURCE_ORE_INFECTION.get());
        if (current == null) {
            int pending = entity.getPersistentData().getInt(INFECTION_PENDING_DOWNGRADE);
            if (pending <= 0) return false;
            if (pending == 1) {
                entity.getPersistentData().remove(INFECTION_PENDING_DOWNGRADE);
                clearSourceOreInfectionExposure(entity);
            } else {
                entity.getPersistentData().putInt(INFECTION_PENDING_DOWNGRADE, pending - 1);
            }
            return true;
        }
        int layers = sourceOreInfectionLayers(entity);
        if (layers <= 1) {
            entity.removeEffect(GeneratedMod.SOURCE_ORE_INFECTION.get());
            entity.getPersistentData().remove(INFECTION_PENDING_DOWNGRADE);
            clearSourceOreInfectionExposure(entity);
            return true;
        }
        int remaining = layers - 1;
        // 每层对应 20 秒标准时长，移除一层同时扣掉这一段剩余时长。
        int remainingDuration = Math.max(1, current.getDuration() - SOURCE_ORE_INFECTION_DURATION_TICKS);
        int pending = entity.getPersistentData().getInt(INFECTION_PENDING_DOWNGRADE);
        entity.removeEffect(GeneratedMod.SOURCE_ORE_INFECTION.get());
        if (pending > 0) {
            entity.getPersistentData().putInt(INFECTION_PENDING_DOWNGRADE, Math.max(0, pending - 1));
        }
        // 直接按剩余层数重建效果：属性快照已经在感染时保存，这里不再走 applySourceOreInfection。
        forceAddModEffect(entity, new MobEffectInstance(GeneratedMod.SOURCE_ORE_INFECTION.get(),
                remainingDuration, remaining - 1, false, true, true));
        return true;
    }

    /** 一段层数对应的持续时间结束后，保留剩余层数并重新按剩余层数计时。 */
    public static void downgradeSourceOreInfection(LivingEntity entity, MobEffectInstance expiredEffect) {
        if (entity == null || expiredEffect == null
                || expiredEffect.getEffect() != GeneratedMod.SOURCE_ORE_INFECTION.get()) return;
        int expiredLayers = Math.min(MAX_SOURCE_ORE_INFECTION_LAYERS,
                expiredEffect.getAmplifier() == Integer.MAX_VALUE
                        ? MAX_SOURCE_ORE_INFECTION_LAYERS
                        : Math.max(1, expiredEffect.getAmplifier() + 1));
        if (expiredLayers <= 1) {
            clearSourceOreInfectionExposure(entity);
            entity.getPersistentData().remove(INFECTION_PENDING_DOWNGRADE);
            return;
        }
        entity.getPersistentData().putInt(INFECTION_PENDING_DOWNGRADE, expiredLayers - 1);
    }

    private static void applyPendingSourceOreInfectionDowngrade(LivingEntity entity) {
        if (entity.getEffect(GeneratedMod.SOURCE_ORE_INFECTION.get()) != null) return;
        int remainingLayers = entity.getPersistentData().getInt(INFECTION_PENDING_DOWNGRADE);
        if (remainingLayers <= 0) return;
        entity.getPersistentData().remove(INFECTION_PENDING_DOWNGRADE);
        forceAddModEffect(entity, new MobEffectInstance(GeneratedMod.SOURCE_ORE_INFECTION.get(),
                durationForLayers(Math.min(MAX_SOURCE_ORE_INFECTION_LAYERS, remainingLayers)),
                Math.min(MAX_SOURCE_ORE_INFECTION_LAYERS, remainingLayers) - 1,
                false, true, true));
    }

    public static void applySourceOreInfectionFromMeteor(LivingEntity entity, float damageMultiplier) {
        if (entity == null || damageMultiplier <= 0.0F) return;
        double infectionAmount = damageMultiplier * BASE_INFECTION_CHANCE;
        int guaranteedLayers = (int) Math.floor(infectionAmount);
        double remainder = infectionAmount - guaranteedLayers;
        if (entity.getRandom().nextDouble() < remainder) guaranteedLayers++;
        if (guaranteedLayers > 0) addSourceOreInfectionLayer(entity, guaranteedLayers, 0);
    }

    /** 哈气贤者每满 100 点生命值增加一次攻击感染层数；不足 100 点按 100 点计算。 */
    public static int pureSourceOreGolemHealthBonus(LivingEntity attacker) {
        if (!(attacker instanceof PureSourceOreGolem)) return 0;
        int effectiveHealth = Math.max(100, net.minecraft.util.Mth.floor(attacker.getHealth()));
        return Math.max(0, effectiveHealth / 100 - 1);
    }

    /** 复活次数会永久转化为攻击时的额外感染层数。 */
    private static int revivalAttackBonus(LivingEntity attacker) {
        if (!(attacker instanceof CalamityMob calamity)
                || (!(attacker instanceof CalamityPrincess)
                && !(attacker instanceof YoungDemonLord)
                && !isConvertedHostile(attacker))) return 0;
        return Math.max(0, calamity.getRevivalCount());
    }

    public static void applySourceOreInfectionFromCalamityAttack(LivingEntity attacker, LivingEntity target) {
        if (attacker == null || target == null) return;
        double chance;
        int layers = 1;
        if (attacker instanceof CalamityPrincess) {
            chance = 1.0D;
            layers = 1 + target.getRandom().nextInt(2);
        } else if (attacker instanceof PureSourceOreGolem) {
            chance = 1.0D;
            layers = 2 + target.getRandom().nextInt(3);
        } else if (attacker instanceof SourceOreGolem) {
            chance = 0.975D;
        } else if (attacker instanceof YoungDemonLord) {
            chance = 0.65D;
        } else if (CalamityLogic.isConvertedHostile(attacker)) {
            chance = 0.325D;
        } else {
            return;
        }
        if (target.getRandom().nextDouble() < chance) {
            // 「源石计划进度」需求 4：天灾生物攻击附加的感染层数中，保底 1 层之外的
            // 机制提升部分（随机追加层、哈气贤者生命加成层、复活次数加成层）按档位缩放，
            // 零头概率取整；基础 1 层与触发概率属规格固定值，不随进度变化。
            int base = 1;
            int extra = layers - base
                    + pureSourceOreGolemHealthBonus(attacker) + revivalAttackBonus(attacker);
            addSourceOreInfectionLayer(target, base
                    + OriginiumPlanProgress.scaleInt(extra, target.level(), target.getRandom()), 0);
        }
    }

    public static void markInfectionExposure(LivingEntity entity) {
        if (entity == null || !(entity.level() instanceof ServerLevel level)) return;
        long now = level.getGameTime();
        long last = entity.getPersistentData().getLong(INFECTION_LAST_EXPOSURE);
        long ticks = entity.getPersistentData().getLong(INFECTION_EXPOSURE_TICKS);
        if (last <= 0L || now - last > 20L) {
            ticks = 0L;
        } else {
            ticks += Math.min(20L, now - last);
        }
        // 黑色晶体和至纯源石的作用范围内，已感染生物每 5 秒增加一层。
        if (ticks >= 100L && sourceOreInfectionLayers(entity) > 0) {
            addSourceOreInfectionLayer(entity, 1, 0);
            ticks %= 100L;
        }
        entity.getPersistentData().putLong(INFECTION_EXPOSURE_TICKS, ticks);
        entity.getPersistentData().putLong(INFECTION_LAST_EXPOSURE, now);
    }

    public static void tickSourceOreInfection(LivingEntity entity) {
        if (!(entity.level() instanceof ServerLevel) || entity.level().getGameTime() % 20L != 0L) return;
        if (isSourceOreInfectionImmune(entity)) {
            entity.removeEffect(GeneratedMod.SOURCE_ORE_INFECTION.get());
            clearSourceOreInfectionExposure(entity);
            clearSourceOreInfectionDeath(entity);
            return;
        }
        applyPendingSourceOreInfectionDowngrade(entity);
        MobEffectInstance effect = entity.getEffect(GeneratedMod.SOURCE_ORE_INFECTION.get());
        if (effect == null) return;
        int layers = Math.max(1, sourceOreInfectionLayers(entity));
        if (layers > 10 && canSummonNaturalMeteorFrom(entity)
                && entity.getPersistentData().getLong(INFECTION_HUNT_UNTIL) <= entity.level().getGameTime()) {
            ServerLevel server = (ServerLevel) entity.level();
            server.addFreshEntity(MeteorEntity.createTargetedNatural(server, entity, 1));
            entity.getPersistentData().putLong(INFECTION_HUNT_UNTIL, entity.level().getGameTime() + 400L);
        }
        float damage = (float) sourceOreInfectionDamage(layers);
        boolean fatal = entity.getHealth() <= damage;
        if (fatal) markSourceOreInfectionDeath(entity);
        boolean hurt = entity.hurt(entity.damageSources().magic(), damage);
        if (!hurt || !entity.isDeadOrDying()) clearSourceOreInfectionDeath(entity);
    }

    public static void clearSourceOreInfectionExposure(LivingEntity entity) {
        entity.getPersistentData().remove(INFECTION_EXPOSURE_TICKS);
        entity.getPersistentData().remove(INFECTION_LAST_EXPOSURE);
    }

    /** 感染效果自然到期且仍有待降层数据时，特蕾西娅不应把历史记录误判为彻底清除。 */
    public static boolean hasPendingSourceOreInfectionDowngrade(LivingEntity entity) {
        return entity != null && entity.getPersistentData().getInt(INFECTION_PENDING_DOWNGRADE) > 0;
    }

    public static void markSourceOreInfectionDeath(LivingEntity entity) {
        entity.getPersistentData().putBoolean(INFECTION_DEATH, true);
    }

    public static void clearSourceOreInfectionDeath(LivingEntity entity) {
        entity.getPersistentData().remove(INFECTION_DEATH);
    }

    public static boolean diedFromSourceOreInfection(LivingEntity entity) {
        return entity.getPersistentData().getBoolean(INFECTION_DEATH);
    }

    /** 标记美化包造成的无因果链移除，防止死亡事件触发复活或原个体衍生。 */
    public static void markBeautificationKill(LivingEntity entity) {
        if (entity != null) entity.getPersistentData().putBoolean(BEAUTIFICATION_KILL, true);
    }

    public static boolean isBeautificationKill(LivingEntity entity) {
        return entity != null && entity.getPersistentData().getBoolean(BEAUTIFICATION_KILL);
    }

    public static void clearBeautificationKill(LivingEntity entity) {
        if (entity != null) entity.getPersistentData().remove(BEAUTIFICATION_KILL);
    }

    /**
     * /kill 类指令或代码造成的击杀（{@code generic_kill} 伤害来源）。
     *
     * <p>这类移除是命令/脚本的强制清理，不构成世界内的因果击杀：模组生物的死亡衍生链
     * （感染转化、死后陨石/复活波次等）一律不触发，避免一条 {@code /kill} 引发一片转化与陨石雨。
     */
    public static boolean isKillCommandDeath(DamageSource source) {
        return source != null && source.is(DamageTypes.GENERIC_KILL);
    }

    /**
     * 感染晶化替换的统一闸门：基岩、屏障这类「无法破坏」（破坏速度为负）的方块默认免疫源石侵染，
     * 只有开启游戏规则「规则改写」时才允许被晶化为黑色晶体。感染地块与陨石晶化两条路径共用本判定。
     */
    public static boolean infectedBlockAllowed(BlockState state, ServerLevel level, BlockPos pos) {
        return OriginFallGameRules.isRuleRewrite(level) || state.getDestroySpeed(level, pos) >= 0.0F;
    }

    /** 感染伤害死亡时，把层数半径内裸露的完整方块替换为黑色晶体。 */
    public static void replaceExposedBlocksWithCrystal(ServerLevel level, BlockPos center, double radius) {
        int extent = net.minecraft.util.Mth.ceil(radius);
        double radiusSquared = radius * radius;
        BlockState crystal = GeneratedMod.BLACK_CRYSTAL.get().defaultBlockState();
        for (int x = -extent; x <= extent; x++) {
            for (int y = -extent; y <= extent; y++) {
                for (int z = -extent; z <= extent; z++) {
                    if (x * x + y * y + z * z > radiusSquared) continue;
                    BlockPos pos = center.offset(x, y, z);
                    BlockState state = level.getBlockState(pos);
                    // 只感染裸露的完整方块；液体、不完整碰撞体、已存在的晶体与「规则改写」未放行
                    // 的无法破坏方块（基岩、屏障等）均跳过。
                    if (state.isAir() || !state.getFluidState().isEmpty()
                            || state.is(GeneratedMod.BLACK_CRYSTAL.get())
                            || !infectedBlockAllowed(state, level, pos)
                            || !state.isCollisionShapeFullBlock(level, pos)) continue;
                    boolean exposed = false;
                    for (Direction direction : Direction.values()) {
                        if (level.getBlockState(pos.relative(direction)).isAir()) {
                            exposed = true;
                            break;
                        }
                    }
                    if (exposed) level.setBlock(pos, crystal, 3);
                }
            }
        }
    }

    /** 源石感染死亡后的转化，倍率只作用于这条转化路径。 */
    public static void convertAfterSourceOreInfectionDeath(ServerLevel level, LivingEntity victim) {
        convertAfterSourceOreInfectionDeath(level, victim, false);
    }

    /**
     * 源石感染死亡后的转化。陨石造成的击杀传入 meteorKill=true：
     * “转化生物密度”只限制转化生物击杀与源石感染击杀，明确不限制陨石转化。
     */
    public static void convertAfterSourceOreInfectionDeath(ServerLevel level, LivingEntity victim,
                                                           boolean meteorKill) {
        // 坍缩个体失去复活与死亡后效果：死亡后不再转化/复生。
        if (isCollapsed(victim)) return;
        int layers = Math.max(1, sourceOreInfectionLayers(victim));
        double scale = infectionDeathScale(layers);
        // 死亡时感染半径等于死亡瞬间的感染层数；层数本身已限制为 255。
        replaceExposedBlocksWithCrystal(level, victim.blockPosition(), layers);
        // 生命上限归零的死亡不得借感染转化链 revive 复活为灾厄生物；上限已削空的垂死实体同样拒绝。
        if (MaxHealthZeroLogic.isCapZeroDeath(victim) || MaxHealthZeroLogic.isCapDepleted(victim)) return;
        if (!(victim instanceof Mob mob) || isConversionImmuneTarget(victim)
                || victim instanceof CalamityMob || victim instanceof SourceOreGolem
                || isConvertedHostile(victim)) return;
        // 达到转化生物密度上限时，感染致杀仍然保留感染地块效果，但不再产出新的转化生物。
        if (!meteorKill && isConversionDensitySaturated(level, victim)) return;
        double maxHealth = victim.getPersistentData().contains(INFECTION_MAX_HEALTH)
                ? victim.getPersistentData().getDouble(INFECTION_MAX_HEALTH) : mob.getMaxHealth();
        double currentHealth = maxHealth;
        double shield = victim.getPersistentData().contains(INFECTION_ARMOR)
                ? victim.getPersistentData().getDouble(INFECTION_ARMOR) : mob.getArmorValue();
        double attack = victim.getPersistentData().contains(INFECTION_ATTACK_DAMAGE)
                ? victim.getPersistentData().getDouble(INFECTION_ATTACK_DAMAGE)
                : (mob.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE)
                ? mob.getAttributeValue(Attributes.ATTACK_DAMAGE) : 2.0D);
        mob.revive();
        mob.setHealth((float) Math.max(1.0D, maxHealth));
        LivingEntity converted = convertMob(mob, maxHealth, currentHealth, shield, attack, scale);
        if (converted != null) {
            converted.removeEffect(GeneratedMod.SOURCE_ORE_INFECTION.get());
            clearSourceOreInfectionExposure(converted);
            clearMeteorAndCrystalEffects(converted);
        }
    }

    /** 使用实体当前属性执行一次天灾转化，并自动读取感染层数倍率。 */
    public static LivingEntity convertMob(Mob original) {
        if (original == null || isConversionImmuneTarget(original)) return null;
        double maxHealth = original.getMaxHealth();
        double attack = original.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE)
                ? original.getAttributeValue(Attributes.ATTACK_DAMAGE) : 2.0D;
        return convertMob(original, maxHealth, original.getHealth(), original.getArmorValue(), attack,
                conversionScaleFromInfection(original));
    }

    /**
     * 源石美化包的强制转化入口：不检查模式、持有物或目标保护，直接复用同化的类型判定。
     */
    public static LivingEntity forceConvertMob(Mob original) {
        if (original == null || original.level().isClientSide
                || isConversionImmuneTarget(original)
                || isSourceOreFactionMember(original)) return null;
        double maxHealth = original.getPersistentData().contains(INFECTION_MAX_HEALTH)
                ? original.getPersistentData().getDouble(INFECTION_MAX_HEALTH) : original.getMaxHealth();
        // 强制转化不是击杀或复活：保留目标当前生命值，避免道具把受伤生物无条件补满。
        double currentHealth = Math.max(1.0D, Math.min(maxHealth, original.getHealth()));
        double shield = original.getPersistentData().contains(INFECTION_ARMOR)
                ? original.getPersistentData().getDouble(INFECTION_ARMOR) : original.getArmorValue();
        double attack = original.getPersistentData().contains(INFECTION_ATTACK_DAMAGE)
                ? original.getPersistentData().getDouble(INFECTION_ATTACK_DAMAGE)
                : (original.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE)
                ? original.getAttributeValue(Attributes.ATTACK_DAMAGE) : 2.0D);
        double scale = conversionScaleFromInfection(original);
        // 先截断原实体的死亡因果链，再交给 convertTo 替换实体；不调用 die()，因此不会触发死亡事件、复活或原个体衍生。
        markBeautificationKill(original);
        original.setHealth(0.0F);
        LivingEntity converted = convertMob(original, maxHealth, currentHealth, shield, attack, scale, true);
        if (converted == null) {
            // 替换失败时恢复原实体，避免一次失败的使用留下一个无法交互的零血实体。
            clearBeautificationKill(original);
            original.setHealth((float) currentHealth);
            return null;
        }
        converted.removeEffect(GeneratedMod.SOURCE_ORE_INFECTION.get());
        clearSourceOreInfectionExposure(converted);
        clearMeteorAndCrystalEffects(converted);
        return converted;
    }

    /**
     * 执行一次天灾转化；调用方传入原有属性需要应用的倍率。
     * 铁傀儡不再进入通用转化实体，而是按专属概率生成源石耄耋或哈气贤者。
     */
    public static LivingEntity convertMob(Mob original, double maxHealth, double currentHealth,
                                          double shield, double attack, double scale) {
        return convertMob(original, maxHealth, currentHealth, shield, attack, scale, false);
    }

    /**
     * 执行转化并可选择跳过原实体的死亡链；美化包使用该模式，原实体只以零血被移除。
     */
    private static LivingEntity convertMob(Mob original, double maxHealth, double currentHealth,
                                           double shield, double attack, double scale,
                                           boolean detachDeathChain) {
        // 总守卫：任何转化路径都不得复活“生命上限归零”的死亡或垂死实体（修复死后残留实体）。
        if (original == null || isConversionImmuneTarget(original)
                || MaxHealthZeroLogic.isCapZeroDeath(original)
                || MaxHealthZeroLogic.isCapDepleted(original)
                || !(original.level() instanceof ServerLevel level)) return null;
        // 「源石计划进度」需求 3：转化生物在原数值之外的“提升数值”按档位幅度缩放——
        // 只压缩倍率高于 1（即相对原属性有提升）的部分，低于 1 的弱化倍率原样保留。
        // 这是所有转化路径的共同收口：感染致杀、被击杀转化、陨石击杀、美化包强制转化都走这里。
        double safeScale = OriginiumPlanProgress.boostedUp(Math.max(0.0D, scale), level);
        double x = original.getX();
        double y = original.getY();
        double z = original.getZ();
        float yRot = original.getYRot();
        float xRot = original.getXRot();

        if (original instanceof IronGolem) {
            if (!detachDeathChain) original.setHealth((float) Math.max(1.0D, maxHealth));
            double roll = level.getRandom().nextDouble();
            SourceOreGolem first;
            if (roll < 0.60D) {
                first = spawnConvertedGolem(level, x, y, z, yRot, xRot, false);
            } else if (roll < 0.90D) {
                first = spawnConvertedGolem(level, x, y, z, yRot, xRot, true);
            } else {
                first = spawnConvertedGolem(level, x, y, z, yRot, xRot, false);
                spawnConvertedGolem(level, x + 1.5D, y, z, yRot, xRot, true);
            }
            original.discard();
            return first;
        }

        // 所有击杀来源共同使用同一判定：90% 为终焉行者，10% 为天灾信使。
        LivingEntity converted;
        if (level.getRandom().nextDouble() < 0.90D) {
            converted = EndWalker.convertFrom(original, maxHealth * safeScale,
                    currentHealth * safeScale, shield * safeScale, attack * safeScale);
        } else {
            converted = CalamityMessenger.convertFrom(original, maxHealth * safeScale,
                    currentHealth * safeScale, shield * safeScale, attack * safeScale);
        }
        if (converted != null) {
            clearBeautificationKill(converted);
            clearMeteorAndCrystalEffects(converted);
            spawnHighHealthConversionGolem(level, converted, maxHealth);
        }
        return converted;
    }

    private static SourceOreGolem spawnConvertedGolem(ServerLevel level, double x, double y, double z,
                                                       float yRot, float xRot, boolean pure) {
        SourceOreGolem golem = pure ? GeneratedMod.PURE_SOURCE_ORE_GOLEM.get().create(level)
                : GeneratedMod.SOURCE_ORE_GOLEM.get().create(level);
        if (golem == null) return null;
        golem.moveTo(x, y, z, yRot, xRot);
        golem.setPlayerCreated(true);
        golem.setCalamityFaction(true);
        golem.setPersistenceRequired();
        level.addFreshEntity(golem);
        return golem;
    }

    /** 500血量以上的普通生物转化后，两个概率分别独立判定。 */
    private static void spawnHighHealthConversionGolem(ServerLevel level, LivingEntity converted,
                                                        double originalMaxHealth) {
        if (originalMaxHealth < 500.0D) return;
        if (level.getRandom().nextDouble() < 0.325D) {
            spawnConvertedGolem(level, converted.getX() + 1.5D, converted.getY(), converted.getZ(),
                    converted.getYRot(), converted.getXRot(), false);
        }
        if (level.getRandom().nextDouble() < 0.0325D) {
            spawnConvertedGolem(level, converted.getX() - 1.5D, converted.getY(), converted.getZ(),
                    converted.getYRot(), converted.getXRot(), true);
        }
    }

    public static boolean isCalamityModePlayer(Player player) {
        return player.getPersistentData().getBoolean(CALAMITY_MODE);
    }

    public static void setCalamityModePlayer(Player player, boolean enabled) {
        player.getPersistentData().putBoolean(CALAMITY_MODE, enabled);
    }

    public static boolean anyCalamityModePlayer(ServerLevel level) {
        return level.getLevelData().isHardcore()
                || level.players().stream().anyMatch(CalamityLogic::isCalamityModePlayer);
    }

    /** 清理转化前已经附着的陨石减速和黑色晶体负面效果。 */
    public static void clearMeteorAndCrystalEffects(LivingEntity entity) {
        entity.removeEffect(net.minecraft.world.effect.MobEffects.WITHER);
        entity.removeEffect(net.minecraft.world.effect.MobEffects.WEAKNESS);
        entity.removeEffect(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN);
    }

    public static boolean isCalamityHostile(LivingEntity entity) {
        // 邪魔（坍缩）一律按天灾敌对目标结算，保证转化生物与陨石也把它当敌人。
        return entity != null && (isCollapsed(entity) || isNaturalHostile(entity)
                || isSourceOreFactionMember(entity)
                || entity.getPersistentData().getBoolean(CALAMITY_HOSTILE_TAG));
    }

    /** 兼容旧调用点：除特蕾西娅外的模组天灾生物都属于源石阵营。 */
    public static boolean isCalamityFactionMember(LivingEntity entity) {
        return isSourceOreFactionMember(entity);
    }

    /** 阵营实体不再受模式开关保护；双方实体始终可以按阵营互相索敌。 */
    public static boolean isSourceOreGolemProtectedTarget(LivingEntity target) {
        return false;
    }

    /** 源石耄耋和哈气贤者的统一攻击判定。 */
    public static boolean canSourceOreGolemAttack(SourceOreGolem source, LivingEntity target) {
        return canFactionCombatantAttack(source, target);
    }

    /**
     * 两阵营索敌统一判定：源石阵营与文明存续阵营互为敌对、相互索敌；
     * 双方同时索敌其他中立与敌对生物（友好生物仅在巴别塔行动开启后由源石阵营索敌）。
     * 两阵营敌对时的玩家目标需处于生存/冒险模式；创造与旁观模式下的玩家不作为有效索敌目标。
     * 索敌范围内存在其他模组的敌对生物时，非原版生物的攻击优先级调到最高（高于阵营其余
     * 互相索敌）：两阵营把枪口一致对外、暂时不互相攻击，外来者清空后阵营敌对立即恢复。
     * 唯一例外：「预言家」博士与「女祭司」普瑞赛斯之间的互相索敌为绝对最高优先级，
     * 既不让位于外来模组威胁，也不受共同索敌呼叫降级——两者始终优先锁定对方。
     * 《方块与深蓝之树》联动：双方模组生物彼此永不索敌（巴别塔口径同样让位）；
     * 共同索敌呼叫生效期间，模组内阵营互斗再降一级——公共敌人在射程内时不互打
     * （双首领互索除外）。
     */
    public static boolean canFactionCombatantAttack(LivingEntity source, LivingEntity target) {
        if (source == null || target == null || !target.isAlive() || source == target
                || isFactionAlly(source, target)) return false;
        // 深蓝之树是联动盟友：任何口径（含巴别塔、自然敌对）都不成为可攻击目标。
        if (CaerulaJointHook.isCrossModAllyPair(source, target)) return false;
        // 两阵营敌对时，创造与旁观模式下的玩家不作为阵营生物的有效索敌/攻击目标。
        if (target instanceof Player player && isFactionExemptPlayer(player)) return false;
        // 邪魔（坍缩）阵营：感染个体与「一切非同阵营活体」敌对，不受外来威胁收窄与
        // 共同索敌降级的约束。两个坍缩个体互为同阵营——互不攻击、互不索敌；
        // 一个感染坍缩、一个未感染时，双方按敌对处理。
        if (isCollapsed(source) && isCollapsed(target)) return false;
        if (isCollapsed(source) || isCollapsed(target)) return true;
        // 外来模组敌对生物在场：可攻击目标收窄为外来生物，两阵营（含对立阵营玩家）暂时停火。
        // 双首领互索为绝对最高优先级，不参与收窄（判定已内置于闸门本身）。
        if (foreignModPriorityBlocks(source, target)) return false;
        // 共同索敌呼叫进行中：模组内两阵营互斗降级（不针对玩家索敌），优先围剿公共敌人；
        // 博士与普瑞赛斯的互相索敌凌驾于呼叫降级之上，照常锁定对方。
        if (!(target instanceof Player) && isOpposingFaction(source, target)
                && !isSupremeMutualTargetingPair(source, target)
                && CaerulaJointHook.hasActiveThreatNear(source)) return false;
        // 巴别塔行动模式下源石阵营不再区分中立与敌对，攻击所有非源石阵营生物。
        if (isBabelAssault(source, target)) return true;
        if (target instanceof Player player) {
            return player.level() instanceof ServerLevel level
                    && DisasterData.get(level).isCalamityActive()
                    && isOpposingFaction(source, player);
        }
        return isOpposingFaction(source, target) || isNaturalHostile(target);
    }

    /** 外来威胁扫描间隔（tick）：与原版目标选择器 10 tick 的扫描节奏一致。 */
    private static final long FOREIGN_HOSTILE_SCAN_INTERVAL = 10L;
    /** 外来威胁扫描缓存：实体 UUID → [结果有效截止 tick, 1=存在外来威胁/0=无]。 */
    private static final java.util.Map<java.util.UUID, long[]> FOREIGN_HOSTILE_CACHE =
            new java.util.concurrent.ConcurrentHashMap<>();

    /**
     * 是否为「其他模组的敌对生物」：注册命名空间既不是原版（minecraft）也不是本模组
     * （originfall_cataclysm）的活体生物，且按原版敌对口径（Enemy 接口或 MONSTER 分类）
     * 判定为敌对；玩家与被驯服的宠物不算。本模组生物与转化生物属于自己的阵营体系，
     * 天然被命名空间排除。
     */
    public static boolean isForeignModHostile(LivingEntity entity) {
        if (entity == null || !entity.isAlive() || entity instanceof Player) return false;
        // 邪魔阵营一律按「非本模组敌对生物」处理：本模组两阵营会因它停火一致对外，
        // 共同索敌也把它当公共敌人（未被联动覆盖时同样成立）。
        if (isCollapsed(entity)) return true;
        // 已归入任一明确阵营的实体（本模组生物、转化生物、带源石阵营标记的个体）不是外来者——
        // 被转化的其他模组生物按自己人处理，不再充当触发停火的「外来威胁」。
        if (getFaction(entity) != Faction.NEUTRAL) return false;
        if (entity instanceof net.minecraft.world.entity.TamableAnimal pet && pet.isTame()) return false;
        ResourceLocation key = net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType());
        if (key == null) return false;
        String namespace = key.getNamespace();
        if ("minecraft".equals(namespace) || GeneratedMod.MOD_ID.equals(namespace)) return false;
        // 深蓝之树生物不是「外来威胁」：它是共同索敌盟友（见 CaerulaJointHook），
        // 双方按互不侵犯处理，不进触发两阵营停火收窄的外来者名单。
        if (CaerulaArborCompat.isCaerulaEntity(entity)) return false;
        return entity instanceof Enemy
                || entity.getType().getCategory() == net.minecraft.world.entity.MobCategory.MONSTER;
    }

    /** 明确属于两阵营之一（源石方/文明方）的模组生物；中立实体与玩家不参与外来优先收窄。 */
    private static boolean isFactionCombatant(LivingEntity entity) {
        return entity instanceof Mob && getFaction(entity) != Faction.NEUTRAL;
    }

    /**
     * 索敌范围内是否存在「其他模组的敌对生物」：扫描半径取实体自身的 FOLLOW_RANGE
     * （即需求里的「索敌范围」），按 {@link #FOREIGN_HOSTILE_SCAN_INTERVAL} 节流缓存，
     * 避免 canAttack 在候选遍历里逐次触发大范围实体查询。
     */
    public static boolean hasForeignModHostileNearby(LivingEntity source) {
        if (!(source.level() instanceof ServerLevel level)) return false;
        long now = level.getGameTime();
        long[] cached = FOREIGN_HOSTILE_CACHE.get(source.getUUID());
        if (cached != null && cached[0] > now) return cached[1] == 1L;
        double range = Math.max(16.0D, source.getAttributeValue(Attributes.FOLLOW_RANGE));
        boolean present = !level.getEntitiesOfClass(LivingEntity.class,
                source.getBoundingBox().inflate(range), CalamityLogic::isForeignModHostile).isEmpty();
        if (FOREIGN_HOSTILE_CACHE.size() > 512) {
            FOREIGN_HOSTILE_CACHE.values().removeIf(entry -> entry[0] <= now);
        }
        FOREIGN_HOSTILE_CACHE.put(source.getUUID(),
                new long[]{now + FOREIGN_HOSTILE_SCAN_INTERVAL, present ? 1L : 0L});
        return present;
    }

    /**
     * 「预言家」博士与「女祭司」普瑞赛斯的互索判定：两位首领互为绝对最高优先级索敌，
     * 凌驾于外来模组威胁收窄与共同索敌呼叫降级两条让位规则之上。除此之外的一切
     * 索敌口径（含两阵营其余个体、转化生物）不受本判定影响。
     */
    public static boolean isSupremeMutualTargetingPair(LivingEntity source, LivingEntity target) {
        return (source instanceof Prophet && target instanceof Priestess)
                || (source instanceof Priestess && target instanceof Prophet);
    }

    /**
     * 外来模组敌对生物的「最高优先级」闸门：两阵营生物在索敌范围内看到其他模组的敌对
     * 生物时，非外来目标一律不可索敌——外来者优先级高于阵营其余互相索敌，两阵营借此
     * 暂时不互相攻击；敌对关系本身不变，外来者清空后（缓存最迟 10 tick 后）阵营交战恢复。
     * 博士与普瑞赛斯之间的互索是唯一的例外：两者始终互为最高优先级，不因外来者让位。
     */
    private static boolean foreignModPriorityBlocks(LivingEntity source, LivingEntity target) {
        if (isSupremeMutualTargetingPair(source, target)) return false;
        // 邪魔不与任何生物停火：坍缩源照常攻击一切目标。
        if (isCollapsed(source)) return false;
        return isFactionCombatant(source) && hasForeignModHostileNearby(source)
                        && !isForeignModHostile(target);
    }

    /** 创造与旁观模式下的玩家不参与阵营敌对索敌。 */
    private static boolean isFactionExemptPlayer(Player player) {
        return player.isCreative() || player.isSpectator();
    }

    /** 判断两个明确阵营实体是否可以互相攻击。 */
    public static boolean canFactionAttack(LivingEntity source, LivingEntity target) {
        return canFactionCombatantAttack(source, target);
    }

    /** 把非玩家、非天灾生物替换为独立的转化实体。 */
    public static boolean markCalamityHostile(LivingEntity entity) {
        if (entity instanceof Player || isConversionImmuneTarget(entity)
                || entity instanceof CalamityMob || entity instanceof SourceOreGolem
                || isConvertedHostile(entity)) return false;
        if (entity instanceof Mob mob && !mob.level().isClientSide) {
            double maxHealth = mob.getMaxHealth();
            double attack = mob.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE)
                    ? mob.getAttributeValue(Attributes.ATTACK_DAMAGE) : 2.0D;
            double armor = mob.getArmorValue();
            return convertMob(mob, maxHealth, mob.getHealth(), armor, attack,
                    conversionScaleFromInfection(mob)) != null;
        } else {
            entity.getPersistentData().putBoolean(CALAMITY_HOSTILE_TAG, true);
            return true;
        }
    }

    public static boolean isHoldingSourceOfRuin(LivingEntity entity) {
        return entity instanceof Player player && hasSourceOfRuin(player);
    }

    /** 毁灭之源放在背包、快捷栏、盔甲栏或副手都算作免疫来源。 */
    public static boolean hasSourceOfRuin(Player player) {
        for (int slot = 0; slot < player.getInventory().getContainerSize(); slot++) {
            if (player.getInventory().getItem(slot).is(GeneratedMod.SOURCE_OF_RUIN.get())) return true;
        }
        return player.getOffhandItem().is(GeneratedMod.SOURCE_OF_RUIN.get());
    }

    /**
     * 不可被任何常规转化路径替换的目标：「预言家」与「女祭司」两位特殊首领，
     * 以及哈基玖（本模组的替身与深蓝之树的本尊同等对待）——它是中立彩蛋生物，
     * 不免疫陨石爆炸伤害与源石感染，但任何击杀、感染、陨石或美化包路径都
     * 不能把它变成转化生物。
     */
    public static boolean isConversionImmuneTarget(LivingEntity entity) {
        return entity instanceof Prophet || entity instanceof Priestess
                || entity instanceof Apocata || CaerulaArborCompat.isNativeApocataEntity(entity);
    }

    public static boolean isPlayerAssimilationTarget(LivingEntity entity) {
        return entity instanceof Mob && !(entity instanceof Player)
                && !isConversionImmuneTarget(entity)
                && !(entity instanceof CalamityMob) && !(entity instanceof SourceOreGolem)
                && !isConvertedHostile(entity);
    }

    /** 普通 Mob 被任意伤害击杀后，立即复活并按原有属性与感染层数转化。 */
    public static LivingEntity convertAfterAnyKillDeath(ServerLevel level, LivingEntity victim) {
        return convertAfterAnyKillDeath(level, victim, null);
    }

    /**
     * 普通 Mob 被任意伤害击杀后转化。击杀者是转化生物时受“转化生物密度”游戏规则限制：
     * 3*3 区块内已经存在达到上限的转化生物就不再转化；陨石转化由调用方走独立入口，不受此限制。
     */
    public static LivingEntity convertAfterAnyKillDeath(ServerLevel level, LivingEntity victim,
                                                        LivingEntity killer) {
        // 生命上限归零属于正常死亡，但不得再借“击杀即转化”复活成灾厄生物（修复残留实体）。
        if (MaxHealthZeroLogic.isCapZeroDeath(victim)) return null;
        // 坍缩个体失去复活与死亡后效果：死亡后不再转化/复生。
        if (isCollapsed(victim)) return null;
        if (!(victim instanceof Mob mob) || isConversionImmuneTarget(victim)
                || victim instanceof CalamityMob || victim instanceof SourceOreGolem
                || isConvertedHostile(victim)) return null;
        if (killer != null && isConvertedCreature(killer) && isConversionDensitySaturated(level, victim)) {
            return null;
        }
        // 感染效果的属性修正不能污染“原有数值”快照；没有感染快照时才读取当前属性。
        double maxHealth = victim.getPersistentData().contains(INFECTION_MAX_HEALTH)
                ? victim.getPersistentData().getDouble(INFECTION_MAX_HEALTH) : mob.getMaxHealth();
        double attack = victim.getPersistentData().contains(INFECTION_ATTACK_DAMAGE)
                ? victim.getPersistentData().getDouble(INFECTION_ATTACK_DAMAGE)
                : (mob.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE)
                ? mob.getAttributeValue(Attributes.ATTACK_DAMAGE) : 2.0D);
        double armor = victim.getPersistentData().contains(INFECTION_ARMOR)
                ? victim.getPersistentData().getDouble(INFECTION_ARMOR) : mob.getArmorValue();
        double infectionScale = conversionScaleFromInfection(mob);
        mob.revive();
        mob.setHealth((float) Math.max(1.0D, maxHealth));
        LivingEntity converted = convertMob(mob, maxHealth, maxHealth, armor, attack, infectionScale);
        if (converted != null) clearMeteorAndCrystalEffects(converted);
        return converted;
    }

    /** 玩家只有在本维度天灾仍开启、且没有天灾模式保护时，才是天灾实体的有效目标。 */
    public static boolean canCalamityAttackPlayer(Player player) {
        if (player == null || !(player.level() instanceof ServerLevel level)) return false;
        return DisasterData.get(level).isCalamityActive() && !isCalamityProtectedPlayer(player);
    }

    /** 校验一次天灾实体对玩家的真实攻击资格，覆盖直接伤害和已经发出的投射物。 */
    public static boolean canCalamityEntityAttackPlayer(LivingEntity attacker, Player player) {
        if (attacker instanceof SourceOreGolem golem) return golem.canAttack(player);
        if (attacker instanceof CalamityMob calamity) return calamity.canAttack(player);
        return isConvertedHostile(attacker) && canConvertedHostileAttack(attacker, player);
    }

    public static boolean canCalamityMobAttack(LivingEntity target) {
        return target != null && target.isAlive()
                && (!(target instanceof Player) || canCalamityAttackPlayer((Player) target))
                && !isSourceOreGolemProtectedTarget(target)
                // 深蓝之树是联动盟友，不作天灾口径的可攻击目标（互不侵犯）。
                && !CaerulaArborCompat.isCaerulaEntity(target)
                && (!(target instanceof CalamityMob)
                || target instanceof SourceOreGolem golem && isSourceOreGolemHostile(golem))
                && (target instanceof Player || isNaturalHostile(target)
                || target instanceof SourceOreGolem golem && isSourceOreGolemHostile(golem))
                && (!isConvertedHostile(target)
                || target instanceof SourceOreGolem golem && isSourceOreGolemHostile(golem));
    }

    public static boolean canConvertedHostileAttack(LivingEntity target) {
        return target != null && target.isAlive()
                && (!(target instanceof Player) || canCalamityAttackPlayer((Player) target))
                && !CaerulaArborCompat.isCaerulaEntity(target)
                && (target instanceof Player || isCalamityHostile(target));
    }

    /** 文明延续玩家在天灾期间属于天灾阵营的敌对目标，其他天灾玩家仍保持原有保护。 */
    public static boolean isCalamityProtectedPlayer(Player player) {
        return isCalamityModePlayer(player) && !isCivilizationContinuancePlayer(player);
    }

    /** 已被源石转化的生物属于同一阵营，不能互相选为攻击目标。 */
    public static boolean isSameConvertedFaction(LivingEntity first, LivingEntity second) {
        return first != null && second != null
                && isConvertedHostile(first) && isConvertedHostile(second);
    }

    public static double convertedTargetRadius(LivingEntity source) {
        return source instanceof CalamityMessenger
                ? CALAMITY_MESSENGER_TARGET_RADIUS : CONVERTED_TARGET_RADIUS;
    }

    public static boolean canConvertedHostileAttack(LivingEntity source, LivingEntity target) {
        double targetRadius = convertedTargetRadius(source);
        return target != null && target.isAlive() && source != target
                && !isFactionAlly(source, target)
                // 深蓝之树盟友不作转化生物的追击目标。
                && !CaerulaJointHook.isCrossModAllyPair(source, target)
                // 转化生物同属源石阵营：外来模组敌对生物在场时同样收窄目标、与文明方暂时停火。
                && !foreignModPriorityBlocks(source, target)
                && (canFactionAttack(source, target) || isNaturalHostile(target))
                && source.distanceToSqr(target) <= targetRadius * targetRadius;
    }

    public static LivingEntity findConvertedHostileTarget(ServerLevel level, LivingEntity source, double radius) {
        double searchRadius = Math.min(radius, convertedTargetRadius(source));
        return level.getEntitiesOfClass(LivingEntity.class, source.getBoundingBox().inflate(searchRadius),
                        entity -> entity != source && canConvertedHostileAttack(source, entity)
                                && entity.distanceToSqr(source) <= searchRadius * searchRadius)
                .stream().min(Comparator.comparingDouble(source::distanceToSqr)).orElse(null);
    }

    public static void ensureConvertedHostileGoal(Mob mob) {
        if (!CONVERTED_GOAL_MOBS.add(mob)) return;
        mob.goalSelector.addGoal(1, new ConvertedHostileGoal(mob));
    }

    public static LivingEntity highestHealthTarget(ServerLevel level, LivingEntity source, double radius) {
        return level.getEntitiesOfClass(LivingEntity.class, source.getBoundingBox().inflate(radius),
                        entity -> isMeteorTarget(entity, source, radius))
                .stream().max(Comparator.comparingDouble(LivingEntity::getMaxHealth)).orElse(null);
    }

    /** 制导陨石的灾厄范围；哈气贤者只在这个范围内接管失去目标的制导陨石。 */
    private static final double GUIDED_METEOR_SAGE_RADIUS = 32.0D;

    public static LivingEntity findGuidedMeteorSage(ServerLevel level, double x, double y, double z) {
        // 陨石通常在 200 格以上的高空，范围判定按灾厄的水平半径处理，不能把 Y 轴高度算进距离。
        AABB area = new AABB(x - GUIDED_METEOR_SAGE_RADIUS, level.getMinBuildHeight(),
                z - GUIDED_METEOR_SAGE_RADIUS, x + GUIDED_METEOR_SAGE_RADIUS,
                level.getMaxBuildHeight(), z + GUIDED_METEOR_SAGE_RADIUS);
        return level.getEntitiesOfClass(PureSourceOreGolem.class, area,
                        sage -> sage.isAlive() && horizontalDistanceSqr(sage, x, z)
                                <= GUIDED_METEOR_SAGE_RADIUS * GUIDED_METEOR_SAGE_RADIUS)
                .stream().min(Comparator.comparingDouble(sage -> horizontalDistanceSqr(sage, x, z))).orElse(null);
    }

    private static double horizontalDistanceSqr(LivingEntity entity, double x, double z) {
        double dx = entity.getX() - x;
        double dz = entity.getZ() - z;
        return dx * dx + dz * dz;
    }

    /** 显式要求以哈气贤者为目标时，先改选其他有效目标，避免贤者成为第一锁定目标。 */
    public static LivingEntity findGuidedMeteorInitialTarget(ServerLevel level, LivingEntity requested) {
        if (!(requested instanceof PureSourceOreGolem)) return requested;
        return level.getEntitiesOfClass(LivingEntity.class,
                        requested.getBoundingBox().inflate(GUIDED_METEOR_SAGE_RADIUS),
                        entity -> entity != requested && isMeteorTarget(entity, requested, GUIDED_METEOR_SAGE_RADIUS))
                .stream().min(Comparator.comparingDouble(requested::distanceToSqr)).orElse(null);
    }

    public static boolean isCalamityPopulationTarget(LivingEntity entity, LivingEntity source, double radius) {
        return entity.isAlive() && entity != source && !(entity instanceof CalamityMob)
                && !(entity instanceof Player) && isCalamityHostile(entity)
                && entity.distanceToSqr(source) <= radius * radius;
    }

    public static boolean isMeteorTarget(LivingEntity entity, LivingEntity source, double radius) {
        return isCalamityPopulationTarget(entity, source, radius)
                && !(entity instanceof PureSourceOreGolem)
                && !isConvertedHostile(entity);
    }

    /** 转化生物死亡后生成五枚不衍生的死亡陨石，并由同一波次汇总击杀数。 */
    public static void summonConvertedDeathMeteors(ServerLevel level, LivingEntity victim) {
        summonConvertedDeathMeteors(level, victim, null);
    }

    public static void summonConvertedDeathMeteors(ServerLevel level, LivingEntity victim, LivingEntity killer) {
        if (!(victim instanceof CalamityMob calamity)) return;
        // 坍缩个体失去死亡后效果：死亡不再召唤复活陨石。
        if (isCollapsed(victim)) return;
        summonDeathRevivalWave(level, calamity, killer, 5, 1.0F, 1.0F, 0.1F, 0.1F, false);
    }

    /** 初生魔王死亡后按规格生成一枚锁定陨石；自然刷新的个体由调用方传入对应倍率。 */
    public static void summonDemonLordDeathMeteor(ServerLevel level, CalamityMob victim, LivingEntity killer,
                                                    float damage, float size, float killerScale, float noKillerScale) {
        summonDemonLordDeathMeteors(level, victim, killer, 1, damage, size, killerScale, noKillerScale);
    }

    /** 生成指定数量的锁定复活陨石，供特殊首领复活规则复用。 */
    public static void summonDemonLordDeathMeteors(ServerLevel level, CalamityMob victim, LivingEntity killer,
                                                      int count, float damage, float size,
                                                      float killerScale, float noKillerScale) {
        summonDeathRevivalWave(level, victim, killer, Math.max(1, count), damage, size,
                killerScale, noKillerScale, true);
    }

    private static void summonDeathRevivalWave(ServerLevel level, CalamityMob victim, LivingEntity killer,
                                                int count, float damage, float size, float killerScale,
                                                float noKillerScale, boolean locked) {
        java.util.UUID waveId = java.util.UUID.randomUUID();
        RevivalWave wave = new RevivalWave(victim.getUUID(), victim.createRevivalSnapshot(), victim.getX(), victim.getY(),
                victim.getZ(), killer == null ? null : killer.getUUID(), count, killerScale, noKillerScale,
                level, level.getGameTime() + REVIVAL_RESULT_DELAY_TICKS);
        REVIVAL_WAVES.put(waveId, wave);
        for (int i = 0; i < count; i++) {
            MeteorEntity meteor;
            if (locked && killer != null) {
                meteor = MeteorEntity.createRevival(level, victim, killer, wave.snapshot(), damage, size,
                        killerScale, waveId);
            } else if (locked) {
                LivingEntity target = CalamityLogic.findDeathMeteorTarget(level, victim);
                meteor = target == null
                        ? MeteorEntity.createRevivalAtRandom(level, victim, wave.snapshot(), damage, size,
                        killerScale, waveId)
                        : MeteorEntity.createRevivalAtTarget(level, victim, target, wave.snapshot(), damage,
                        size, killerScale, waveId);
            } else {
                double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
                double distance = Math.sqrt(level.getRandom().nextDouble()) * 16.0D;
                meteor = MeteorEntity.createNaturalRevival(level, victim.getX() + Math.cos(angle) * distance,
                        victim.getZ() + Math.sin(angle) * distance, waveId);
            }
            level.addFreshEntity(meteor);
        }
    }

    public static LivingEntity findDeathMeteorTarget(ServerLevel level, LivingEntity source) {
        return level.getEntitiesOfClass(LivingEntity.class, source.getBoundingBox().inflate(32.0D),
                        entity -> entity != source && entity.isAlive() && !CalamityLogic.isSameConvertedFaction(source, entity)
                                && (entity instanceof Enemy || entity instanceof NeutralMob))
                .stream().min(Comparator.comparingDouble(source::distanceToSqr)).orElse(null);
    }

    public static void recordRevivalWaveKills(ServerLevel level, java.util.UUID waveId, java.util.UUID killerUuid,
                                               int killedCount) {
        RevivalWave wave = REVIVAL_WAVES.get(waveId);
        if (wave == null) return;
        wave.killedCount += Math.max(0, killedCount);
        if (killerUuid != null && wave.killerUuid == null) wave.killerUuid = killerUuid;
    }

    /**
     * 在死亡后固定 20 秒统一结算该波次；陨石尚未落地的部分不再阻塞结算。
     * 结算成功后再等待 5 秒复活，复活属性使用整波击杀统计结果。
     */
    public static void tickRevivalWaves(ServerLevel level) {
        if (REVIVAL_WAVES.isEmpty()) return; // 性能：无波次时直接返回，免去每 tick 的流分配。
        List<java.util.Map.Entry<java.util.UUID, RevivalWave>> dueWaves = REVIVAL_WAVES.entrySet().stream()
                .filter(entry -> entry.getValue().level == level
                        && !entry.getValue().scheduled
                        && level.getGameTime() >= entry.getValue().resolveTick)
                .toList();
        for (java.util.Map.Entry<java.util.UUID, RevivalWave> entry : dueWaves) {
            RevivalWave wave = REVIVAL_WAVES.get(entry.getKey());
            if (wave == null || wave.scheduled) continue;
            List<MeteorEntity> meteors = level.getEntitiesOfClass(MeteorEntity.class,
                            new net.minecraft.world.phys.AABB(-3.0E7D, level.getMinBuildHeight(), -3.0E7D,
                                    3.0E7D, level.getMaxBuildHeight(), 3.0E7D),
                            meteor -> meteor.belongsToRevivalWave(entry.getKey()))
                    .stream().toList();
            for (MeteorEntity meteor : meteors) meteor.resolveAtRevivalDeadline();
            REVIVAL_WAVES.remove(entry.getKey());
            scheduleWaveRevival(level, wave);
        }
    }

    private static void scheduleWaveRevival(ServerLevel level, RevivalWave wave) {
        int count = wave.killedCount;
        if (count <= 0 || wave.snapshot.getDouble("CalamityPreviousMaxHealth") <= 0.0D) return;
        boolean killerKilled = wave.killerUuid != null
                && level.getEntity(wave.killerUuid) instanceof LivingEntity killer
                && killer.isDeadOrDying();
        double healthScale = killerKilled ? 1.0D + count * wave.killerScale : count * wave.noKillerScale;
        double attackScale = killerKilled ? 1.0D + count * wave.killerScale : count * wave.noKillerScale;
        scheduleCalamityRevival(level, wave.snapshot, wave.x, wave.y, wave.z,
                healthScale, healthScale, attackScale, REVIVAL_AFTER_RESULT_DELAY_TICKS);
    }

    /** 保留旧调用入口，兼容已存在的陨石实体和旧存档。 */
    public static void completeRevivalWaveMeteor(ServerLevel level, java.util.UUID waveId) {
        RevivalWave wave = REVIVAL_WAVES.get(waveId);
        if (wave == null || wave.scheduled) return;
        wave.remainingMeteors = Math.max(0, wave.remainingMeteors - 1);
    }

    public static boolean isRevivalWaveVictim(java.util.UUID waveId, java.util.UUID uuid) {
        RevivalWave wave = REVIVAL_WAVES.get(waveId);
        return wave != null && wave.victimUuid.equals(uuid);
    }

    public static void scheduleMeteorRevival(ServerLevel level, CompoundTag entityTag,
                                              double x, double y, double z) {
        scheduleCalamityRevival(level, entityTag, x, y, z, 1.0D, 1.0D, 1.0D);
    }

    public static void scheduleCalamityRevival(ServerLevel level, CompoundTag entityTag,
                                                double x, double y, double z, double scale) {
        scheduleCalamityRevival(level, entityTag, x, y, z, scale, scale, scale);
    }

    public static void scheduleCalamityRevival(ServerLevel level, CompoundTag entityTag,
                                                double x, double y, double z, double healthScale,
                                                double shieldScale, double attackScale) {
        scheduleCalamityRevival(level, entityTag, x, y, z, healthScale, shieldScale, attackScale,
                FRIENDLY_REVIVAL_DELAY_TICKS);
    }

    private static void scheduleCalamityRevival(ServerLevel level, CompoundTag entityTag,
                                                 double x, double y, double z, double healthScale,
                                                 double shieldScale, double attackScale, long delayTicks) {
        if (healthScale <= 0.0D || TiantangzhidianLogic.snapshotIsNoRevive(entityTag)) return;
        java.util.UUID uuid = entityTag.hasUUID("UUID") ? entityTag.getUUID("UUID") : null;
        if (uuid != null && !SCHEDULED_REVIVALS.add(uuid)) return;
        PENDING_REVIVALS.add(new PendingRevival(level, entityTag.copy(), x, y, z,
                level.getGameTime() + delayTicks, healthScale, shieldScale, attackScale, false, uuid));
    }

    public static void scheduleFriendlyRevival(ServerLevel level, CompoundTag entityTag,
                                                double x, double y, double z) {
        if (TiantangzhidianLogic.snapshotIsNoRevive(entityTag)) return;
        java.util.UUID uuid = entityTag.hasUUID("UUID") ? entityTag.getUUID("UUID") : null;
        if (uuid != null && !SCHEDULED_REVIVALS.add(uuid)) return;
        PENDING_REVIVALS.add(new PendingRevival(level, entityTag.copy(), x, y, z,
                level.getGameTime() + FRIENDLY_REVIVAL_DELAY_TICKS, 1.0D, 1.0D, 1.0D, true, uuid));
    }

    public static void tickRevivals(ServerLevel level) {
        Iterator<PendingRevival> iterator = PENDING_REVIVALS.iterator();
        while (iterator.hasNext()) {
            PendingRevival pending = iterator.next();
            if (pending.level != level || level.getGameTime() < pending.readyTick) continue;
            iterator.remove();
            if (pending.uuid != null) SCHEDULED_REVIVALS.remove(pending.uuid);
            Entity entity = EntityType.loadEntityRecursive(pending.entityTag.copy(), level, loaded -> loaded);
            if (!(entity instanceof LivingEntity living)) continue;
            entity.moveTo(pending.x, pending.y, pending.z, entity.getYRot(), entity.getXRot());
            if (pending.friendly && entity instanceof Mob mob) {
                mob.setTarget(null);
                mob.setPersistenceRequired();
                living.setHealth(living.getMaxHealth());
            } else if (living instanceof CalamityMob calamity) {
                calamity.loadRevivalStats(pending.entityTag);
                if (!calamity.reviveWithScaling(pending.healthScale, pending.shieldScale, pending.attackScale)) continue;
            } else {
                living.setHealth(living.getMaxHealth());
                if (living instanceof Mob mob) {
                    mob.setTarget(null);
                    mob.setPersistenceRequired();
                }
            }
            level.addFreshEntity(entity);
            // 复活由死亡快照重建：恶意等级与词条会随快照带回旧值，
            // 这里对模组生物按莱特兰机制重掷一次（原版与其他模组生物不受影响）。
            MaliceCompat.onRevive(living);
        }
    }

    private record PendingRevival(ServerLevel level, CompoundTag entityTag, double x, double y, double z,
                                  long readyTick, double healthScale, double shieldScale, double attackScale,
                                   boolean friendly,
                                  java.util.UUID uuid) {}

    private static final class RevivalWave {
        private final java.util.UUID victimUuid;
        private final CompoundTag snapshot;
        private final double x;
        private final double y;
        private final double z;
        private java.util.UUID killerUuid;
        private int remainingMeteors;
        private int killedCount;
        private final float killerScale;
        private final float noKillerScale;
        private final ServerLevel level;
        private final long resolveTick;
        private boolean scheduled;

        private RevivalWave(java.util.UUID victimUuid, CompoundTag snapshot, double x, double y, double z,
                            java.util.UUID killerUuid, int remainingMeteors, float killerScale, float noKillerScale,
                            ServerLevel level, long resolveTick) {
            this.victimUuid = victimUuid;
            this.snapshot = snapshot;
            this.x = x;
            this.y = y;
            this.z = z;
            this.killerUuid = killerUuid;
            this.remainingMeteors = remainingMeteors;
            this.killerScale = killerScale;
            this.noKillerScale = noKillerScale;
            this.level = level;
            this.resolveTick = resolveTick;
        }

        private CompoundTag snapshot() { return snapshot; }
    }
}
