package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

import java.util.List;
import java.util.UUID;

/** 影霄：无耐久的剑类武器，实际攻击机制由 CommonEvents 统一驱动。 */
public final class YingsiaoSwordItem extends SwordItem {
    public static final String ITEM_ID = "originfall_cataclysm:yingsiao";
    public static final String EXECUTION_TAG = "OriginFallYingsiaoExecution";
    public static final String EMPOWERED_UNTIL = "OriginFallYingsiaoEmpoweredUntil";
    public static final String LAST_ATTACK_TICK = "OriginFallYingsiaoLastAttackTick";
    public static final String EXTRA_HEALTH = "OriginFallYingsiaoExtraHealth";
    public static final String SURVIVAL_TAG = "OriginFallYingsiaoSurvival";
    public static final String SURVIVAL_UNTIL = "OriginFallYingsiaoSurvivalUntil";
    public static final String SURVIVAL_WINDOW_START = "OriginFallYingsiaoSurvivalWindowStart";
    public static final String SURVIVAL_TRIGGER_COUNT = "OriginFallYingsiaoSurvivalTriggerCount";
    /** 终焉极道上一次成功触发的时刻，用于强制两次触发之间的最低间隔。 */
    public static final String SURVIVAL_LAST_TRIGGER = "OriginFallYingsiaoSurvivalLastTrigger";
    public static final String USED_THIS_ATTACK = "OriginFallYingsiaoUsedThisAttack";
    public static final String INTERNAL_DAMAGE = "OriginFallYingsiaoInternalDamage";
    private static final UUID EXTRA_HEALTH_UUID = UUID.fromString("1b80a7ec-8f1d-4f7e-9ed2-1dc83fb1d9a4");
    private static final int EXECUTION_WINDOW = 200;
    private static final long SURVIVAL_RATE_WINDOW = 1200L;
    /** 终焉极道两次触发之间的最低间隔：10 秒。 */
    public static final long SURVIVAL_MIN_INTERVAL_TICKS = 200L;
    private static final double SURVIVAL_BASE_HEALTH = 1000.0D;
    private static final double SPLASH_CHANCE = 0.325D;
    private static final double HEAL_RATIO = 0.325D;
    /** 魔王权柄：斩杀造成使用者自身最大生命值的倍数伤害。 */
    private static final double EXECUTION_DAMAGE_RATIO = 1.5D;

    public YingsiaoSwordItem() {
        super(Tiers.NETHERITE, 3, -2.4F,
                new Item.Properties().stacksTo(1).fireResistant());
    }

    public static boolean isHolding(LivingEntity entity) {
        return entity != null && (entity.getMainHandItem().is(GeneratedMod.YINGSIAO.get())
                || entity.getOffhandItem().is(GeneratedMod.YINGSIAO.get()));
    }

    public static boolean isHolding(Player player) {
        return isHolding((LivingEntity) player);
    }

    public static boolean hasYingsiaoAccess(LivingEntity entity) {
        return entity instanceof Player player ? hasInInventory(player) : isHolding(entity);
    }

    public static boolean hasInInventory(Player player) {
        if (player == null) return false;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            if (player.getInventory().getItem(i).is(GeneratedMod.YINGSIAO.get())) return true;
        }
        return player.getOffhandItem().is(GeneratedMod.YINGSIAO.get());
    }

    /** 影霄的近战命中入口：只认主手影霄，避免副手插着影霄时如我所见的攻击被误判为影霄攻击。 */
    public static boolean isSwordAttackSource(DamageSource source) {
        return source != null && source.getEntity() instanceof Player player
                && source.getDirectEntity() == player
                && player.getMainHandItem().is(GeneratedMod.YINGSIAO.get());
    }

    public static boolean hasExecutionMark(LivingEntity entity) {
        return entity != null && entity.getPersistentData().getBoolean(EXECUTION_TAG);
    }

    public static void markExecution(LivingEntity entity) {
        if (entity != null) entity.getPersistentData().putBoolean(EXECUTION_TAG, true);
    }

    public static void clearExecution(LivingEntity entity) {
        if (entity != null) entity.getPersistentData().remove(EXECUTION_TAG);
    }

    public static boolean isEmpowered(Player player) {
        return isEmpowered((LivingEntity) player);
    }

    public static boolean isEmpowered(LivingEntity entity) {
        return entity != null && entity.getPersistentData().getLong(EMPOWERED_UNTIL) > entity.level().getGameTime();
    }

    public static boolean isModCreature(LivingEntity target) {
        return target instanceof CalamityMob || target instanceof SourceOreGolem
                || CalamityLogic.isConvertedHostile(target);
    }

    public static double executionChance(LivingEntity target) {
        double health = Math.max(1.0D, target.getHealth());
        // 斩杀概率按“下一档位”判定：超过10血至100血按100血档，
        // 超过100血至1000血按1000血档，因此101血为0.325%。
        double probabilityTier = 10.0D;
        while (health > probabilityTier && probabilityTier < Double.MAX_VALUE / 10.0D) {
            probabilityTier *= 10.0D;
        }
        double chance = 3.25D / probabilityTier;
        if (isModCreature(target)) chance *= 2.0D;
        return Math.min(1.0D, chance);
    }

    public static boolean shouldExecute(Player attacker, LivingEntity target) {
        return shouldExecute((LivingEntity) attacker, target);
    }

    public static boolean shouldExecute(LivingEntity attacker, LivingEntity target) {
        if (attacker == null || target == null || target == attacker || target instanceof Player) return false;
        return target.level().getRandom().nextDouble() < executionChance(target);
    }

    public static void healFromDamage(Player player, double amount, boolean execution, double victimMaxHealth) {
        healFromDamage((LivingEntity) player, amount, execution, victimMaxHealth);
    }

    public static void healFromDamage(LivingEntity entity, double amount, boolean execution, double victimMaxHealth) {
        if (entity == null || amount <= 0.0D) return;
        double healing = execution ? victimMaxHealth * HEAL_RATIO : amount * HEAL_RATIO;
        if (!(entity instanceof Player player)) {
            if (entity.getHealth() < entity.getMaxHealth()) {
                entity.heal((float) healing);
                return;
            }
            double extra = Math.max(0.0D, entity.getPersistentData().getDouble(EXTRA_HEALTH)) + healing;
            entity.getPersistentData().putDouble(EXTRA_HEALTH, extra);
            updateExtraHealth(entity);
            entity.heal((float) healing);
            return;
        }
        float current = player.getHealth();
        float max = player.getMaxHealth();
        if (current < max) {
            player.heal((float) healing);
            return;
        }
        AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr == null) return;
        double extra = Math.max(0.0D, player.getPersistentData().getDouble(EXTRA_HEALTH));
        extra += healing;
        player.getPersistentData().putDouble(EXTRA_HEALTH, extra);
        updateExtraHealth(player);
        player.heal((float) healing);
    }

    public static void updateExtraHealth(Player player) {
        updateExtraHealth((LivingEntity) player);
    }

    public static void updateExtraHealth(LivingEntity entity) {
        if (entity == null) return;
        AttributeInstance attr = entity.getAttribute(Attributes.MAX_HEALTH);
        if (attr == null) return;
        attr.removeModifier(EXTRA_HEALTH_UUID);
        double extra = Math.max(0.0D, entity.getPersistentData().getDouble(EXTRA_HEALTH));
        boolean hasAccess = entity instanceof Player player ? hasInInventory(player) : hasYingsiaoAccess(entity);
        if (extra > 0.0D && hasAccess) {
            attr.addPermanentModifier(new AttributeModifier(EXTRA_HEALTH_UUID, "影霄源石核心", extra,
                    AttributeModifier.Operation.ADDITION));
        } else if (extra <= 0.0D || !hasAccess) {
            entity.getPersistentData().remove(EXTRA_HEALTH);
        }
    }

    public static void clearExtraHealth(Player player) {
        clearExtraHealth((LivingEntity) player);
    }

    public static void clearExtraHealth(LivingEntity entity) {
        if (entity == null) return;
        entity.getPersistentData().remove(EXTRA_HEALTH);
        AttributeInstance attr = entity.getAttribute(Attributes.MAX_HEALTH);
        if (attr != null) attr.removeModifier(EXTRA_HEALTH_UUID);
    }

    public static int survivalTriggersPerWindow(Player player) {
        return survivalTriggersPerWindow((LivingEntity) player);
    }

    public static int survivalTriggersPerWindow(LivingEntity entity) {
        if (entity == null) return 1;
        double maxHealth = Math.max(1.0D, entity.getMaxHealth());
        int triggers = 1;
        while (maxHealth > SURVIVAL_BASE_HEALTH && triggers < Integer.MAX_VALUE) {
            maxHealth /= 10.0D;
            triggers++;
        }
        return triggers;
    }

    public static boolean canActivateSurvival(Player player) {
        return canActivateSurvival((LivingEntity) player);
    }

    public static boolean canActivateSurvival(LivingEntity entity) {
        if (entity == null || !hasYingsiaoAccess(entity)) return false;
        CompoundTag data = entity.getPersistentData();
        long now = entity.level().getGameTime();
        // 终焉极道两次触发之间至少间隔 10 秒，冷却内的致命伤害正常结算。
        long lastTrigger = data.getLong(SURVIVAL_LAST_TRIGGER);
        if (lastTrigger > 0L && now - lastTrigger < SURVIVAL_MIN_INTERVAL_TICKS) return false;
        long windowStart = data.getLong(SURVIVAL_WINDOW_START);
        int triggerCount = data.getInt(SURVIVAL_TRIGGER_COUNT);
        if (!data.contains(SURVIVAL_WINDOW_START) || now - windowStart >= SURVIVAL_RATE_WINDOW) {
            windowStart = now;
            triggerCount = 0;
            data.putLong(SURVIVAL_WINDOW_START, windowStart);
            data.putInt(SURVIVAL_TRIGGER_COUNT, 0);
        }
        return triggerCount < survivalTriggersPerWindow(entity);
    }

    public static void activateSurvival(Player player) {
        activateSurvival((LivingEntity) player);
    }

    public static void activateSurvival(LivingEntity entity) {
        if (entity == null) return;
        CompoundTag data = entity.getPersistentData();
        long now = entity.level().getGameTime();
        long windowStart = data.getLong(SURVIVAL_WINDOW_START);
        if (!data.contains(SURVIVAL_WINDOW_START) || now - windowStart >= SURVIVAL_RATE_WINDOW) {
            data.putLong(SURVIVAL_WINDOW_START, now);
            data.putInt(SURVIVAL_TRIGGER_COUNT, 0);
        }
        data.putInt(SURVIVAL_TRIGGER_COUNT, data.getInt(SURVIVAL_TRIGGER_COUNT) + 1);
        data.putLong(SURVIVAL_LAST_TRIGGER, now);
        data.putBoolean(SURVIVAL_TAG, true);
        data.putLong(SURVIVAL_UNTIL, now + EXECUTION_WINDOW);
        data.putLong(EMPOWERED_UNTIL, now + EXECUTION_WINDOW);
    }

    public static void completeSurvival(Player player) {
        completeSurvival((LivingEntity) player);
    }

    public static void completeSurvival(LivingEntity entity) {
        if (entity == null || !entity.getPersistentData().getBoolean(SURVIVAL_TAG)) return;
        entity.getPersistentData().remove(SURVIVAL_TAG);
        entity.getPersistentData().remove(SURVIVAL_UNTIL);
        entity.getPersistentData().remove(EMPOWERED_UNTIL);
        entity.heal(entity.getMaxHealth() * (float) HEAL_RATIO);
    }

    public static boolean consumeEmpowered(Player player) {
        return consumeEmpowered((LivingEntity) player);
    }

    public static boolean consumeEmpowered(LivingEntity entity) {
        if (!isEmpowered(entity)) return false;
        entity.getPersistentData().remove(EMPOWERED_UNTIL);
        return true;
    }

    public static void removeSwordFromPlayer(Player player) {
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (stack.is(GeneratedMod.YINGSIAO.get())) {
                player.getInventory().setItem(i, ItemStack.EMPTY);
                player.spawnAtLocation(stack);
            }
        }
        if (player.getOffhandItem().is(GeneratedMod.YINGSIAO.get())) {
            ItemStack stack = player.getOffhandItem().copy();
            player.setItemSlot(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
            player.spawnAtLocation(stack);
        }
    }

    public static void tickPlayer(Player player) {
        if (player.level().isClientSide) return;
        if (hasInInventory(player)) updateExtraHealth(player);
        else clearExtraHealth(player);
        if (player.getPersistentData().getBoolean(SURVIVAL_TAG)
                && player.getPersistentData().getLong(SURVIVAL_UNTIL) <= player.level().getGameTime()) {
            player.setHealth(0.0F);
            player.die(player.level().damageSources().genericKill());
            removeSwordFromPlayer(player);
            clearExtraHealth(player);
            player.getPersistentData().remove(SURVIVAL_TAG);
            player.getPersistentData().remove(SURVIVAL_UNTIL);
            player.getPersistentData().remove(EMPOWERED_UNTIL);
        }
    }

    public static void applyAttack(Player attacker, LivingEntity target, boolean splash, int depth) {
        applyAttack((LivingEntity) attacker, target, splash, depth);
    }

    public static void applyAttack(LivingEntity attacker, LivingEntity target, boolean splash, int depth) {
        if (attacker == null || target == null || !target.isAlive() || depth > 16) return;
        if (!splash && !hasYingsiaoAccess(attacker)) return;
        boolean execution = shouldExecute(attacker, target);
        boolean empowered = !splash && consumeEmpowered(attacker);
        double targetMax = Math.max(1.0D, target.getMaxHealth());
        double firstDamage = empowered ? attacker.getMaxHealth() : attacker.getMaxHealth() * 0.20D;
        if (execution) {
            firstDamage = attacker.getMaxHealth() * EXECUTION_DAMAGE_RATIO;
            markExecution(target);
        }
        double secondDamage = execution || empowered ? 0.0D : (target.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE)
                ? Math.max(0.0D, target.getAttributeValue(Attributes.ATTACK_DAMAGE)) : 0.0D);
        double total = firstDamage + secondDamage;
        DamageSource source = attacker instanceof Player player
                ? attacker.level().damageSources().playerAttack(player)
                : attacker.level().damageSources().mobAttack(attacker);
        if (firstDamage > 0.0D && target.isAlive()) {
            if (execution) {
                // 斩杀：造成使用者自身最大生命值150%的无视防御伤害；直接压低生命值后补齐死亡流程。
                target.getPersistentData().putBoolean(INTERNAL_DAMAGE, true);
                try {
                    target.setHealth(Math.max(0.0F, target.getHealth() - (float) firstDamage));
                    // setHealth 压到零血后 isAlive() 已为 false，必须无条件 die()，否则目标
                    // 停留在零生命状态、死亡登记（含博士巴别塔回忆的死亡快照）等不到。
                    // die() 内部会对已死/已移除再判一次，安全。
                    if (target.getHealth() <= 0.0F) target.die(source);
                } finally {
                    target.getPersistentData().remove(INTERNAL_DAMAGE);
                }
            } else {
                // 第一段是无视护甲的真实伤害；直接压低生命值后补齐死亡流程。
                target.setHealth(Math.max(0.0F, target.getHealth() - (float) firstDamage));
                if (target.getHealth() <= 0.0F) target.die(source);
            }
            healFromDamage(attacker, firstDamage, execution || empowered, targetMax);
        }
        if (secondDamage > 0.0D && target.isAlive()) {
            target.getPersistentData().putBoolean(INTERNAL_DAMAGE, true);
            target.hurt(source, (float) secondDamage);
            target.getPersistentData().remove(INTERNAL_DAMAGE);
            healFromDamage(attacker, secondDamage, false, targetMax);
        }
        // setHealth 不会自动进入 LivingEntity 的死亡流程；目标压到零血后必须显式 die，
        // 否则斩杀目标会停留在零生命状态，导致后续攻击与客户端同步异常、死亡登记也等不到。
        // 去掉 isAlive() 拦截（setHealth(0) 后恒为 false），die() 内部会对已死/已移除再判一次。
        if (target.getHealth() <= 0.0F) target.die(source);
        if (empowered && target.isDeadOrDying()) completeSurvival(attacker);
        if (target.isAlive()) {
            // 影霄的斩击是直接结算生命值的真实伤害，不经过史诗战斗的伤害管线；这里补上命中反馈，
            // 使持剑者（含特蕾西娅的剑形气劲）的每一刀在史诗战斗下都有对应的打断/受击表现。
            SkillCombatHooks.impact(target, (float) total, execution || empowered
                    ? SkillCombatHooks.Impact.HEAVY : SkillCombatHooks.Impact.LIGHT);
        }
        if (!splash && attacker.level().getRandom().nextDouble() < SPLASH_CHANCE) {
            // 斩杀/强化攻击的溅射不包含使用者；普通攻击按要求包含使用者自身。
            splashAttack(attacker, target, total, depth + 1, !(execution || empowered));
        }
        if (execution) clearExecution(target);
    }

    private static void splashAttack(LivingEntity attacker, LivingEntity primary, double damage, int depth,
                                     boolean includeAttacker) {
        if (depth > 16 || attacker.level().getRandom().nextDouble() >= SPLASH_CHANCE) return;
        AABB box = attacker.getBoundingBox().inflate(4.0D);
        List<LivingEntity> targets = attacker.level().getEntitiesOfClass(LivingEntity.class, box,
                entity -> entity.isAlive() && entity != primary
                        && (includeAttacker || entity != attacker)
                        && (entity == attacker || (!entity.isAlliedTo(attacker)
                        && !CalamityLogic.isFactionAlly(attacker, entity))));
        for (LivingEntity target : targets) {
            applySplashDamage(attacker, target, damage, depth, includeAttacker);
        }
    }

    private static void applySplashDamage(LivingEntity attacker, LivingEntity target, double incoming, int depth,
                                          boolean includeAttacker) {
        if (depth > 16 || !target.isAlive()) return;
        boolean execution = shouldExecute(attacker, target);
        double targetMax = Math.max(1.0D, target.getMaxHealth());
        double damage = execution ? attacker.getMaxHealth() * EXECUTION_DAMAGE_RATIO : incoming;
        if (execution) markExecution(target);
        DamageSource splashSource = attacker instanceof Player player
                ? attacker.level().damageSources().playerAttack(player)
                : attacker.level().damageSources().mobAttack(attacker);
        target.getPersistentData().putBoolean(INTERNAL_DAMAGE, true);
        try {
            if (execution) {
                // 溅射斩杀同样造成使用者自身最大生命值150%的无视防御伤害。
                target.setHealth(Math.max(0.0F, target.getHealth() - (float) damage));
            } else {
                target.hurt(splashSource, (float) damage);
            }
        } finally {
            target.getPersistentData().remove(INTERNAL_DAMAGE);
        }
        healFromDamage(attacker, damage, execution, targetMax);
        if (target.isAlive()) {
            // 溅射同样是直接结算，命中反馈在这里补齐（未装史诗战斗时空操作）。
            SkillCombatHooks.impact(target, (float) damage, execution
                    ? SkillCombatHooks.Impact.HEAVY : SkillCombatHooks.Impact.LIGHT);
        }
        // setHealth 不会自动进入 LivingEntity 的死亡流程；目标压到零血后必须显式 die，
        // 否则溅射斩杀目标会停留在零生命状态、死亡登记也等不到。
        // 去掉 isDeadOrDying() 拦截（setHealth(0) 后恒为 true），die() 内部会对已死/已移除再判一次。
        if (target.getHealth() <= 0.0F) target.die(splashSource);
        // 每次成功溅射攻击本身再次进行32.5%递归判定。
        splashAttack(attacker, target, damage, depth + 1, includeAttacker && !execution);
        if (execution) clearExecution(target);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack, Enchantment enchantment) {
        return enchantment.category.canEnchant(stack.getItem());
    }

    @Override
    public boolean isValidRepairItem(ItemStack stack, ItemStack repair) {
        return false;
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        // 原版玩家攻击事件在 CommonEvents 中接管；这里保持剑的攻击动作与兼容性。
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("两段伤害：使用者最大生命值20%的无视防御伤害 + 目标自身属性伤害")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("青色怒火：任意攻击32.5%概率向周围4格溅射，溅射可递归触发")
                .withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.literal("魔王权柄：10血32.5%、100血3.25%、1000血0.325%、10000血0.0325%判定斩杀，斩杀造成自身最大生命值150%伤害，模组生物概率提升2倍")
                .withStyle(ChatFormatting.DARK_RED));
        tooltip.add(Component.literal("源石核心：造成伤害的32.5%回复，满血时临时增加最大生命")
                .withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.literal("终焉极道：受到致命伤害时锁定为1并传送；每分钟最多按最大生命值十倍档位触发，两次触发至少间隔10秒，10秒内下一击伤害为使用者最大生命值")
                .withStyle(ChatFormatting.DARK_AQUA));
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
