package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 邪魔（坍缩）累计层数之约。
 *
 * <p>累计层数＝世界里所有存活邪魔（带坍缩效果的生物）当前坍缩层数之和；
 * 邪魔死亡（含 /kill）时其层数从累计中扣除。账本按实体 UUID 记入随存档保存的
 * {@link SavedData}：加层时改账、死亡时销账，未加载区块里的邪魔保留最后一次已知层数。</p>
 *
 * <p>累计层数每达到 2 的三次方及以上的 2 的幂（8、16、32、64…），以及 100 及以后
 * 每 100 的倍数（100、200、300…），就点亮一个档位；跌破即收回，
 * 回升到同一档位时沿用该档位第一次抽取到的加成种类，不再重抽。加成共十种，
 * 每个档位从<b>未到上限的加成池中等概率随机抽取一种</b>——某个加成生效层数
 * 已达其上限时，新一轮抽取将它整个剔除出池子，不再被抽出（旧记录沿用与
 * 跌破收回后仍可能保留/回到上限内）。同一加成被多个档位选中即叠加层数
 * （有上限的按上限截断）。触发与收回都会在聊天框公告，
 * 效果作用于所有坍缩状态生物。</p>
 *
 * <p>十种加成（层数上限：无/一/无/无/无/二/无/一/五/无）：</p>
 * <ol>
 *   <li><b>非线性移动</b>：每层 +32.5% 移速；被攻击时进入 3 秒额外 +100% 移速状态。</li>
 *   <li><b>亚空间悖论</b>：所有邪魔学会传送（行为与转化生物学到的 teleport 词条一致：
 *       每 20 tick、与目标距离超过 4 格时 20% 概率闪现到目标附近）。</li>
 *   <li><b>情绪实体</b>：感染新生物（首次坍缩）时，立刻复制当前层数只该生物，
 *       继承其全部能力（完整 NBT 拷贝）。</li>
 *   <li><b>实质性坍缩</b>：移动中留下邪魔领域大小的感染空间（性质参考龙息，带粒子），
 *       空间内非邪魔生物移速与攻速各降 3.25%×层数，持续 层数×2 秒；感染空间以大量
 *       龙息粒子维持雾化外观，邪魔本体也参考阳火的喷发方式从身体持续冒出同款粒子，
 *       冒放量随生效层数从少量逐步增加。</li>
 *   <li><b>气压失序</b>：邪魔领域内所有（非邪魔）生物每秒受到 1×层数 点伤害。</li>
 *   <li><b>触发性危殆</b>：邪魔攻击的坍缩传染概率 +32.5%×层数。</li>
 *   <li><b>去量化</b>：邪魔的攻击造成 1～层数×2 倍（等概率随机）的最终伤害。</li>
 *   <li><b>睁眼瞎</b>：被邪魔造成伤害（含气压这类邪魔范围伤害）的生物获得无限时长失明 I。</li>
 *   <li><b>一抹黑</b>：进入邪魔领域的生物被附加 层数×1 秒 的失明 I。</li>
 *   <li><b>坍缩范式</b>：邪魔领域半径每层 +32.5%。</li>
 * </ol>
 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID)
public final class CollapseCovenant extends SavedData {
    public static final int NONLINEAR_MOVEMENT = 0;
    public static final int SUBSPACE_PARADOX = 1;
    public static final int EMOTION_ENTITY = 2;
    public static final int SUBSTANTIVE_COLLAPSE = 3;
    public static final int PRESSURE_DISORDER = 4;
    public static final int TRIGGER_CRITICAL = 5;
    public static final int DEQUANTIZATION = 6;
    public static final int BLIND_ON_HIT = 7;
    public static final int BLIND_ON_ENTER = 8;
    public static final int COLLAPSE_PARADIGM = 9;
    public static final int BUFF_COUNT = 10;

    private static final String[] BUFF_NAMES = {
            "非线性移动", "亚空间悖论", "情绪实体", "实质性坍缩", "气压失序",
            "触发性危殆", "去量化", "睁眼瞎", "一抹黑", "坍缩范式"};
    /** 各加成的层数上限（{@link Integer#MAX_VALUE} 即无上限）。 */
    private static final int[] BUFF_CAPS = {
            Integer.MAX_VALUE, 1, Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE,
            2, Integer.MAX_VALUE, 1, 5, Integer.MAX_VALUE};
    /** 档位序列起点：2 的三次方＝8，此后 8、16、32、64…每个 2 的幂点亮一个档位。 */
    private static final int STAGE_POWER_START = 8;
    /** 档位序列补档：100 及以后每 100 的倍数（100、200、300…）再点亮一个档位。 */
    private static final int STAGE_MULTIPLE_STEP = 100;
    /** 档位结算间隔（tick）。 */
    private static final long EVAL_INTERVAL = 20L;

    /** 非线性移动：每层移速加成。 */
    public static final double NONLINEAR_SPEED_PER_STACK = 0.325D;
    /** 非线性移动：被攻击后的狂暴窗口（3 秒）与额外移速（+100%）。 */
    public static final long NONLINEAR_RAGE_TICKS = 60L;
    public static final double NONLINEAR_RAGE_BONUS = 1.0D;
    /** 亚空间悖论：传送行为与 teleport 词条同参——每 20 tick、4 格外、20% 概率。 */
    private static final double TELEPORT_MIN_DISTANCE_SQR = 4.0D * 4.0D;
    private static final float TELEPORT_CHANCE = 0.20F;
    /** 实质性坍缩：每层削弱幅度（移速/攻速 −3.25%）与空间存续（每层 2 秒）。 */
    public static final double ZONE_REDUCE_PER_STACK = 0.0325D;
    public static final long ZONE_LIFE_TICKS_PER_STACK = 40L;
    /** 气压失序：每层每秒伤害（1 点）。 */
    public static final double PRESSURE_DAMAGE_PER_STACK = 1.0D;
    /** 触发性危殆：每层追加的传染概率（32.5%）。 */
    public static final double TRIGGER_CHANCE_PER_STACK = 0.325D;
    /** 一抹黑：每层失明时长（1 秒）。 */
    public static final int BLIND_ENTER_TICKS_PER_STACK = 20;
    /** 坍缩范式：每层领域半径增幅（+32.5%）。 */
    public static final double PARADIGM_PER_STACK = 0.325D;
    /** 感染空间掉落的最小位移阈值与节流水位。 */
    private static final double ZONE_MOVE_THRESHOLD_SQR = 1.0D;
    private static final int MAX_ZONES = 256;

    private static final String DATA_NAME = "originfall_collapse_covenant";
    private static final String RAGE_UNTIL_TAG = "OriginFallCollapseRageUntil";
    private static final String ZONE_LAST_X_TAG = "OriginFallSubstanceZoneLastX";
    private static final String ZONE_LAST_Z_TAG = "OriginFallSubstanceZoneLastZ";
    private static final UUID NONLINEAR_SPEED_UUID =
            UUID.fromString("7c4d9a21-3b58-4f60-9d17-2a8e4c6b0f31");

    /** 账本：邪魔 UUID → 其当前坍缩层数。随存档保存，死亡时销账。 */
    private final Map<UUID, Integer> ledger = new ConcurrentHashMap<>();
    /** 档位抽取记录：档键（阈值）→ 加成编号。永久保留，跌破回升后沿用。 */
    private final Map<String, Integer> stageBuffs = new HashMap<>();
    /** 上次结算时点亮的总档数；−1 表示服务器刚加载，首次结算静默对齐。 */
    private int prevActiveCount = -1;

    /** 结算后的生效层数（含上限截断）；仅服务端主线程读写。 */
    private static final int[] STACKS = new int[BUFF_COUNT];
    /** 实质性坍缩留下的感染空间（短寿命的临时物，不随存档保存）。 */
    private static final List<Zone> ZONES = new ArrayList<>();

    private record Zone(ServerLevel level, double x, double y, double z,
                        double radius, long expireTick, int stacks) {}

    public static CollapseCovenant load(CompoundTag tag) {
        CollapseCovenant data = new CollapseCovenant();
        ListTag ledgerTag = tag.getList("Ledger", Tag.TAG_COMPOUND);
        for (int i = 0; i < ledgerTag.size(); i++) {
            CompoundTag entry = ledgerTag.getCompound(i);
            if (entry.hasUUID("Id")) data.ledger.put(entry.getUUID("Id"), entry.getInt("Layers"));
        }
        CompoundTag stages = tag.getCompound("Stages");
        for (String key : stages.getAllKeys()) {
            data.stageBuffs.put(key, stages.getInt(key));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag ledgerTag = new ListTag();
        for (Map.Entry<UUID, Integer> entry : ledger.entrySet()) {
            CompoundTag record = new CompoundTag();
            record.putUUID("Id", entry.getKey());
            record.putInt("Layers", entry.getValue());
            ledgerTag.add(record);
        }
        tag.put("Ledger", ledgerTag);
        CompoundTag stages = new CompoundTag();
        for (Map.Entry<String, Integer> entry : stageBuffs.entrySet()) {
            stages.putInt(entry.getKey(), entry.getValue());
        }
        tag.put("Stages", stages);
        return tag;
    }

    public static CollapseCovenant get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(CollapseCovenant::load,
                CollapseCovenant::new, DATA_NAME);
    }

    /** 账本与档位记录全服共享，统一挂在主世界的存档数据上。 */
    private static CollapseCovenant forEntity(LivingEntity entity) {
        return entity.level() instanceof ServerLevel level
                ? get(level.getServer().overworld()) : null;
    }

    // ================= 对外读取 =================

    /** 加成当前生效层数（已按上限截断）；仅服务端。 */
    public static int stacks(int buff) {
        return STACKS[buff];
    }

    /** 坍缩范式缩放后的邪魔领域半径（基础 4 格，每层 +32.5%）。 */
    public static double fieldRadius() {
        return CalamityLogic.COLLAPSE_SPREAD_RADIUS * (1.0D + PARADIGM_PER_STACK * stacks(COLLAPSE_PARADIGM));
    }

    /** 触发性危殆对传染概率的追加值。 */
    public static double triggerChanceBonus() {
        return TRIGGER_CHANCE_PER_STACK * stacks(TRIGGER_CRITICAL);
    }

    // ================= 账本维护 =================

    /**
     * 坍缩层数变化入口（由 {@link CalamityLogic#addCollapseLayer} 调用）：
     * 记入/更新账本、取消邪魔的原版消散，首次感染时结算「情绪实体」的复制。
     */
    public static void onLayersChanged(LivingEntity entity, int layers, boolean firstInfection) {
        if (entity == null || entity.level().isClientSide || !(entity.level() instanceof ServerLevel)) return;
        CollapseCovenant data = forEntity(entity);
        data.ledger.put(entity.getUUID(), layers);
        data.setDirty();
        // 邪魔是永久感染体：不允许原版因距离消散，否则累计层数会静默漂移。
        if (entity instanceof Mob mob) mob.setPersistenceRequired();
        if (firstInfection) {
            int clones = stacks(EMOTION_ENTITY);
            if (clones > 0 && entity instanceof Mob mob) {
                for (int i = 0; i < clones; i++) {
                    duplicateCollapsed(mob);
                }
            }
        }
    }

    /**
     * 情绪实体：完整 NBT 复制一只刚被感染的邪魔——装备、行为特性、属性与坍缩层数
     * 一并继承（「继承目标生物全部能力」）。副本以新 UUID 入场并单独记账。
     */
    private static void duplicateCollapsed(Mob original) {
        if (!(original.level() instanceof ServerLevel level)) return;
        CompoundTag tag = original.saveWithoutId(new CompoundTag());
        tag.remove("UUID");
        tag.remove("Pos");
        tag.remove("Motion");
        tag.remove("FallDistance");
        tag.remove("Fire");
        Entity copy = EntityType.loadEntityRecursive(tag, level, loaded -> {
            double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
            double distance = 0.75D + level.getRandom().nextDouble() * 1.25D;
            loaded.setPos(original.getX() + Math.cos(angle) * distance,
                    original.getY(), original.getZ() + Math.sin(angle) * distance);
            if (loaded instanceof Mob mob) {
                mob.setTarget(null);
            }
            return loaded;
        });
        if (copy instanceof LivingEntity living) {
            onLayersChanged(living, CalamityLogic.collapseLayers(living), false);
            level.addFreshEntity(copy);
        }
    }

    /** 邪魔死亡：从账本扣除其层数（含 /kill 与各类直接死亡，死亡事件是唯一收口）。 */
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide || !CalamityLogic.isCollapsed(victim)) return;
        CollapseCovenant data = forEntity(victim);
        if (data != null && data.ledger.remove(victim.getUUID()) != null) data.setDirty();
    }

    // ================= 档位结算 =================

    /** 主世界每 tick 调用；每 20 tick 结算一次累计层数与档位。 */
    public static void tickServer(MinecraftServer server) {
        ServerLevel overworld = server.overworld();
        long now = overworld.getGameTime();
        if (now % EVAL_INTERVAL != 0L) return;
        get(overworld).evaluate(server, now);
    }

    private void evaluate(MinecraftServer server, long now) {
        net.minecraft.util.RandomSource random = server.overworld().getRandom();
        int total = 0;
        for (int layers : ledger.values()) total += layers;
        // 当前点亮的总档数＝累计层数内 2 的幂（≥8）与 100 的倍数（≥100）的个数之和。
        int active = stageCount(total);
        // 合并排序后的阈值序列：新档要看它们，跌破收回时还要看已经越过的旧档。
        int[] thresholds = stageThresholds(Math.max(active, prevActiveCount));
        // 先统计当前点亮档位里每个加成的生效个数：新档抽取时以此判定「已达上限」，
        // 达到上限的加成将从抽取池里整个剔除，不再占用后续档位。
        int[] counts = new int[BUFF_COUNT];
        for (int index = 0; index < active; index++) {
            Integer buff = stageBuffs.get(stageKey(thresholds[index]));
            if (buff != null) counts[buff]++;
        }
        // 服务器刚加载：静默对齐到当前档位，只恢复生效层数，不刷屏补公告。
        if (prevActiveCount < 0) {
            prevActiveCount = active;
        } else if (active > prevActiveCount) {
            for (int index = prevActiveCount; index < active; index++) {
                activateStage(server, random, thresholds[index], counts);
            }
        } else if (active < prevActiveCount) {
            for (int index = active; index < prevActiveCount; index++) {
                int threshold = thresholds[index];
                Integer buff = stageBuffs.get(stageKey(threshold));
                if (buff != null) {
                    broadcast(server, "【邪魔之约】邪魔累计层数跌破 " + threshold
                            + "，收回加成：【" + BUFF_NAMES[buff] + "】（档位休眠，回升后沿用）");
                }
            }
        }
        prevActiveCount = active;
        for (int buff = 0; buff < BUFF_COUNT; buff++) {
            STACKS[buff] = Math.min(counts[buff], BUFF_CAPS[buff]);
        }
    }

    /** 累计层数内点亮的档位总数：2 的幂（≥8）与 100 的倍数（≥100）不重合，直接相加。 */
    private static int stageCount(int total) {
        int count = 0;
        for (long power = STAGE_POWER_START; power > 0L && power <= total; power <<= 1) count++;
        count += total / STAGE_MULTIPLE_STEP;
        return count;
    }

    /**
     * 前 {@code count} 个档位阈值，按升序合并两列：2 的三次方及以上的 2 的幂
     * （8、16、32、64…）与 100 及以后每 100 的倍数（100、200、300…）。
     * 两列不会重合——2 的幂不含因数 25，永远不会是 100 的倍数。
     */
    private static int[] stageThresholds(int count) {
        int[] thresholds = new int[Math.max(0, count)];
        long power = STAGE_POWER_START;
        long multiple = STAGE_MULTIPLE_STEP;
        for (int i = 0; i < thresholds.length; i++) {
            if (power > 0L && power < multiple) {
                thresholds[i] = (int) Math.min(power, Integer.MAX_VALUE);
                power <<= 1;
            } else {
                thresholds[i] = (int) Math.min(multiple, Integer.MAX_VALUE);
                multiple += STAGE_MULTIPLE_STEP;
            }
        }
        return thresholds;
    }

    private void activateStage(MinecraftServer server, net.minecraft.util.RandomSource random,
                               int threshold, int[] counts) {
        String key = stageKey(threshold);
        Integer buff = stageBuffs.get(key);
        if (buff == null) {
            buff = drawBuff(random, counts);
            counts[buff]++;
            stageBuffs.put(key, buff);
            setDirty();
            broadcast(server, "【邪魔之约】邪魔累计层数达到 " + threshold
                    + "，随机抽取加成：【" + BUFF_NAMES[buff] + "】");
        } else {
            broadcast(server, "【邪魔之约】邪魔累计层数回升到 " + threshold
                    + "，沿用该档位上次抽取的加成：【" + BUFF_NAMES[buff] + "】");
        }
    }

    /**
     * 等概率抽取：从「生效层数尚未到上限」的加成池里均匀随机取一种——
     * 已到上限的加成不再被抽出（十成里有七成本就无上限，池子不会抽空；
     * 兜底分支只防极端旧档，理论不可达）。
     */
    private static int drawBuff(net.minecraft.util.RandomSource random, int[] counts) {
        int[] pool = new int[BUFF_COUNT];
        int size = 0;
        for (int buff = 0; buff < BUFF_COUNT; buff++) {
            if (counts[buff] < BUFF_CAPS[buff]) pool[size++] = buff;
        }
        if (size <= 0) return random.nextInt(BUFF_COUNT);
        return pool[random.nextInt(size)];
    }

    private static String stageKey(int threshold) {
        return "t" + threshold;
    }

    private static void broadcast(MinecraftServer server, String text) {
        server.getPlayerList().broadcastSystemMessage(Component.literal(text), false);
    }

    // ================= 逐 tick 的邪魔自身结算 =================

    /**
     * 每 tick 由 {@link CalamityLogic#tickCollapse} 对每只邪魔调用：
     * 非线性移速与狂暴、亚空间传送、气压失序范围伤害、实质性坍缩的感染空间掉落。
     */
    public static void onCollapseTick(ServerLevel level, LivingEntity entity) {
        long now = level.getGameTime();
        // —— 非线性移动 ——
        int nonlinear = stacks(NONLINEAR_MOVEMENT);
        AttributeInstance speed = entity.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            if (nonlinear > 0) {
                boolean rage = now < entity.getPersistentData().getLong(RAGE_UNTIL_TAG);
                double value = nonlinear * NONLINEAR_SPEED_PER_STACK + (rage ? NONLINEAR_RAGE_BONUS : 0.0D);
                AttributeModifier wanted = new AttributeModifier(NONLINEAR_SPEED_UUID,
                        "collapse_nonlinear_movement", value, AttributeModifier.Operation.MULTIPLY_BASE);
                AttributeModifier current = speed.getModifier(NONLINEAR_SPEED_UUID);
                if (current == null || current.getAmount() != value) {
                    speed.removeModifier(NONLINEAR_SPEED_UUID);
                    speed.addPermanentModifier(wanted);
                }
            } else if (speed.getModifier(NONLINEAR_SPEED_UUID) != null) {
                speed.removeModifier(NONLINEAR_SPEED_UUID);
            }
        }
        // —— 亚空间悖论：与转化生物 teleport 词条完全相同的传送行为（上限 1 层）——
        if (stacks(SUBSPACE_PARADOX) > 0 && entity instanceof Mob mob && entity.tickCount % 20 == 0) {
            LivingEntity target = mob.getTarget();
            if (target != null && target.isAlive()
                    && entity.distanceToSqr(target) > TELEPORT_MIN_DISTANCE_SQR
                    && entity.getRandom().nextFloat() < TELEPORT_CHANCE) {
                double x = target.getX() + (entity.getRandom().nextDouble() - 0.5D) * 8.0D;
                double y = target.getY() + entity.getRandom().nextInt(3) - 1.0D;
                double z = target.getZ() + (entity.getRandom().nextDouble() - 0.5D) * 8.0D;
                entity.randomTeleport(x, y, z, true);
            }
        }
        // —— 气压失序：领域内所有非邪魔生物每秒 1×层数 点伤害 ——
        int pressure = stacks(PRESSURE_DISORDER);
        if (pressure > 0 && entity.tickCount % 20 == 0) {
            double radius = fieldRadius();
            double radiusSq = radius * radius;
            DamageSource source = new DamageSource(magicHolder(level), entity, null);
            for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class,
                    entity.getBoundingBox().inflate(radius),
                    candidate -> candidate != entity && candidate.isAlive()
                            && !CalamityLogic.isCollapsed(candidate)
                            && !(candidate instanceof Player player
                            && (player.isCreative() || player.isSpectator())))) {
                if (victim.distanceToSqr(entity) <= radiusSq) {
                    victim.hurt(source, (float) (pressure * PRESSURE_DAMAGE_PER_STACK));
                }
            }
        }
        // —— 实质性坍缩：移动即在原地留下邪魔领域大小的感染空间 ——
        int substantive = stacks(SUBSTANTIVE_COLLAPSE);
        // 邪魔本体参考阳火的喷发方式持续冒出同款龙息粒子：每 4 tick 一簇，
        // 1 层只冒极少量，随生效层数线性加重（封顶 20/簇防粒子爆炸）。
        if (substantive > 0 && entity.tickCount % 4 == 0) {
            double cx = entity.getX();
            double cy = entity.getY() + entity.getBbHeight() * 0.5D;
            double cz = entity.getZ();
            double spread = Math.max(0.15D, entity.getBbWidth() * 0.5D);
            level.sendParticles(ParticleTypes.DRAGON_BREATH, cx, cy, cz,
                    Math.min(2 + substantive * 3, 20),
                    spread, entity.getBbHeight() * 0.4D, spread, 0.01D);
        }
        if (substantive > 0 && entity instanceof Mob && entity.tickCount % 20 == 0) {
            CompoundTag data = entity.getPersistentData();
            if (!data.contains(ZONE_LAST_X_TAG)) {
                data.putDouble(ZONE_LAST_X_TAG, entity.getX());
                data.putDouble(ZONE_LAST_Z_TAG, entity.getZ());
            } else {
                double dx = entity.getX() - data.getDouble(ZONE_LAST_X_TAG);
                double dz = entity.getZ() - data.getDouble(ZONE_LAST_Z_TAG);
                if (dx * dx + dz * dz >= ZONE_MOVE_THRESHOLD_SQR) {
                    spawnZone((ServerLevel) entity.level(), entity, substantive);
                    data.putDouble(ZONE_LAST_X_TAG, entity.getX());
                    data.putDouble(ZONE_LAST_Z_TAG, entity.getZ());
                }
            }
        }
    }

    private static Holder<net.minecraft.world.damagesource.DamageType> magicHolder(ServerLevel level) {
        return level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolderOrThrow(DamageTypes.MAGIC);
    }

    /** 被邪魔击伤时记录非线性移动的狂暴窗口起点（3 秒）。 */
    public static void markCollapseRage(LivingEntity victim) {
        if (victim.level() instanceof ServerLevel level) {
            victim.getPersistentData().putLong(RAGE_UNTIL_TAG, level.getGameTime() + NONLINEAR_RAGE_TICKS);
        }
    }

    // ================= 实质性坍缩的感染空间 =================

    private static void spawnZone(ServerLevel level, LivingEntity source, int stacksSnapshot) {
        ZONES.add(new Zone(level, source.getX(), source.getY(), source.getZ(), fieldRadius(),
                level.getGameTime() + stacksSnapshot * ZONE_LIFE_TICKS_PER_STACK, stacksSnapshot));
        while (ZONES.size() > MAX_ZONES) {
            ZONES.remove(0);
        }
    }

    /** 每维度每 tick 由 {@link CommonEvents} 调用：粒子、范围减速与到期回收。 */
    public static void tickZones(ServerLevel level) {
        long now = level.getGameTime();
        Iterator<Zone> iterator = ZONES.iterator();
        while (iterator.hasNext()) {
            Zone zone = iterator.next();
            if (zone.level != level) continue;
            if (now >= zone.expireTick) {
                iterator.remove();
                continue;
            }
            // 空间性质参考龙息：一团雾化的粒子悬在感染空间里，浓度按「大量」维持。
            if (now % 3 == 0L) {
                level.sendParticles(ParticleTypes.DRAGON_BREATH, zone.x, zone.y + 0.5D, zone.z,
                        24, zone.radius * 0.8D, 0.6D, zone.radius * 0.8D, 0.0D);
            }
            // 每 10 tick 刷新一次范围减速（效果时长 22 tick > 刷新周期，离开即自然消退）。
            if (now % 10 == 0L) {
                double radius = zone.radius;
                double radiusSq = radius * radius;
                MobEffectInstance debuff = new MobEffectInstance(GeneratedMod.COLLAPSE_ZONE.get(),
                        22, Math.min(254, zone.stacks - 1), false, false, true);
                for (LivingEntity victim : level.getEntitiesOfClass(LivingEntity.class,
                        box(zone, radius),
                        candidate -> candidate.isAlive() && !CalamityLogic.isCollapsed(candidate))) {
                    double dx = victim.getX() - zone.x;
                    double dy = victim.getY() + victim.getBbHeight() * 0.5D - zone.y;
                    double dz = victim.getZ() - zone.z;
                    if (dx * dx + dy * dy + dz * dz <= radiusSq) {
                        victim.addEffect(new MobEffectInstance(debuff));
                    }
                }
            }
        }
    }

    private static net.minecraft.world.phys.AABB box(Zone zone, double radius) {
        return new net.minecraft.world.phys.AABB(zone.x - radius, zone.y - radius, zone.z - radius,
                zone.x + radius, zone.y + radius, zone.z + radius);
    }

    // ================= 一抹黑 =================

    /** 进入邪魔领域的生物：附加 层数×1 秒 的失明 I（已有更长/无限时长时不降级）。 */
    public static void applyAreaBlindness(LivingEntity target) {
        int stacks = stacks(BLIND_ON_ENTER);
        if (stacks <= 0) return;
        int duration = stacks * BLIND_ENTER_TICKS_PER_STACK;
        MobEffectInstance existing = target.getEffect(MobEffects.BLINDNESS);
        if (existing != null && (existing.isInfiniteDuration() || existing.getDuration() >= duration)) return;
        target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, duration, 0, false, false, true));
    }

    // ================= 伤害事件：狂暴 / 去量化 / 睁眼瞎 =================

    /** 受击入口：邪魔被打即刷新非线性移动的狂暴窗口（与伤害来源无关）。 */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide || event.getAmount() <= 0.0F) return;
        if (CalamityLogic.isCollapsed(victim) && stacks(NONLINEAR_MOVEMENT) > 0) {
            markCollapseRage(victim);
        }
    }

    /**
     * 实际造成伤害的结算入口：
     * <ul>
     *   <li><b>去量化</b>——邪魔的近战/投射攻击（伤害带直接实体；气压这类无实体的
     *       范围伤害不参与倍率）等概率随机放大 1～层数×2 倍；</li>
     *   <li><b>睁眼瞎</b>——被邪魔造成伤害（含邪魔范围自身伤害，如气压失序）的非邪魔
     *       生物获得无限时长失明 I。</li>
     * </ul>
     */
    @SubscribeEvent
    public static void onDamage(LivingDamageEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide || !(victim.level() instanceof ServerLevel level)) return;
        if (event.getAmount() <= 0.0F) return;
        if (!(event.getSource().getEntity() instanceof LivingEntity attacker) || attacker == victim) return;
        if (!CalamityLogic.isCollapsed(attacker)) return;
        int dequant = stacks(DEQUANTIZATION);
        // 去量化只作用于「攻击」：有直接伤害实体（近战命中或投射物）才算攻击，
        // 气压失序这类范围伤害的直接实体为空，不叠加倍率。
        if (dequant > 0 && event.getSource().getDirectEntity() != null) {
            int multiplier = 1 + level.getRandom().nextInt(dequant * 2);
            if (multiplier > 1) event.setAmount(event.getAmount() * multiplier);
        }
        if (stacks(BLIND_ON_HIT) > 0 && !CalamityLogic.isCollapsed(victim)
                && !(victim instanceof Player player && (player.isCreative() || player.isSpectator()))) {
            victim.addEffect(new MobEffectInstance(MobEffects.BLINDNESS,
                    MobEffectInstance.INFINITE_DURATION, 0, false, false, true));
        }
    }

    /** 停机清场：感染空间与生效层数都是运行期状态，不得跨存档残留。 */
    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        ZONES.clear();
        for (int buff = 0; buff < BUFF_COUNT; buff++) STACKS[buff] = 0;
    }
}
