package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.network.NetworkHooks;

/**
 * 「无下限•内化宇宙」的实心结界球体展示实体。
 *
 * 与领域展开的「空心无厚度球体」相对，内化宇宙的球体是一个「实心球体」：
 * 以触发者为圆心，从 0 开始向外扩张至指定半径（内化宇宙为 16 格），
 * 之后在整个内化宇宙存在期间持续保持，直至内化宇宙结束（虚空传送时间耗尽）才被移除。
 *
 * 服务端只负责生命周期与半径推进（触发时生成、结束时移除）；客户端渲染器读取当前半径，
 * 画出对应颜色的半透明实心光球。内化宇宙的光效以紫色为主，故实心球体同样取紫色。
 */
public final class UniverseSphereEntity extends Entity {

    /** 从圆心扩张到目标半径所用的 tick 数；越短扩张越快（沿用领域球体的节奏）。 */
    public static final int EXPAND_TICKS = 40;

    private static final EntityDataAccessor<Float> DATA_RADIUS =
            SynchedEntityData.defineId(UniverseSphereEntity.class, EntityDataSerializers.FLOAT);
    /** 当前渲染半径（服务端从 0 逐 tick 推进到目标半径）。 */
    private static final EntityDataAccessor<Float> DATA_CURRENT_RADIUS =
            SynchedEntityData.defineId(UniverseSphereEntity.class, EntityDataSerializers.FLOAT);

    private static final String RADIUS_TAG = "UniverseSphereRadius";
    private static final String SPAWN_TAG = "UniverseSphereSpawnGameTime";

    /** 服务端记录球体生成时的游戏时间，用于逐 tick 推进扩张半径。 */
    private long spawnGameTime;

    public UniverseSphereEntity(EntityType<? extends UniverseSphereEntity> type, Level level) {
        super(type, level);
        setNoGravity(true);
    }

    /**
     * 在指定圆心生成一颗实心结界球体并加入世界（服务端调用）。
     *
     * @param level  服务端维度
     * @param x/y/z  球体圆心（内化宇宙触发者的位置，即触发中心）
     * @param radius 球体目标半径（格）
     * @return 生成成功返回实体，否则返回 null
     */
    public static UniverseSphereEntity create(ServerLevel level, double x, double y, double z, double radius) {
        UniverseSphereEntity sphere = GeneratedMod.UNIVERSE_SPHERE.get().create(level);
        if (sphere == null) return null;
        sphere.moveTo(x, y, z, 0.0F, 0.0F);
        sphere.setTargetRadius(radius);
        sphere.spawnGameTime = level.getGameTime();
        // 初始半径 0，由服务端逐 tick 扩到目标半径；客户端据此做出“向外扩张”的动画。
        sphere.setCurrentRadius(0.0F);
        level.addFreshEntity(sphere);
        return sphere;
    }

    // ---------------- 访问器（客户端渲染与服务器匹配共用） ----------------

    public float getCurrentRadius() {
        return entityData.get(DATA_CURRENT_RADIUS);
    }

    public void setCurrentRadius(float radius) {
        entityData.set(DATA_CURRENT_RADIUS, radius);
    }

    public void setTargetRadius(double radius) {
        entityData.set(DATA_RADIUS, (float) radius);
    }

    // ---------------- 行为覆盖 ----------------

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    @Override
    public boolean isSilent() {
        return true;
    }

    /** 客户端剔除判定按整个球体范围计算，避免球体巨大但实体原点太小导致提前被剔除。 */
    @Override
    public AABB getBoundingBoxForCulling() {
        float r = Math.max(0.0F, getCurrentRadius());
        return new AABB(getX() - r, getY() - r, getZ() - r, getX() + r, getY() + r, getZ() + r);
    }

    @Override
    public void tick() {
        super.tick();
        setDeltaMovement(0.0D, 0.0D, 0.0D);
        if (level().isClientSide) return;
        // 服务端推进扩张：从 0 缓慢扩到目标半径，用平滑曲线让“向外扩张”更明显。
        if (!(level() instanceof ServerLevel server)) return;
        float target = entityData.get(DATA_RADIUS);
        if (target <= 0.0F) return;
        long elapsed = server.getGameTime() - spawnGameTime;
        float current;
        if (elapsed >= EXPAND_TICKS) {
            current = target;
        } else {
            double progress = (double) elapsed / (double) EXPAND_TICKS;
            double eased = 1.0D - Math.pow(1.0D - progress, 3.0D);
            current = (float) (target * eased);
        }
        float prev = entityData.get(DATA_CURRENT_RADIUS);
        if (Math.abs(prev - current) > 0.0005F || (current >= target && prev != target)) {
            entityData.set(DATA_CURRENT_RADIUS, current);
        }
    }

    @Override
    public Packet getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(DATA_RADIUS, 0.0F);
        entityData.define(DATA_CURRENT_RADIUS, 0.0F);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        // 读取保存时的目标半径；扩张进度由服务端在下一 tick 按生成时间重新推进。
        entityData.set(DATA_RADIUS, tag.getFloat(RADIUS_TAG));
        spawnGameTime = tag.getLong(SPAWN_TAG);
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putFloat(RADIUS_TAG, entityData.get(DATA_RADIUS));
        tag.putLong(SPAWN_TAG, spawnGameTime);
    }
}
