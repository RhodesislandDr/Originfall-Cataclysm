package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.network.chat.Component;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.common.MinecraftForge;

@Mod(GeneratedMod.MOD_ID)
public final class GeneratedMod {
    public static final String MOD_ID = "originfall_cataclysm";

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MOD_ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS = DeferredRegister.create(net.minecraft.core.registries.Registries.CREATIVE_MODE_TAB, MOD_ID);
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MOD_ID);
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MOD_ID);
    public static final DeferredRegister<MobEffect> MOB_EFFECTS = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, MOD_ID);

    public static final RegistryObject<MobEffect> SOURCE_ORE_INFECTION = MOB_EFFECTS.register("source_ore_infection",
            SourceOreInfectionEffect::new);

    /** 坍缩：邪魔化的新状态，最多 {@link CalamityLogic#MAX_COLLAPSE_LAYERS} 层，无法以任何形式清除。 */
    public static final RegistryObject<MobEffect> COLLAPSE = MOB_EFFECTS.register("collapse",
            CollapseEffect::new);

    /** 坍缩领域：「实质性坍缩」加成留下的感染空间内的移速/攻速削弱载体（无 HUD 图标）。 */
    public static final RegistryObject<MobEffect> COLLAPSE_ZONE = MOB_EFFECTS.register("collapse_zone",
            CollapseZoneEffect::new);

    /** 保留 meteor_block 注册 ID，兼容旧存档；游戏内名称和外观改为至纯源石。 */
    public static final RegistryObject<Block> METEOR_BLOCK = BLOCKS.register("meteor_block", () -> new PureSourceOreBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_ORANGE).strength(5.0F, 1200.0F)
                    .requiresCorrectToolForDrops().noOcclusion().sound(SoundType.AMETHYST).lightLevel(state -> 10)));
    public static final RegistryObject<Item> METEOR_BLOCK_ITEM = ITEMS.register("meteor_block",
            () -> new BlockItem(METEOR_BLOCK.get(), new Item.Properties().fireResistant()));
    public static final RegistryObject<Item> PURE_SOURCE_ORE_ITEM = ITEMS.register("pure_source_ore",
            () -> new BlockItem(METEOR_BLOCK.get(), new Item.Properties().fireResistant()));
    public static final RegistryObject<Block> BLACK_CRYSTAL = BLOCKS.register("black_crystal", () -> new BlackCrystalBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(3.0F, 1200.0F)
                    .requiresCorrectToolForDrops().sound(SoundType.AMETHYST)));
    public static final RegistryObject<Item> BLACK_CRYSTAL_ITEM = ITEMS.register("black_crystal",
            () -> new BlockItem(BLACK_CRYSTAL.get(), new Item.Properties().fireResistant()));
    public static final RegistryObject<Block> ZHANGSHI_BLOCK = BLOCKS.register("zhangshi_block",
            () -> new ZhangshiBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).strength(30.0F, 1200.0F)
                    .requiresCorrectToolForDrops().sound(SoundType.STONE)));
    public static final RegistryObject<Item> ZHANGSHI_BLOCK_ITEM = ITEMS.register("zhangshi_block",
            () -> new BlockItem(ZHANGSHI_BLOCK.get(), new Item.Properties().fireResistant()));

    public static final RegistryObject<Item> SOURCE_OF_RUIN = ITEMS.register("source_of_ruin",
            () -> new ControlItem(ControlItem.Mode.SOURCE));
    public static final RegistryObject<Item> CIVILIZATION_CONTINUANCE = ITEMS.register("civilization_continuance",
            CivilizationContinuanceItem::new);
    public static final RegistryObject<Item> DESTRUCTION_AND_SALVATION = ITEMS.register("destruction_and_salvation",
            () -> new ControlItem(ControlItem.Mode.SALVATION));
    public static final RegistryObject<Item> OATH_OF_BABEL = ITEMS.register("oath_of_babel",
            () -> new ControlItem(ControlItem.Mode.MESSENGER));
    public static final RegistryObject<Item> PLANE_CHILD_XIU_ER = ITEMS.register("plane_child_xiu_er",
            () -> new ControlItem(ControlItem.Mode.PLANE_CHILD_XIU_ER));
    public static final RegistryObject<Item> METEOR_STAFF = ITEMS.register("meteor_staff", MeteorStaff::new);
    public static final RegistryObject<Item> SOURCE_ORE_BEAUTIFICATION_PACK = ITEMS.register(
            "source_ore_beautification_pack", SourceOreBeautificationPackItem::new);
    public static final RegistryObject<Item> YINGSIAO = ITEMS.register("yingsiao", YingsiaoSwordItem::new);
    public static final RegistryObject<Item> RUWOSUOJIAN = ITEMS.register("ruwosuojian", RuwosuojianSwordItem::new);
    public static final RegistryObject<Item> TIANTANGZHIDIAN = ITEMS.register("tiantangzhidian", TiantangzhidianSwordItem::new);
    /** 阳火展示物：与实体上的独立阳火模型共用同一套白金火焰资源。 */
    public static final RegistryObject<Item> YANG_FIRE = ITEMS.register("yang_fire", YangFireItem::new);
    /** 表里之间：「预言家」博士召唤仪式获得的一次性道具，右键地面召唤博士后消失。 */
    public static final RegistryObject<Item> BIAOLIZHIJIAN = ITEMS.register("biaolizhijian",
            () -> new BiaolizhijianItem(new Item.Properties().stacksTo(1).fireResistant()));
    /** 《源石对世界的融合研究及实践》：开局赠予的机制说明书，右键翻阅，随模组调整自动更新。 */
    public static final RegistryObject<Item> ORIGINFALL_MANUAL = ITEMS.register("originfall_manual",
            () -> new OriginFallManualItem(new Item.Properties().stacksTo(1).fireResistant()));
    /** 邪魔测试物品：仅创造可获得的调试工具，右键生物附加一层坍缩（上限 5 层，走正式感染入口）。 */
    public static final RegistryObject<Item> CALAMITY_TEST_ITEM = ITEMS.register("calamity_test_item",
            CalamityTestItem::new);
    public static final RegistryObject<EntityType<YoungDemonLord>> YOUNG_DEMON_LORD = ENTITY_TYPES.register("young_demon_lord",
            () -> EntityType.Builder.of(YoungDemonLord::new, MobCategory.CREATURE).sized(0.6F, 1.95F).clientTrackingRange(64).build("young_demon_lord"));
    public static final RegistryObject<EntityType<CalamityPrincess>> CALAMITY_PRINCESS = ENTITY_TYPES.register("calamity_princess",
            () -> EntityType.Builder.of(CalamityPrincess::new, MobCategory.CREATURE).sized(0.6F, 1.95F).clientTrackingRange(64).build("calamity_princess"));
    public static final RegistryObject<EntityType<EndWalker>> END_WALKER = ENTITY_TYPES.register("end_walker",
            () -> EntityType.Builder.of(EndWalker::new, MobCategory.MONSTER).sized(0.6F, 1.95F).clientTrackingRange(64).build("end_walker"));
    public static final RegistryObject<EntityType<CalamityMessenger>> CALAMITY_MESSENGER = ENTITY_TYPES.register("calamity_messenger",
            () -> EntityType.Builder.of(CalamityMessenger::new, MobCategory.MONSTER).sized(0.6F, 2.0F).clientTrackingRange(64).build("calamity_messenger"));
    public static final RegistryObject<EntityType<Theresia>> THERESIA = ENTITY_TYPES.register("theresia",
            () -> EntityType.Builder.of(Theresia::new, MobCategory.MONSTER).sized(0.6F, 1.95F)
                    .clientTrackingRange(64).build("theresia"));
    public static final RegistryObject<EntityType<Priestess>> PRIESTESS = ENTITY_TYPES.register("priestess",
            () -> EntityType.Builder.of(Priestess::new, MobCategory.MONSTER).sized(0.6F, 1.95F)
                    .clientTrackingRange(64).build("priestess"));
    public static final RegistryObject<EntityType<Prophet>> PROPHET = ENTITY_TYPES.register("prophet",
            () -> EntityType.Builder.of(Prophet::new, MobCategory.MONSTER).sized(0.6F, 1.95F)
                    .clientTrackingRange(64).build("prophet"));

    /** 领域展开的空心结界球体：只作可视化，无可碰撞、无 AI、无伤害。 */
    public static final RegistryObject<EntityType<DomainSphereEntity>> DOMAIN_SPHERE = ENTITY_TYPES.register("domain_sphere",
            () -> EntityType.Builder.<DomainSphereEntity>of(DomainSphereEntity::new, MobCategory.MISC)
                    .sized(0.1F, 0.1F).clientTrackingRange(128).updateInterval(1).build("domain_sphere"));

    /** 「无下限•内化宇宙」的实心结界球体：只作可视化，无可碰撞、无 AI、无伤害。 */
    public static final RegistryObject<EntityType<UniverseSphereEntity>> UNIVERSE_SPHERE = ENTITY_TYPES.register("universe_sphere",
            () -> EntityType.Builder.<UniverseSphereEntity>of(UniverseSphereEntity::new, MobCategory.MISC)
                    .sized(0.1F, 0.1F).clientTrackingRange(128).updateInterval(1).build("universe_sphere"));

    /** 月牙形剑气：作为近战武器延伸的远程攻击手段，不注册刷怪蛋，因此不出现在创造栏。 */
    public static final RegistryObject<EntityType<SwordQiEntity>> SWORD_QI = ENTITY_TYPES.register("sword_qi",
            () -> EntityType.Builder.<SwordQiEntity>of(SwordQiEntity::new, MobCategory.MISC)
                    .sized(0.7F, 0.45F).clientTrackingRange(64).updateInterval(1).build("sword_qi"));

    public static final RegistryObject<EntityType<SourceOreGolemEntity>> SOURCE_ORE_GOLEM = ENTITY_TYPES.register("source_ore_golem",
            () -> EntityType.Builder.of(SourceOreGolemEntity::new, MobCategory.CREATURE).sized(1.4F, 2.7F)
                    .clientTrackingRange(64).build("source_ore_golem"));
    public static final RegistryObject<EntityType<PureSourceOreGolem>> PURE_SOURCE_ORE_GOLEM = ENTITY_TYPES.register("pure_source_ore_golem",
            () -> EntityType.Builder.of(PureSourceOreGolem::new, MobCategory.CREATURE).sized(1.4F, 2.7F)
                    .clientTrackingRange(64).build("pure_source_ore_golem"));
    /**
     * 哈基玖：《方块与深蓝之树》联动彩蛋生物（中立，可反击，接入首领舞蹈队列）。
     * 张师块＋南瓜头的召唤<b>不依赖深蓝之树在场</b>：未安装时产出本替身但不掉
     * 「哈基玖本人」；装有深蓝之树时召唤优先产出<b>本尊</b>实体，死亡掉落与
     * 潮曦奇美拉钩子仅在装有深蓝之树时结算。本类型也保留给旧存档与 /give。
     */
    public static final RegistryObject<EntityType<Apocata>> APOCATA = ENTITY_TYPES.register("apocata",
            () -> EntityType.Builder.of(Apocata::new, MobCategory.CREATURE).sized(0.6F, 1.95F)
                    .clientTrackingRange(64).build("apocata"));
    public static final RegistryObject<Item> YOUNG_DEMON_LORD_SPAWN_EGG = ITEMS.register("young_demon_lord_spawn_egg",
            () -> new ForgeSpawnEggItem(YOUNG_DEMON_LORD, 0x17253C, 0xF1E8EA, new Item.Properties()));
    public static final RegistryObject<Item> CALAMITY_PRINCESS_SPAWN_EGG = ITEMS.register("calamity_princess_spawn_egg",
            () -> new ForgeSpawnEggItem(CALAMITY_PRINCESS, 0xF4DCE6, 0x6D263F, new Item.Properties()));
    public static final RegistryObject<Item> CALAMITY_MESSENGER_SPAWN_EGG = ITEMS.register("calamity_messenger_spawn_egg",
            () -> new ForgeSpawnEggItem(CALAMITY_MESSENGER, 0x171426, 0xC83B69, new Item.Properties()));
    public static final RegistryObject<Item> PRIESTESS_SPAWN_EGG = ITEMS.register("priestess_spawn_egg",
            () -> new ForgeSpawnEggItem(PRIESTESS, 0xB07CD6, 0x3B2750, new Item.Properties()));
    public static final RegistryObject<Item> PROPHET_SPAWN_EGG = ITEMS.register("prophet_spawn_egg",
            () -> new ForgeSpawnEggItem(PROPHET, 0x2E3B4E, 0xE6E6E6, new Item.Properties()));

    public static final RegistryObject<Item> SOURCE_ORE_GOLEM_SPAWN_EGG = ITEMS.register("source_ore_golem_spawn_egg",
            () -> new ForgeSpawnEggItem(SOURCE_ORE_GOLEM, 0x202020, 0xE26A18, new Item.Properties()));
    public static final RegistryObject<Item> PURE_SOURCE_ORE_GOLEM_SPAWN_EGG = ITEMS.register("pure_source_ore_golem_spawn_egg",
            () -> new ForgeSpawnEggItem(PURE_SOURCE_ORE_GOLEM, 0xFF8A18, 0x252525, new Item.Properties()));
    /** 哈基玖刷怪蛋：刻意<b>不进创造标签页</b>（本尊的蛋归深蓝之树），只保留 /give 入口。 */
    public static final RegistryObject<Item> APOCATA_SPAWN_EGG = ITEMS.register("apocata_spawn_egg",
            () -> new ForgeSpawnEggItem(APOCATA, 0xE9B7C6, 0x2A2332, new Item.Properties()));
    /** 「哈基玖本人」：哈基玖死亡掉落的彩蛋食物（真实伤害 32、饥饿 -57、饱和度 -114）。 */
    public static final RegistryObject<Item> APOCATA_HIMSELF = ITEMS.register("apocata_herself", ApocataHerselfItem::new);

    public static final RegistryObject<CreativeModeTab> ORIGINFALL_TAB = CREATIVE_TABS.register("originfall_tab",
            () -> CreativeModeTab.builder().title(Component.translatable("itemGroup.originfall_cataclysm"))
                    .icon(() -> new net.minecraft.world.item.ItemStack(METEOR_STAFF.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(new net.minecraft.world.item.ItemStack(SOURCE_OF_RUIN.get()));
                        output.accept(new net.minecraft.world.item.ItemStack(CIVILIZATION_CONTINUANCE.get()));
                        output.accept(new net.minecraft.world.item.ItemStack(DESTRUCTION_AND_SALVATION.get()));
                        output.accept(new net.minecraft.world.item.ItemStack(OATH_OF_BABEL.get()));
                        output.accept(new net.minecraft.world.item.ItemStack(PLANE_CHILD_XIU_ER.get()));
                        output.accept(new net.minecraft.world.item.ItemStack(METEOR_STAFF.get()));
                         output.accept(new net.minecraft.world.item.ItemStack(SOURCE_ORE_BEAUTIFICATION_PACK.get()));
                        output.accept(new net.minecraft.world.item.ItemStack(YINGSIAO.get()));
                        output.accept(new net.minecraft.world.item.ItemStack(RUWOSUOJIAN.get()));
                        output.accept(new net.minecraft.world.item.ItemStack(TIANTANGZHIDIAN.get()));
                         output.accept(new net.minecraft.world.item.ItemStack(YANG_FIRE.get()));
                         output.accept(new net.minecraft.world.item.ItemStack(BIAOLIZHIJIAN.get()));
                         output.accept(new net.minecraft.world.item.ItemStack(ORIGINFALL_MANUAL.get()));
                         output.accept(new net.minecraft.world.item.ItemStack(METEOR_BLOCK_ITEM.get()));
                        output.accept(new net.minecraft.world.item.ItemStack(BLACK_CRYSTAL_ITEM.get()));
                         output.accept(new net.minecraft.world.item.ItemStack(ZHANGSHI_BLOCK_ITEM.get()));
                        output.accept(new net.minecraft.world.item.ItemStack(YOUNG_DEMON_LORD_SPAWN_EGG.get()));
                        output.accept(new net.minecraft.world.item.ItemStack(CALAMITY_PRINCESS_SPAWN_EGG.get()));
                         output.accept(new net.minecraft.world.item.ItemStack(CALAMITY_MESSENGER_SPAWN_EGG.get()));
                         output.accept(new net.minecraft.world.item.ItemStack(PRIESTESS_SPAWN_EGG.get()));
                         output.accept(new net.minecraft.world.item.ItemStack(PROPHET_SPAWN_EGG.get()));
                          

                         output.accept(new net.minecraft.world.item.ItemStack(SOURCE_ORE_GOLEM_SPAWN_EGG.get()));
                         output.accept(new net.minecraft.world.item.ItemStack(PURE_SOURCE_ORE_GOLEM_SPAWN_EGG.get()));
                        output.accept(new net.minecraft.world.item.ItemStack(APOCATA_HIMSELF.get()));
                        // 调试专区：邪魔测试物品放在标签页最末，避免与正式内容混淆。
                        output.accept(new net.minecraft.world.item.ItemStack(CALAMITY_TEST_ITEM.get()));
                    }).build());

    public static final RegistryObject<EntityType<MeteorEntity>> METEOR = ENTITY_TYPES.register("meteor",
            () -> EntityType.Builder.of(MeteorEntity::new, MobCategory.MISC)
                    .sized(1.0F, 1.0F).clientTrackingRange(128).updateInterval(1).build("meteor"));
    public static final RegistryObject<BlockEntityType<MeteorBlockEntity>> METEOR_BLOCK_ENTITY = BLOCK_ENTITY_TYPES.register(
            "meteor_block", () -> BlockEntityType.Builder.of(MeteorBlockEntity::new, METEOR_BLOCK.get()).build(null));
    public static final RegistryObject<BlockEntityType<PureSourceOreBlockEntity>> PURE_SOURCE_ORE_BLOCK_ENTITY =
            BLOCK_ENTITY_TYPES.register("pure_source_ore", () -> BlockEntityType.Builder.of(
                    PureSourceOreBlockEntity::new, METEOR_BLOCK.get()).build(null));
    public static final RegistryObject<BlockEntityType<ZhangshiBlockEntity>> ZHANGSHI_BLOCK_ENTITY =
            BLOCK_ENTITY_TYPES.register("zhangshi_block", () -> BlockEntityType.Builder.of(
                    ZhangshiBlockEntity::new, ZHANGSHI_BLOCK.get()).build(null));

    public static final RegistryObject<SoundEvent> METEOR_IMPACT = SOUNDS.register("meteor_impact",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "meteor_impact")));
    public static final RegistryObject<SoundEvent> CALAMITY_MUSIC = SOUNDS.register("calamity_music",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "calamity_music")));
    /** 无下限•内化宇宙触发时在光点中心播放的自定义音乐。 */
    public static final RegistryObject<SoundEvent> UNIVERSE_MUSIC = SOUNDS.register("universe_music",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "universe_music")));
    /** 「预言家」博士「巴别塔回忆」献祭特蕾西娅时播放的专属音乐。 */
    public static final RegistryObject<SoundEvent> BABEL_MEMORY_MUSIC = SOUNDS.register("babel_memory_music",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "babel_memory_music")));
    /** 「扒臀舞」触发曲（玩家提供的琵琶曲，纯 Vorbis 转码）：优先级最高，播放期间不可被打断。 */
    public static final RegistryObject<SoundEvent> TAUNT_DANCE_MUSIC = SOUNDS.register("taunt_dance_music",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "taunt_dance_music")));

    public GeneratedMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        // 游戏规则必须在模组构造阶段注册，这里主动加载一次规则类。
        OriginFallGameRules.bootstrap();
        BLOCKS.register(bus);
        ITEMS.register(bus);
        CREATIVE_TABS.register(bus);
        ENTITY_TYPES.register(bus);
        BLOCK_ENTITY_TYPES.register(bus);
        SOUNDS.register(bus);
        MOB_EFFECTS.register(bus);
        YangFireParticles.init(bus);
        WeaponFlameParticles.init(bus);
        GravityCoreParticles.init(bus);
        YangFireNetworking.init();
        bus.addListener(GeneratedMod::registerAttributes);
        bus.addListener(LearnedTraitLogic::registerCapabilities);
        // 莱特兰-恶意配置加载/重载时自动把 allowTraitOnOwnable 与 allowPlayerAllies 修正为 true
        // （保留驯服生物词条，并让玩家刷怪蛋/道具召唤或认主的生物同样获得等级与恶意词条）。
        bus.addListener(CommonEvents::onModConfig);
        MinecraftForge.EVENT_BUS.register(new CommonEvents());
        MinecraftForge.EVENT_BUS.register(new TiantangzhidianLogic.TiantangzhidianEvents());
        MinecraftForge.EVENT_BUS.register(new RuwosuojianLogic.RuwosuojianEvents());
        MinecraftForge.EVENT_BUS.register(new ProphetSkillLogic.ProphetSkillEvents());
        MinecraftForge.EVENT_BUS.register(new PriestessSkillLogic.PriestessSkillEvents());
        // 生命上限归零 = 正常死亡且不可复活（玩家复活后上限钉 1）；纯原版兜底通道。
        MinecraftForge.EVENT_BUS.register(new MaxHealthZeroLogic.MaxHealthZeroEvents());
        // 史诗战斗（Epic Fight）兼容层：兼容代码位于独立的 epicfight 源码集（同一 jar 内），
        // 只在确认 Epic Fight 存在时经反射入口加载；未安装时该类永不触达，
        // 模组用自带的 AdaptiveCombatGoal 行动逻辑，可完全脱离史诗战斗运行。
        if (net.minecraftforge.fml.ModList.get().isLoaded("epicfight")) {
            try {
                Class<?> compat = Class.forName(
                        "cn.blockforge.generated.originfallcataclysm.OriginfallEpicFightCompat");
                compat.getMethod("init", IEventBus.class).invoke(null, bus);
            } catch (ReflectiveOperationException | LinkageError e) {
                com.mojang.logging.LogUtils.getLogger()
                        .error("[源石天灾] Epic Fight 兼容层加载失败，生物将退回模组自身战斗逻辑", e);
            }
        }
    }

    /**
     * “这片大地”的传承所用到的武器判定：本模组注册、且不是方块或刷怪蛋的物品，
     * 视为生物可以持有的模组武器（影霄、陨星法杖与各控制装置等）。
     */
    public static boolean isModWeapon(net.minecraft.world.item.ItemStack stack) {
        if (stack.isEmpty()) return false;
        Item item = stack.getItem();
        if (item instanceof BlockItem || item instanceof ForgeSpawnEggItem) return false;
        ResourceLocation key = ForgeRegistries.ITEMS.getKey(item);
        return key != null && MOD_ID.equals(key.getNamespace());
    }

    private static void registerAttributes(net.minecraftforge.event.entity.EntityAttributeCreationEvent event) {
        event.put(YOUNG_DEMON_LORD.get(), YoungDemonLord.createAttributes().build());
        event.put(CALAMITY_PRINCESS.get(), CalamityPrincess.createAttributes().build());
         event.put(CALAMITY_MESSENGER.get(), CalamityMessenger.createAttributes().build());
         event.put(THERESIA.get(), Theresia.createAttributes().build());
         event.put(PRIESTESS.get(), Priestess.createAttributes().build());
         event.put(PROPHET.get(), Prophet.createAttributes().build());

        event.put(END_WALKER.get(), EndWalker.createAttributes().build());
        event.put(SOURCE_ORE_GOLEM.get(), SourceOreGolemEntity.createAttributes().build());
        event.put(PURE_SOURCE_ORE_GOLEM.get(), PureSourceOreGolem.createAttributes().build());
        event.put(APOCATA.get(), Apocata.createAttributes().build());
    }

}
