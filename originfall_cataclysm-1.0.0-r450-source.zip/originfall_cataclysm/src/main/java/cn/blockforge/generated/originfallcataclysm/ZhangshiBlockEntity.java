package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * 张师块的方块特性：半径 8 格范围内每 3.25 秒（65 tick）移除一层源石感染。
 * 计时按累计叠加保存：进度写入存档，区块重载后继续累加；一个周期内如果没有完成结算，
 * 余下的整周期会一次性补掉，多个张师块同时生效时净化速度自然叠加。
 */
public final class ZhangshiBlockEntity extends BlockEntity {
    private static final double EFFECT_RADIUS = 8.0D;
    /** 3.25 秒 = 65 tick。 */
    private static final long CLEANSE_INTERVAL_TICKS = 65L;
    /** 单次结算最多补掉的周期数，避免长时间未加载的区块一次性清空全部感染层数。 */
    private static final int MAX_CLEANSING_PER_PASS = 4;

    private long accumulatedTicks;

    public ZhangshiBlockEntity(BlockPos pos, BlockState state) {
        super(GeneratedMod.ZHANGSHI_BLOCK_ENTITY.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state,
                                  ZhangshiBlockEntity blockEntity) {
        blockEntity.accumulatedTicks++;
        if (blockEntity.accumulatedTicks < CLEANSE_INTERVAL_TICKS) {
            // 累计进度每 20 tick 落一次盘，代价远低于每次破坏都写 NBT。
            if (blockEntity.accumulatedTicks % 20L == 0L) blockEntity.setChanged();
            return;
        }
        long cycles = Math.min(MAX_CLEANSING_PER_PASS,
                blockEntity.accumulatedTicks / CLEANSE_INTERVAL_TICKS);
        blockEntity.accumulatedTicks %= CLEANSE_INTERVAL_TICKS;
        blockEntity.setChanged();
        if (!(level instanceof ServerLevel server)) return;

        AABB area = new AABB(pos).inflate(EFFECT_RADIUS);
        for (LivingEntity living : server.getEntitiesOfClass(LivingEntity.class, area,
                entity -> entity.isAlive()
                        && entity.distanceToSqr(pos.getCenter()) <= EFFECT_RADIUS * EFFECT_RADIUS
                        && CalamityLogic.sourceOreInfectionLayers(entity) > 0)) {
            for (long cycle = 0L; cycle < cycles; cycle++) {
                if (!CalamityLogic.removeOneSourceOreInfectionLayer(living)) break;
            }
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putLong("AccumulatedTicks", Math.max(0L, accumulatedTicks));
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        accumulatedTicks = Math.max(0L, Math.min(CLEANSE_INTERVAL_TICKS - 1L, tag.getLong("AccumulatedTicks")));
    }
}
