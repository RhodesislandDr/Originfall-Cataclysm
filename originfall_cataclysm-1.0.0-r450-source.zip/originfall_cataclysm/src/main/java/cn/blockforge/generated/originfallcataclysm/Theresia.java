package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.core.registries.BuiltInRegistries;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** 新生的特蕾西娅：使用玩家人形模型的源石阵营敌对个体。 */
public final class Theresia extends CalamityMob {
    private static final String KILL_COUNT = "TheresiaKillCount";
    private static final UUID GROWTH_HEALTH = UUID.fromString("f1a4e6b2-0c8c-4e9c-9c2b-1f2e9f8c1101");
    private static final UUID GROWTH_ATTACK = UUID.fromString("f1a4e6b2-0c8c-4e9c-9c2b-1f2e9f8c1102");
    private static final UUID GROWTH_ARMOR = UUID.fromString("f1a4e6b2-0c8c-4e9c-9c2b-1f2e9f8c1103");
    private static final UUID GROWTH_SPEED = UUID.fromString("f1a4e6b2-0c8c-4e9c-9c2b-1f2e9f8c1104");
    private static final UUID GROWTH_ATTACK_SPEED = UUID.fromString("f1a4e6b2-0c8c-4e9c-9c2b-1f2e9f8c1105");
    private static final UUID GROWTH_FOLLOW_RANGE = UUID.fromString("f1a4e6b2-0c8c-4e9c-9c2b-1f2e9f8c1106");
    private static final UUID GROWTH_ARMOR_TOUGHNESS = UUID.fromString("f1a4e6b2-0c8c-4e9c-9c2b-1f2e9f8c1107");
    private static final UUID GROWTH_FLYING_SPEED = UUID.fromString("f1a4e6b2-0c8c-4e9c-9c2b-1f2e9f8c1108");
    private static final UUID GROWTH_ATTACK_KNOCKBACK = UUID.fromString("f1a4e6b2-0c8c-4e9c-9c2b-1f2e9f8c1109");
    private static final UUID GROWTH_KNOCKBACK_RESISTANCE = UUID.fromString("f1a4e6b2-0c8c-4e9c-9c2b-1f2e9f8c1110");
    private static final UUID INFECTION_SPEED = UUID.fromString("f1a4e6b2-0c8c-4e9c-9c2b-1f2e9f8c1111");
    private static final UUID INFECTION_FLYING_SPEED = UUID.fromString("f1a4e6b2-0c8c-4e9c-9c2b-1f2e9f8c1115");
    private static final UUID INFECTION_ATTACK_SPEED = UUID.fromString("f1a4e6b2-0c8c-4e9c-9c2b-1f2e9f8c1112");
    private static final UUID NEGATIVE_EFFECT_SPEED = UUID.fromString("f1a4e6b2-0c8c-4e9c-9c2b-1f2e9f8c1113");
    private static final UUID NEGATIVE_EFFECT_ATTACK_SPEED = UUID.fromString("f1a4e6b2-0c8c-4e9c-9c2b-1f2e9f8c1114");
    private static final String RECORDED_INFECTION_LAYERS = "TheresiaRecordedInfectionLayers";
    private static final String NEGATIVE_EFFECT_HISTORY = "TheresiaNegativeEffectHistory";
    private static final String RECORDED_NEGATIVE_LAYERS = "TheresiaRecordedNegativeLayers";
    private int killCount;

    public Theresia(EntityType<? extends Theresia> type, Level level) {
        super(type, level);
        setTame(false);
        setFollowingOwner(true);
    }

    /**
     * 模组天灾生物的基准移速。设计上的“初始移速 1.0”按该基准的 1.0 倍解释：
     * 原版 MOVEMENT_SPEED 的单位是每 tick 的移动系数（玩家 0.1、铁傀儡 0.25），
     * 直接把 1.0 写进属性会让特蕾西娅达到玩家十倍速度，生成后表现为贴地飞射、
     * 寻路反复过冲，也就是“生成时移动速度异常”。
     */
    public static final double BASE_MOVEMENT_SPEED = 0.28D;
    /** 初始移速倍率：1.0 即基准移速。 */
    public static final double INITIAL_MOVEMENT_SPEED_SCALE = 1.0D;
    /** 击杀成长对移速、飞行速度的加成上限，避免长时间屠杀后速度失控。 */
    private static final double MAX_SPEED_GROWTH = 1.0D;
    /** 感染与其他负面效果能提供的额外移速上限（各自最多 +50%）。 */
    private static final double MAX_EFFECT_SPEED_BONUS = 0.5D;

    /** 基础数值：生命 200、攻击 30、初始移速 1.0（基准倍率）、玩家默认攻速 4.0、索敌 64、抗击退 2.0。 */
    public static AttributeSupplier.Builder createAttributes() {
        return CalamityMob.createAttributes(200.0D, 0.0D, 64.0D)
                .add(Attributes.MOVEMENT_SPEED, BASE_MOVEMENT_SPEED * INITIAL_MOVEMENT_SPEED_SCALE)
                .add(Attributes.ATTACK_DAMAGE, 30.0D)
                .add(Attributes.ATTACK_SPEED, 4.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 2.0D);
    }

    public int getKillCount() {
        return killCount;
    }

    /** 每击杀一只生物，所有主要基础属性提高 10%。 */
    public void recordKill() {
        if (level().isClientSide) return;
        killCount++;
        updateGrowthModifiers(true);
    }

    @Override
    protected double followRange() {
        return 64.0D;
    }

    @Override
    protected boolean canTeleportAcrossDimensions() {
        return true;
    }

    @Override
    protected boolean shouldFollowOwner() {
        return true;
    }

    @Override
    protected void registerGoals() {
        // 攻击任务优先于跟随任务，只有没有攻击目标时才会跟随主人。
        goalSelector.addGoal(3, new AdaptiveCombatGoal(this, 1.18D));
        goalSelector.addGoal(4, new CalamityFollowOwnerGoal(this, 1.15D, 10.0F, 2.0F, true));
        goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.85D));
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 12.0F));
        goalSelector.addGoal(9, new RandomLookAroundGoal(this));
        // 已取消固定索敌顺序：与其他阵营生物一致，按就近原则在可攻击目标中选取。
        targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 10,
                true, false, this::canAttack));
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        if (target == null || !target.isAlive() || target == this || isOrderedToSit()) return false;
        if (getOwnerUUID() != null && target.getUUID().equals(getOwnerUUID())) return false;
        return CalamityLogic.canFactionCombatantAttack(this, target);
    }

    @Override
    public boolean isAlliedTo(Entity other) {
        return other instanceof LivingEntity living && CalamityLogic.isFactionAlly(this, living)
                || super.isAlliedTo(other);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        if (!(target instanceof LivingEntity living) || !canAttack(living)) return false;
        if (getMainHandItem().is(GeneratedMod.YINGSIAO.get())) {
            YingsiaoSwordItem.applyAttack(this, living, false, 0);
            return true;
        }
        return super.doHurtTarget(target);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND || !player.getMainHandItem().isEmpty()) {
            return super.mobInteract(player, hand);
        }
        if (!CalamityLogic.isCivilizationContinuancePlayer(player)) return InteractionResult.PASS;
        if (level().isClientSide) return InteractionResult.sidedSuccess(true);
        if (isOwnedBy(player)) {
            if (player.isShiftKeyDown()) {
                setOrderedToSit(!isOrderedToSit());
                setFollowingOwner(!isOrderedToSit());
            } else {
                setOrderedToSit(false);
                setFollowingOwner(!isFollowingOwner());
            }
            return InteractionResult.CONSUME;
        }
        if (getOwnerUUID() == null) {
            tame(player);
            setTame(true);
            setFollowingOwner(true);
            return InteractionResult.CONSUME;
        }
        return InteractionResult.PASS;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        updateGrowthModifiers(false);
        updateNegativeEffectModifiers();
        if (getTarget() != null && !canAttack(getTarget())) setTarget(null);
    }

    private void updateGrowthModifiers(boolean preserveHealth) {
        double oldMax = getMaxHealth();
        float oldHealth = getHealth();
        // 「源石计划进度」需求 1：击杀成长（每杀 +10% 的累积曲线）中，超出原数值的
        // 提升幅度按档位缩放；1.0 基准本身不动。
        double growth = OriginiumPlanProgress.amplify(
                Math.max(0.0D, Math.pow(1.10D, killCount) - 1.0D), this);
        // 移速与飞行速度的成长单独封顶，其余属性保持每杀 10% 的原始曲线。
        double speedGrowth = Math.min(growth, MAX_SPEED_GROWTH);
        setGrowthModifier(Attributes.MAX_HEALTH, GROWTH_HEALTH, growth, "特蕾西娅击杀成长生命");
        setGrowthModifier(Attributes.ATTACK_DAMAGE, GROWTH_ATTACK, growth, "特蕾西娅击杀成长攻击");
        setGrowthModifier(Attributes.ARMOR, GROWTH_ARMOR, growth, "特蕾西娅击杀成长护甲");
        setGrowthModifier(Attributes.MOVEMENT_SPEED, GROWTH_SPEED, speedGrowth, "特蕾西娅击杀成长移速");
        setGrowthModifier(Attributes.ATTACK_SPEED, GROWTH_ATTACK_SPEED, growth, "特蕾西娅击杀成长攻速");
        setGrowthModifier(Attributes.FOLLOW_RANGE, GROWTH_FOLLOW_RANGE, growth, "特蕾西娅击杀成长索敌");
        setGrowthModifier(Attributes.ARMOR_TOUGHNESS, GROWTH_ARMOR_TOUGHNESS, growth, "特蕾西娅击杀成长护甲韧性");
        setGrowthModifier(Attributes.FLYING_SPEED, GROWTH_FLYING_SPEED, speedGrowth, "特蕾西娅击杀成长飞行");
        setGrowthModifier(Attributes.ATTACK_KNOCKBACK, GROWTH_ATTACK_KNOCKBACK, growth, "特蕾西娅击杀成长击退");
        setGrowthModifier(Attributes.KNOCKBACK_RESISTANCE, GROWTH_KNOCKBACK_RESISTANCE, growth, "特蕾西娅击杀成长抗击退");
        if (preserveHealth && oldMax > 0.0D) {
            setHealth((float) Math.min(getMaxHealth(), oldHealth / oldMax * getMaxHealth()));
        }
    }

    private void setGrowthModifier(net.minecraft.world.entity.ai.attributes.Attribute attribute, UUID id,
                                   double amount, String name) {
        var instance = getAttribute(attribute);
        if (instance == null) return;
        instance.removeModifier(id);
        if (amount > 0.0D) {
            instance.addPermanentModifier(new AttributeModifier(id, name, amount,
                    AttributeModifier.Operation.MULTIPLY_BASE));
        }
    }

    /**
     * 源石感染记录曾经达到的最高层数，其他负面效果记录同时存在时达到过的总层数。
     * 当对应效果彻底清除时，回收该类效果已经获得的额外攻速和移速加成。
     */
    private void updateNegativeEffectModifiers() {
        int currentInfectionLayers = CalamityLogic.sourceOreInfectionLayers(this);
        boolean infectionPendingDowngrade = CalamityLogic.hasPendingSourceOreInfectionDowngrade(this);
        int recordedInfectionLayers = Math.max(0,
                getPersistentData().getInt(RECORDED_INFECTION_LAYERS));
        if (currentInfectionLayers > 0 || infectionPendingDowngrade) {
            recordedInfectionLayers = Math.max(recordedInfectionLayers, currentInfectionLayers);
        } else {
            recordedInfectionLayers = 0;
        }

        CompoundTag history = getPersistentData().getCompound(NEGATIVE_EFFECT_HISTORY);
        Set<String> activeEffectKeys = new HashSet<>();
        long recordedNegativeLayersTotal = 0L;
        for (MobEffectInstance effect : getActiveEffects()) {
            if (effect.getEffect().getCategory() != MobEffectCategory.HARMFUL
                    || effect.getEffect() == GeneratedMod.SOURCE_ORE_INFECTION.get()) continue;
            String key = BuiltInRegistries.MOB_EFFECT.getKey(effect.getEffect()).toString();
            activeEffectKeys.add(key);
            int currentLayers = Math.max(1, effect.getAmplifier() + 1);
            int recordedLayers = Math.max(history.getInt(key), currentLayers);
            history.putInt(key, recordedLayers);
            recordedNegativeLayersTotal += recordedLayers;
        }
        // 未清除的效果保留历史值；已清除的效果删除记录并回收对应加成。
        for (String key : new HashSet<>(history.getAllKeys())) {
            if (!activeEffectKeys.contains(key)) history.remove(key);
        }
        int recordedNegativeLayers = (int) Math.min(Integer.MAX_VALUE, recordedNegativeLayersTotal);
        getPersistentData().put(NEGATIVE_EFFECT_HISTORY, history);
        getPersistentData().putInt(RECORDED_INFECTION_LAYERS, recordedInfectionLayers);
        getPersistentData().putInt(RECORDED_NEGATIVE_LAYERS, recordedNegativeLayers);

        var speed = getAttribute(Attributes.MOVEMENT_SPEED);
        var attackSpeed = getAttribute(Attributes.ATTACK_SPEED);
        var flyingSpeed = getAttribute(Attributes.FLYING_SPEED);
        // 感染减速只在效果存在时抵消；效果彻底清除后，感染历史加成和抵消项一并回收。
        // 层数加成单独封顶：255 层原样换算会给出 +510% 移速，属于“生成后速度异常”的另一来源。
        double infectionReduction = CalamityLogic.sourceOreInfectionReduction(currentInfectionLayers);
        double infectionSpeedBonus = Math.min(MAX_EFFECT_SPEED_BONUS, recordedInfectionLayers * 0.02D);
        double negativeSpeedBonus = Math.min(MAX_EFFECT_SPEED_BONUS, recordedNegativeLayers * 0.05D);
        setPermanentModifier(speed, INFECTION_SPEED, "特蕾西娅源石感染移速",
                infectionReduction + infectionSpeedBonus);
        setPermanentModifier(attackSpeed, INFECTION_ATTACK_SPEED, "特蕾西娅源石感染攻速",
                recordedInfectionLayers * 0.02D);
        setPermanentModifier(speed, NEGATIVE_EFFECT_SPEED, "特蕾西娅其他负面效果移速", negativeSpeedBonus);
        setPermanentModifier(attackSpeed, NEGATIVE_EFFECT_ATTACK_SPEED, "特蕾西娅其他负面效果攻速", recordedNegativeLayers * 0.05D);
        // 感染每级提高移速时同步提高飞行速度（仅当已学习飞行逻辑）；飞行速度没有感染自带的减速，
        // 因此只镜像“每层 +2%”的净加速，不叠加用于抵消减速的那部分。
        double infectionFlightBonus = LearnedTraitLogic.has(this, LearnedTraitLogic.FLIGHT) ? infectionSpeedBonus : 0.0D;
        setPermanentModifier(flyingSpeed, INFECTION_FLYING_SPEED, "特蕾西娅源石感染飞行", infectionFlightBonus);
    }

    private void setPermanentModifier(net.minecraft.world.entity.ai.attributes.AttributeInstance instance,
                                      UUID id, String name, double amount) {
        if (instance == null) return;
        instance.removeModifier(id);
        if (amount > 0.0D) {
            instance.addPermanentModifier(new AttributeModifier(id, name, amount,
                    AttributeModifier.Operation.MULTIPLY_TOTAL));
        }
    }

    @Override
    protected void serverAbilityTick(ServerLevel level) {
        // 特蕾西娅不拥有其他天灾首领的复活或周期陨石能力。
    }

    @Override
    protected void onCalamityDeath(ServerLevel level, LivingEntity killer, CompoundTag snapshot) {
        // 无复活机制，也不生成死亡陨石。
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt(KILL_COUNT, killCount);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        killCount = Math.max(0, tag.getInt(KILL_COUNT));
        // 旧存档把 MOVEMENT_SPEED 的基础值按 1.0（属性原始单位）写进了 NBT，
        // 重新加载时会覆盖新的默认基准，导致特蕾西娅一加载就超速。这里强制回到基准值。
        var speed = getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.setBaseValue(BASE_MOVEMENT_SPEED * INITIAL_MOVEMENT_SPEED_SCALE);
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        // 特蕾西娅明确不免疫陨石/爆炸伤害和源石感染伤害。
        return super.hurt(source, amount);
    }

    public static boolean canUseYingsiao(LivingEntity entity) {
        return entity instanceof Theresia && entity.getMainHandItem().is(GeneratedMod.YINGSIAO.get());
    }

    /** 精锐集结召唤标记：此类特蕾西娅由「预言家」博士召唤，武器由标记决定而非固定影霄。 */
    public static final String ELITE_SUMMONED = "OriginFallTheresiaEliteSummoned";
    /** 精锐集结特蕾西娅绑定的主手武器注册 ID；为空表示不绑定（可持有任何武器）。 */
    public static final String ELITE_WEAPON_ID = "OriginFallTheresiaEliteWeaponId";

    /** 特蕾西娅的主手默认绑定影霄；精锐集结召唤的个体按标记绑定对应武器，无法以任何形式被替换。 */
    @Override
    protected Item getBoundWeapon() {
        if (getPersistentData().getBoolean(ELITE_SUMMONED)) {
            String weaponId = getPersistentData().getString(ELITE_WEAPON_ID);
            if (weaponId.isEmpty()) return null;
            net.minecraft.resources.ResourceLocation key =
                    net.minecraft.resources.ResourceLocation.tryParse(weaponId);
            if (key != null) {
                Item item = net.minecraftforge.registries.ForgeRegistries.ITEMS.getValue(key);
                if (item != null) return item;
            }
            return null;
        }
        return GeneratedMod.YINGSIAO.get();
    }
}
