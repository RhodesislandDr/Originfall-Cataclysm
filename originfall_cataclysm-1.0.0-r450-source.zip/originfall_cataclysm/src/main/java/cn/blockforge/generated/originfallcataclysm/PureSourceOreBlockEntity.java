package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/** 至纯源石持续对半径 8 格内的生物施加感染，并对已感染目标每 5 秒增加一层。 */
public final class PureSourceOreBlockEntity extends BlockEntity {
    private static final double EFFECT_RADIUS = 8.0D;

    public PureSourceOreBlockEntity(BlockPos pos, BlockState state) {
        super(GeneratedMod.PURE_SOURCE_ORE_BLOCK_ENTITY.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state,
                                   PureSourceOreBlockEntity blockEntity) {
        if (!(level instanceof ServerLevel server) || server.getGameTime() % 10L != 0L) return;
        AABB area = new AABB(pos).inflate(EFFECT_RADIUS);
        for (LivingEntity living : server.getEntitiesOfClass(LivingEntity.class, area,
                entity -> entity.isAlive() && entity.distanceToSqr(pos.getCenter()) <= EFFECT_RADIUS * EFFECT_RADIUS)) {
            CalamityLogic.applySourceOreInfection(living, 1, 0);
            CalamityLogic.markInfectionExposure(living);
        }
    }
}
