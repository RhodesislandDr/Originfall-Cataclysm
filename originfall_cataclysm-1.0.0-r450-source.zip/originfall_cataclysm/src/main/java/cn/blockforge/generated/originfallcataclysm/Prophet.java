package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

/**
 * 「预言家」博士：使用玩家人形模型的文明存续阵营首领。
 * 生成时必定手持如我所见，身穿随机附魔护甲；拥有全图外显的 boss 式血条，
 * 并可与「女祭司」普瑞赛斯互为最高优先级索敌。
 */
public final class Prophet extends CalamityMob {
    /** 基准移速，与模组其它人形天灾生物一致（详见 Theresia.BASE_MOVEMENT_SPEED）。 */
    public static final double BASE_MOVEMENT_SPEED = 0.28D;

    /** 首领级索敌半径：博士与普瑞赛斯互为最高优先级目标，索敌范围提升至 128 格。 */
    public static final double FOLLOW_RANGE = 128.0D;

    /** 「女祭司」普瑞赛斯的注册 ID；普瑞赛斯未注册时该目标恒为空，注册后自动互为最高优先级索敌。 */
    private static final ResourceLocation PRIESTESS_TYPE_ID =
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "priestess");

    private final ServerBossEvent bossEvent;

    public Prophet(EntityType<? extends Prophet> type, Level level) {
        super(type, level);
        setTame(false);
        setFollowingOwner(false);
        bossEvent = new ServerBossEvent(
                Component.translatable("entity.originfall_cataclysm.prophet"),
                BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);
        bossEvent.setDarkenScreen(false);
        bossEvent.setPlayBossMusic(false);
        bossEvent.setCreateWorldFog(false);
        bossEvent.setVisible(true);
    }

    /** 基础数值：生命 1000、护甲 5、攻击 10、移速基准、攻速 4、抗击退 0.6、索敌 128。 */
    public static AttributeSupplier.Builder createAttributes() {
        return CalamityMob.createAttributes(1000.0D, 5.0D, FOLLOW_RANGE)
                .add(Attributes.MOVEMENT_SPEED, BASE_MOVEMENT_SPEED)
                .add(Attributes.ATTACK_DAMAGE, 10.0D)
                .add(Attributes.ATTACK_SPEED, 4.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D);
    }

    @Override
    protected double followRange() {
        return FOLLOW_RANGE;
    }

    @Override
    protected boolean canTeleportAcrossDimensions() {
        return true;
    }

    @Override
    protected boolean shouldFollowOwner() {
        return false;
    }

    @Override
    protected void registerGoals() {
        // 攻击任务优先：只有没有攻击目标时才游荡、打量玩家。
        goalSelector.addGoal(3, new AdaptiveCombatGoal(this, 1.18D));
        goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.85D));
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 12.0F));
        goalSelector.addGoal(9, new RandomLookAroundGoal(this));
        // 「女祭司」普瑞赛斯为绝对最高优先级（0）索敌：外来模组敌对生物在场也不让位；
        // 其余目标按就近原则在可攻击目标中选取。
        targetSelector.addGoal(0, new NearestAttackableTargetGoal<>(this, LivingEntity.class,
                10, true, false, this::isPriestessTarget));
        targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, LivingEntity.class,
                10, true, false, this::canAttack));
    }

    private boolean isPriestessTarget(LivingEntity target) {
        if (target == null || !target.isAlive() || target == this) return false;
        // 与普瑞赛斯的互索为绝对最高优先级：外来威胁在场时不再让位（原版选择器会经
        // canAttack 复核，两 boss 互索的放行已挂在 CalamityLogic#isSupremeMutualTargetingPair）。
        ResourceLocation key = ForgeRegistries.ENTITY_TYPES.getKey(target.getType());
        return key != null && key.equals(PRIESTESS_TYPE_ID);
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        if (target == null || !target.isAlive() || target == this || isOrderedToSit()) return false;
        return CalamityLogic.canFactionCombatantAttack(this, target);
    }

    @Override
    public boolean isAlliedTo(Entity other) {
        return other instanceof LivingEntity living && CalamityLogic.isFactionAlly(this, living)
                || super.isAlliedTo(other);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        if (!(target instanceof LivingEntity living) || !canAttack(living)) return false;
        // 如我所见的全部权能（两段伤害、源石权柄、锚定现实、阳火、时光之末、昔时我见、无下限内化宇宙）
        // 由 RuwosuojianEvents 依据“是否持剑”自动结算，这里走普通近战即可。
        // 「我将无我」黑闪的伤害结算与属性增强统一挂在 ProphetSkillEvents.onLivingDamage 上，
        // 以便同时覆盖近战与剑气（SwordQiEntity）两种攻击路径。
        return super.doHurtTarget(target);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        // 首领不可被认主/驯服，也不响应交互。
        return InteractionResult.PASS;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        updateBossBar();
    }

    private void updateBossBar() {
        if (!isAlive()) {
            bossEvent.removeAllPlayers();
            return;
        }
        bossEvent.setProgress((float) (getHealth() / Math.max(1.0D, getMaxHealth())));
        if (!(level() instanceof ServerLevel server)) return;
        MinecraftServer mcServer = server.getServer();
        if (mcServer == null) return;
        List<ServerPlayer> online = mcServer.getPlayerList().getPlayers();
        // 全图外显：将血条广播给服务器上每一位在线玩家。
        for (ServerPlayer player : online) {
            bossEvent.addPlayer(player);
        }
        // 清理已经离线/不在线的玩家，避免残留引用。
        for (ServerPlayer player : new ArrayList<>(bossEvent.getPlayers())) {
            if (!online.contains(player)) {
                bossEvent.removePlayer(player);
            }
        }
    }

    /**
     * 「巴别塔回忆」复活重建后立即广播一次 boss 血条。
     * 重建出来的实体拿着全新的 {@link ServerBossEvent}（旧的随死亡从所有玩家处移除），
     * 必须在入世界的当刻立刻补一次外显，避免复活后短时间内看不到血条。
     */
    public void refreshBossBar() {
        updateBossBar();
    }

    @Override
    public void die(DamageSource source) {
        // 「巴别塔回忆」：死亡时登记死亡快照与死亡地点，20 tick 后由 ProphetSkillLogic 统一结算
        // 献祭与复活。这里刻意不校验「彻底死亡」标记，因为该技能按需求无视它。
        if (!level().isClientSide && level() instanceof ServerLevel server) {
            // 与 CalamityMob.die 的死亡快照口径保持一致：学习特性不随复活带回。
            LearnedTraitLogic.clearOnDeath(this);
            ProphetSkillLogic.onProphetDeath(this, server);
        }
        bossEvent.removeAllPlayers();
        super.die(source);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        bossEvent.removeAllPlayers();
        super.remove(reason);
    }

    @Override
    protected void serverAbilityTick(ServerLevel level) {
        // 博士没有周期性复活或陨石能力。
    }

    @Override
    protected void onCalamityDeath(ServerLevel level, LivingEntity killer, CompoundTag snapshot) {
        // 无复活机制，也不生成死亡陨石。
    }

    public static boolean canUseRuwosuojian(LivingEntity entity) {
        return entity instanceof Prophet
                && (entity.getMainHandItem().is(GeneratedMod.RUWOSUOJIAN.get())
                || entity.getOffhandItem().is(GeneratedMod.RUWOSUOJIAN.get()));
    }

    /** 「预言家」博士的主手绑定如我所见，无法以任何形式被替换。 */
    @Override
    protected Item getBoundWeapon() {
        return GeneratedMod.RUWOSUOJIAN.get();
    }
}
