package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * 阳火：创造栏展示物。对着生物右键即为其附加「阳火」状态（叠满 32 层）。
 * 「阳火」的每秒最大生命值削减、叠层与衰减逻辑仍由 {@link RuwosuojianLogic} 统一处理。
 */
public final class YangFireItem extends Item {
    public YangFireItem() {
        super(new Item.Properties().stacksTo(1).fireResistant());
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player,
                                                  LivingEntity entity, InteractionHand hand) {
        if (!player.level().isClientSide) {
            RuwosuojianLogic.applyYangFire(entity);
        }
        return InteractionResult.SUCCESS;
    }
}
