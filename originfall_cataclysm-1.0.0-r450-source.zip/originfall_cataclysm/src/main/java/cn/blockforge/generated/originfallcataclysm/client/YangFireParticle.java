package cn.blockforge.generated.originfallcataclysm.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/**
 * 阳火火苗粒子：上升的白金色小火苗，图集动画帧由粒子贴图自身的 mcmeta 驱动。
 * 只作为“阳火”状态的动态点缀，无法通过任何物品形式获得。
 */
public class YangFireParticle extends TextureSheetParticle {

    private final SpriteSet sprites;

    protected YangFireParticle(ClientLevel level, SpriteSet sprites,
                               double x, double y, double z, double vx, double vy, double vz) {
        super(level, x, y, z, vx, vy, vz);
        this.sprites = sprites;
        this.quadSize *= this.random.nextFloat() * 0.5F + 0.9F;
        this.xd *= 0.2D;
        this.yd *= 0.2D;
        this.zd *= 0.2D;
        this.gravity = -0.08F;
        this.lifetime = (int) (16.0D / (Math.random() * 0.6D + 0.4D));
        this.hasPhysics = false;
        this.setSpriteFromAge(sprites);
    }

    @Override
    public void tick() {
        super.tick();
        this.setSpriteFromAge(this.sprites);
    }

    @Override
    public float getQuadSize(float scaleFactor) {
        float f = (float) this.age / (float) this.lifetime;
        return this.quadSize * (1.0F - f * f * 0.75F);
    }

    @Override
    protected int getLightColor(float partialTick) {
        // 阳火自带光辉：不受环境光影响，恒定满亮度。
        return 15728880;
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static ParticleProvider<SimpleParticleType> factory(SpriteSet sprites) {
        return (type, level, x, y, z, vx, vy, vz) -> new YangFireParticle(level, sprites, x, y, z, vx, vy, vz);
    }
}
