package cn.blockforge.generated.originfallcataclysm;

import cn.blockforge.generated.originfallcataclysm.client.BlinkState;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;

import javax.annotation.Nullable;

/**
 * 「眨眼」的眼睑部件（纯客户端、纯外貌）：三套生物模型（{@link CalamityHumanoidModel}
 * 人形首领、{@link CalamityMessengerModel} 信使、{@link SourceOreGolemModel} 源石傀儡）
 * 的头部网格各挂一对薄板眼睑——只加在身体层（装甲层网格没有这两块，取到 null 直接跳过）。
 *
 * <p>睁眼时两块都 {@code skipDraw}，与没有它们时逐像素一致；闭眼时按 {@link BlinkState}
 * 的闭合量沿眉线向下 {@code yScale} 生长，盖住脸区的眼睛行（贴图 v=11~13）。眼睑的采样
 * UV 取同张贴图眼睛上方「额头到眼睑」的三行（v≈9.9~12）：上半是皮肤色、下缘恰好落在
 * 眼行像素的深色上，所以闭眼自然呈现一条深色睫毛缝，不需要任何额外的贴图资产。</p>
 *
 * <p>定身实体（恒为 NoAi，例如流放虚空中的生物）与已倒下的生物不眨眼；深蓝之树本尊的
 * 替身外观代画用的就是 {@link CalamityHumanoidModel}，因此本尊平时与舞蹈期间都同样
 * 带眨（外观统一为替身，见 {@code NativeApocataAppearanceEvents}）。</p>
 *
 * <p>安装了史诗战斗时，人形生物改由它的 BIPED 骨架网格渲染、不再走 {@code setupAnim}——
 * 这条通道上没有部件可摆，眨眼由兼容层在同一坐标系里按头部关节矩阵补画同一对薄板
 * （{@code OriginfallEpicFightClientCompat} 的补丁渲染器），两种环境的节律与观感同源。</p>
 */
final class BlinkLids {

    /** 眼睑薄板与脸皮的层距：外凸 0.06 防共面闪烁，又不至于看出浮层。 */
    private static final float PROTRUDE = 0.12F;

    private BlinkLids() {
    }

    /** 在头部 {@link PartDefinition} 上追加左右眼睑（轴心在部件原点，网格框从原点向下）。 */
    static void addEyelids(PartDefinition head, CubeDeformation deformation) {
        // 正脸采样区 = texOffs + depth（1.20.1 的 texOffs 只收整数）：(9,11)+0.12 →
        // 实际采到 u9.12~11.12、v11.12~13.18——即「眉上一行皮肤 + 眼睛暗行」两行，
        // 闭眼时上半是肤色、下缘一条深色睫毛缝。实测全模组贴图眼睛暗行都在 v=12
        // （下缘 13）、眼列 u9~10 与 u13~14，采样带正好盖住；左眼同构右移 4 列。
        head.addOrReplaceChild("blink_lid_right", CubeListBuilder.create().texOffs(9, 11)
                        .addBox(-3.0F, -0.02F, -4.0F - PROTRUDE, 2.0F, 2.06F, PROTRUDE, deformation),
                PartPose.offset(0.0F, -5.0F, 0.0F));
        head.addOrReplaceChild("blink_lid_left", CubeListBuilder.create().texOffs(13, 11)
                        .addBox(1.0F, -0.02F, -4.0F - PROTRUDE, 2.0F, 2.06F, PROTRUDE, deformation),
                PartPose.offset(0.0F, -5.0F, 0.0F));
    }

    /** 从已烘焙的根部件找眼睑（装甲层网格没有这两块时返回 null）。 */
    @Nullable
    static ModelPart find(ModelPart head, String name) {
        return head == null ? null : head.getChild(name);
    }

    /** 每帧在 {@code setupAnim} 末尾调用：按实体 id 的独立节律摆好两块眼睑。 */
    static void apply(@Nullable ModelPart rightLid, @Nullable ModelPart leftLid,
                      LivingEntity entity, float ageInTicks) {
        if (rightLid == null || leftLid == null) return;
        // 睁眼 = 完全 skipDraw：走位、攻击、待机一切与加块之前逐像素一致。
        // 定身实体（恒为 NoAi，例如流放虚空中的生物，1.20.1 该标志在 Mob 上）与已倒下的不眨眼。
        if (!(entity instanceof Mob mob) || !mob.isAlive() || mob.isNoAi()) {
            rightLid.skipDraw = true;
            leftLid.skipDraw = true;
            return;
        }
        float lid = BlinkState.lid(ageInTicks, entity.getId());
        if (lid < 0.02F) {
            rightLid.skipDraw = true;
            leftLid.skipDraw = true;
            return;
        }
        rightLid.skipDraw = false;
        leftLid.skipDraw = false;
        // 轴心在眉线（部件原点），yScale 即闭合量：板从眉线向眼下生长。
        rightLid.yScale = lid;
        leftLid.yScale = lid;
    }
}
