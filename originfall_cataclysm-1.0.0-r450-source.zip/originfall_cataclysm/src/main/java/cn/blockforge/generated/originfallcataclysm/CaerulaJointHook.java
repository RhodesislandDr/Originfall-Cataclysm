package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 「方块与深蓝之树」×「源石计划」共同索敌联动钩子。
 *
 * <p>整套机制以事件钩子实现，不引用深蓝之树的任何编译期类：未安装对方模组时所有
 * 判定退化为恒假/恒空，本模组照常独立运行。</p>
 *
 * <p>规则全貌（与需求逐条对应）：</p>
 * <ul>
 *   <li><b>互不侵犯</b>：双方模组生物彼此不攻击、不索敌——索敌切换与伤害结算两个
 *       入口都拦（见 {@link #onChangeTarget} / {@link #onHurt}），张冠李戴的报复性
 *       锁定也一并抹掉；</li>
 *   <li><b>32 格索敌呼叫</b>：任一方生物对公共敌人（非玩家、非双方模组生物）索敌
 *       成功时，呼叫半径 32 格内双方所有具有攻击逻辑的生物共同索敌。源石方的
 *       非敌对生物在巴别塔行动未开启时不响应呼叫；源石方发起的呼叫不受深蓝之树
 *       全面反击/全面进攻模式影响（直接改写对方目标的呼叫链路对模式免疫）；</li>
 *   <li><b>16 格威胁呼叫</b>：任一方生物被公共敌人打伤时，呼叫半径 16 格内双方
 *       生物共同索敌报复者；深蓝之树开启全面反击模式时本呼叫整体不生效；</li>
 *   <li><b>不触发呼叫的内斗</b>：模组内阵营对抗（源石×文明）与同模组生物互殴
 *       既不发起也不转派呼叫——呼叫只针对公共敌人；</li>
 *   <li><b>内斗降级</b>：呼叫生效期间（活动威胁登记存在且公共敌人在射程内），
 *       模组内两阵营的互相索敌让位于围剿公共敌人；</li>
 *   <li><b>不针对玩家</b>：呼叫的敌人永不为玩家，玩家被索敌也不触发任何呼叫。</li>
 * </ul>
 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID)
public final class CaerulaJointHook {

    /** 索敌成功后的呼叫半径（格）。 */
    public static final double CALL_RADIUS = 32.0D;
    /** 被威胁（受击）后的呼叫半径（格）。 */
    public static final double THREAT_RADIUS = 16.0D;
    /** 活动威胁登记的存活时长（tick）：到期后模组内互斗优先级恢复常态。 */
    private static final long THREAT_TTL = 400L;
    /** 同一生物的索敌呼叫节流（tick），防止目标评估高频重发。 */
    private static final long CALL_COOLDOWN = 100L;
    /** 同一生物的威胁呼叫节流（tick），受击事件可能高频触发。 */
    private static final long THREAT_COOLDOWN = 40L;

    /** 呼叫重入闸：broadcast 期间改写他人目标会再发 LivingChangeTargetEvent，必须静默。 */
    private static boolean broadcasting;
    private static final Map<UUID, Long> LAST_CALL = new HashMap<>();
    private static final Map<UUID, Long> LAST_THREAT = new HashMap<>();
    /** 活动威胁登记：维度 → 公共敌人 UUID → 过期 tick。供阵营内斗降级判定读取。 */
    private static final Map<ServerLevel, Map<UUID, Long>> THREATS = new IdentityHashMap<>();

    private CaerulaJointHook() {
    }

    // ---------------- 归属判定 ----------------

    /** 是否源石计划（本模组）一方的生物：本模组命名空间，或已归入任一明确阵营的个体。 */
    public static boolean isOfcOwned(LivingEntity entity) {
        if (entity == null) return false;
        // 邪魔（坍缩）不算本模组一方：它在索敌与共同索敌里按「非本模组敌对生物」处理。
        if (CalamityLogic.isCollapsed(entity)) return false;
        ResourceLocation key = BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType());
        if (key != null && GeneratedMod.MOD_ID.equals(key.getNamespace())) return true;
        return CalamityLogic.getFaction(entity) != CalamityLogic.Faction.NEUTRAL;
    }

    /** 是否深蓝之树模组的生物；未安装对方时恒为假。感染的个体同样归入邪魔阵营。 */
    public static boolean isCaerulaOwned(LivingEntity entity) {
        if (entity != null && CalamityLogic.isCollapsed(entity)) return false;
        return CaerulaArborCompat.isCaerulaEntity(entity);
    }

    /**
     * 双方模组生物之间的跨模组伙伴对：这一对彼此永不攻击、永不索敌。
     * 只约束生物——阵营玩家与深蓝之树生物的交战属玩家行为，不在互不侵犯范围内，
     * 且该索敌机制整体不针对玩家。
     */
    public static boolean isCrossModAllyPair(LivingEntity first, LivingEntity second) {
        if (first instanceof Player || second instanceof Player) return false;
        // 邪魔与所有生物敌对：跨模组互不侵犯对感染个体一律失效。
        if (CalamityLogic.isCollapsed(first) || CalamityLogic.isCollapsed(second)) return false;
        return (isOfcOwned(first) && isCaerulaOwned(second)) || (isCaerulaOwned(first) && isOfcOwned(second));
    }

    /** 可参与共同索敌的联动成员：双方模组内具有攻击逻辑的存活生物。 */
    public static boolean isJointMember(LivingEntity entity) {
        return entity instanceof Mob && entity.isAlive()
                && (isOfcOwned(entity) || isCaerulaOwned(entity));
    }

    /** 公共敌人：不在任一成员方、且不是玩家（该机制不针对玩家索敌）。 */
    public static boolean isCommonEnemy(LivingEntity entity) {
        return entity != null && entity.isAlive() && !(entity instanceof Player)
                && !isOfcOwned(entity) && !isCaerulaOwned(entity);
    }

    /** 是否具攻击性口径：敌对接口、MONSTER 分类或明确的阵营战斗成员；其余按非敌对生物处理。 */
    private static boolean isAggressiveCreature(LivingEntity entity) {
        return entity instanceof Enemy
                || entity.getType().getCategory() == MobCategory.MONSTER
                || CalamityLogic.isSourceOreFactionMember(entity)
                || CalamityLogic.isContinuanceFactionMember(entity);
    }

    // ---------------- 事件入口 ----------------

    /**
     * 索敌切换：先执行跨模组互不侵犯（抹掉任何一方对伙伴方生物的锁定），
     * 再对"成员 → 公共敌人"的成功索敌发起 32 格呼叫（带节流与内斗排除）。
     */
    @SubscribeEvent
    public static void onChangeTarget(LivingChangeTargetEvent event) {
        if (!(event.getEntity() instanceof Mob mob) || mob.level().isClientSide) return;
        LivingEntity target = event.getNewTarget();
        if (target == null) return;
        if (isCrossModAllyPair(mob, target)) {
            event.setNewTarget(null);
            return;
        }
        if (broadcasting || !(mob.level() instanceof ServerLevel level)) return;
        if (!isJointMember(mob) || !isCommonEnemy(target)) return;
        long now = level.getGameTime();
        if (throttled(LAST_CALL, mob, now, CALL_COOLDOWN)) return;
        broadcast(level, mob, target, CALL_RADIUS, now);
    }

    /**
     * 受击：先执行跨模组互不侵犯（伙伴方伤害直接取消），再对"成员被公共敌人打伤"
     * 发起 16 格威胁呼叫。阵营内斗与同模组互殴不呼叫；深蓝之树全面反击模式下
     * 威胁呼叫整体不生效。
     */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide || !(victim.level() instanceof ServerLevel level)) return;
        Entity rawAttacker = event.getSource().getEntity();
        if (!(rawAttacker instanceof LivingEntity attacker) || attacker == victim) return;
        if (isCrossModAllyPair(attacker, victim)) {
            event.setCanceled(true);
            return;
        }
        if (broadcasting || !isJointMember(victim)) return;
        // 呼叫只针对公共敌人：玩家（不针对玩家索敌）与任一成员方的内斗都不触发。
        if (!isCommonEnemy(attacker)) return;
        // 深蓝之树全面反击模式开启时，威胁呼叫不生效。
        if (CaerulaArborCompat.isFullRetaliation(level)) return;
        long now = level.getGameTime();
        if (throttled(LAST_THREAT, victim, now, THREAT_COOLDOWN)) return;
        broadcast(level, victim, attacker, THREAT_RADIUS, now);
    }

    // ---------------- 呼叫实现 ----------------

    /**
     * 发起一次共同索敌呼叫：登记活动威胁，然后把半径内所有响应成员的目标改到
     * 公共敌人上。可改派的对象：当前无目标/目标已死的成员，以及正在与"自己模组内
     * 生物"互殴的成员（模组内互斗优先级被压低，转随大部队围剿公共敌人）；
     * 已经在打别的公共敌人的成员保持原目标不动。
     * 源石方非敌对生物在巴别塔行动未开启时不响应；源石方（本呼叫链路）不受
     * 全面反击/全面进攻模式影响，成员一律照常转派。
     */
    private static void broadcast(ServerLevel level, LivingEntity member, LivingEntity enemy,
                                  double radius, long now) {
        registerThreat(level, enemy, now);
        List<LivingEntity> responders = level.getEntitiesOfClass(LivingEntity.class,
                member.getBoundingBox().inflate(radius, radius, radius),
                candidate -> candidate != member && candidate != enemy
                        && isJointMember(candidate));
        if (responders.isEmpty()) return;
        boolean babel = OriginFallGameRules.isBabelActionMode(level);
        broadcasting = true;
        try {
            for (LivingEntity responder : responders) {
                // 非敌对生物（源石方口径）：巴别塔行动未开启时不索敌、不响应呼叫。
                if (isOfcOwned(responder) && !isAggressiveCreature(responder) && !babel) continue;
                if (!(responder instanceof Mob mob)) continue;
                LivingEntity current = mob.getTarget();
                boolean switchable = current == null || !current.isAlive()
                        || isSameModPair(responder, current);
                if (switchable) mob.setTarget(enemy);
            }
        } finally {
            broadcasting = false;
        }
    }

    /** 同模组内斗对：双方都是源石方成员，或双方都是深蓝之树成员。 */
    private static boolean isSameModPair(LivingEntity first, LivingEntity second) {
        return (isOfcOwned(first) && isOfcOwned(second)) || (isCaerulaOwned(first) && isCaerulaOwned(second));
    }

    // ---------------- 活动威胁登记（模组内互斗降级的依据） ----------------

    private static void registerThreat(ServerLevel level, LivingEntity enemy, long now) {
        THREATS.computeIfAbsent(level, k -> new HashMap<>()).put(enemy.getUUID(), now + THREAT_TTL);
    }

    /**
     * 附近是否存在活动公共威胁：任一登记敌人仍存活、在场且在源实体索敌射程
     * （FOLLOW_RANGE 与呼叫半径取大）内。顺带清理过期条目。阵营内斗判定
     * （{@link CalamityLogic#canFactionCombatantAttack}）在呼叫生效期间据此降级。
     */
    public static boolean hasActiveThreatNear(LivingEntity source) {
        if (!(source.level() instanceof ServerLevel level)) return false;
        Map<UUID, Long> map = THREATS.get(level);
        if (map == null || map.isEmpty()) return false;
        long now = level.getGameTime();
        double range = Math.max(CALL_RADIUS, source.getAttributeValue(Attributes.FOLLOW_RANGE));
        double rangeSq = range * range;
        Iterator<Map.Entry<UUID, Long>> iterator = map.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Long> entry = iterator.next();
            if (entry.getValue() <= now) {
                iterator.remove();
                continue;
            }
            Entity threat = level.getEntity(entry.getKey());
            if (threat instanceof LivingEntity living && living.isAlive()
                    && source.distanceToSqr(threat) <= rangeSq) {
                return true;
            }
            iterator.remove(); // 威胁实体已离场：立即销账
        }
        return false;
    }

    /** 节流：同一实体在 interval tick 内只允许发起一次同类呼叫。 */
    private static boolean throttled(Map<UUID, Long> map, LivingEntity entity, long now, long interval) {
        if (map.size() > 1024) map.values().removeIf(last -> last + interval * 4L <= now);
        Long last = map.get(entity.getUUID());
        if (last != null && now - last < interval) return true;
        map.put(entity.getUUID(), now);
        return false;
    }

    /** 停机兜底：清空全部静态登记，避免跨存档残留。 */
    @SubscribeEvent
    public static void onServerStopped(net.minecraftforge.event.server.ServerStoppedEvent event) {
        LAST_CALL.clear();
        LAST_THREAT.clear();
        THREATS.clear();
    }
}
