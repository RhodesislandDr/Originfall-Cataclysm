package cn.blockforge.generated.originfallcataclysm.client;

import net.minecraft.client.Minecraft;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 深蓝之树本尊「扒臀长舞」的客户端视图：服务端开跳/补同步时用
 * {@link cn.blockforge.generated.originfallcataclysm.YangFireNetworking.NativeDanceSync}
 * 报文送「总舞程 + 剩余舞程」，这里换算成「本地 gameTime 截止点」，渲染替换与姿势通道
 * 每帧按实体 id 取用。
 *
 * <p>与替身的首领不同，本尊是外部实体，挂不上本模组的同步实体数据，客户端只能靠这条
 * 自建通道知道它「正在跳、跳到哪一段」。倒计时用客户端自己的 gameTime 逐 tick 递减，
 * 与服务端舞步同一节拍（两端都是 20Hz 游戏刻，漂移最多一两刻，肉眼不可感）。</p>
 */
public final class NativeApocataDanceState {

    private record Session(long endGameTime, int totalTicks) {
    }

    private static final Map<Integer, Session> SESSIONS = new ConcurrentHashMap<>();

    private NativeApocataDanceState() {
    }

    /** 报文处理（客户端主线程）：以「当前 gameTime + 剩余 tick」记截止点；total 供姿势分相。 */
    public static void onSync(int entityId, int totalTicks, int remainingTicks) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) return;
        if (remainingTicks <= 0) {
            SESSIONS.remove(entityId);
            return;
        }
        SESSIONS.put(entityId, new Session(minecraft.level.getGameTime() + remainingTicks, totalTicks));
    }

    /** 该实体此刻的剩余舞 tick：无记录/已到点返回 0（到点顺手清条目，防 id 复用误跳）。 */
    public static int remaining(int entityId) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) return 0;
        Session session = SESSIONS.get(entityId);
        if (session == null) return 0;
        long remaining = session.endGameTime() - minecraft.level.getGameTime();
        if (remaining <= 0L) {
            SESSIONS.remove(entityId);
            return 0;
        }
        return (int) Math.min(remaining, Integer.MAX_VALUE);
    }

    /** 开跳时登记的总舞程（客户端分相用：elapsed = total − remaining）。 */
    public static int total(int entityId) {
        Session session = SESSIONS.get(entityId);
        return session == null ? 0 : session.totalTicks();
    }

    /** 断线清表：实体 id 跨存档复用，旧截止点绝不能带进下一个世界。 */
    public static void clear() {
        SESSIONS.clear();
    }
}
