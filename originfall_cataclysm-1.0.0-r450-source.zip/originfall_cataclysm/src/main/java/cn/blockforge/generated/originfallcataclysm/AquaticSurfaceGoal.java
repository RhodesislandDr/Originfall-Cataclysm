package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * 水下没有可攻击目标时让模组生物主动游到水面；有目标时不抢占战斗 AI。
 * 该目标不处理氧气，具体生物会在基类中永久允许水下呼吸。
 */
public final class AquaticSurfaceGoal extends Goal {
    private static final int MAX_SURFACE_SCAN = 64;
    private final Mob mob;

    public AquaticSurfaceGoal(Mob mob) {
        this.mob = mob;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return mob.isAlive() && mob.isInWater() && !hasValidTarget();
    }

    @Override
    public boolean canContinueToUse() {
        return mob.isAlive() && mob.isInWater() && !hasValidTarget();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void start() {
        mob.getNavigation().stop();
    }

    @Override
    public void stop() {
        mob.getNavigation().stop();
    }

    @Override
    public void tick() {
        mob.getNavigation().stop();
        mob.setAggressive(false);

        double surfaceY = findSurfaceY();
        double verticalDistance = surfaceY - mob.getY();
        double upwardSpeed = Math.min(0.18D, Math.max(0.06D, verticalDistance * 0.08D));
        Vec3 movement = mob.getDeltaMovement();
        mob.setDeltaMovement(movement.x * 0.65D, Math.max(movement.y * 0.65D, upwardSpeed),
                movement.z * 0.65D);
    }

    private boolean hasValidTarget() {
        LivingEntity target = mob.getTarget();
        if (target == null || !target.isAlive()) return false;
        if (mob instanceof SourceOreGolem golem) return golem.canAttack(target);
        if (mob instanceof CalamityMob calamity) return calamity.canAttack(target);
        return CalamityLogic.canConvertedHostileAttack(mob, target);
    }

    /** 返回当前水柱上方的水面高度；没有找到时继续向上游，避免卡在深水中。 */
    private double findSurfaceY() {
        BlockPos origin = mob.blockPosition();
        for (int offset = 0; offset <= MAX_SURFACE_SCAN; offset++) {
            BlockPos candidate = origin.above(offset);
            if (!mob.level().getFluidState(candidate).is(FluidTags.WATER)) {
                return candidate.getY();
            }
        }
        return mob.getY() + MAX_SURFACE_SCAN;
    }
}
