package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

/**
 * 技能命中的「打击反馈」钩子：本模组的近战与技能伤害结算点在此把命中信息交给外部兼容层，
 * 由兼容层决定它在当前环境下意味着什么。
 *
 * <p>设计上与 {@link AdaptiveCombatGoal} 的动作桥完全一致：主源码集不认识史诗战斗的任何类，
 * 钩子默认未安装（{@code handler == null}），此时 {@link #impact} 只是一次空判返回，
 * 模组可脱离史诗战斗独立运行，行为与没有这套钩子时逐 tick 相同。只有安装了 Epic Fight，
 * {@code OriginfallEpicFightCompat#init} 才会安装真正的处理者，把这些命中转成史诗战斗的
 * 硬直结算（{@code StunType} 短硬直 / 长硬直 / 击倒）与对应受击动画。</p>
 *
 * <p>之所以需要这一层：史诗战斗只对「自己动画管线的伤害」（{@code EpicFightDamageSource}）
 * 施加硬直与受击动作。模组的剑气、陨石、傀儡拍击等技能走的是原版伤害来源，
 * 若不接入，玩家被打中时只会掉血+原版击退，看不出史诗战斗的攻防节奏。
 * 接入后这些技能命中会让目标进入史诗战斗的受击状态（出招期间不打断、已在硬直中不叠加），
 * 与史诗战斗生物的连段手感保持一致。</p>
 */
public final class SkillCombatHooks {
    private SkillCombatHooks() {}

    /** 命中力度：由轻到重，兼容层据此选择史诗战斗的硬直种类。 */
    public enum Impact {
        /** 轻击：普攻、剑气这类高频命中，只造成短硬直。 */
        LIGHT,
        /** 重击：傀儡拍击、陨石爆轰这类低频高伤，造成长硬直。 */
        HEAVY,
        /** 击倒：灾难级技能（巨型陨石）直接把人打倒。 */
        KNOCKDOWN
    }

    /** 由兼容层安装的处理者；未安装时整套钩子不起作用。 */
    public interface ImpactHandler {
        void apply(LivingEntity victim, float damage, Impact impact);
    }

    private static volatile ImpactHandler handler;

    /** 兼容层安装处理者（只在史诗战斗确实存在时调用）。 */
    public static void install(ImpactHandler newHandler) {
        handler = newHandler;
    }

    /**
     * 上报一次技能/近战命中。只在服务端生效，目标死亡或世界尚未就绪时静默跳过；
     * 未安装史诗战斗兼容层时立即返回，不做任何属性读取，保证零开销、零行为差异。
     */
    public static void impact(LivingEntity victim, float damage, Impact impact) {
        ImpactHandler current = handler;
        if (current == null) return;
        if (victim == null) return;
        Level level = victim.level();
        if (level == null || level.isClientSide || !victim.isAlive()) return;
        current.apply(victim, damage, impact);
    }
}
