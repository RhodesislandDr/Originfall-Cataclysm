package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** 为同化生物、源石耄耋和哈气贤者提供同一套随机武器、盔甲与附魔。 */
public final class AssimilationEquipment {
    private static final String EQUIPMENT_ASSIGNED = "OriginFallEquipmentAssigned";

    private AssimilationEquipment() {
    }

    public static boolean isAssigned(LivingEntity entity) {
        return entity.getPersistentData().getBoolean(EQUIPMENT_ASSIGNED);
    }

    public static void assign(LivingEntity entity) {
        entity.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        entity.setItemSlot(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (slot.isArmor()) entity.setItemSlot(slot, ItemStack.EMPTY);
        }

        if (entity instanceof Apocata) {
            // 哈基玖是深蓝之树联动的彩蛋生物：白板设定，上面已清空的装备槽直接保持空手，
            // 不参与「随机武器＋随机盔甲」的同化装备池。
            entity.getPersistentData().putBoolean(EQUIPMENT_ASSIGNED, true);
            return;
        }
        if (entity instanceof CalamityMessenger) {
            assignMessengerWeapon(entity);
            entity.getPersistentData().putBoolean(EQUIPMENT_ASSIGNED, true);
            return;
        }
        if (entity instanceof Theresia) {
            assignTheresiaEquipment(entity);
            entity.getPersistentData().putBoolean(EQUIPMENT_ASSIGNED, true);
            return;
        }
        if (entity instanceof Priestess) {
            assignPriestessEquipment(entity);
            entity.getPersistentData().putBoolean(EQUIPMENT_ASSIGNED, true);
            return;
        }
        if (entity instanceof Prophet) {
            assignProphetEquipment(entity);
            entity.getPersistentData().putBoolean(EQUIPMENT_ASSIGNED, true);
            return;
        }

        ItemStack weapon = buildRandomWeapon(entity);
        if (weapon.getItem() instanceof BowItem || weapon.getItem() instanceof CrossbowItem) {
            entity.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.ARROW, 64));
        }
        entity.setItemSlot(EquipmentSlot.MAINHAND, weapon);

        Item[][] armor = {
                {Items.LEATHER_HELMET, Items.IRON_HELMET, Items.GOLDEN_HELMET, Items.DIAMOND_HELMET, Items.NETHERITE_HELMET},
                {Items.LEATHER_CHESTPLATE, Items.IRON_CHESTPLATE, Items.GOLDEN_CHESTPLATE, Items.DIAMOND_CHESTPLATE, Items.NETHERITE_CHESTPLATE},
                {Items.LEATHER_LEGGINGS, Items.IRON_LEGGINGS, Items.GOLDEN_LEGGINGS, Items.DIAMOND_LEGGINGS, Items.NETHERITE_LEGGINGS},
                {Items.LEATHER_BOOTS, Items.IRON_BOOTS, Items.GOLDEN_BOOTS, Items.DIAMOND_BOOTS, Items.NETHERITE_BOOTS}
        };
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (int i = 0; i < slots.length; i++) {
            if (entity.getRandom().nextFloat() >= 0.65F) continue;
            ItemStack stack = new ItemStack(armor[i][entity.getRandom().nextInt(armor[i].length)]);
            net.minecraft.world.item.enchantment.Enchantment[] protection = {
                    net.minecraft.world.item.enchantment.Enchantments.ALL_DAMAGE_PROTECTION,
                    net.minecraft.world.item.enchantment.Enchantments.FIRE_PROTECTION,
                    net.minecraft.world.item.enchantment.Enchantments.BLAST_PROTECTION,
                    net.minecraft.world.item.enchantment.Enchantments.PROJECTILE_PROTECTION
            };
            stack.enchant(protection[entity.getRandom().nextInt(protection.length)],
                    1 + entity.getRandom().nextInt(4));
            if (entity.getRandom().nextFloat() < 0.55F) {
                stack.enchant(net.minecraft.world.item.enchantment.Enchantments.UNBREAKING,
                        1 + entity.getRandom().nextInt(3));
            }
            if (entity.getRandom().nextFloat() < 0.2F) {
                stack.enchant(net.minecraft.world.item.enchantment.Enchantments.MENDING, 1);
            }
            if (entity.getRandom().nextFloat() < 0.25F) {
                stack.enchant(net.minecraft.world.item.enchantment.Enchantments.THORNS,
                        1 + entity.getRandom().nextInt(3));
            }
            if (slots[i] == EquipmentSlot.HEAD) {
                if (entity.getRandom().nextFloat() < 0.4F) {
                    stack.enchant(net.minecraft.world.item.enchantment.Enchantments.RESPIRATION,
                            1 + entity.getRandom().nextInt(3));
                }
                if (entity.getRandom().nextFloat() < 0.2F) {
                    stack.enchant(net.minecraft.world.item.enchantment.Enchantments.AQUA_AFFINITY, 1);
                }
            } else if (slots[i] == EquipmentSlot.FEET) {
                stack.enchant(net.minecraft.world.item.enchantment.Enchantments.FALL_PROTECTION,
                        1 + entity.getRandom().nextInt(4));
                if (entity.getRandom().nextFloat() < 0.35F) {
                    stack.enchant(entity.getRandom().nextBoolean()
                                    ? net.minecraft.world.item.enchantment.Enchantments.DEPTH_STRIDER
                                    : net.minecraft.world.item.enchantment.Enchantments.SOUL_SPEED,
                            1 + entity.getRandom().nextInt(3));
                }
            } else if (slots[i] == EquipmentSlot.LEGS && entity.getRandom().nextFloat() < 0.3F) {
                stack.enchant(net.minecraft.world.item.enchantment.Enchantments.SWIFT_SNEAK,
                        1 + entity.getRandom().nextInt(3));
            }
            entity.setItemSlot(slots[i], stack);
        }
        entity.getPersistentData().putBoolean(EQUIPMENT_ASSIGNED, true);
    }

    /** 标记实体已完成装备分配，避免 tick 内的自动分配覆盖手动设置的主手武器。 */
    public static void markAssigned(LivingEntity entity) {
        if (entity != null) entity.getPersistentData().putBoolean(EQUIPMENT_ASSIGNED, true);
    }

    /**
     * 终焉行者的武器生成机制：生成一把随机的近战/弓弩武器并附带完整随机附魔。
     * 「预言家」博士「精锐集结」召唤的特蕾西娅（50% 概率）复用此机制。
     */
    public static ItemStack buildRandomWeapon(LivingEntity entity) {
        return buildRandomWeapon(entity, false);
    }

    /**
     * 随机武器生成。{@code meleeOnly} 为 true 时只在近战武器列表中抽取（不出现弓/弩），
     * 供「预言家」博士「精锐集结」召唤的特蕾西娅使用（需求：其随机武器均为近战武器）。
     */
    public static ItemStack buildRandomWeapon(LivingEntity entity, boolean meleeOnly) {
        Item[] meleeWeapons = {
                Items.WOODEN_SWORD, Items.STONE_SWORD, Items.IRON_SWORD, Items.GOLDEN_SWORD,
                Items.DIAMOND_SWORD, Items.NETHERITE_SWORD, Items.WOODEN_AXE, Items.STONE_AXE,
                Items.IRON_AXE, Items.GOLDEN_AXE, Items.DIAMOND_AXE, Items.NETHERITE_AXE,
                Items.WOODEN_PICKAXE, Items.STONE_PICKAXE, Items.IRON_PICKAXE, Items.GOLDEN_PICKAXE,
                Items.DIAMOND_PICKAXE, Items.NETHERITE_PICKAXE, Items.WOODEN_SHOVEL, Items.STONE_SHOVEL,
                Items.IRON_SHOVEL, Items.GOLDEN_SHOVEL, Items.DIAMOND_SHOVEL, Items.NETHERITE_SHOVEL,
                Items.WOODEN_HOE, Items.STONE_HOE, Items.IRON_HOE, Items.GOLDEN_HOE,
                Items.DIAMOND_HOE, Items.NETHERITE_HOE, Items.TRIDENT
        };
        boolean ranged = !meleeOnly && entity.getRandom().nextFloat() < 0.18F;
        ItemStack weapon = new ItemStack(ranged
                ? (entity.getRandom().nextBoolean() ? Items.BOW : Items.CROSSBOW)
                : meleeWeapons[entity.getRandom().nextInt(meleeWeapons.length)]);
        if (weapon.getItem() instanceof BowItem) {
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.POWER_ARROWS,
                    1 + entity.getRandom().nextInt(5));
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.PUNCH_ARROWS,
                    1 + entity.getRandom().nextInt(2));
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.FLAMING_ARROWS, 1);
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.INFINITY_ARROWS, 1);
        } else if (weapon.getItem() instanceof CrossbowItem) {
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.PIERCING,
                    1 + entity.getRandom().nextInt(5));
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.QUICK_CHARGE,
                    1 + entity.getRandom().nextInt(3));
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.MULTISHOT, 1);
        } else if (weapon.is(Items.TRIDENT)) {
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.IMPALING,
                    1 + entity.getRandom().nextInt(5));
        } else {
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.SHARPNESS,
                    1 + entity.getRandom().nextInt(5));
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.FIRE_ASPECT,
                    1 + entity.getRandom().nextInt(2));
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.KNOCKBACK,
                    1 + entity.getRandom().nextInt(2));
            if (weapon.getItem() instanceof DiggerItem) {
                weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.BLOCK_EFFICIENCY,
                        1 + entity.getRandom().nextInt(5));
                if (entity.getRandom().nextBoolean()) {
                    weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.BLOCK_FORTUNE,
                            1 + entity.getRandom().nextInt(3));
                }
            }
        }
        weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.UNBREAKING,
                1 + entity.getRandom().nextInt(3));
        weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.MENDING, 1);
        return weapon;
    }

    private static void assignTheresiaEquipment(LivingEntity entity) {
        ItemStack sword = new ItemStack(GeneratedMod.YINGSIAO.get());
        sword.enchant(net.minecraft.world.item.enchantment.Enchantments.SHARPNESS,
                1 + entity.getRandom().nextInt(5));
        sword.enchant(net.minecraft.world.item.enchantment.Enchantments.FIRE_ASPECT,
                1 + entity.getRandom().nextInt(2));
        sword.enchant(net.minecraft.world.item.enchantment.Enchantments.KNOCKBACK,
                1 + entity.getRandom().nextInt(2));
        sword.enchant(net.minecraft.world.item.enchantment.Enchantments.UNBREAKING,
                1 + entity.getRandom().nextInt(3));
        sword.enchant(net.minecraft.world.item.enchantment.Enchantments.MENDING, 1);
        entity.setItemSlot(EquipmentSlot.MAINHAND, sword);

        Item[][] armor = {
                {Items.LEATHER_HELMET, Items.IRON_HELMET, Items.GOLDEN_HELMET, Items.DIAMOND_HELMET, Items.NETHERITE_HELMET},
                {Items.LEATHER_CHESTPLATE, Items.IRON_CHESTPLATE, Items.GOLDEN_CHESTPLATE, Items.DIAMOND_CHESTPLATE, Items.NETHERITE_CHESTPLATE},
                {Items.LEATHER_LEGGINGS, Items.IRON_LEGGINGS, Items.GOLDEN_LEGGINGS, Items.DIAMOND_LEGGINGS, Items.NETHERITE_LEGGINGS},
                {Items.LEATHER_BOOTS, Items.IRON_BOOTS, Items.GOLDEN_BOOTS, Items.DIAMOND_BOOTS, Items.NETHERITE_BOOTS}
        };
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (int i = 0; i < slots.length; i++) {
            ItemStack piece = new ItemStack(armor[i][entity.getRandom().nextInt(armor[i].length)]);
            piece.enchant(net.minecraft.world.item.enchantment.Enchantments.ALL_DAMAGE_PROTECTION,
                    1 + entity.getRandom().nextInt(4));
            piece.enchant(net.minecraft.world.item.enchantment.Enchantments.UNBREAKING,
                    1 + entity.getRandom().nextInt(3));
            piece.enchant(net.minecraft.world.item.enchantment.Enchantments.MENDING, 1);
            entity.setItemSlot(slots[i], piece);
        }
    }

    private static void assignPriestessEquipment(LivingEntity entity) {
        ItemStack sword = new ItemStack(GeneratedMod.TIANTANGZHIDIAN.get());
        sword.enchant(net.minecraft.world.item.enchantment.Enchantments.SHARPNESS,
                1 + entity.getRandom().nextInt(5));
        sword.enchant(net.minecraft.world.item.enchantment.Enchantments.FIRE_ASPECT,
                1 + entity.getRandom().nextInt(2));
        sword.enchant(net.minecraft.world.item.enchantment.Enchantments.KNOCKBACK,
                1 + entity.getRandom().nextInt(2));
        sword.enchant(net.minecraft.world.item.enchantment.Enchantments.UNBREAKING,
                1 + entity.getRandom().nextInt(3));
        sword.enchant(net.minecraft.world.item.enchantment.Enchantments.MENDING, 1);
        entity.setItemSlot(EquipmentSlot.MAINHAND, sword);

        Item[][] armor = {
                {Items.LEATHER_HELMET, Items.IRON_HELMET, Items.GOLDEN_HELMET, Items.DIAMOND_HELMET, Items.NETHERITE_HELMET},
                {Items.LEATHER_CHESTPLATE, Items.IRON_CHESTPLATE, Items.GOLDEN_CHESTPLATE, Items.DIAMOND_CHESTPLATE, Items.NETHERITE_CHESTPLATE},
                {Items.LEATHER_LEGGINGS, Items.IRON_LEGGINGS, Items.GOLDEN_LEGGINGS, Items.DIAMOND_LEGGINGS, Items.NETHERITE_LEGGINGS},
                {Items.LEATHER_BOOTS, Items.IRON_BOOTS, Items.GOLDEN_BOOTS, Items.DIAMOND_BOOTS, Items.NETHERITE_BOOTS}
        };
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        net.minecraft.world.item.enchantment.Enchantment[] protection = {
                net.minecraft.world.item.enchantment.Enchantments.ALL_DAMAGE_PROTECTION,
                net.minecraft.world.item.enchantment.Enchantments.FIRE_PROTECTION,
                net.minecraft.world.item.enchantment.Enchantments.BLAST_PROTECTION,
                net.minecraft.world.item.enchantment.Enchantments.PROJECTILE_PROTECTION
        };
        for (int i = 0; i < slots.length; i++) {
            // 普瑞赛斯必定穿满四件护甲（首领规格），但每件材质与附魔随机。
            ItemStack piece = new ItemStack(armor[i][entity.getRandom().nextInt(armor[i].length)]);
            piece.enchant(protection[entity.getRandom().nextInt(protection.length)],
                    1 + entity.getRandom().nextInt(4));
            if (entity.getRandom().nextFloat() < 0.6F) {
                piece.enchant(net.minecraft.world.item.enchantment.Enchantments.UNBREAKING,
                        1 + entity.getRandom().nextInt(3));
            }
            if (entity.getRandom().nextFloat() < 0.3F) {
                piece.enchant(net.minecraft.world.item.enchantment.Enchantments.MENDING, 1);
            }
            if (entity.getRandom().nextFloat() < 0.3F) {
                piece.enchant(net.minecraft.world.item.enchantment.Enchantments.THORNS,
                        1 + entity.getRandom().nextInt(3));
            }
            if (slots[i] == EquipmentSlot.HEAD) {
                if (entity.getRandom().nextFloat() < 0.45F) {
                    piece.enchant(net.minecraft.world.item.enchantment.Enchantments.RESPIRATION,
                            1 + entity.getRandom().nextInt(3));
                }
            } else if (slots[i] == EquipmentSlot.FEET) {
                piece.enchant(net.minecraft.world.item.enchantment.Enchantments.FALL_PROTECTION,
                        1 + entity.getRandom().nextInt(4));
            } else if (slots[i] == EquipmentSlot.LEGS && entity.getRandom().nextFloat() < 0.3F) {
                piece.enchant(net.minecraft.world.item.enchantment.Enchantments.SWIFT_SNEAK,
                        1 + entity.getRandom().nextInt(3));
            }
            entity.setItemSlot(slots[i], piece);
        }
    }

    /** 「预言家」博士：必定手持如我所见并随机附魔，穿满四件随机材质护甲并随机附魔。 */
    private static void assignProphetEquipment(LivingEntity entity) {
        ItemStack sword = new ItemStack(GeneratedMod.RUWOSUOJIAN.get());
        sword.enchant(net.minecraft.world.item.enchantment.Enchantments.SHARPNESS,
                1 + entity.getRandom().nextInt(5));
        sword.enchant(net.minecraft.world.item.enchantment.Enchantments.FIRE_ASPECT,
                1 + entity.getRandom().nextInt(2));
        sword.enchant(net.minecraft.world.item.enchantment.Enchantments.KNOCKBACK,
                1 + entity.getRandom().nextInt(2));
        sword.enchant(net.minecraft.world.item.enchantment.Enchantments.UNBREAKING,
                1 + entity.getRandom().nextInt(3));
        sword.enchant(net.minecraft.world.item.enchantment.Enchantments.MENDING, 1);
        entity.setItemSlot(EquipmentSlot.MAINHAND, sword);

        Item[][] armor = {
                {Items.LEATHER_HELMET, Items.IRON_HELMET, Items.GOLDEN_HELMET, Items.DIAMOND_HELMET, Items.NETHERITE_HELMET},
                {Items.LEATHER_CHESTPLATE, Items.IRON_CHESTPLATE, Items.GOLDEN_CHESTPLATE, Items.DIAMOND_CHESTPLATE, Items.NETHERITE_CHESTPLATE},
                {Items.LEATHER_LEGGINGS, Items.IRON_LEGGINGS, Items.GOLDEN_LEGGINGS, Items.DIAMOND_LEGGINGS, Items.NETHERITE_LEGGINGS},
                {Items.LEATHER_BOOTS, Items.IRON_BOOTS, Items.GOLDEN_BOOTS, Items.DIAMOND_BOOTS, Items.NETHERITE_BOOTS}
        };
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        net.minecraft.world.item.enchantment.Enchantment[] protection = {
                net.minecraft.world.item.enchantment.Enchantments.ALL_DAMAGE_PROTECTION,
                net.minecraft.world.item.enchantment.Enchantments.FIRE_PROTECTION,
                net.minecraft.world.item.enchantment.Enchantments.BLAST_PROTECTION,
                net.minecraft.world.item.enchantment.Enchantments.PROJECTILE_PROTECTION
        };
        for (int i = 0; i < slots.length; i++) {
            // 博士必定穿满四件护甲（首领规格），但每件材质与附魔随机。
            ItemStack piece = new ItemStack(armor[i][entity.getRandom().nextInt(armor[i].length)]);
            piece.enchant(protection[entity.getRandom().nextInt(protection.length)],
                    1 + entity.getRandom().nextInt(4));
            if (entity.getRandom().nextFloat() < 0.6F) {
                piece.enchant(net.minecraft.world.item.enchantment.Enchantments.UNBREAKING,
                        1 + entity.getRandom().nextInt(3));
            }
            if (entity.getRandom().nextFloat() < 0.3F) {
                piece.enchant(net.minecraft.world.item.enchantment.Enchantments.MENDING, 1);
            }
            if (entity.getRandom().nextFloat() < 0.3F) {
                piece.enchant(net.minecraft.world.item.enchantment.Enchantments.THORNS,
                        1 + entity.getRandom().nextInt(3));
            }
            if (slots[i] == EquipmentSlot.HEAD) {
                if (entity.getRandom().nextFloat() < 0.45F) {
                    piece.enchant(net.minecraft.world.item.enchantment.Enchantments.RESPIRATION,
                            1 + entity.getRandom().nextInt(3));
                }
            } else if (slots[i] == EquipmentSlot.FEET) {
                piece.enchant(net.minecraft.world.item.enchantment.Enchantments.FALL_PROTECTION,
                        1 + entity.getRandom().nextInt(4));
            } else if (slots[i] == EquipmentSlot.LEGS && entity.getRandom().nextFloat() < 0.3F) {
                piece.enchant(net.minecraft.world.item.enchantment.Enchantments.SWIFT_SNEAK,
                        1 + entity.getRandom().nextInt(3));
            }
            entity.setItemSlot(slots[i], piece);
        }
    }

    private static void assignMessengerWeapon(LivingEntity entity) {
        ItemStack weapon = new ItemStack(entity.getRandom().nextBoolean() ? Items.BOW : Items.CROSSBOW);
        if (weapon.getItem() instanceof BowItem) {
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.POWER_ARROWS,
                    2 + entity.getRandom().nextInt(4));
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.PUNCH_ARROWS, 1);
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.FLAMING_ARROWS, 1);
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.INFINITY_ARROWS, 1);
        } else {
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.PIERCING,
                    2 + entity.getRandom().nextInt(4));
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.QUICK_CHARGE,
                    1 + entity.getRandom().nextInt(3));
            weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.MULTISHOT, 1);
        }
        weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.UNBREAKING,
                1 + entity.getRandom().nextInt(3));
        weapon.enchant(net.minecraft.world.item.enchantment.Enchantments.MENDING, 1);
        entity.setItemSlot(EquipmentSlot.MAINHAND, weapon);
        entity.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.ARROW, 64));
    }
}
