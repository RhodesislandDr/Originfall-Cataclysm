package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.CalamityMessenger;
import cn.blockforge.generated.originfallcataclysm.CalamityMessengerModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;
import com.mojang.blaze3d.vertex.PoseStack;

/** 天灾信使渲染器，使用标准玩家皮肤人形模型并保留远程武器显示；不添加护甲渲染层。 */
public final class CalamityMessengerRenderer
        extends MobRenderer<CalamityMessenger, CalamityMessengerModel> {
    private final ResourceLocation texture;

    public CalamityMessengerRenderer(EntityRendererProvider.Context context, ResourceLocation texture,
                                     ModelLayerLocation layer) {
        super(context, new CalamityMessengerModel(context.bakeLayer(layer)), 0.5F);
        this.texture = texture;
        addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
    }

    @Override
    public ResourceLocation getTextureLocation(CalamityMessenger entity) {
        return texture;
    }

    @Override
    public void render(CalamityMessenger entity, float yaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        poseStack.scale(0.9375F, 0.9375F, 0.9375F);
        super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
        poseStack.popPose();
    }
}
