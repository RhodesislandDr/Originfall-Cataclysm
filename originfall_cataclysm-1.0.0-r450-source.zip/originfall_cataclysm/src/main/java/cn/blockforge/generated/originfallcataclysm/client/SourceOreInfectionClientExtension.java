package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.GeneratedMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.EffectRenderingInventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectUtil;
import net.minecraftforge.client.extensions.common.IClientMobEffectExtensions;

/** 以阿拉伯数字显示源石感染层数，避免原版药水效果使用罗马数字。 */
public final class SourceOreInfectionClientExtension implements IClientMobEffectExtensions {
    @Override
    public boolean renderInventoryText(MobEffectInstance effect, EffectRenderingInventoryScreen screen,
                                       GuiGraphics graphics, int x, int y, int blitOffset) {
        if (effect.getEffect() != GeneratedMod.SOURCE_ORE_INFECTION.get()) return false;
        long layers = Math.min((long) cn.blockforge.generated.originfallcataclysm.CalamityLogic.MAX_SOURCE_ORE_INFECTION_LAYERS,
                effect.getAmplifier() == Integer.MAX_VALUE
                        ? cn.blockforge.generated.originfallcataclysm.CalamityLogic.MAX_SOURCE_ORE_INFECTION_LAYERS
                        : Math.max(1L, (long) effect.getAmplifier() + 1L));
        Minecraft minecraft = Minecraft.getInstance();
        graphics.drawString(minecraft.font,
                Component.literal("源石感染 " + layers), x + 28, y + 6, 0xFFFFFFFF);
        graphics.drawString(minecraft.font, MobEffectUtil.formatDuration(effect, 1.0F),
                x + 28, y + 16, 0xFF7F7F7F);
        return true;
    }

    @Override
    public boolean renderGuiIcon(MobEffectInstance effect, Gui gui, GuiGraphics graphics,
                                 int x, int y, float z, float alpha) {
        return false;
    }
}
