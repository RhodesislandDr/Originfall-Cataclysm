package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;

/** 参考原版狼的主人跟随：有停止距离、路径重算和无法寻路时的近身传送。 */
public final class SourceOreGolemFollowOwnerGoal extends Goal {
    private static final int TELEPORT_WHEN_DISTANCE_IS = 12;
    private static final int MIN_HORIZONTAL_DISTANCE_FROM_OWNER = 2;
    private static final int MAX_HORIZONTAL_DISTANCE_FROM_OWNER = 3;
    private static final int MAX_VERTICAL_DISTANCE_FROM_OWNER = 1;
    private static final int MIN_VERTICAL_DISTANCE_FROM_OWNER = -1;
    private final SourceOreGolem golem;
    private final double speed;
    private final float startDistance;
    private final float stopDistance;
    private Player owner;
    private int timeToRecalcPath;

    public SourceOreGolemFollowOwnerGoal(SourceOreGolem golem, double speed,
                                         float startDistance, float stopDistance) {
        this.golem = golem;
        this.speed = speed;
        this.startDistance = startDistance;
        this.stopDistance = stopDistance;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        owner = golem.getOwnerPlayer();
        return shouldFollow() && owner != null && golem.distanceToSqr(owner) > startDistance * startDistance;
    }

    @Override
    public boolean canContinueToUse() {
        return shouldFollow() && owner != null && owner.isAlive()
                && golem.distanceToSqr(owner) > stopDistance * stopDistance;
    }

    @Override
    public void start() {
        timeToRecalcPath = 0;
    }

    @Override
    public void stop() {
        owner = null;
        golem.getNavigation().stop();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        if (owner == null || !owner.isAlive()) return;
        golem.getLookControl().setLookAt(owner, 10.0F, golem.getMaxHeadXRot());
        if (--timeToRecalcPath <= 0) {
            timeToRecalcPath = 10;
            if (!golem.getNavigation().moveTo(owner, speed)) {
                if (golem.distanceToSqr(owner) >= TELEPORT_WHEN_DISTANCE_IS * TELEPORT_WHEN_DISTANCE_IS) {
                    teleportNearOwner();
                }
            }
        }
    }

    private boolean shouldFollow() {
        return golem.isFollowingOwner() && !golem.isOrderedToSit()
                && golem.getTarget() == null && (owner == null || owner.isAlive());
    }

    private void teleportNearOwner() {
        for (int dx = MIN_HORIZONTAL_DISTANCE_FROM_OWNER; dx <= MAX_HORIZONTAL_DISTANCE_FROM_OWNER; dx++) {
            for (int dz = MIN_HORIZONTAL_DISTANCE_FROM_OWNER; dz <= MAX_HORIZONTAL_DISTANCE_FROM_OWNER; dz++) {
                for (int signX : new int[] {-1, 1}) {
                    for (int signZ : new int[] {-1, 1}) {
                        BlockPos pos = owner.blockPosition().offset(dx * signX, 0, dz * signZ);
                        for (int dy = MIN_VERTICAL_DISTANCE_FROM_OWNER; dy <= MAX_VERTICAL_DISTANCE_FROM_OWNER; dy++) {
                            BlockPos candidate = pos.above(dy);
                            if (canTeleportTo(candidate)) {
                                golem.moveTo(candidate.getX() + 0.5D, candidate.getY(), candidate.getZ() + 0.5D,
                                        golem.getYRot(), golem.getXRot());
                                golem.getNavigation().stop();
                                return;
                            }
                        }
                    }
                }
            }
        }
    }

    private boolean canTeleportTo(BlockPos pos) {
        return golem.level().noCollision(golem, golem.getBoundingBox().move(
                        pos.getX() + 0.5D - golem.getX(), pos.getY() - golem.getY(), pos.getZ() + 0.5D - golem.getZ()))
                && !golem.level().getBlockState(pos.below()).isAir()
                && !golem.level().getBlockState(pos).isSuffocating(golem.level(), pos);
    }
}
