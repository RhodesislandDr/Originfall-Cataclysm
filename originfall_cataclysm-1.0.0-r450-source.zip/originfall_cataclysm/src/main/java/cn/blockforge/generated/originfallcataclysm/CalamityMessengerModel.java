package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.SwordItem;

/** 天灾信使的标准玩家皮肤模型；使用上传的 64x64 皮肤并保留玩家式服装外层。 */
public final class CalamityMessengerModel extends PlayerModel<CalamityMessenger> {
    /** 眨眼眼睑（仅身体层有）：见 {@link BlinkLids}。 */
    private final ModelPart blinkLidRight;
    private final ModelPart blinkLidLeft;

    public CalamityMessengerModel(ModelPart root) {
        // 使用经典 4 像素手臂，严格匹配玩家皮肤的标准几何和 UV 布局。
        super(root, false);
        this.blinkLidRight = BlinkLids.find(root.getChild("head"), "blink_lid_right");
        this.blinkLidLeft = BlinkLids.find(root.getChild("head"), "blink_lid_left");
        if (this.blinkLidRight != null) this.blinkLidRight.skipDraw = true;
        if (this.blinkLidLeft != null) this.blinkLidLeft.skipDraw = true;
    }

    @Override
    public void prepareMobModel(CalamityMessenger entity, float limbSwing, float limbSwingAmount,
                                float partialTick) {
        super.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTick);
        leftArmPose = ArmPose.EMPTY;
        rightArmPose = ArmPose.EMPTY;

        ItemStack weapon = entity.getMainHandItem();
        HumanoidArm weaponArm = entity.getMainArm();
        if (isSwordWeapon(weapon)) {
            // 影霄、如我所见、天堂支点等剑类武器按原版单手持剑姿势（同钻石剑）适配。
            setArmPose(weaponArm, ArmPose.ITEM);
        } else if (weapon.getItem() instanceof BowItem && entity.isUsingItem()
                && entity.getUsedItemHand() == InteractionHand.MAIN_HAND) {
            // BOW_AND_ARROW 是双臂姿态；只设置持弓手会让另一只手保持下垂。
            setArmPose(HumanoidArm.RIGHT, ArmPose.BOW_AND_ARROW);
            setArmPose(HumanoidArm.LEFT, ArmPose.BOW_AND_ARROW);
        } else if (weapon.getItem() instanceof CrossbowItem && (entity.isUsingItem()
                || CrossbowItem.isCharged(weapon))) {
            ArmPose crossbowPose = CrossbowItem.isCharged(weapon)
                    ? ArmPose.CROSSBOW_HOLD : ArmPose.CROSSBOW_CHARGE;
            setArmPose(weaponArm, crossbowPose);
            setArmPose(weaponArm == HumanoidArm.RIGHT ? HumanoidArm.LEFT : HumanoidArm.RIGHT, crossbowPose);
        } else if (weapon.is(Items.TRIDENT) && entity.isUsingItem()
                && entity.getUsedItemHand() == InteractionHand.MAIN_HAND) {
            setArmPose(weaponArm, ArmPose.THROW_SPEAR);
        }
    }

    /** 是否为剑类武器：模组三把剑（影霄/如我所见/天堂支点）及所有原版剑统一按钻石剑的持握动作适配。 */
    private static boolean isSwordWeapon(ItemStack weapon) {
        return weapon.getItem() instanceof SwordItem;
    }

    private void setArmPose(HumanoidArm arm, ArmPose pose) {
        if (arm == HumanoidArm.RIGHT) {
            rightArmPose = pose;
        } else {
            leftArmPose = pose;
        }
    }

    @Override
    public void setupAnim(CalamityMessenger entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);

        boolean moving = entity.getDeltaMovement().horizontalDistanceSqr() > 0.0001D
                || limbSwingAmount > 0.08F;
        if (moving) {
            // 飞行移动沿用终焉行者式的玩家双腿节奏，不添加翅膀或翅膀骨骼。
            float amount = Math.max(limbSwingAmount, 0.65F);
            rightLeg.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * amount;
            leftLeg.xRot = Mth.cos(limbSwing * 0.6662F + Mth.PI) * 1.4F * amount;
            rightLeg.zRot = 0.0F;
            leftLeg.zRot = 0.0F;
        } else {
            // 悬停时让双腿错相轻摆，保持空中生物的节奏感。
            float phase = ageInTicks * 0.20F;
            rightLeg.xRot = Mth.cos(phase) * 0.20F;
            leftLeg.xRot = Mth.cos(phase + Mth.PI) * 0.20F;
            rightLeg.zRot = Mth.cos(phase) * 0.07F;
            leftLeg.zRot = Mth.cos(phase + Mth.PI) * 0.07F;
        }

        // PlayerModel 在 super.setupAnim 中复制外层部件；上面的自定义腿部动画
        // 发生在复制之后，必须再次同步裤腿，否则悬停时外层 UV 会留在旧姿态，
        // 看起来就像贴图错位或闪烁。
        rightPants.copyFrom(rightLeg);
        leftPants.copyFrom(leftLeg);

        // 眨眼（纯外貌）：随头骨骼走，睁眼时两块眼睑完全 skipDraw。
        BlinkLids.apply(blinkLidRight, blinkLidLeft, entity, ageInTicks);
    }

    public static LayerDefinition createBodyLayer() {
        // PlayerModel 自带 head/body/limb 外层部件，直接使用标准玩家建模形式。
        net.minecraft.client.model.geom.builders.MeshDefinition mesh =
                PlayerModel.createMesh(CubeDeformation.NONE, false);
        // 眨眼眼睑（身体层，见 BlinkLids）：贴在正脸上方，平时完全不渲染。
        BlinkLids.addEyelids(mesh.getRoot().getChild("head"), CubeDeformation.NONE);
        return LayerDefinition.create(mesh, 64, 64);
    }
}
