package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.BlockPos;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.AABB;

public final class MeteorBlockEntity extends BlockEntity {
    private static final double EFFECT_RADIUS = 8.0D;
    private static final int EFFECT_DURATION = 0;

    public MeteorBlockEntity(BlockPos pos, BlockState state) {
        super(GeneratedMod.METEOR_BLOCK_ENTITY.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, MeteorBlockEntity blockEntity) {
        if (!(level instanceof ServerLevel server) || server.getGameTime() % 10L != 0L) return;
        AABB area = new AABB(pos).inflate(EFFECT_RADIUS);
        for (LivingEntity living : server.getEntitiesOfClass(LivingEntity.class, area,
                entity -> entity.isAlive() && entity.distanceToSqr(pos.getCenter()) <= EFFECT_RADIUS * EFFECT_RADIUS)) {
            // 源石感染属于本模组负面效果，强制附加，不受陨石免疫判定影响。
            CalamityLogic.applySourceOreInfection(living, 1, EFFECT_DURATION);
            CalamityLogic.markInfectionExposure(living);
        }
    }
}
