package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;

import java.util.UUID;

/**
 * 属性修饰符的幂等写入工具。
 *
 * 原版 1.20.1 的 {@link AttributeInstance#addPermanentModifier(AttributeModifier)} 在同一 UUID
 * 已经存在时会直接抛出 “Modifier is already applied on this attribute!”。本模组的吸血溢出上限、
 * 最大生命削减、内化宇宙增减、咫尺天堂/昔时代价的半血衰减等状态，都会在受击事件、治疗回调以及
 * 周期性 tick 同步中反复重建同一批修饰符，因此一律经由这里“先按 UUID 清除、再按需添加”，
 * 使同步过程可重入、可重复执行，杜绝重复添加导致的服务器崩溃。
 */
public final class OfcAttributes {

    private OfcAttributes() {
    }

    /**
     * 设置（或清除）一个固定 UUID 的属性修饰符。
     * 当 {@code enabled} 为 false、金额非有限数或近似为 0 时，只移除不添加。
     */
    public static void set(AttributeInstance instance, UUID id, String name, double amount,
                           AttributeModifier.Operation operation, boolean enabled) {
        if (instance == null || id == null) return;
        clear(instance, id);
        if (!enabled || !Double.isFinite(amount) || Math.abs(amount) <= 1.0E-9D) return;
        instance.addPermanentModifier(new AttributeModifier(id, name, amount, operation));
    }

    /** 金额为 0 时等价于清除。 */
    public static void set(AttributeInstance instance, UUID id, String name, double amount,
                           AttributeModifier.Operation operation) {
        set(instance, id, name, amount, operation, true);
    }

    /** 按 UUID 移除修饰符；不存在时无副作用。 */
    public static void clear(AttributeInstance instance, UUID id) {
        if (instance == null || id == null) return;
        if (instance.getModifier(id) != null) {
            instance.removeModifier(id);
        }
    }
}
