package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.GeneratedMod;
import cn.blockforge.generated.originfallcataclysm.YangFireParticles;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.TextureStitchEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 阳火状态形态的客户端挂点。
 *
 * 阳火的视觉表现（需求变更）：
 * - 不再叠加自定义的「独立建模白金火焰」特效；
 * - 视觉效果改由服务端在 {@code RuwosuojianLogic.tickFire} 里喷发的「原版岩浆粒子」承担，
 *   客户端仅需保留网络层数同步与粒子提供者的注册，不再渲染火焰模型。
 *
 * 取精灵的方式：1.20.1 的 Minecraft#getTextureAtlas 只能解析 ModelManager 管理的
 * 图集（blocks 等），粒子图集由 ParticleEngine 自己上传、不在其中，直接查询会在
 * AtlasSet 里 get 到 null 并崩溃（r188 的崩溃点）。因此改在粒子图集缝合完成的
 * TextureStitchEvent.Post 回调里缓存精灵；尚未完成首次缝合时本渲染直接跳过。
 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT)
public final class YangFireClientEvents {

    private static final ResourceLocation SPRITE_LOCATION =
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "particle/yang_fire_model");

    /** 粒子图集里的阳火动画精灵；缝合事件赋值，首次资源加载完成前为 null。 */
    private static volatile TextureAtlasSprite yangFireSprite;

    private YangFireClientEvents() {
    }

    @SubscribeEvent
    public static void onRenderLivingPost(RenderLivingEvent.Post event) {
        // 阳火特效已取消：不再叠加自定义白金火焰模型。
        // 视觉表现改由服务端「由生物向外喷发的原版岩浆粒子」承担（见 RuwosuojianLogic.tickFire）。
    }

    @SubscribeEvent
    public static void onClientLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        YangFireClientState.clear();
    }

    /** 模组总线：注册阳火粒子提供者，并在粒子图集缝合完成后缓存阳火精灵。 */
    @Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModBusSetup {

        private ModBusSetup() {
        }

        @SubscribeEvent
        public static void registerParticleProviders(RegisterParticleProvidersEvent event) {
            event.registerSpriteSet(YangFireParticles.YANG_FIRE_MODEL.get(), YangFireParticle::factory);
        }

        @SubscribeEvent
        public static void onParticleAtlasStitched(TextureStitchEvent.Post event) {
            // Post 在 TextureAtlas#upload 尾部派发，此时精灵表已经填充；
            // 资源热重载（含 F3+T）会重新缝合并刷新缓存，无需额外清理。
            if (TextureAtlas.LOCATION_PARTICLES.equals(event.getAtlas().location())) {
                yangFireSprite = event.getAtlas().getSprite(SPRITE_LOCATION);
            }
        }
    }
}
