package cn.blockforge.generated.originfallcataclysm.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.util.Mth;

/**
 * 阳火的独立模型（参考原版燃烧叠加层 EntityRenderDispatcher#renderFlame 的形态学，但为单独建模），
 * 不再缠绕附身于实体身体，而是在该实体头顶之上立起一簇明亮白金火苗：
 * <ul>
 *   <li>外环：自基座向上逐层收分、朝向相机的火舌面片，逐层镜像 UV、随时间轻微摆动；</li>
 *   <li>内核：两束 45°/135° 正交的“光柱”面片，比外环更高更亮，是阳火区别于原版火的自有特征；</li>
 *   <li>动态：贴图本身是 8 帧动画条带（粒子图集自动换帧），模型再叠加宽度抖动、透明度脉动与整体浮动。</li>
 * </ul>
 * 基座锚定在实体头顶（bbHeight 处的世界 Y）并留一小段空隙，火焰朝相机回转（billboard）。
 * 面片 UV 直接取自粒子图集里的 yang_fire 精灵，因此与粒子共用同一份动态帧。
 */
public final class YangFireModel {

    /** 原版同款：每层火舌上升的步进（缩放单位）。 */
    private static final float LAYER_STEP = 0.45F;
    /** 原版同款：每层宽度的收分系数。 */
    private static final float LAYER_TAPER = 0.9F;

    private YangFireModel() {
    }

    /**
     * 渲染一具实体头顶的阳火模型。调用方保证 poseStack 已位于实体脚底（相机相对坐标、未旋转），
     * 与原版 renderFlame 的调用环境一致；本方法自行把火焰基座抬升到该实体头顶之上。
     *
     * @param billboardYawDegrees 朝向相机的偏航旋转（通常为 -camera.getYRot()）
     * @param age                 平滑时间刻（tickCount + partialTick）
     * @param layers              当前阳火层数（1~32），影响体型加成与内核亮度
     */
    public static void render(PoseStack poseStack, VertexConsumer consumer, TextureAtlasSprite sprite,
                              float bbWidth, float bbHeight, float age, int layers, float billboardYawDegrees) {
        float boost = 1.0F + Math.min(layers, 32) * 0.012F;
        // 火焰单位尺度：以实体碰撞箱宽度为参照，头顶火苗比附身版更紧凑。
        float s = bbWidth * 1.15F * boost;
        // 火苗相对高度（尺度单位）：外环向上收分，光柱更高。
        float flameHeight = 1.25F;

        poseStack.pushPose();
        // 基座放到头顶之上：bbHeight 是头顶处的世界 Y，再留一小段空隙避免插进模型。
        poseStack.translate(0.0F, bbHeight + 0.06F * s, 0.0F);
        poseStack.mulPose(Axis.YP.rotationDegrees(billboardYawDegrees));
        poseStack.scale(s, s, s);
        // 整体轻微浮动：让静态的火苗垂直“呼吸”起来。
        poseStack.translate(0.0F, 0.02F * Mth.sin(age * 0.25F), 0.0F);

        float u0 = sprite.getU0();
        float u1 = sprite.getU1();
        float v0 = sprite.getV0();
        float v1 = sprite.getV1();

        // ---- 外环火舌：自基座向上逐层堆叠、收分的相机朝向面片 ----
        float halfW = 0.5F;
        float bottom = 0.0F;
        float remaining = flameHeight;
        int layer = 0;
        PoseStack.Pose pose = poseStack.last();
        while (remaining > 0.0F) {
            float wobble = 1.0F + 0.06F * Mth.sin(age * 0.32F + layer * 1.7F);
            float w = halfW * wobble;
            float a = u0;
            float b = u1;
            if ((layer / 2) % 2 == 1) {
                float t = a;
                a = b;
                b = t;
            }
            int alpha = (int) (208.0F + 40.0F * Mth.sin(age * 0.45F + layer * 0.8F));
            alpha = Mth.clamp(alpha, 150, 255);
            vertex(pose, consumer, -w, bottom, 0.0F, b, v1, 255, 243, 210, alpha);
            vertex(pose, consumer, w, bottom, 0.0F, a, v1, 255, 243, 210, alpha);
            vertex(pose, consumer, w, bottom + 1.0F, 0.0F, a, v0, 255, 243, 210, alpha);
            vertex(pose, consumer, -w, bottom + 1.0F, 0.0F, b, v0, 255, 243, 210, alpha);
            remaining -= LAYER_STEP;
            bottom += LAYER_STEP;
            halfW *= LAYER_TAPER;
            layer++;
        }

        // ---- 内核光柱：45° 与 135° 两束，更高更白，阳火自有特征（双面发射，背面不剔除也可见） ----
        poseStack.mulPose(Axis.YP.rotationDegrees(45.0F));
        int coreAlpha = Mth.clamp(150 + layers * 3, 150, 235);
        float coreH = flameHeight * 1.35F;
        for (int i = 0; i < 2; i++) {
            PoseStack.Pose core = poseStack.last();
            float cw = 0.30F * (1.0F + 0.05F * Mth.sin(age * 0.5F + i * 2.0F));
            vertex(core, consumer, -cw, 0.0F, 0.0F, u1, v1, 255, 252, 238, coreAlpha);
            vertex(core, consumer, cw, 0.0F, 0.0F, u0, v1, 255, 252, 238, coreAlpha);
            vertex(core, consumer, cw, coreH, 0.0F, u0, v0, 255, 252, 238, coreAlpha);
            vertex(core, consumer, -cw, coreH, 0.0F, u1, v0, 255, 252, 238, coreAlpha);
            vertex(core, consumer, -cw, coreH, 0.0F, u1, v0, 255, 252, 238, coreAlpha);
            vertex(core, consumer, cw, coreH, 0.0F, u0, v0, 255, 252, 238, coreAlpha);
            vertex(core, consumer, cw, 0.0F, 0.0F, u0, v1, 255, 252, 238, coreAlpha);
            vertex(core, consumer, -cw, 0.0F, 0.0F, u1, v1, 255, 252, 238, coreAlpha);
            poseStack.mulPose(Axis.YP.rotationDegrees(90.0F));
        }
        poseStack.popPose();
    }

    private static void vertex(PoseStack.Pose pose, VertexConsumer consumer,
                               float x, float y, float z, float u, float v,
                               int r, int g, int b, int a) {
        // 与原版 fireVertex 同规格：满方块光(240)让阳火自带辉光，属性一次填满 NEW_ENTITY 格式。
        consumer.vertex(pose.pose(), x, y, z).color(r, g, b, a).uv(u, v)
                .overlayCoords(0, 10).uv2(240).normal(pose.normal(), 0.0F, 1.0F, 0.0F).endVertex();
    }
}
