package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.BlockPos;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public final class BlackCrystalBlock extends Block {
    private static final int EFFECT_DURATION = 0;

    public BlackCrystalBlock(Properties properties) {
        super(properties);
    }

    private void infect(Entity entity) {
        if (entity.level().isClientSide || !(entity instanceof LivingEntity living) || !living.isAlive()) return;
        CalamityLogic.applySourceOreInfection(living, 1, EFFECT_DURATION);
        CalamityLogic.markInfectionExposure(living);
    }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        infect(entity);
        super.stepOn(level, pos, state, entity);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        infect(entity);
        super.entityInside(state, level, pos, entity);
    }
}
