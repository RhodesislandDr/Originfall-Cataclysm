package cn.blockforge.generated.originfallcataclysm.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;

/**
 * 首领武装火焰粒子：贴着武器表面燃起的小火苗，颜色由注册类型固定（博士金 / 普瑞赛斯紫）。
 *
 * <p>表现要点：</p>
 * <ul>
 *   <li><b>亮度</b>：走加法混合（{@link #ADDITIVE_SHEET}）而不是原版的半透明混合。加法混合下
 *       每一枚火苗都把自身颜色「加」到画面上，越靠近刀身粒子越密、亮度自然叠加，暗处会真的
 *       发光；半透明混合最多只能到纯白，叠不出这种光晕。加上恒定满亮度、偏亮的金/紫色，
 *       整体观感比原来亮一档。</li>
 *   <li><b>流畅</b>：每颗粒子带一个随机的明灭相位，且透明度走三次方缓降，因此整簇火焰是
 *       连续流动的，不会所有粒子同生同灭地一起闪；上升更平缓、水平抖动更小，火线更稳。</li>
 * </ul>
 *
 * <p>贴图本身是中性白，实际颜色由 {@code setColor} 乘上去。</p>
 */
public class WeaponFlameParticle extends TextureSheetParticle {

    /**
     * 加法混合的粒子渲染类型：混合模式与「发光」类特效一致（源 × 源 alpha，再加到目标上）。
     *
     * <p>其余设置照抄原版 {@code PARTICLE_SHEET_TRANSLUCENT}：绑定粒子图集、按 QUADS/PARTICLE
     * 顶点格式提交。只把混合函数与深度写入换成加法混合该有的样子。粒子引擎是按渲染类型
     * 分组建队列的，自定义类型会自动排在原版类型之后绘制，不需要额外注册。</p>
     */
    public static final ParticleRenderType ADDITIVE_SHEET = new ParticleRenderType() {
        @Override
        public void begin(BufferBuilder buffer, TextureManager textureManager) {
            // 不写深度：叠加出来的光晕不会在后续粒子之间留下硬边。
            RenderSystem.depthMask(false);
            RenderSystem.setShaderTexture(0, TextureAtlas.LOCATION_PARTICLES);
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
            buffer.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.PARTICLE);
        }

        @Override
        public void end(Tesselator tesselator) {
            tesselator.end();
            // 把混合状态还给默认值，避免影响这一帧后面绘制的东西。
            RenderSystem.defaultBlendFunc();
            RenderSystem.depthMask(true);
        }

        @Override
        public String toString() {
            return "originfall_cataclysm:weapon_flame_additive";
        }
    };

    /** 金：博士。整体比原版更亮、更接近火焰芯的黄白。 */
    public static final float[] GOLD = {1.00F, 0.86F, 0.44F};
    /** 紫：普瑞赛斯。提高 G 通道，避免在暗处糊成纯黑紫。 */
    public static final float[] PURPLE = {0.84F, 0.54F, 1.00F};

    private final SpriteSet sprites;
    private final float baseSize;
    /** 0~1 的随机相位：让每颗粒子的明灭互不同步，整簇火焰因此是连续流动的。 */
    private final float phase;

    protected WeaponFlameParticle(ClientLevel level, SpriteSet sprites, double x, double y, double z,
                                  double vx, double vy, double vz, float red, float green, float blue) {
        super(level, x, y, z, vx, vy, vz);
        this.sprites = sprites;
        this.setColor(red, green, blue);
        this.baseSize = 0.24F + this.random.nextFloat() * 0.22F;
        this.phase = this.random.nextFloat();
        this.quadSize = this.baseSize;
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        // 轻微上浮，并且横向阻尼更大：火苗沿着武器缓缓上升，不会左右乱飘。
        this.gravity = -0.02F;
        this.friction = 0.96F;
        this.hasPhysics = false;
        this.lifetime = 12 + this.random.nextInt(9);
        this.alpha = 1.0F;
        this.setSpriteFromAge(sprites);
    }

    @Override
    public void tick() {
        super.tick();
        this.setSpriteFromAge(this.sprites);
        // 三次方缓降：大部分寿命里保持接近全亮，只到最后才淡出，视觉上更亮也更顺。
        float progress = Mth.clamp(((float) this.age + this.phase) / (float) this.lifetime, 0.0F, 1.0F);
        this.alpha = 1.0F - progress * progress * progress;
    }

    @Override
    public float getQuadSize(float scaleFactor) {
        float progress = Mth.clamp(
                ((float) this.age + scaleFactor + this.phase) / (float) this.lifetime, 0.0F, 1.0F);
        // 先迅速窜大再缓慢收缩，像火苗被点燃后窜起来再熄灭。
        float grow = progress < 0.22F ? 0.82F + progress * 1.1F : 1.06F - (progress - 0.22F) * 0.62F;
        return this.baseSize * grow;
    }

    @Override
    protected int getLightColor(float partialTick) {
        // 火焰自带光辉：恒定满亮度，不受环境光影响。
        return 15728880;
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ADDITIVE_SHEET;
    }

    public static ParticleProvider<SimpleParticleType> golden(SpriteSet sprites) {
        return (type, level, x, y, z, vx, vy, vz) -> new WeaponFlameParticle(
                level, sprites, x, y, z, vx, vy, vz, GOLD[0], GOLD[1], GOLD[2]);
    }

    public static ParticleProvider<SimpleParticleType> purple(SpriteSet sprites) {
        return (type, level, x, y, z, vx, vy, vz) -> new WeaponFlameParticle(
                level, sprites, x, y, z, vx, vy, vz, PURPLE[0], PURPLE[1], PURPLE[2]);
    }
}
