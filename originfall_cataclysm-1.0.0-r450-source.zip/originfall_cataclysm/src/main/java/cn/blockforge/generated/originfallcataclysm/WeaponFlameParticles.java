package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * 首领武装火焰粒子注册。
 *
 * <p>「预言家」博士与「女祭司」普瑞赛斯手持武器时，武器表面会持续燃起火焰并在挥砍时留下拖尾：
 * 博士为金色火焰，普瑞赛斯为紫色火焰。两者共用同一张粒子贴图，颜色由
 * {@code WeaponFlameParticle} 在构造时按注册类型着色，因此这里只需要注册两个粒子类型。</p>
 *
 * <p>整套表现完全在客户端生成（见 {@code client.WeaponFlameEvents}），粒子不参与任何伤害、
 * 属性或状态判定，也不随存档同步，纯装饰。</p>
 */
public final class WeaponFlameParticles {

    public static final DeferredRegister<ParticleType<?>> PARTICLE_TYPES =
            DeferredRegister.create(ForgeRegistries.Keys.PARTICLE_TYPES, GeneratedMod.MOD_ID);

    /** 博士武装上的金色火焰。 */
    public static final RegistryObject<SimpleParticleType> GOLDEN_WEAPON_FLAME =
            PARTICLE_TYPES.register("golden_weapon_flame", () -> new SimpleParticleType(true));

    /** 普瑞赛斯武装上的紫色火焰。 */
    public static final RegistryObject<SimpleParticleType> PURPLE_WEAPON_FLAME =
            PARTICLE_TYPES.register("purple_weapon_flame", () -> new SimpleParticleType(true));

    private WeaponFlameParticles() {
    }

    public static void init(IEventBus modBus) {
        PARTICLE_TYPES.register(modBus);
    }
}
