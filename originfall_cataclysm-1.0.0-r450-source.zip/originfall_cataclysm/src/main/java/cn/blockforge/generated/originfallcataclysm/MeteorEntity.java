package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.Direction;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

public final class MeteorEntity extends Entity {
    private static final EntityDataAccessor<Float> DATA_DAMAGE_MULTIPLIER =
            SynchedEntityData.defineId(MeteorEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DATA_SIZE_MULTIPLIER =
            SynchedEntityData.defineId(MeteorEntity.class, EntityDataSerializers.FLOAT);
    private static final String IMPACT_Y = "ImpactY";
    private static final String DAMAGE_MULTIPLIER = "DamageMultiplier";
    private static final String SIZE_MULTIPLIER = "SizeMultiplier";
    private static final String TARGET_UUID = "TargetUUID";
    private static final String TARGETED = "Targeted";
    private static final String PLANE_CHILD_SUMMONED = "PlaneChildSummoned";
    private static final String REVIVE_KILLED_ENTITIES = "ReviveKilledEntities";
    private static final String DEATH_SUMMONED_METEOR = "DeathSummonedMeteor";
    private static final String WARNING_SOUND_PLAYED = "WarningSoundPlayed";
    private static final String REVIVAL_WAVE_ID = "RevivalWaveId";
    private static final String HORIZONTAL_TRACKING = "HorizontalTracking";
    private static final double FALL_SPEED = 0.5D;
    private static final double TARGETED_FALL_SPEED = 0.5D;
    private static final int MAX_DERIVATIVE_DEPTH = 5;
    private static final String DERIVATIVE_DEPTH = "DerivativeDepth";
    private int impactY;
    private float damageMultiplier = 1.0F;
    private float sizeMultiplier = 1.0F;
    private java.util.UUID targetUuid;
    private boolean targeted;
    private boolean forcedImpact;
    private boolean targetLost;
    private boolean planeChildSummoned;
    private boolean reviveKilledEntities;
    private boolean warningSoundPlayed;
    private int derivativeDepth;
    private java.util.UUID revivalVictimUuid;
    private java.util.UUID revivalKillerUuid;
    private float revivalExtraKillScale;
    private CompoundTag revivalVictimTag;
    private java.util.UUID revivalWaveId;
    private boolean horizontalTracking;
    private long cameraLockUntil;

    public MeteorEntity(EntityType<? extends MeteorEntity> type, Level level) {
        super(type, level);
        this.noCulling = true;
        this.impactY = 0;
    }

    public static MeteorEntity create(ServerLevel level, double x, double z) {
        return createNatural(level, x, z);
    }

    public static MeteorEntity createTargeted(ServerLevel level, LivingEntity target) {
        return createTargeted(level, target, 1000.0F, 200.0F, true);
    }

    public static MeteorEntity createTargetedNatural(ServerLevel level, LivingEntity target, int sourceDepth) {
        MeteorEntity meteor = createTargeted(level, target, 1.0F, 1.0F, true);
        meteor.derivativeDepth = Math.max(0, Math.min(MAX_DERIVATIVE_DEPTH, sourceDepth));
        return meteor;
    }

    /**
     * 按指定倍率生成一颗锁定制导陨石（不携带复活波次）。
     * 用于「天灾学者」等按攻击次数量产陨石的技能：陨石锁定目标后可横向移动追踪。
     */
    public static MeteorEntity createScaledTargeted(ServerLevel level, LivingEntity target,
                                                     float damageMultiplier, float sizeMultiplier) {
        return createTargeted(level, target, Math.max(1.0F, damageMultiplier),
                Math.max(1.0F, sizeMultiplier), false);
    }

    public static MeteorEntity createRevival(ServerLevel level, CalamityMob victim, LivingEntity killer,
                                              CompoundTag snapshot, float damage, float size, float extraKillScale) {
        return createRevival(level, victim, killer, snapshot, damage, size, extraKillScale, null);
    }

    public static MeteorEntity createRevival(ServerLevel level, CalamityMob victim, LivingEntity killer,
                                              CompoundTag snapshot, float damage, float size, float extraKillScale,
                                              java.util.UUID waveId) {
        MeteorEntity meteor = killer == null
                ? createNatural(level, victim.getX(), victim.getZ())
                : createTargeted(level, killer, damage, size, false);
        if (killer != null) meteor.revivalKillerUuid = killer.getUUID();
        meteor.reviveKilledEntities = true;
        meteor.getPersistentData().putBoolean(DEATH_SUMMONED_METEOR, true);
        meteor.revivalVictimUuid = victim.getUUID();
        meteor.revivalVictimTag = snapshot.copy();
        meteor.revivalExtraKillScale = extraKillScale;
        meteor.revivalWaveId = waveId;
        meteor.horizontalTracking = killer != null;
        return meteor;
    }

    public static MeteorEntity createRevivalAtRandom(ServerLevel level, CalamityMob victim,
                                                       CompoundTag snapshot, float damage, float size,
                                                       float extraKillScale, java.util.UUID waveId) {
        double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
        double distance = 4.0D + level.getRandom().nextDouble() * 32.0D;
        MeteorEntity meteor = createNatural(level, victim.getX() + Math.cos(angle) * distance,
                victim.getZ() + Math.sin(angle) * distance);
        meteor.setImpactTier(damage, size);
        meteor.reviveKilledEntities = true;
        meteor.getPersistentData().putBoolean(DEATH_SUMMONED_METEOR, true);
        meteor.revivalVictimUuid = victim.getUUID();
        meteor.revivalVictimTag = snapshot.copy();
        meteor.revivalExtraKillScale = extraKillScale;
        meteor.revivalWaveId = waveId;
        return meteor;
    }

    public static MeteorEntity createRevivalAtTarget(ServerLevel level, CalamityMob victim, LivingEntity target,
                                                       CompoundTag snapshot, float damage, float size,
                                                       float extraKillScale, java.util.UUID waveId) {
        MeteorEntity meteor = createTargeted(level, target, damage, size, false);
        meteor.reviveKilledEntities = true;
        meteor.getPersistentData().putBoolean(DEATH_SUMMONED_METEOR, true);
        meteor.revivalVictimUuid = victim.getUUID();
        meteor.revivalVictimTag = snapshot.copy();
        meteor.revivalExtraKillScale = extraKillScale;
        meteor.revivalWaveId = waveId;
        return meteor;
    }

    private static MeteorEntity createTargeted(ServerLevel level, LivingEntity requestedTarget,
                                                float damage, float size, boolean planeChildSummoned) {
        LivingEntity target = CalamityLogic.findGuidedMeteorInitialTarget(level, requestedTarget);
        MeteorEntity meteor = new MeteorEntity(GeneratedMod.METEOR.get(), level);
        // 请求目标本身是哈气贤者且附近没有其他目标时，仍保留“制导中”的状态，
        // 让下一 tick 按失去首个目标后的接管规则锁定贤者，而不是随机坠落。
        meteor.targeted = target != null || requestedTarget instanceof PureSourceOreGolem;
        meteor.targetUuid = target == null ? null : target.getUUID();
        meteor.targetLost = target == null;
        meteor.planeChildSummoned = planeChildSummoned;
        meteor.horizontalTracking = true;
        meteor.setImpactTier(damage, size);
        LivingEntity spawnAnchor = target == null ? requestedTarget : target;
        meteor.impactY = net.minecraft.util.Mth.floor(spawnAnchor.getY());
        double spawnY = Math.min(200.0D + level.getRandom().nextDouble() * 55.0D,
                level.getMaxBuildHeight() - 1.0D);
        double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
        double distance = level.getRandom().nextDouble() * 18.0D;
        meteor.setPos(spawnAnchor.getX() + Math.cos(angle) * distance, spawnY,
                spawnAnchor.getZ() + Math.sin(angle) * distance);
        return meteor;
    }

    public static MeteorEntity createNatural(ServerLevel level, double x, double z) {
        return createNatural(level, x, z, 0);
    }

    private static MeteorEntity createNatural(ServerLevel level, double x, double z, int depth) {
        MeteorEntity meteor = new MeteorEntity(GeneratedMod.METEOR.get(), level);
        meteor.derivativeDepth = Math.max(0, Math.min(MAX_DERIVATIVE_DEPTH, depth));
        meteor.setImpactTier(level.getRandom().nextFloat());
        initializePosition(meteor, level, x, z);
        return meteor;
    }

    /** 创建死亡后召唤的陨石；该类陨石会执行死亡继承计算。 */
    public static MeteorEntity createNaturalRevival(ServerLevel level, double x, double z) {
        return createNaturalRevival(level, x, z, null);
    }

    public static MeteorEntity createNaturalRevival(ServerLevel level, double x, double z, java.util.UUID waveId) {
        MeteorEntity meteor = createNatural(level, x, z);
        meteor.reviveKilledEntities = true;
        meteor.getPersistentData().putBoolean(DEATH_SUMMONED_METEOR, true);
        meteor.revivalWaveId = waveId;
        return meteor;
    }

    public boolean isDeathSummonedMeteor() {
        return reviveKilledEntities;
    }

    public boolean belongsToRevivalWave(java.util.UUID waveId) {
        return reviveKilledEntities && revivalWaveId != null && revivalWaveId.equals(waveId);
    }

    /** 在复活波次的固定 20 秒判定点强制完成陨石落地。 */
    public void resolveAtRevivalDeadline() {
        if (isRemoved() || !reviveKilledEntities || !(level() instanceof ServerLevel server)) return;
        LivingEntity target = findTarget(server);
        if (target == null && targeted) {
            target = CalamityLogic.findGuidedMeteorSage(server, getX(), getY(), getZ());
            if (target != null) {
                targetUuid = target.getUUID();
                targetLost = true;
            }
        }
        if (target != null) {
            setPos(target.getX(), target.getBoundingBox().maxY, target.getZ());
        } else {
            setPos(getX(), impactY + 0.1D, getZ());
        }
        forcedImpact = true;
        impact();
    }

    /**
     * 文明延续开局陨石：优先把落点放在半径内的非玩家生物上；没有可选生物时，
     * 按自然陨石规则在圆形范围内随机落点。
     */
    public static MeteorEntity createNaturalPrioritizingNonPlayer(ServerLevel level, LivingEntity player,
                                                                    double radius) {
        java.util.List<LivingEntity> entities = level.getEntitiesOfClass(LivingEntity.class,
                player.getBoundingBox().inflate(radius),
                entity -> entity.isAlive() && entity != player && !(entity instanceof Player)
                        && entity.distanceToSqr(player) <= radius * radius);
        if (!entities.isEmpty()) {
            LivingEntity target = entities.get(level.getRandom().nextInt(entities.size()));
            return createTargetedNatural(level, target, 0);
        }
        double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
        double distance = Math.sqrt(level.getRandom().nextDouble()) * radius;
        return createNatural(level, player.getX() + Math.cos(angle) * distance,
                player.getZ() + Math.sin(angle) * distance);
    }

    public static MeteorEntity createNaturalForPlayer(ServerLevel level, LivingEntity player, double radius) {
        double roll = level.getRandom().nextDouble();
        LivingEntity target = null;
        boolean princessInfluence = !level.getEntitiesOfClass(CalamityPrincess.class, player.getBoundingBox().inflate(32.0D),
                princess -> princess.isAlive() && princess.distanceToSqr(player) <= 1024.0D).isEmpty();
        if (princessInfluence) {
            target = CalamityLogic.highestHealthTarget(level, player, radius);
        } else if (roll < 0.45D) {
            java.util.List<LivingEntity> entities = level.getEntitiesOfClass(LivingEntity.class,
                    player.getBoundingBox().inflate(radius),
                    entity -> entity.isAlive() && CalamityLogic.isMeteorTarget(entity, player, radius));
            if (!entities.isEmpty()) target = entities.get(level.getRandom().nextInt(entities.size()));
        } else if (roll >= 0.95D) {
            target = player;
        }

        double x;
        double z;
        if (target != null) {
            x = target.getX();
            z = target.getZ();
        } else {
            double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
            double distance = Math.sqrt(level.getRandom().nextDouble()) * radius;
            x = player.getX() + Math.cos(angle) * distance;
            z = player.getZ() + Math.sin(angle) * distance;
        }
        return createNatural(level, x, z);
    }

    private static MeteorEntity initializePosition(MeteorEntity meteor, ServerLevel level, double x, double z) {
        int ix = net.minecraft.util.Mth.floor(x);
        int iz = net.minecraft.util.Mth.floor(z);
        meteor.impactY = level.getHeight(Heightmap.Types.MOTION_BLOCKING, ix, iz);
        double spawnY = 200.0D + level.getRandom().nextDouble() * 55.0D;
        int top = level.getMaxBuildHeight() - 1;
        meteor.setPos(x + 0.5D, Math.min(spawnY, top), z + 0.5D);
        return meteor;
    }

    private void setImpactTier(float roll) {
        // 原有倍率的出现概率全部减半，并新增 0.5 倍率，占剩余的 50%。
        if (roll < 0.50F) {
            setImpactTier(0.5F, 0.5F);
        } else if (roll < 0.90F) {
            setImpactTier(1.0F, 1.0F);
        } else if (roll < 0.95F) {
            setImpactTier(2.0F, 2.0F);
        } else if (roll < 0.99445F) {
            setImpactTier(5.0F, 5.0F);
        } else if (roll < 0.99945F) {
            setImpactTier(10.0F, 10.0F);
        } else if (roll < 0.99995F) {
            setImpactTier(100.0F, 100.0F);
        } else {
            setImpactTier(1000.0F, 200.0F);
        }
    }

    private void setImpactTier(float damage, float size) {
        damageMultiplier = damage;
        entityData.set(DATA_DAMAGE_MULTIPLIER, damage);
        setSizeMultiplier(size);
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(DATA_DAMAGE_MULTIPLIER, 1.0F);
        entityData.define(DATA_SIZE_MULTIPLIER, 1.0F);
    }

    public float getDamageMultiplier() {
        return entityData.get(DATA_DAMAGE_MULTIPLIER);
    }

    /** 返回陨石体积相对基础陨石的倍数；模型和影响半径按立方根换算。 */
    public float getSizeMultiplier() {
        return entityData.get(DATA_SIZE_MULTIPLIER);
    }

    public float getLinearSizeMultiplier() {
        return (float) Math.cbrt(getSizeMultiplier());
    }

    private void setSizeMultiplier(float multiplier) {
        sizeMultiplier = multiplier;
        entityData.set(DATA_SIZE_MULTIPLIER, multiplier);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            spawnTrail();
            return;
        }
        ServerLevel serverLevel = (ServerLevel) level();
        playWarningSound(serverLevel);
        if (damageMultiplier >= 1000.0F) {
            if (cameraLockUntil == 0L) cameraLockUntil = serverLevel.getGameTime() + 40L;
            for (Player player : serverLevel.players()) {
                if (player instanceof ServerPlayer serverPlayer && serverPlayer.distanceToSqr(this) <= 36864.0D
                        && !CalamityLogic.isHoldingSourceOfRuin(serverPlayer)) {
                    if (serverLevel.getGameTime() < cameraLockUntil) {
                        serverPlayer.lookAt(EntityAnchorArgument.Anchor.EYES, this, EntityAnchorArgument.Anchor.EYES);
                    }
                    CalamityLogic.applySourceOreInfection(serverPlayer, 1, 0);
                }
            }
        }

        if (targeted && !forcedImpact) {
            LivingEntity target = findTarget((ServerLevel) level());
            if (target == null) {
                // 制导陨石原目标失效后，灾厄范围内存在哈气贤者时强制改锁贤者；
                // 哈气贤者只有在目标已经丢失后才能成为锁定目标，绝不作为第一目标。
                LivingEntity sage = CalamityLogic.findGuidedMeteorSage(serverLevel, getX(), getY(), getZ());
                if (sage != null) {
                    targetUuid = sage.getUUID();
                    target = sage;
                    targetLost = true;
                    impactY = net.minecraft.util.Mth.floor(target.getY());
                } else {
                    targeted = false;
                    targetUuid = null;
                    impactY = serverLevel.getHeight(Heightmap.Types.MOTION_BLOCKING,
                            blockPosition().getX(), blockPosition().getZ());
                }
            }
            if (target != null) {
                // 所有锁定陨石都检查飞向目标的路径；遇到方块遮挡时立即在遮挡处落地。
                Vec3 targetTop = new Vec3(target.getX(), target.getBoundingBox().maxY, target.getZ());
                BlockHitResult obstruction = (BlockHitResult) level().clip(new ClipContext(position(), targetTop,
                        ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, this));
                if (obstruction.getType() != HitResult.Type.MISS) {
                    setPos(obstruction.getLocation().x, obstruction.getLocation().y, obstruction.getLocation().z);
                    forcedImpact = true;
                    impact();
                    return;
                }
                if (getY() - TARGETED_FALL_SPEED <= target.getBoundingBox().maxY) {
                    setPos(target.getX(), target.getBoundingBox().maxY, target.getZ());
                    forcedImpact = true;
                    impact();
                    return;
                }
                setPos(target.getX(), getY(), target.getZ());
            }
        }

        double fallSpeed = targeted ? TARGETED_FALL_SPEED : FALL_SPEED;
        if (getY() - fallSpeed <= impactY + 0.1D) {
            setPos(getX(), impactY + 0.1D, getZ());
            impact();
            return;
        }
        setDeltaMovement(0.0D, -fallSpeed, 0.0D);
        Vec3 beforeMove = position();
        move(net.minecraft.world.entity.MoverType.SELF, getDeltaMovement());
        if (hasBlockContact(beforeMove) || hasEntityContact()) {
            impact();
            return;
        }
        if (tickCount % 4 == 0) {
            ((ServerLevel) level()).sendParticles(ParticleTypes.FLAME, getX(), getY(), getZ(), 4, 0.35D, 0.35D, 0.35D, 0.02D);
            ((ServerLevel) level()).sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY(), getZ(), 3, 0.3D, 0.3D, 0.3D, 0.01D);
        }
    }

    private LivingEntity findTarget(ServerLevel server) {
        if (targetUuid == null) return null;
        Entity entity = server.getEntity(targetUuid);
        return entity instanceof LivingEntity living && living.isAlive() ? living : null;
    }

    private void playWarningSound(ServerLevel server) {
        if (warningSoundPlayed || damageMultiplier < 1000.0F) return;
        // 在陨石真正开始下落后播放一次，避免实体尚未加入世界时丢失声音。
        warningSoundPlayed = true;
        // 模组生物死亡后召唤的复活陨石不播报天灾音乐：这类陨石是死亡/复活演出的延伸，
        // 音乐应留给死亡方自身（例如「预言家」博士死亡时的巴别塔回忆），否则复活陨石的
        // 坠落音乐会反过来打断它。这里既不播放，也不登记播放期。
        if (isDeathSummonedMeteor()) return;
        // 内化宇宙音乐全服播放期间，不播报1000倍陨石坠落音乐，避免与宇宙音乐叠播。
        if (UniverseLightLogic.isUniverseMusicActive()) return;
        // 「扒臀舞」琵琶曲是最高优先级：在播期间本音乐同样让位，不得打断舞曲。
        if (TauntSongMusic.isActive()) return;
        // 1000倍陨石坠落音乐音量相对满音降低50%（0.5F），避免单颗1000倍陨石过响。
        for (ServerPlayer player : server.getServer().getPlayerList().getPlayers()) {
            player.playNotifySound(GeneratedMod.CALAMITY_MUSIC.get(),
                    net.minecraft.sounds.SoundSource.MASTER, 0.5F, 1.0F);
        }
        // 陨石坠落音乐优先级高于「巴别塔回忆」音乐：登记其播放期并打断正在播放的巴别塔回忆音乐。
        BabelMemoryMusic.onCalamityMusicPlayed(server);
    }

    private void spawnTrail() {
        if (tickCount % 2 == 0) {
            level().addParticle(ParticleTypes.FLAME, getX(), getY() + 0.2D, getZ(), 0.0D, -0.05D, 0.0D);
            level().addParticle(ParticleTypes.SMOKE, getX(), getY() + 0.1D, getZ(), 0.0D, -0.03D, 0.0D);
        }
        if (impactY > 0 && getY() - impactY < 24.0D) {
            level().addParticle(ParticleTypes.LAVA, getX(), impactY + 0.2D, getZ(), 0.0D, 0.02D, 0.0D);
            if (tickCount % 4 == 0) {
                level().addParticle(ParticleTypes.EXPLOSION, getX(), impactY + 0.5D, getZ(), 0.0D, 0.0D, 0.0D);
            }
        }
    }

    private boolean hasBlockContact(Vec3 beforeMove) {
        AABB swept = getBoundingBox().minmax(getBoundingBox().move(beforeMove.subtract(position())));
        boolean occupied = net.minecraft.core.BlockPos.betweenClosedStream(swept.inflate(0.01D))
                .anyMatch(pos -> !level().getBlockState(pos).isAir());
        return occupied || horizontalCollision || verticalCollision || !level().noCollision(this)
                || !level().noCollision(swept);
    }

    private boolean hasEntityContact() {
        double collisionRadius = 0.15D + 0.5D * getLinearSizeMultiplier();
        AABB area = getBoundingBox().inflate(collisionRadius);
        return !level().getEntities(this, area,
                entity -> entity.isAlive() && !(entity instanceof MeteorEntity)).isEmpty();
    }

    private void impact() {
        ServerLevel server = (ServerLevel) level();
        float multiplier = damageMultiplier;
        // 「源石计划进度」：爆炸伤害按档位幅度缩放，向下取整（系数 0.01~1.70）。
        // 半径的缩放值同时用于伤害衰减与爆炸粒子，确保两者边界一致。
        float progressFactor = (float) OriginiumPlanProgress.factor(server);
        // 半径保底 1 格：低档位缩小倍率后不能出现零半径导致的除零与判定失效。
        float blastRadius = Math.max(1.0F, (float) Math.floor(getBlastRadius() * progressFactor));
        // 需求：难度档位对地形感染（晶化替换）的影响降为原影响比例的 10%（系数 0.901~1.07），
        // 晶化半径与爆炸伤害半径解耦，各自保底 1 格。
        float crystalRadius = Math.max(1.0F,
                (float) Math.floor(getBlastRadius() * OriginiumPlanProgress.terrainFactor(server)));
        float landingRoll = server.getRandom().nextFloat();
        boolean replace = landingRoll >= 0.50F && landingRoll < 0.95F;
        boolean retain = landingRoll >= 0.95F;
        // 100 倍及以上陨石即使抽到保留结果，也必须执行暴露方块替换。
        if (multiplier >= 100.0F) replace = true;

        // 5% 的落地结果保留陨石本体，不触发爆炸、伤害或衍生陨石；方块实体继续提供原有效果。
        if (retain) {
            if (replace) replaceExposedBlocksWithCrystal(server, Math.min(128.0F, crystalRadius));
            if (revivalWaveId != null) CalamityLogic.completeRevivalWaveMeteor(server, revivalWaveId);
            BlockPos pos = blockPosition();
            if (server.getBlockState(pos).isAir() || server.getBlockState(pos).canBeReplaced()) {
                server.setBlock(pos, GeneratedMod.METEOR_BLOCK.get().defaultBlockState(), 3);
            }
            discard();
            return;
        }

        // 复活陨石也可以按原规则衍生；衍生陨石不携带复活波次 ID，击杀不会计入复活数据。
        spawnChildren(server);

        // 所有爆炸都不破坏地形；替换结果只把暴露面上的方块改成黑色晶体。
        server.playSound(null, blockPosition(), net.minecraft.sounds.SoundEvents.GENERIC_EXPLODE,
                net.minecraft.sounds.SoundSource.BLOCKS, Math.min(8.0F, 1.5F + multiplier / 100.0F), 0.65F);
        DamageSource source = server.damageSources().explosion(this, this);
        applyScaledDamage(source, multiplier, blastRadius);

        if (replace) {
            replaceExposedBlocksWithCrystal(server, Math.min(128.0F, crystalRadius));
        }
        spawnImpactEffect(server, multiplier, blastRadius);
        if (multiplier >= 100.0F) {
            for (Player player : server.players()) {
                if (player.distanceToSqr(this) < 25600.0D) {
                    player.displayClientMessage(net.minecraft.network.chat.Component.literal("§6§l源石天灾：超规格撞击"), true);
                }
            }
        }
        if (multiplier >= 1000.0F) {
            applyCataclysmEffect(server);
        }
        discard();
    }

    /** 爆炸粒子按实际生效的（进度缩放后的）半径布置。 */
    private void spawnImpactEffect(ServerLevel server, float multiplier, double blastRadius) {
        double radius = blastRadius;
        if (multiplier >= 1000.0F) {
            spawnMushroomCloud(server, radius);
            return;
        }

        // 每个爆炸粒子都是原版 TNT 的完整爆炸动画，外圈按实际伤害半径布置。
        int shellCount = net.minecraft.util.Mth.clamp(net.minecraft.util.Mth.ceil(radius * 4.0D), 8, 96);
        server.sendParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY(), getZ(), 1,
                0.0D, 0.0D, 0.0D, 0.0D);
        for (int i = 0; i < shellCount; i++) {
            double theta = server.getRandom().nextDouble() * Math.PI * 2.0D;
            double phi = Math.acos(2.0D * server.getRandom().nextDouble() - 1.0D);
            double shellRadius = radius * (0.62D + server.getRandom().nextDouble() * 0.38D);
            double sinPhi = Math.sin(phi);
            double x = getX() + Math.cos(theta) * sinPhi * shellRadius;
            double y = getY() + Math.cos(phi) * shellRadius;
            double z = getZ() + Math.sin(theta) * sinPhi * shellRadius;
            server.sendParticles(ParticleTypes.EXPLOSION_EMITTER, x, y, z, 1,
                    0.0D, 0.0D, 0.0D, 0.0D);
        }
        int flashCount = net.minecraft.util.Mth.clamp(net.minecraft.util.Mth.ceil(radius * 2.0D), 8, 48);
        server.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.4D, getZ(), flashCount,
                radius * 0.45D, radius * 0.35D, radius * 0.45D, 0.02D);
    }

    private void spawnMushroomCloud(ServerLevel server, double radius) {
        double stemHeight = radius * 1.35D;
        int stemCount = net.minecraft.util.Mth.clamp(net.minecraft.util.Mth.ceil(radius * 2.5D), 24, 64);
        server.sendParticles(ParticleTypes.FLAME, getX(), getY() + stemHeight * 0.32D, getZ(),
                stemCount, radius * 0.22D, stemHeight * 0.32D, radius * 0.22D, 0.04D);
        server.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + stemHeight * 0.55D, getZ(),
                stemCount, radius * 0.28D, stemHeight * 0.42D, radius * 0.28D, 0.02D);

        double capY = getY() + stemHeight;
        int capCount = net.minecraft.util.Mth.clamp(net.minecraft.util.Mth.ceil(radius * 4.0D), 40, 96);
        server.sendParticles(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE, getX(), capY, getZ(),
                Math.max(1, capCount / 8), radius * 0.6D, radius * 0.18D, radius * 0.6D, 0.03D);
        server.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), capY, getZ(), capCount,
                radius * 0.72D, radius * 0.25D, radius * 0.72D, 0.035D);
        server.sendParticles(ParticleTypes.SMOKE, getX(), capY + radius * 0.22D, getZ(),
                Math.max(12, capCount / 2), radius * 0.8D, radius * 0.3D, radius * 0.8D, 0.02D);
        server.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + radius * 0.2D, getZ(),
                Math.max(8, capCount / 4), radius * 0.55D, radius * 0.25D, radius * 0.55D, 0.02D);
    }

    private void replaceExposedBlocksWithCrystal(ServerLevel server, float radius) {
        BlockPos center = blockPosition();
        int extent = net.minecraft.util.Mth.ceil(radius);
        double radiusSquared = radius * radius;
        BlockState crystal = GeneratedMod.BLACK_CRYSTAL.get().defaultBlockState();
        for (int x = -extent; x <= extent; x++) {
            for (int y = -extent; y <= extent; y++) {
                for (int z = -extent; z <= extent; z++) {
                    if (x * x + y * y + z * z > radiusSquared) continue;
                    BlockPos pos = center.offset(x, y, z);
                    BlockState state = server.getBlockState(pos);
                    // 基岩、屏障这类无法破坏方块：游戏规则「规则改写」未开启时不被晶化。
                    if (state.isAir() || !state.getFluidState().isEmpty()
                            || state.is(GeneratedMod.BLACK_CRYSTAL.get())
                            || !CalamityLogic.infectedBlockAllowed(state, server, pos)) continue;
                    boolean touchesSolid = false;
                    boolean touchesAir = false;
                    for (Direction direction : Direction.values()) {
                        BlockState neighbor = server.getBlockState(pos.relative(direction));
                        if (neighbor.isAir()) touchesAir = true;
                        else touchesSolid = true;
                    }
                    if (touchesSolid && touchesAir) server.setBlock(pos, crystal, 3);
                }
            }
        }
    }

    private float getBlastRadius() {
        return Math.min(128.0F, 4.0F * getLinearSizeMultiplier());
    }

    private void applyScaledDamage(DamageSource source, float multiplier, float radius) {
        AABB area = new AABB(getX() - radius, getY() - radius, getZ() - radius,
                getX() + radius, getY() + radius, getZ() + radius);
        java.util.List<LivingEntity> killed = new java.util.ArrayList<>();
        int lethalKills = 0;
        for (Entity entity : level().getEntities(this, area, Entity::isAlive)) {
            if (!(entity instanceof LivingEntity living)) continue;
            double distance = distanceTo(living);
            if (distance > radius) continue;
            // 「源石计划进度」：爆炸伤害按档位幅度缩放后向下取整，保底 1 点。
            float damage = Math.max(1.0F, (float) Math.floor(20.0F * multiplier
                    * (1.0F - (float) (distance / radius)) * OriginiumPlanProgress.factor(level())));
            // 源石感染属于本模组负面效果，先强制附加，再按原规则处理爆炸伤害免疫。
            CalamityLogic.applySourceOreInfectionFromMeteor(living, multiplier);
            if (living instanceof SourceOreGolem golem) {
                golem.onMeteorBlast(multiplier);
                continue;
            }
            if (CalamityLogic.isMeteorAndCrystalImmune(living)) continue;
            float healthBefore = living.getHealth();
            double maxHealthBefore = living.getMaxHealth();
            double totalShieldBefore = living instanceof CalamityMob calamity
                    ? calamity.getTotalShield() : living.getArmorValue();
            double attackDamageBefore = living.getAttributes().hasAttribute(
                    net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE)
                    ? living.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE) : 2.0D;

            // 普通自然陨石的致死命中直接转化，不触发生物死亡；死亡后召唤的陨石
            // 才先完成真实击杀，再把被击杀的普通 Mob 纳入转化阶段。
            if (!reviveKilledEntities && healthBefore > 0.0F && damage >= healthBefore
                    && shouldConvertOnLethalHit(living)) {
                LivingEntity converted = convertLethalMob((Mob) living, maxHealthBefore,
                        healthBefore, totalShieldBefore, attackDamageBefore, false);
                if (converted != null) {
                    killed.add(converted);
                    lethalKills++;
                    continue;
                }
            }

            living.hurt(source, damage);
            // 陨石爆轰属于史诗战斗意义上的重击：按实际落点伤害决定把人打僵还是直接击倒。
            SkillCombatHooks.impact(living, damage, damage >= 12.0F
                    ? SkillCombatHooks.Impact.KNOCKDOWN : SkillCombatHooks.Impact.HEAVY);
            if (multiplier >= 10.0F) living.setSecondsOnFire(4);
            if (healthBefore > 0.0F && living.isDeadOrDying()) {
                if (living instanceof Mob mob && !(living instanceof CalamityMob)
                        && shouldConvertOnLethalHit(living)) {
                    LivingEntity converted = convertLethalMob(mob, maxHealthBefore,
                            healthBefore, totalShieldBefore, attackDamageBefore, true);
                    if (converted != null) {
                        // 死亡后陨石击杀普通生物并转化，仍计入本波次击杀数。
                        killed.add(converted);
                        lethalKills++;
                        continue;
                    }
                }
                killed.add(living);
            }
        }
        if (!level().isClientSide) {
            ServerLevel server = (ServerLevel) level();
            int collateral = lethalKills;
            for (LivingEntity living : killed) {
                // 统计本次爆炸真正击杀的实体；普通生物被转换时由 lethalKills 计入。
                if (living.isDeadOrDying()) collateral++;
            }
            if (revivalWaveId != null) {
                // targetUuid 只是无击杀者时的搜索目标，不能被误当成复活倍率判定中的击杀者。
                CalamityLogic.recordRevivalWaveKills(server, revivalWaveId, revivalKillerUuid, collateral);
                CalamityLogic.completeRevivalWaveMeteor(server, revivalWaveId);
            }
            // 兼容旧存档中没有波次 ID 的死亡陨石。
            if (revivalWaveId == null && revivalVictimUuid != null && revivalVictimTag != null) {
                LivingEntity legacyKiller = revivalKillerUuid == null ? null : findLivingByUuid(revivalKillerUuid);
                boolean killerKilled = legacyKiller != null && legacyKiller.isDeadOrDying();
                if (collateral > 0) {
                    double healthScale = killerKilled ? 1.0D + collateral * revivalExtraKillScale
                            : collateral * (revivalExtraKillScale == 1.0F ? 0.4D
                            : revivalExtraKillScale == 0.5F ? 0.5D : 0.1D);
                    CalamityLogic.scheduleCalamityRevival(server, revivalVictimTag, getX(), getY(), getZ(),
                            healthScale, healthScale, healthScale);
                }
            }
        }
    }

    private boolean shouldConvertOnLethalHit(LivingEntity living) {
        // 陨石击杀的普通 Mob 进入转化阶段；玩家、天灾生物、已转化生物与坍缩个体不重复转换。
        return living instanceof Mob && !(living instanceof Player) && !(living instanceof CalamityMob)
                && !CalamityLogic.isConversionImmuneTarget(living)
                && !CalamityLogic.isConvertedHostile(living)
                && !CalamityLogic.isCollapsed(living);
    }

    /**
     * 在死亡事件已经由 hurt() 触发后恢复原实体，再替换为转化实体。
     * 转化使用伤害前的生命、护盾和攻击力，因此不会把本次击杀当作复活继承。
     */
    private LivingEntity convertLethalMob(Mob original, double maxHealth, double currentHealth,
                                                    double totalShield, double attackDamage, boolean afterDeath) {
        // 生命上限归零的死亡不得借陨石转化链“复活”为灾厄生物；上限已为 0 的残留实体同样拒绝。
        if (MaxHealthZeroLogic.isCapZeroDeath(original) || maxHealth <= 0.0D) return null;
        if (afterDeath) original.revive();
        original.setHealth((float) Math.max(1.0D, currentHealth));
        // 陨石造成的主动击杀同样保留感染前属性，并按每层 10% 增幅。
        double infectionScale = CalamityLogic.conversionScaleFromInfection(original);
        return CalamityLogic.convertMob(original, maxHealth, currentHealth, totalShield, attackDamage,
                infectionScale);
    }

    private LivingEntity findLivingByUuid(java.util.UUID uuid) {
        Entity entity = ((ServerLevel) level()).getEntity(uuid);
        return entity instanceof LivingEntity living ? living : null;
    }

    private void applyCataclysmEffect(ServerLevel server) {
        for (Player player : server.players()) {
            if (player.distanceToSqr(this) <= 25600.0D
                    && !CalamityLogic.isHoldingSourceOfRuin(player)) {
                CalamityLogic.applySourceOreInfection(player, 1, 0);
            }
        }
    }

    private void spawnChildren(ServerLevel server) {
        // 派生深度从 0 开始计数；第 5 次递归的陨石仍可落地，但不再生成子陨石。
        if (derivativeDepth >= MAX_DERIVATIVE_DEPTH) return;
        // 1000 倍陨石是终点，禁止任何派生，避免位面之子链式生成超规格陨石。
        if (damageMultiplier >= 1000.0F) return;

        if (planeChildSummoned && targetUuid != null) {
            LivingEntity target = findTarget(server);
            if (target != null) {
                int count = 1 + server.getRandom().nextInt(3);
                for (int i = 0; i < count; i++) {
                    MeteorEntity child = createTargetedNaturalChild(server, target, derivativeDepth + 1);
                    server.addFreshEntity(child);
                }

            }
            return;
        }

        float roll = server.getRandom().nextFloat();
        int count = roll < 0.0001F ? 10 : roll < 0.0011F ? 3 : roll < 0.0111F ? 2 : roll < 0.1111F ? 1 : 0;
        for (int i = 0; i < count; i++) {
            double angle = server.getRandom().nextDouble() * Math.PI * 2.0D;
            double distance = 4.0D + server.getRandom().nextDouble() * 28.0D;
            MeteorEntity child = createNatural(server, getX() + Math.cos(angle) * distance,
                    getZ() + Math.sin(angle) * distance, derivativeDepth + 1);
            server.addFreshEntity(child);
        }
    }

    private static MeteorEntity createTargetedNaturalChild(ServerLevel level, LivingEntity target, int depth) {
        MeteorEntity meteor = createTargeted(level, target, 1.0F, 1.0F, true);
        meteor.derivativeDepth = depth;
        meteor.setImpactTier(level.getRandom().nextFloat());
        return meteor;
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt(IMPACT_Y, impactY);
        tag.putFloat(DAMAGE_MULTIPLIER, damageMultiplier);
        tag.putFloat(SIZE_MULTIPLIER, sizeMultiplier);
        tag.putBoolean(TARGETED, targeted);
        tag.putBoolean(PLANE_CHILD_SUMMONED, planeChildSummoned);
        tag.putBoolean(REVIVE_KILLED_ENTITIES, reviveKilledEntities);
        tag.putBoolean(WARNING_SOUND_PLAYED, warningSoundPlayed);
        tag.putInt(DERIVATIVE_DEPTH, derivativeDepth);
        if (targetUuid != null) tag.putUUID(TARGET_UUID, targetUuid);
        if (revivalVictimUuid != null) tag.putUUID("RevivalVictimUUID", revivalVictimUuid);
        if (revivalKillerUuid != null) tag.putUUID("RevivalKillerUUID", revivalKillerUuid);
        tag.putFloat("RevivalExtraKillScale", revivalExtraKillScale);
        tag.putBoolean(HORIZONTAL_TRACKING, horizontalTracking);
        tag.putLong("CameraLockUntil", cameraLockUntil);
        if (revivalWaveId != null) tag.putUUID(REVIVAL_WAVE_ID, revivalWaveId);
        if (revivalVictimTag != null) tag.put("RevivalVictimTag", revivalVictimTag.copy());
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        impactY = tag.getInt(IMPACT_Y);
        damageMultiplier = tag.contains(DAMAGE_MULTIPLIER) ? tag.getFloat(DAMAGE_MULTIPLIER) : 1.0F;
        entityData.set(DATA_DAMAGE_MULTIPLIER, damageMultiplier);
        setSizeMultiplier(tag.contains(SIZE_MULTIPLIER) ? tag.getFloat(SIZE_MULTIPLIER) : 1.0F);
        targeted = tag.getBoolean(TARGETED);
        planeChildSummoned = tag.getBoolean(PLANE_CHILD_SUMMONED);
        reviveKilledEntities = tag.getBoolean(REVIVE_KILLED_ENTITIES);
        warningSoundPlayed = tag.getBoolean(WARNING_SOUND_PLAYED);
        derivativeDepth = Math.max(0, Math.min(MAX_DERIVATIVE_DEPTH, tag.getInt(DERIVATIVE_DEPTH)));
        targetUuid = tag.hasUUID(TARGET_UUID) ? tag.getUUID(TARGET_UUID) : null;
        revivalVictimUuid = tag.hasUUID("RevivalVictimUUID") ? tag.getUUID("RevivalVictimUUID") : null;
        revivalKillerUuid = tag.hasUUID("RevivalKillerUUID") ? tag.getUUID("RevivalKillerUUID") : null;
        revivalExtraKillScale = tag.getFloat("RevivalExtraKillScale");
        horizontalTracking = tag.getBoolean(HORIZONTAL_TRACKING);
        cameraLockUntil = tag.getLong("CameraLockUntil");
        revivalWaveId = tag.hasUUID(REVIVAL_WAVE_ID) ? tag.getUUID(REVIVAL_WAVE_ID) : null;
        revivalVictimTag = tag.contains("RevivalVictimTag") ? tag.getCompound("RevivalVictimTag") : null;
    }

    @Override
    public Packet getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    public boolean isPickable() {
        return false;
    }
}
