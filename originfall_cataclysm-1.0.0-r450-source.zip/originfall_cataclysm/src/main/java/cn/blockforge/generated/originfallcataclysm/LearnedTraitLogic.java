package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;

import java.util.ArrayList;
import java.util.List;

/** 生物吞噬学习的规则、标签读取、行为赋予和客户端同步。 */
public final class LearnedTraitLogic {
    public static final String EXPLOSION = "explosion";
    public static final String TELEPORT = "teleport";
    public static final String FIRE_ATTACK = "fire_attack";
    public static final String WALL_CLIMB = "wall_climb";
    public static final String FLIGHT = "flight";
    public static final String RANGED_ATTACK = "ranged_attack";
    public static final String SWIM = "swim";
    public static final String JUMP = "jump";
    public static final String SPEED = "speed";
    public static final String REGENERATION = "regeneration";
    public static final String RESISTANCE = "resistance";
    public static final String KNOCKBACK = "knockback";
    /** 磁铁：吸入周围掉落物。独立形态下并入词条池，供首领初始随机附带与击杀学习。 */
    public static final String MAGNET = "magnet";

    private static final String CAPABILITY_PATH = "learned_traits";
    private static final TagKey<EntityType<?>> EXPLOSION_TAG = tag("explosion");
    private static final TagKey<EntityType<?>> TELEPORT_TAG = tag("teleport");
    private static final TagKey<EntityType<?>> FIRE_ATTACK_TAG = tag("fire_attack");
    private static final TagKey<EntityType<?>> WALL_CLIMB_TAG = tag("wall_climb");
    private static final TagKey<EntityType<?>> FLIGHT_TAG = tag("flight");
    private static final TagKey<EntityType<?>> RANGED_ATTACK_TAG = tag("ranged_attack");
    private static final TagKey<EntityType<?>> SWIM_TAG = tag("swim");
    private static final TagKey<EntityType<?>> JUMP_TAG = tag("jump");
    private static final TagKey<EntityType<?>> SPEED_TAG = tag("speed");
    private static final TagKey<EntityType<?>> REGENERATION_TAG = tag("regeneration");
    private static final TagKey<EntityType<?>> RESISTANCE_TAG = tag("resistance");
    private static final TagKey<EntityType<?>> KNOCKBACK_TAG = tag("knockback");
    private static final String EXPLOSION_COOLDOWN = "OriginFallLearnedExplosionCooldown";
    private static final String TRAIT_EFFECT_COOLDOWN = "OriginFallLearnedTraitEffectCooldown";
    /** 派生击杀标记：由溅射（时光之末）或派生真实伤害（源石之始/流放虚空）造成，非近战直接击杀。 */
    private static final String DERIVED_KILL_TAG = "OriginFallDerivedKill";
    /** 击杀归属账本：受害者最近一次被本模组学习者伤害的攻击者 UUID。 */
    private static final String KILL_CREDIT_UUID = "OriginFallKillCreditAttacker";
    /** 击杀归属账本：上述伤害发生的游戏刻。 */
    private static final String KILL_CREDIT_TIME = "OriginFallKillCreditTime";
    /** 击杀归属有效窗口（tick）：覆盖阳火/点燃/爆裂等武器特效完成击杀所需的时间（200 tick＝10 秒）。 */
    private static final int KILL_CREDIT_WINDOW = 200;
    private static final double MESSENGER_MIN_DISTANCE = 4.0D;
    private static final double MESSENGER_MIN_DISTANCE_SQR = MESSENGER_MIN_DISTANCE * MESSENGER_MIN_DISTANCE;

    private LearnedTraitLogic() {}

    private static TagKey<EntityType<?>> tag(String name) {
        return TagKey.create(Registries.ENTITY_TYPE,
                ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "behavior/" + name));
    }

    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.register(LearnedTraitCapability.class);
    }

    public static void attachCapabilities(AttachCapabilitiesEvent<Entity> event) {
        if (!(event.getObject() instanceof LivingEntity living) || !isLearner(living)) return;
        event.addCapability(ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, CAPABILITY_PATH),
                new LearnedTraitProvider(living));
    }

    /**
     * 「预言家」博士与「女祭司」普瑞赛斯：无数量上限的全特性学习者。
     * 其学习逻辑等同于转化生物（终焉行者/天灾信使）与特蕾西娅——
     * 既能像转化生物那样学习全部行为特性（含 explosion），又拥有特蕾西娅式的
     * CalamityMob 学习路径；仅在不设数量上限这点上区别于两者的固定上限。
     * 两者击杀学习的来源一致：近战、远程（剑气）、武器特效（阳火/爆裂/派生真实伤害）
     * 与溅射击杀均可学习（详见 canLearnFromKill）。
     */
    public static int learningLimit(LivingEntity entity) {
        if (entity instanceof Priestess) return Integer.MAX_VALUE;
        if (entity instanceof Prophet) return Integer.MAX_VALUE;
        if (entity instanceof Theresia) return 12;
        if (entity instanceof CalamityMessenger || entity instanceof EndWalker) return 1;
        if (entity instanceof PureSourceOreGolem) return 12;
        if (entity instanceof CalamityPrincess) return 9;
        if (entity instanceof YoungDemonLord) return 3;
        if (entity instanceof SourceOreGolem) return 6;
        return 0;
    }

    public static boolean isLearner(LivingEntity entity) {
        return entity != null && learningLimit(entity) > 0;
    }

    /** 备用学习机制的击杀归属标记（模组技能/仪式召唤生物统一带此标记）。 */
    public static boolean isModSummoned(LivingEntity entity) {
        return entity != null && entity.getPersistentData().contains(PriestessSkillLogic.SUMMON_BY);
    }

    /**
     * 莱特兰恶意词条击杀学习（含备用学习机制）的资格判定：
     * <b>该模组所有生物</b>与<b>该模组所有召唤生物</b>。
     *
     * <p>对应内置 kube 脚本中 {@code killer.isLiving() && killer.isSummoned()} 的闸门，
     * 按要求改写为模组口径：标准学习者、全部模组生物本体、被模组技能/仪式/道具召唤
     * （带 {@code SUMMON_BY} 标记）的生物，以及认主于模组生物为主的召唤物都能通过；
     * 玩家、原版与其他模组生物一律不通过，延续「非模组生物击杀不得感染词条」的约束。</p>
     */
    public static boolean isKillLearningCandidate(LivingEntity entity) {
        if (entity == null || entity instanceof Player) return false;
        if (isLearner(entity)) return true;
        if (isModSummoned(entity)) return true;
        if (entity instanceof net.minecraft.world.entity.OwnableEntity ownable) {
            LivingEntity owner = ownable.getOwner();
            if (owner != null
                    && (owner instanceof CalamityMob || isLearner(owner) || isModSummoned(owner))) {
                return true;
            }
        }
        return entity instanceof CalamityMob || entity instanceof SourceOreGolem;
    }

    /**
     * 恶意词条数量上限：基础值＝「原有学习生物行动逻辑数量」的两倍
     * （1/12/9/3/6 → 2/24/18/6/12，无上限者仍无上限），
     * 在此之上按恶意等级逐级扩容：<b>恶意等级每提升 20 级增加 1 个词条上限</b>。
     * 恶意等级兼容形态取莱特兰-恶意自身数据，独立形态取模组自持的等级系统。
     */
    public static int maliceLimit(LivingEntity entity) {
        int base = learningLimit(entity);
        if (base >= Integer.MAX_VALUE / 2) return Integer.MAX_VALUE;
        return base * 2 + maliceCountBonus(MaliceCompat.maliceLevelOf(entity));
    }

    /**
     * 恶意等级带来的词条数量上限加成档数：以 20 级为一档，<b>未满一档的部分一律按上一档
     * （向下取整）判定</b>。例：20 级得 1 档、25 级同样按 20 级判定得 1 档、40 级得 2 档。
     * 该档数即为 {@link #maliceLimit} 在基础值之上多加的词条上限数量。
     * 恶意等级取不到（含兼容层未接管时回退−1）按 0 档处理。
     */
    public static int maliceCountBonus(int maliceLevel) {
        return Math.max(0, maliceLevel) / 20;
    }

    /** 当前形态下行为特性词条实际生效的数量上限。 */
    public static int traitLimit(LivingEntity entity) {
        return MaliceCompat.l2Active() ? learningLimit(entity) : maliceLimit(entity);
    }

    /**
     * 恶意词条击杀学习（含备用学习机制）实际使用的数量上限。
     *
     * <p>标准学习者沿用 {@link #maliceLimit}（原有行动逻辑数量 ×2，外加每 20 级 +1）；
     * 「该模组所有召唤生物」中的<b>非标准学习者</b>（被模组技能/仪式召唤、或认主于模组
     * 生物的召唤物）没有行动逻辑档位，按最小档 1 折算——基础 2 条名额，同样享受
     * 每 20 级 +1 的扩容。这对应内置 kube 备用脚本「召唤物击杀后获得目标恶意词条」
     * 的模组化名额口径；不满足击杀资格判定的实体返回 0，一律不占词条。</p>
     */
    public static int maliceKillLimit(LivingEntity entity) {
        if (isLearner(entity)) return maliceLimit(entity);
        if (!isKillLearningCandidate(entity)) return 0;
        return 2 + maliceCountBonus(MaliceCompat.maliceLevelOf(entity));
    }

    /** 单条词条自身的等级封顶：纯位移/纯机制类词条只到 1 级，可量化的可到 3 级。 */
    public static int baseMaxLevel(String trait) {
        if (trait == null) return 1;
        if (trait.equals(WALL_CLIMB) || trait.equals(FLIGHT) || trait.equals(JUMP) || trait.equals(EXPLOSION)) {
            return 1;
        }
        return 3;
    }

    /** 该生物当前可融合到的等级：恶意等级映射的上限与词条自身上限取小。 */
    public static int levelCap(LivingEntity entity, String trait) {
        return Math.min(baseMaxLevel(trait), MaliceLevelSystem.maxTraitLevel(MaliceLevelSystem.levelOf(entity)));
    }

    /** 原版 Mob 和本模组生物都可以成为行为特性来源；玩家不参与学习。 */
    private static boolean isLearnableSource(LivingEntity victim) {
        return victim instanceof CalamityMob || victim instanceof SourceOreGolem
                || victim instanceof Mob && !(victim instanceof Player)
                && !CalamityLogic.isConvertedHostile(victim);
    }

    public static boolean isMeleeOrRangedAttack(DamageSource source, LivingEntity attacker) {
        if (source == null || attacker == null || source.is(DamageTypeTags.IS_EXPLOSION)) return false;
        Entity direct = source.getDirectEntity();
        if (direct == attacker) return true;
        return direct instanceof Projectile projectile && projectile.getOwner() == attacker;
    }

    /**
     * 击杀是否触发恶意学习（近战/远程直接击杀、武器特效击杀、异阵营、非感染死亡等基础闸门）。
     * 独立形态与莱特兰兼容形态共用同一套判定。
     *
     * <p>恶意词条通道（含备用学习机制）的击杀者资格比行为特性通道宽：
     * 「该模组所有生物」加上「该模组所有召唤生物」（{@link #isKillLearningCandidate}），
     * 即内置 kube 脚本里 {@code killer.isSummoned()} 判断的模组化改写；
     * 玩家与一切非模组生物仍然完全走不进这条链。</p>
     */
    public static boolean canLearnMaliceFromKill(LivingEntity attacker, LivingEntity victim, DamageSource source) {
        return passesKillGates(attacker, victim, source, true);
    }

    /** 基础闸门之上再要求目标确实带有可学词条，才进入独立形态的学习流程。 */
    public static boolean canLearnFromKill(LivingEntity attacker, LivingEntity victim, DamageSource source) {
        return passesKillGates(attacker, victim, source, false)
                && !candidateTraits(victim, attacker).isEmpty();
    }

    private static boolean passesKillGates(LivingEntity attacker, LivingEntity victim, DamageSource source,
                                           boolean allowModSummons) {
        boolean attackerOk = allowModSummons ? isKillLearningCandidate(attacker) : isLearner(attacker);
        return attackerOk && isLearnableSource(victim)
                && !CalamityLogic.diedFromSourceOreInfection(victim)
                // 近战/远程直接击杀，或目标近期确实被该学习者伤害过（武器特效、阳火、爆裂、
                // 溅射与派生真实伤害的击杀事件常常丢失攻击者实体，用击杀归属账本补回）。
                && (isMeleeOrRangedAttack(source, attacker) || isCreditedKill(attacker, victim))
                && !sameLearnerFamily(attacker, victim)
                && !CalamityLogic.isFactionAlly(attacker, victim);
    }

    /** 标记该目标为“派生/溅射击杀”（非近战直接击杀），供击杀学习判定区分。 */
    public static void markDerivedKill(LivingEntity victim) {
        if (victim != null) victim.getPersistentData().putBoolean(DERIVED_KILL_TAG, true);
    }

    /** 该目标是否由溅射/派生真实伤害击杀。 */
    public static boolean isDerivedKill(LivingEntity victim) {
        return victim != null && victim.getPersistentData().getBoolean(DERIVED_KILL_TAG);
    }

    /** 清除派生击杀标记（目标死亡清理时调用）。 */
    public static void clearDerivedKill(LivingEntity victim) {
        if (victim != null) victim.getPersistentData().remove(DERIVED_KILL_TAG);
    }

    /**
     * 记录「该学习者最近一次对目标造成伤害」，作为击杀归属。
     *
     * <p>武器特效、阳火/点燃、爆裂（{@code Explosion} 的单参伤害来源不携带实体）与命中后
     * 延迟结算的伤害，最终击杀事件往往解析不出攻击者。这里在每次有效伤害时把攻击者写进
     * 受害者数据，击杀时便能把这份学习资格补记回真正造成伤害的学习者身上。</p>
     */
    public static void recordKillCredit(LivingEntity attacker, LivingEntity victim) {
        if (attacker == null || victim == null || attacker == victim) return;
        if (victim.level().isClientSide || !isKillLearningCandidate(attacker)) return;
        var data = victim.getPersistentData();
        // 账本只有一条记录：非标准学习者不得顶掉窗口内的既有归属——标准学习者
        // （行为特性与恶意词条的学习主体）的武器特效/溅射击杀资格不受召唤物补刀影响；
        // 非标准学习者只在账本空窗时写入自己的归属，供恶意词条备用通道使用。
        if (!isLearner(attacker) && data.hasUUID(KILL_CREDIT_UUID)
                && victim.level().getGameTime() - data.getLong(KILL_CREDIT_TIME) <= KILL_CREDIT_WINDOW) {
            return;
        }
        data.putUUID(KILL_CREDIT_UUID, attacker.getUUID());
        data.putLong(KILL_CREDIT_TIME, victim.level().getGameTime());
    }

    /** 目标近期被哪个学习者伤害；超出窗口、攻击者已死亡或已卸载时返回 null。 */
    public static LivingEntity recentKillCredit(LivingEntity victim) {
        if (victim == null || victim.level().isClientSide) return null;
        var data = victim.getPersistentData();
        if (!data.hasUUID(KILL_CREDIT_UUID)) return null;
        if (victim.level().getGameTime() - data.getLong(KILL_CREDIT_TIME) > KILL_CREDIT_WINDOW) return null;
        if (!(victim.level() instanceof ServerLevel level)) return null;
        Entity credited = level.getEntity(data.getUUID(KILL_CREDIT_UUID));
        return credited instanceof LivingEntity living && living.isAlive() ? living : null;
    }

    /** 击杀归属是否指向该学习者（窗口内）。 */
    public static boolean isCreditedKill(LivingEntity attacker, LivingEntity victim) {
        if (attacker == null || victim == null) return false;
        LivingEntity credited = recentKillCredit(victim);
        return credited != null && credited.getUUID().equals(attacker.getUUID());
    }

    /** 防止同一种学习生物互相吞噬；现有阵营规则之外再做一次实体类型兜底。 */
    public static boolean sameLearnerFamily(LivingEntity first, LivingEntity second) {
        return isLearner(first) && isLearner(second)
                && first.getType() == second.getType()
                && sameFaction(first, second);
    }

    private static boolean sameFaction(LivingEntity first, LivingEntity second) {
        if (first instanceof Theresia && second instanceof Theresia) return true;
        if (first instanceof SourceOreGolem && second instanceof SourceOreGolem) {
            return CalamityLogic.isFactionAlly(first, second);
        }
        if (first instanceof CalamityMob && second instanceof CalamityMob) {
            return CalamityLogic.isCalamityFactionMember(first) == CalamityLogic.isCalamityFactionMember(second);
        }
        return CalamityLogic.isFactionAlly(first, second);
    }

    private static List<String> candidateTraits(LivingEntity victim, LivingEntity learner) {
        List<String> result = new ArrayList<>();
        if (victim.getType().is(EXPLOSION_TAG) && canLearnExplosion(learner)) result.add(EXPLOSION);
        if (victim.getType().is(TELEPORT_TAG)) result.add(TELEPORT);
        if (victim.getType().is(FIRE_ATTACK_TAG)) result.add(FIRE_ATTACK);
        if (victim.getType().is(WALL_CLIMB_TAG)) result.add(WALL_CLIMB);
        if (victim.getType().is(FLIGHT_TAG)) result.add(FLIGHT);
        if (victim.getType().is(RANGED_ATTACK_TAG)) result.add(RANGED_ATTACK);
        if (victim.getType().is(SWIM_TAG)) result.add(SWIM);
        if (victim.getType().is(JUMP_TAG)) result.add(JUMP);
        if (victim.getType().is(SPEED_TAG)) result.add(SPEED);
        if (victim.getType().is(REGENERATION_TAG)) result.add(REGENERATION);
        if (victim.getType().is(RESISTANCE_TAG)) result.add(RESISTANCE);
        if (victim.getType().is(KNOCKBACK_TAG)) result.add(KNOCKBACK);
        // 模组生物没有原版行为标签时，直接暴露其已实现的行为，供异阵营学习。
        if (victim instanceof CalamityMessenger) {
            addIfMissing(result, FLIGHT);
            addIfMissing(result, RANGED_ATTACK);
        } else if (victim instanceof EndWalker) {
            addIfMissing(result, TELEPORT);
        } else if (victim instanceof CalamityPrincess) {
            addIfMissing(result, REGENERATION);
        } else if (victim instanceof SourceOreGolem) {
            addIfMissing(result, RESISTANCE);
            addIfMissing(result, KNOCKBACK);
        } else if (victim instanceof YoungDemonLord) {
            addIfMissing(result, FIRE_ATTACK);
        }
        LearnedTraitCapability sourceData = LearnedTraitCapability.getOrNull(victim);
        if (sourceData != null) {
            for (String trait : sourceData.getTraits()) {
                if (!trait.equals(EXPLOSION) || !(learner instanceof Theresia)) addIfMissing(result, trait);
            }
        }
        return result;
    }

    private static void addIfMissing(List<String> traits, String trait) {
        if (!traits.contains(trait)) traits.add(trait);
    }

    private static boolean isConvertedLearner(LivingEntity entity) {
        return entity instanceof EndWalker || entity instanceof CalamityMessenger;
    }

    /** 是否属于「无上限全特性学习者」：博士与女祭司，学习逻辑等同转化生物+特蕾西娅。 */
    private static boolean isUnlimitedLearner(LivingEntity entity) {
        return entity instanceof Prophet || entity instanceof Priestess;
    }

    /**
     * 是否可以学习爆炸特性：转化生物默认可学；博士与女祭司按“等同转化生物”的处理同样可学。
     * 特蕾西娅显式排除在外（她的设计不包含爆炸特性），因此与博士/女祭司的“全特性”定位不冲突。
     */
    private static boolean canLearnExplosion(LivingEntity learner) {
        if (learner == null || learner instanceof Theresia) return false;
        return isConvertedLearner(learner) || isUnlimitedLearner(learner);
    }

    /**
     * 击杀/转化成功后的恶意词条学习（独立形态）：可学习对方的所有词条。
     * 与莱特兰兼容形态同一套语义——
     * ① 相同词条逐条融合升级（未到可融合等级上限的），融合不占用词条数量；
     * ② 新词条按剩余名额（词条数量上限 − 当前持有数）学入；
     * ③ 对方词条数量大于剩余名额时，随机抽取到名额数量再学入。
     */
    public static void learnAfterConversion(LivingEntity learner, LivingEntity victim, DamageSource source) {
        // 源石感染造成的死亡属于环境转化，不是学习者的近战或远程击杀，绝不能触发学习。
        if (CalamityLogic.diedFromSourceOreInfection(victim)
                || !canLearnFromKill(learner, victim, source)) return;
        LearnedTraitCapability data = LearnedTraitCapability.getOrNull(learner);
        if (data == null) return;
        data.setLimit(traitLimit(learner));
        List<String> candidates = candidateTraits(victim, learner);
        if (candidates.isEmpty()) return;
        boolean changed = false;
        // ① 相同词条优先融合升级：只提升等级，不占数量名额。
        List<String> fresh = new ArrayList<>();
        for (String trait : candidates) {
            if (data.has(trait)) {
                changed |= data.upgrade(trait, levelCap(learner, trait));
            } else {
                fresh.add(trait);
            }
        }
        // ②③ 新词条按剩余名额学入；多于名额时以实体随机源洗牌后随机抽取。
        int slots = data.getLimit() - data.size();
        if (slots > 0 && !fresh.isEmpty()) {
            if (fresh.size() > slots) {
                for (int i = fresh.size() - 1; i > 0; i--) {
                    int j = learner.getRandom().nextInt(i + 1);
                    String tmp = fresh.get(i);
                    fresh.set(i, fresh.get(j));
                    fresh.set(j, tmp);
                }
            }
            int take = Math.min(slots, fresh.size());
            for (int i = 0; i < take; i++) {
                if (data.add(fresh.get(i))) {
                    changed = true;
                    applyImmediateTraitState(learner, fresh.get(i));
                }
            }
        }
        if (changed) sync(learner, data);
    }

    public static boolean has(LivingEntity entity, String trait) {
        return levelOf(entity, trait) > 0;
    }

    /** 读取词条等级：服务端优先取 Capability，客户端回退到同步字符串（格式 "a:2,b"）。 */
    public static int levelOf(LivingEntity entity, String trait) {
        LearnedTraitCapability data = LearnedTraitCapability.getOrNull(entity);
        if (data != null) return data.levelOf(trait);
        String encoded = syncedTraits(entity);
        if (encoded.isBlank()) return 0;
        for (String token : encoded.split(",")) {
            if (token.isBlank()) continue;
            int sep = token.indexOf(':');
            String name = sep < 0 ? token : token.substring(0, sep);
            if (!trait.equals(name)) continue;
            if (sep < 0) return 1;
            try {
                return Math.max(1, Integer.parseInt(token.substring(sep + 1)));
            } catch (NumberFormatException ignored) {
                return 1;
            }
        }
        return 0;
    }

    public static void tick(LivingEntity entity) {
        if (!(entity.level() instanceof ServerLevel level)) return;
        // 恶意等级系统的两种形态在此分流：装有莱特兰-恶意时走兼容层
        // （按 boss 级别附带词条、自适应强化）；未安装时由独立实现兜底。
        if (entity instanceof Mob) {
            MaliceCompat.onLearnerTick(entity);
            if (!MaliceCompat.l2Active()) {
                MaliceLevelSystem.ensureAssigned(entity);
                // 独立形态的恶意等级经同步数据外显到名牌（与莱特兰在场时它自身的外显对齐）。
                syncMaliceLevel(entity, MaliceLevelSystem.levelOf(entity));
            }
        }
        LearnedTraitCapability data = LearnedTraitCapability.getOrNull(entity);
        if (data == null) return;
        // 性能：词条上限与客户端同步串的一致性兜底比对由每 tick 降为每 10 tick（0.5 秒）。
        // 词条的每次实际变化（学习、融合升级、上限调整）都会在变化点立即 sync，这里的比对
        // 只用于自愈（事件遗漏、跨版本存档迁移），半秒的收敛延迟对名额与名牌显示不可感知；
        // 而它原本每 tick 都要重算 traitLimit 并拼一次同步串，是模组生物数量大时的固定开销。
        if (entity.tickCount % 10 == 0) {
            int limit = traitLimit(entity);
            if (data.getLimit() != limit) data.setLimit(limit);
            if (!syncedTraits(entity).equals(data.encoded())) sync(entity, data);
        }
        if (data.size() == 0) return;
        applyImmediateTraitState(entity, null);
        if (!(entity instanceof Mob mob)) return;

        // 移动类和爆炸类特性都必须脱离原版"只等目标选择器"的节奏，主动补充有效目标。
        if (has(entity, WALL_CLIMB) || has(entity, FLIGHT) || has(entity, TELEPORT) || has(entity, EXPLOSION)) {
            LivingEntity target = mob.getTarget();
            if (target == null || !target.isAlive() || !canTraitTarget(mob, target)) {
                mob.setTarget(findTraitTarget(level, mob));
            }
        }

        if (has(entity, TELEPORT) && entity.tickCount % 20 == 0
                && mob.getTarget() != null && mob.getTarget().isAlive()
                && entity.distanceToSqr(mob.getTarget()) > MESSENGER_MIN_DISTANCE_SQR
                && entity.getRandom().nextFloat() < 0.20F + 0.08F * (levelOf(entity, TELEPORT) - 1)) {
            LivingEntity target = mob.getTarget();
            double x = target.getX() + (entity.getRandom().nextDouble() - 0.5D) * 8.0D;
            double y = target.getY() + entity.getRandom().nextInt(3) - 1.0D;
            double z = target.getZ() + (entity.getRandom().nextDouble() - 0.5D) * 8.0D;
            entity.randomTeleport(x, y, z, true);
        }
        if (has(entity, EXPLOSION)) tickExplosionTrait(level, mob);
        if (has(entity, JUMP) && entity.onGround() && entity.getRandom().nextFloat() < 0.08F) {
            entity.setDeltaMovement(entity.getDeltaMovement().add(0.0D, 0.42D, 0.0D));
            entity.hasImpulse = true;
        }
        if (has(entity, MAGNET)) tickMagnetTrait(level, entity);
        int regen = levelOf(entity, REGENERATION);
        if (regen > 0 && entity.tickCount % 40 == 0) entity.heal(regen);
        int resistance = levelOf(entity, RESISTANCE);
        if (resistance > 0 && entity.tickCount % 20 == 0) {
            entity.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, 40, resistance - 1, false, false, true));
        }
        int speed = levelOf(entity, SPEED);
        if (speed > 0 && entity.tickCount % 20 == 0) {
            entity.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                    net.minecraft.world.effect.MobEffects.MOVEMENT_SPEED, 40, speed - 1, false, false, true));
        }
    }

    /** 磁铁：周期性把周围的掉落物吸向自己，等级越高吸附半径越大。 */
    private static void tickMagnetTrait(ServerLevel level, LivingEntity entity) {
        double radius = 4.0D + 2.0D * levelOf(entity, MAGNET);
        for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class,
                entity.getBoundingBox().inflate(radius), it -> !it.getItem().isEmpty())) {
            Vec3 pull = entity.position().add(0.0D, entity.getBbHeight() * 0.5D, 0.0D)
                    .subtract(item.position()).normalize().scale(0.32D);
            item.setDeltaMovement(item.getDeltaMovement().add(pull));
            item.hasImpulse = true;
        }
    }

    private static LivingEntity findTraitTarget(ServerLevel level, Mob source) {
        double radius = source.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.FOLLOW_RANGE);
        return level.getEntitiesOfClass(LivingEntity.class, source.getBoundingBox().inflate(radius),
                        target -> target != source && canTraitTarget(source, target))
                .stream().min(java.util.Comparator.comparingDouble(source::distanceToSqr)).orElse(null);
    }

    private static boolean canTraitTarget(Mob source, LivingEntity target) {
        if (target == null || !target.isAlive() || target == source
                || CalamityLogic.isSameConvertedFaction(source, target)) return false;
        if (source instanceof SourceOreGolem golem) return golem.canAttack(target);
        if (source instanceof CalamityMob calamity) return calamity.canAttack(target);
        return CalamityLogic.canConvertedHostileAttack(source, target);
    }

    /** explosion 特性不等待近战碰撞：锁定最近目标，在目标位置释放爆炸。 */
    private static void tickExplosionTrait(ServerLevel level, Mob source) {
        int cooldown = source.getPersistentData().getInt(EXPLOSION_COOLDOWN);
        if (cooldown > 0) {
            source.getPersistentData().putInt(EXPLOSION_COOLDOWN, cooldown - 1);
            return;
        }
        LivingEntity target = source.getTarget();
        if (target == null || !canTraitTarget(source, target)) return;
        double radius = source.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.FOLLOW_RANGE);
        if (source.distanceToSqr(target) > radius * radius) return;
        // 爆裂的伤害来源（{@code Explosion} 单参构造）不携带攻击者实体，击杀事件解析不出释放者；
        // 先把爆裂范围内的有效目标记为本次击杀归属，特效击杀才能真正算到释放者头上。
        double ex = target.getX();
        double ey = target.getY() + target.getBbHeight() * 0.5D;
        double ez = target.getZ();
        for (LivingEntity nearby : level.getEntitiesOfClass(LivingEntity.class,
                new net.minecraft.world.phys.AABB(ex - 4.0D, ey - 4.0D, ez - 4.0D,
                        ex + 4.0D, ey + 4.0D, ez + 4.0D),
                candidate -> candidate != source && canTraitTarget(source, candidate))) {
            recordKillCredit(source, nearby);
        }
        // 爆炸等级已在 baseMaxLevel 封顶为 1，此处保持 2.5F 威力。
        level.explode(source, ex, ey, ez, 2.5F, Level.ExplosionInteraction.MOB);
        source.getPersistentData().putInt(EXPLOSION_COOLDOWN, 60);
    }

    /** 在攻击成功后赋予行为类特性的即时效果。 */
    public static void onSuccessfulAttack(LivingEntity attacker, LivingEntity target,
                                           DamageSource source) {
        if (!isLearner(attacker) || target == null || !isMeleeOrRangedAttack(source, attacker)) return;
        int fireLevel = levelOf(attacker, FIRE_ATTACK);
        if (fireLevel > 0) target.setSecondsOnFire(2 + 2 * fireLevel);
        int knockback = levelOf(attacker, KNOCKBACK);
        if (knockback > 0) {
            // 击退等级越高，目标被推离得越远。
            Vec3 away = target.position().subtract(attacker.position()).normalize()
                    .scale(0.35D * knockback);
            target.setDeltaMovement(target.getDeltaMovement().add(away.x, 0.25D, away.z));
            target.hurtMarked = true;
        }
    }

    public static void applyImmediateTraitState(LivingEntity entity, String selected) {
        // flight 需要持续悬浮；wall_climb 保留正常重力，由 onClimbable() 接管贴墙上爬。
        if (has(entity, FLIGHT)) entity.setNoGravity(true);
        if (entity.level().isClientSide) return;
        if (entity instanceof Mob mob && has(entity, RANGED_ATTACK)) {
            // 黑人像（博士/女祭司/特蕾西娅）与已持近战武器者保持其近战武器，改为投出剑气远程攻击；
            // 弓弩改为「近战武器延伸」的黑/白剑气，不再强制替换为弓/弩。
            if (isBlackSwordQiHolder(mob) || isHoldingMeleeWeapon(mob)) return;
            if (!mob.getMainHandItem().is(net.minecraft.world.item.Items.BOW)
                    && !mob.getMainHandItem().is(net.minecraft.world.item.Items.CROSSBOW)) {
                mob.setItemSlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND,
                        new ItemStack(entity.getRandom().nextBoolean() ? net.minecraft.world.item.Items.BOW
                                : net.minecraft.world.item.Items.CROSSBOW));
                mob.setItemSlot(net.minecraft.world.entity.EquipmentSlot.OFFHAND,
                        new ItemStack(net.minecraft.world.item.Items.ARROW, 64));
            }
        }
    }

    /** 使用黑色月牙剑气远程攻击的指定首领：博士、女祭司、特蕾西娅。 */
    private static boolean isBlackSwordQiHolder(Mob mob) {
        return mob instanceof Priestess || mob instanceof Theresia || mob instanceof Prophet;
    }

    /** 主手是否持有近战武器（非空、非弓/弩/三叉戟）。 */
    private static boolean isHoldingMeleeWeapon(Mob mob) {
        ItemStack item = mob.getMainHandItem();
        return !item.isEmpty()
                && !item.is(net.minecraft.world.item.Items.BOW)
                && !item.is(net.minecraft.world.item.Items.CROSSBOW)
                && !item.is(net.minecraft.world.item.Items.TRIDENT);
    }

    /** 死亡立即清空学习数据，复活实体不会继承。 */
    public static void clearOnDeath(LivingEntity entity) {
        LearnedTraitCapability data = LearnedTraitCapability.getOrNull(entity);
        if (data != null) {
            data.clear();
            data.setLimit(traitLimit(entity));
            sync(entity, data);
        }
        clearDerivedKill(entity);
        entity.getPersistentData().remove(KILL_CREDIT_UUID);
        entity.getPersistentData().remove(KILL_CREDIT_TIME);
        // 独立形态的恶意等级与首领附带标记一并清除，新个体重新按档位定级。
        entity.getPersistentData().remove(MaliceLevelSystem.LEVEL_TAG);
        entity.getPersistentData().remove(MaliceLevelSystem.BOSS_TRAITS_TAG);
    }

    /** 独立形态：把恶意等级写进同步数据，供客户端名牌外显读取。 */
    public static void syncMaliceLevel(LivingEntity entity, int level) {
        if (entity instanceof CalamityMob calamity) {
            if (calamity.getEntityData().get(CalamityMob.MALICE_LEVEL_DATA) != level) {
                calamity.getEntityData().set(CalamityMob.MALICE_LEVEL_DATA, level);
            }
        } else if (entity instanceof SourceOreGolem golem) {
            if (golem.getEntityData().get(SourceOreGolem.MALICE_LEVEL_DATA) != level) {
                golem.getEntityData().set(SourceOreGolem.MALICE_LEVEL_DATA, level);
            }
        }
    }

    public static void sync(LivingEntity entity, LearnedTraitCapability data) {
        String encoded = data.encoded();
        if (entity instanceof CalamityMob calamity) {
            calamity.getEntityData().set(CalamityMob.LEARNED_TRAITS_DATA, encoded);
            calamity.getEntityData().set(CalamityMob.LEARNED_LIMIT_DATA, data.getLimit());
        } else if (entity instanceof SourceOreGolem golem) {
            golem.getEntityData().set(SourceOreGolem.LEARNED_TRAITS_DATA, encoded);
            golem.getEntityData().set(SourceOreGolem.LEARNED_LIMIT_DATA, data.getLimit());
        }
    }

    public static String syncedTraits(LivingEntity entity) {
        if (entity instanceof CalamityMob calamity) return calamity.getEntityData().get(CalamityMob.LEARNED_TRAITS_DATA);
        if (entity instanceof SourceOreGolem golem) return golem.getEntityData().get(SourceOreGolem.LEARNED_TRAITS_DATA);
        return "";
    }
}
