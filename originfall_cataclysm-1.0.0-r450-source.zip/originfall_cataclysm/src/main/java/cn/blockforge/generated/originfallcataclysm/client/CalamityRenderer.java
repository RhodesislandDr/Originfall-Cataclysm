package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.CalamityHumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;
import com.mojang.blaze3d.vertex.PoseStack;

/**
 * 天灾系人形生物渲染器。泛型上界放开到 {@link Mob}（自家 {@code CalamityMob} 的直系约束，
 * MobRenderer 的固有要求）：除自家生物外，还用于深蓝之树本尊哈基玖（同为 Mob）的
 * 替身外观全程代画——平时与「扒臀长舞」共用同一接管（{@link NativeApocataAppearanceEvents}）。
 */
public final class CalamityRenderer<T extends Mob> extends MobRenderer<T, CalamityHumanoidModel<T>> {
    private final ResourceLocation texture;

    public CalamityRenderer(EntityRendererProvider.Context context, ResourceLocation texture, ModelLayerLocation layer,
                             ModelLayerLocation innerArmorLayer, ModelLayerLocation outerArmorLayer) {
        super(context, new CalamityHumanoidModel<>(context.bakeLayer(layer)), 0.5F);
        this.texture = texture;
        addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
        // 天灾实体复活或同化后不显示任何附加盔甲。
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        return texture;
    }

    @Override
    public void render(T entity, float yaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        poseStack.scale(0.9375F, 0.9375F, 0.9375F);
        super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
        poseStack.popPose();
    }
}
