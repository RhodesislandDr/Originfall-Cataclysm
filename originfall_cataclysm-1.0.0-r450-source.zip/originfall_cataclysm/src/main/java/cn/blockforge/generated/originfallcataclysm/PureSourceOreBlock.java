package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

/** 未爆炸陨石的至纯源石形态；保留旧方块注册名以兼容已存在的存档。 */
public final class PureSourceOreBlock extends Block implements EntityBlock {
    public PureSourceOreBlock(Properties properties) {
        super(properties);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new PureSourceOreBlockEntity(pos, state);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, net.minecraft.world.entity.Entity entity) {
        if (!level.isClientSide && entity instanceof net.minecraft.world.entity.LivingEntity living && living.isAlive()) {
            CalamityLogic.applySourceOreInfection(living, 1, 0);
            CalamityLogic.markInfectionExposure(living);
        }
        super.entityInside(state, level, pos, entity);
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state,
                                                                   BlockEntityType<T> type) {
        if (level.isClientSide) return null;
        if (type == GeneratedMod.PURE_SOURCE_ORE_BLOCK_ENTITY.get()) {
            return (currentLevel, pos, currentState, blockEntity) ->
                    PureSourceOreBlockEntity.serverTick(currentLevel, pos, currentState,
                            (PureSourceOreBlockEntity) blockEntity);
        }
        if (type == GeneratedMod.METEOR_BLOCK_ENTITY.get()) {
            return (currentLevel, pos, currentState, blockEntity) ->
                    MeteorBlockEntity.serverTick(currentLevel, pos, currentState,
                            (MeteorBlockEntity) blockEntity);
        }
        return null;
    }
}
