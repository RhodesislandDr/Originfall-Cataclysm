package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;

/**
 * 「沉默」的技能打断钩子：锚定现实等控制效果在施加瞬间需要<b>打断目标正在释放的技能</b>，
 * 主源码集不认识史诗战斗的任何类，因此把「打断进行中的动作/技能演出」这一层交给外部兼容层，
 * 与 {@link SkillCombatHooks} 的打击反馈桥完全同一套设计。
 *
 * <p>钩子默认未安装（{@code handler == null}），此时 {@link #interruptSkills} 只是一次空判返回，
 * 模组可脱离史诗战斗独立运行。只有安装了 Epic Fight，
 * {@code OriginfallEpicFightCompat#init} 才会安装真正的处理者，把沉默目标正在播放的
 * 出招/技能动画强制转成史诗战斗的受击硬直（不遵守“出招中不打断”的连段豁免——
 * 沉默本来就是打断手段）。模组自身的领域、剑气、陨石、召唤等主动技能则在各自的
 * 发动入口按 {@link RuwosuojianLogic#isSilenced} 拦截，不依赖本钩子。</p>
 */
public final class SilenceHooks {
    private SilenceHooks() {}

    /** 由兼容层安装的打断处理者；未安装时整套钩子不起作用。 */
    public interface InterruptHandler {
        void interrupt(LivingEntity victim);
    }

    private static volatile InterruptHandler handler;

    /** 兼容层安装处理者（只在史诗战斗确实存在时调用）。 */
    public static void install(InterruptHandler newHandler) {
        handler = newHandler;
    }

    /**
     * 沉默生效瞬间对目标调用一次：打断其进行中的技能/动作演出。只在服务端生效，
     * 目标死亡或世界尚未就绪时静默跳过；未安装兼容层时立即返回，零开销、零行为差异。
     */
    public static void interruptSkills(LivingEntity victim) {
        InterruptHandler current = handler;
        if (current == null) return;
        if (victim == null) return;
        Level level = victim.level();
        if (level == null || level.isClientSide || !victim.isAlive()) return;
        current.interrupt(victim);
    }
}
