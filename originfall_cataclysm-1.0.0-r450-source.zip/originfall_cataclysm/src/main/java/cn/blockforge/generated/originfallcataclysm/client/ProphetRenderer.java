package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.CalamityHumanoidModel;
import cn.blockforge.generated.originfallcataclysm.Prophet;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;
import com.mojang.blaze3d.vertex.PoseStack;

/** 「预言家」博士使用原版玩家人形骨骼+提供的贴图；护甲只用于属性计算，不渲染盔甲层。 */
public final class ProphetRenderer extends MobRenderer<Prophet, CalamityHumanoidModel<Prophet>> {
    private final ResourceLocation texture;

    public ProphetRenderer(EntityRendererProvider.Context context, ResourceLocation texture,
                           ModelLayerLocation layer) {
        super(context, new CalamityHumanoidModel<>(context.bakeLayer(layer)), 0.5F);
        this.texture = texture;
        addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
    }

    @Override
    public ResourceLocation getTextureLocation(Prophet entity) {
        return texture;
    }

    @Override
    public void render(Prophet entity, float yaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        poseStack.scale(0.9375F, 0.9375F, 0.9375F);
        super.render(entity, yaw, partialTick, poseStack, buffer, packedLight);
        poseStack.popPose();
    }
}
