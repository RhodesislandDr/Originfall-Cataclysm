package cn.blockforge.generated.originfallcataclysm.client;

/**
 * 「眨眼」的纯客户端外观计时器：按实体 id 给出当前帧的眼睑闭合量，
 * 不产生任何服务端状态、不发包、不影响逻辑——需求明确「仅仅外貌改动」。
 *
 * <p>每个实体用 id 散列出独立的「周期 + 相位」，所以一群生物不会整齐地同眨；
 * 周期约 7~11 秒，闭眼段约 0.3 秒（2 刻合拢、2 刻保持、2.5 刻睁开），
 * 用渲染帧时钟（{@code entity.tickCount + partialTick}）插值，睁闭过程平滑。</p>
 */
public final class BlinkState {

    private BlinkState() {
    }

    /** 眼睑闭合量 [0,1]：0 全睁，1 全闭。 */
    public static float lid(float ageInTicks, int entityId) {
        int h = entityId * 0x9E3779B1;
        h ^= h >>> 15;
        h *= 0x85EBCA6B;
        h ^= h >>> 13;
        double period = 140.0 + (h & 0x7F);                                  // 140~267 tick 一跳
        // Math.floorMod 没有 double 重载：手算非负取模（ageInTicks 恒 ≥0，直接 % 即可）。
        double phase = (ageInTicks + (double) ((h >>> 8) & 0x3FF)) % period;
        if (phase < 2.0) return (float) (phase * 0.5);                       // 合拢
        if (phase < 4.0) return 1.0F;                                        // 保持闭眼
        if (phase < 6.5) return (float) ((6.5 - phase) * 0.4);               // 睁开
        return 0.0F;
    }
}
