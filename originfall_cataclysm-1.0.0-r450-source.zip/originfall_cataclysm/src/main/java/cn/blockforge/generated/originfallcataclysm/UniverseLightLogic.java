package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 无下限•内化宇宙的光点表现（服务端粒子驱动，触发点为光点中心）：
 * 1. 触发瞬间在中心生成一个明亮的紫色光点，并在同一位置播放玩家提供的音乐（universe_music）；
 *    音乐去重：自上次实际播放起 10 秒（200 tick）内再次触发内化宇宙时不重复播放，满 10 秒后再触发则重新播放；
 * 2. 同时以触发者为圆心生成一个 16 格实心结界球体（UniverseSphereEntity），逐 tick 向外扩张，
 *    并在整个内化宇宙存在期间持续保持，内化宇宙结束时随之移除；
 * 3. 光晕从0格开始逐渐扩张，第4秒（80 tick）末恰好达到32格半径——按 tick 线性推进，
 *    每一tick的半径 = 32 × (已过tick+1) / 80，不是先闪满再收回；
 * 4. 之后维持32格直到内化宇宙效果消失（虚空流放时长耗尽，默认10秒），
 *    再用1秒把大光环逐tick收拢回中心，化作一颗小光点熄灭；
 * 5. 内化宇宙消失（虚空传送时间结束）的那一tick，统一清除所有被拉入生物的“阴/阳”标记；
 * 6. 内化宇宙结束时被拉入生物附加一分二十六秒的速度II（仅仍存活者）。
 *
 * 光点列表只在服务端主线程读写（LivingTick / LevelTick 事件），无需并发容器。
 */
public final class UniverseLightLogic {

    /** 逐渐扩张阶段：4秒 = 80 tick，末tick半径恰好32格。 */
    private static final int EXPAND_TICKS = 80;
    /** 收缩阶段：内化宇宙结束后用1秒把光晕收拢成小光点。 */
    private static final int COLLAPSE_TICKS = 20;
    /** 开放内化宇宙的可视化与判定半径（格）。 */
    private static final double MAX_RADIUS = 64.0D;
    /** 内化宇宙实心结界球体的目标半径（格）：从触发者圆心向外扩张至 16 格并保持。 */
    private static final double SPHERE_RADIUS = 16.0D;
    /** 速度II：内化宇宙结束后时长 1 分 26 秒（86 秒 = 1720 tick，amplifier=1 即 II 级）。 */
    private static final int SPEED_TICKS = 1720;
    private static final int SPEED_AMPLIFIER = 1;
    /** 音乐响度：全服广播经 playNotifySound 在玩家自身位置播放，正常音量即可。 */
    private static final float MUSIC_VOLUME = 1.0F;
    /** 内化宇宙音乐重复播放冷却：自上次播放起 10 秒（200 tick）内再次触发不重复播放。 */
    private static final int MUSIC_COOLDOWN_TICKS = 200;

    /** 亮紫色尘埃：core 用大颗粒，光环用中等颗粒。 */
    private static final ParticleOptions PURPLE_CORE =
            new DustParticleOptions(new org.joml.Vector3f(0.66F, 0.16F, 0.96F), 1.8F);
    private static final ParticleOptions PURPLE_RING =
            new DustParticleOptions(new org.joml.Vector3f(0.60F, 0.12F, 0.92F), 1.4F);

    private record Light(ResourceKey<Level> dimension, Vec3 center, long startGameTime,
                         long universeTicks, List<UUID> marked, UUID sphereId) {
    }

    private static final List<Light> LIGHTS = new ArrayList<>();
    /** 上一次实际播放内化宇宙音乐的服务器全局 tick；-1 表示尚未播放过。 */
    private static long lastMusicServerTick = -1L;
    /**
     * 音乐基准所隶属的服务器实例。每次加载世界都会新建一个 MinecraftServer，其 tickCount
     * 从 0 重新开始；而本类静态状态在客户端进程里跨世界存活。实例一变即说明进入了全新的
     * 一次游戏会话，旧的 tickCount 基准作废，否则重载后 now（小）- 基准（大）长期为负，
     * 永远达不到去重阈值，音乐被永久静默。光点表 LIGHTS 不受影响：它按 level.getGameTime()
     * 记账，游戏时间随存档持久化，重载后仍能正确走完印记清除与球体回收。
     */
    private static java.lang.ref.WeakReference<net.minecraft.server.MinecraftServer> musicOwnerServer;

    private UniverseLightLogic() {
    }

    /** 把音乐冷却基准对齐到当前服务器实例：实例变化（世界重载 / 换存档 / 重启）即重置基准。 */
    private static void alignToServer(net.minecraft.server.MinecraftServer server) {
        if (musicOwnerServer != null && musicOwnerServer.get() == server) return;
        musicOwnerServer = new java.lang.ref.WeakReference<>(server);
        lastMusicServerTick = -1L;
    }

    /**
     * 内化宇宙触发入口：登记光点、点亮中心并播放音乐（速度II 改为内化宇宙结束时施加）。
     *
     * @param pulled        本次被拉入内化宇宙的全部存活生物（含使用者与目标）
     * @param universeTicks 内化宇宙（虚空传送）时长，tick；到期即收缩并清除阴/阳标记
     */
    public static void trigger(ServerLevel level, Vec3 center, List<LivingEntity> pulled, long universeTicks) {
        List<UUID> ids = new ArrayList<>();
        for (LivingEntity entity : pulled) {
            ids.add(entity.getUUID());
        }
        // 音乐去重：自上次实际播放起 10 秒（200 tick）内再次触发内化宇宙时不重复播放；
        // 满 10 秒后再次触发时音乐重新播放。用服务器全局 tick 作为时钟，跨维度也一致。
        // 本类静态状态跨世界存活，先对齐到当前服务器实例，防止重载后永久静默。
        alignToServer(level.getServer());
        long now = (long) level.getServer().getTickCount();
        if (lastMusicServerTick < 0L || now - lastMusicServerTick >= MUSIC_COOLDOWN_TICKS) {
            // 「扒臀舞」琵琶曲是最高优先级：在播期间本音乐不起播，也不记去重时刻——
            // 舞曲结束后再触发内化宇宙时音乐照常播放。结界等其余演出照常进行。
            if (!TauntSongMusic.isActive()) {
                // 内化宇宙音乐优先级高于「巴别塔回忆」音乐：起播前先打断正在播放的巴别塔回忆音乐。
                BabelMemoryMusic.interrupt(level.getServer());
                // 音乐改为全服务器播放：向所有在线玩家发送通知音，任何维度的玩家都能听到。
                // 分类与 1000 倍陨石坠落音乐保持一致（MASTER）：RECORDS 受「唱片和音乐方块」
                // 音量滑块支配，该滑块归零的玩家会完全听不到内化宇宙音乐，MASTER 只受主音量控制。
                for (ServerPlayer player : level.getServer().getPlayerList().getPlayers()) {
                    player.playNotifySound(GeneratedMod.UNIVERSE_MUSIC.get(), SoundSource.MASTER, MUSIC_VOLUME, 1.0F);
                }
                lastMusicServerTick = now;
            }
        }
        // 以触发者为圆心生成 16 格实心结界球体，随内化宇宙逐步扩张并全程保持。
        UniverseSphereEntity sphere = UniverseSphereEntity.create(level, center.x, center.y, center.z, SPHERE_RADIUS);
        UUID sphereId = sphere == null ? null : sphere.getUUID();
        LIGHTS.add(new Light(level.dimension(), center, level.getGameTime(), universeTicks, ids, sphereId));
        igniteBurst(level, center);
    }

    /** 内化宇宙音乐是否正在全服播放（存在任一活跃光点即视为音乐期内）。 */
    public static boolean isUniverseMusicActive() {
        return !LIGHTS.isEmpty();
    }

    /** 由 CommonEvents 的 LevelTick（服务端侧）驱动，逐tick推进半径与粒子表现。 */
    public static void tick(ServerLevel level) {
        if (LIGHTS.isEmpty()) return;
        long now = level.getGameTime();
        for (int i = LIGHTS.size() - 1; i >= 0; i--) {
            Light light = LIGHTS.get(i);
            if (!light.dimension().equals(level.dimension())) continue;
            long elapsed = now - light.startGameTime();
            long universeEnd = light.universeTicks();
            if (elapsed < EXPAND_TICKS) {
                // 逐渐扩大：第1~79 tick线性增长，第80 tick（第4秒末）恰好到达32格。
                renderFrame(level, light.center(), MAX_RADIUS * (elapsed + 1) / EXPAND_TICKS, elapsed);
            } else if (elapsed < universeEnd) {
                // 维持32格域场直到内化宇宙效果消失。
                renderFrame(level, light.center(), MAX_RADIUS, elapsed);
            } else if (elapsed < universeEnd + COLLAPSE_TICKS) {
                if (elapsed == universeEnd) {
                    clearMarks(level, light);
                    // 内化宇宙结束：为被拉入生物附加一分二十六秒的速度II。
                    grantPostUniverseSpeed(level, light);
                    // 内化宇宙到期即移除随之生成、全程保持的实心结界球体。
                    discardSphere(level, light);
                }
                // 收缩：光环逐tick向中心收拢，最后只剩中心的小光点。
                double radius = MAX_RADIUS * (universeEnd + COLLAPSE_TICKS - elapsed) / (double) COLLAPSE_TICKS;
                renderFrame(level, light.center(), radius, elapsed);
            } else {
                clearMarks(level, light);
                extinguish(level, light.center());
                LIGHTS.remove(i);
            }
        }
    }

    /** 触发瞬间的点灯爆发：一圈致密的光尘把“明亮紫色光点”点亮。 */
    private static void igniteBurst(ServerLevel level, Vec3 center) {
        double cx = center.x;
        double cy = center.y + 1.1D;
        double cz = center.z;
        level.sendParticles(ParticleTypes.END_ROD, cx, cy, cz, 40, 0.5D, 0.9D, 0.5D, 0.08D);
        level.sendParticles(ParticleTypes.PORTAL, cx, cy, cz, 40, 0.6D, 1.0D, 0.6D, 0.15D);
        level.sendParticles(PURPLE_CORE, cx, cy, cz, 24, 0.45D, 0.8D, 0.45D, 0.05D);
    }

    /** 一个tick的光点画面：中心亮核 + 两条不同高度的紫色光环（半径由调用方给出）。 */
    private static void renderFrame(ServerLevel level, Vec3 center, double radius, long elapsed) {
        double cx = center.x;
        double cy = center.y + 1.1D;
        double cz = center.z;
        // 中心：始终维持一颗明亮的光点本体。
        level.sendParticles(ParticleTypes.PORTAL, cx, cy, cz, 8, 0.22D, 0.55D, 0.22D, 0.12D);
        level.sendParticles(ParticleTypes.END_ROD, cx, cy, cz, 5, 0.14D, 0.4D, 0.14D, 0.002D);
        level.sendParticles(PURPLE_CORE, cx, cy + 0.3D, cz, 4, 0.18D, 0.45D, 0.18D, 0.008D);
        // 中心向上的光柱，强化“光点”存在感。
        level.sendParticles(ParticleTypes.PORTAL, cx, cy + 1.8D, cz, 3, 0.08D, 0.9D, 0.08D, 0.06D);
        // 贴地光环 + 半空光环：半径随 elapsed 逐tick增大，即“逐渐扩大”的画面。
        sendRing(level, center, center.y + 0.08D, radius, elapsed, 0.0D);
        sendRing(level, center, center.y + 1.5D, radius * 0.82D, elapsed, 1.1D);
    }

    /** 用12段圆弧近似一整个圆环：每段一个小盒随机撒粒子，段内偏移沿切线拉长。 */
    private static void sendRing(ServerLevel level, Vec3 center, double y, double radius, long elapsed,
                                 double phaseOffset) {
        if (radius < 0.5D) return;
        final int arcs = 12;
        double rot = elapsed * Math.PI / 96.0D + phaseOffset;
        for (int i = 0; i < arcs; i++) {
            double a = rot + (2.0D * Math.PI * i) / arcs;
            double px = center.x + Math.cos(a) * radius;
            double pz = center.z + Math.sin(a) * radius;
            // 弧段的切线半长：半径越大弧越长，盒子的偏移方向跟着圆走。
            double arcHalf = Math.max(0.15D, Math.PI * radius / arcs * 0.55D);
            double ox = Math.max(0.12D, Math.abs(Math.sin(a)) * arcHalf);
            double oz = Math.max(0.12D, Math.abs(Math.cos(a)) * arcHalf);
            level.sendParticles(PURPLE_RING, px, y, pz, 3, ox, 0.1D, oz, 0.0D);
            if (i % 3 == 0) {
                level.sendParticles(ParticleTypes.PORTAL, px, y + 0.25D, pz, 2, ox, 0.2D, oz, 0.05D);
            }
        }
    }

    /** 熄灭：大光环已收拢回中心，最后一小簇光点亮灭即散。 */
    private static void extinguish(ServerLevel level, Vec3 center) {
        double cx = center.x;
        double cy = center.y + 1.1D;
        double cz = center.z;
        level.sendParticles(ParticleTypes.END_ROD, cx, cy, cz, 18, 0.12D, 0.18D, 0.12D, 0.04D);
        level.sendParticles(PURPLE_CORE, cx, cy, cz, 10, 0.1D, 0.14D, 0.1D, 0.02D);
        level.sendParticles(ParticleTypes.POOF, cx, cy, cz, 6, 0.1D, 0.12D, 0.1D, 0.05D);
    }

    /** 虚空传送时间结束：被拉入生物的“阴/阳”标记全部消失。 */
    private static void clearMarks(ServerLevel level, Light light) {
        for (UUID id : light.marked()) {
            if (level.getEntity(id) instanceof LivingEntity entity) {
                TiantangzhidianLogic.clearYinYangMarks(entity);
            }
        }
    }

    /** 内化宇宙结束：被拉入生物附加一分二十六秒的速度II（仅仍存活者）。 */
    private static void grantPostUniverseSpeed(ServerLevel level, Light light) {
        for (UUID id : light.marked()) {
            if (level.getEntity(id) instanceof LivingEntity entity && entity.isAlive()) {
                entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, SPEED_TICKS, SPEED_AMPLIFIER,
                        false, true));
            }
        }
    }

    /** 内化宇宙结束：移除随本次内化宇宙生成、全程保持的实心结界球体。 */
    private static void discardSphere(ServerLevel level, Light light) {
        if (light.sphereId() != null && level.getEntity(light.sphereId()) instanceof UniverseSphereEntity sphere) {
            sphere.discard();
        }
    }
}
