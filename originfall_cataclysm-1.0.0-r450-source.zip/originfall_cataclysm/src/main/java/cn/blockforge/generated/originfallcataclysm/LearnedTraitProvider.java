package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.Nullable;

/** 为每个 LivingEntity 附加独立的学习特性存储。 */
public final class LearnedTraitProvider implements ICapabilitySerializable<CompoundTag> {
    private final LearnedTraitCapability backend = new LearnedTraitCapability();
    private final LazyOptional<LearnedTraitCapability> optional = LazyOptional.of(() -> backend);
    private final LivingEntity owner;

    public LearnedTraitProvider(LivingEntity owner) {
        this.owner = owner;
        backend.setLimit(LearnedTraitLogic.traitLimit(owner));
        backend.setDirtyListener(() -> {
            if (owner.level().isClientSide) return;
            LearnedTraitLogic.sync(owner, backend);
        });
    }

    @Override
    public <T> LazyOptional<T> getCapability(net.minecraftforge.common.capabilities.Capability<T> capability,
                                               @Nullable Direction side) {
        return capability == LearnedTraitCapability.CAPABILITY ? optional.cast() : LazyOptional.empty();
    }

    @Override
    public CompoundTag serializeNBT() {
        return backend.serializeNBT();
    }

    @Override
    public void deserializeNBT(CompoundTag tag) {
        backend.deserializeNBT(tag);
    }

    public LearnedTraitCapability backend() {
        return backend;
    }

    public Runnable optionalListener() {
        return optional::invalidate;
    }
}
