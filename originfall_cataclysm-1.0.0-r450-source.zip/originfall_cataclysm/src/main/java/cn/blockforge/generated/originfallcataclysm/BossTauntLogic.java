package cn.blockforge.generated.originfallcataclysm;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;

import java.util.List;
import java.util.UUID;

/**
 * 「扒臀长舞」服务端驱动：中枪/中法术后背对伤害施加者跳完一整首曲子，全程以每秒 2 格
 * 背向贴近伤害施加者。整套 28.86 秒（编排 30.3 秒 ×1.05 倍基础速度）动作依次为——下蹲夹臀 → 前倾拍臀 → 岔腿交替后退 →
 * 抱胸摆臂 → 拍大腿 → 撅臀起跳 → 趴地撅臀撑起（俯卧撑跳） → 黑帮摇（编排 20 秒） → 站直跨步跳 → 前倾蹦跳指向身后 →
 * 转身五圈后左腿向左平伸、左手摸腿收尾；曲长超过一轮时循环播放。姿势本身由 {@link BossTauntPose}
 * 在客户端人形骨架上还原（关键帧见 {@link BossDanceKeyframes}），这里只负责六件事：
 * <ol>
 *   <li>倒计时：{@code TAUNT_TICKS} 每 tick 递减（写入点见 {@link #start}，递减在 CalamityMob#tick）；</li>
 *   <li>转身：跳舞期间把朝向锁定为「背对伤害施加者」（背对方向为施加者方向）；</li>
 *   <li>扭头：每 tick 把头部偏航 {@code yHeadRot} 限步长（{@link #HEAD_FOLLOW_STEP}）拉向当前
 *       身体朝向——需求 4「原有扭头未生效（现有方向进行扭头，不用管看谁）」的服务端一半：
 *       转身时头落后于身体、转完再甩上来。渲染层两条路径各自消费这个量：纯模组由
 *       {@link BossTauntPose} 把 {@code netHeadYaw/headPitch} 前置合成进头部，史诗战斗由
 *       {@code OriginfallDanceAnimation.doesHeadRotFollowEntityHead()} 交回原版叠加。
 *       头只跟身体朝向，不指向任何个体（关键帧里原先的「转头看锁定目标」反解已删除，
 *       见 {@code work/generate_boss_dance.py} 的 H2 段）；</li>
 *   <li>贴近：以每秒 2 格向伤害施加者平移，距其 {@link #DANCE_MIN_GAP} 格内停下，
 *       同时清目标、停寻路，避免动作被攻击走位和挥砍吞掉；</li>
 *   <li>根位移：把 {@link BossDanceKeyframes#MOVE} 里「交替后退」那 3.5 格动作位移
 *       （岔腿四步 + 抱胸三步，每步 0.5 格）逐 tick
 *       按当前朝向施加到实体上，叠加在追踪速度之上（动作自己走的路另外算）；</li>
 *   <li>防御：舞曲期间弹飞一切弹射物（{@link #deflectAround}）、吞掉一切伤害。</li>
 * </ol>
 *
 * <p>触发规则（与外部枪械/魔法模组兼容，识别见 {@link WeaponCompat}，入口 {@link #handleIncomingHit}）：
 * 舞蹈所有设定中的「跟随谁、背对谁」统一为<b>使用魔法或枪械造成伤害的个体</b>，而非玩家——
 * 该个体由触发行凶的那一击解析（{@code DamageSource#getEntity}）并记在 {@link CalamityMob#getTauntTargetId()}。
 * 《方块与深蓝之树》的<b>远程攻击</b>也接入同一规则：与 TaCZ 等模组共用跳舞开关与复触发概率，
 * 舞曲期间其一切弹体/光束同样被弹开（识别口径见 {@code WeaponCompat#isCaerulaRangedDamage}）。</p>
 * <ul>
 *   <li>个体首次被枪械或魔法命中：免疫该击，起播琵琶曲（{@link TauntSongMusic}）并跳满整曲；</li>
 *   <li>首次触发结束后：枪械每次造成伤害有 0.325% 概率再次触发（同样免疫该击再起跳）；</li>
 *   <li>舞曲播放期间其它个体触发：不换新曲，跟随当前曲目剩余时长共舞，各自跟随自己的伤害施加者；</li>
 *   <li>舞期内：免疫一切伤害（{@link #handleIncomingHit} 直接吞掉）、弹开一切弹射物、
 *       出手伤害一律归零（CommonEvents 拦截），即「不会进行任何攻击」。</li>
 * </ul>
 *
 * <p>测试命令 {@code /ofctaunt [ticks]}（权限2）保留作调试入口，命令执行者充当伤害施加者。
 * 长舞程（跟满整曲 1900 tick）时客户端姿势按 {@link BossDanceKeyframes#TICKS} 取模自然循环，
 * 无需按周期重发动作。</p>
 */
public final class BossTauntLogic {
    /** 默认舞程：整段「扒臀长舞」一轮的长度（577 tick ≈ 28.86 秒，编排 30.3 秒 ×1.05 倍基础速度）。 */
    public static final int DEFAULT_TICKS = BossDanceKeyframes.TICKS;
    /** 复触发概率：首次触发结束后，枪械每次造成伤害 0.325% 起舞。 */
    public static final float RETRIGGER_CHANCE = 0.00325F;
    /** 舞期内弹射物弹开半径（格）。 */
    public static final double DEFLECT_RADIUS = 4.0D;
    /** 锁定「伤害施加者」的最远距离；施加者超出该距离或死亡/离场后原地跳，保持最后朝向。 */
    public static final double FACE_RANGE = 64.0D;
    /** 舞蹈平移速度：每秒 2 格 = 每 tick 0.1 格，背向贴近伤害施加者。 */
    private static final double DANCE_SPEED = 0.1D;
    /** 贴近的最近间距：距伤害施加者 2 格内停止平移，只继续舞蹈与转身。 */
    private static final double DANCE_MIN_GAP = 2.0D;
    /** 转身速度：每 tick 最多转多少度。 */
    private static final float TURN_STEP = 18.0F;
    /**
     * 扭头跟随速度：每 tick 头部偏航（{@code yHeadRot}）向当前身体朝向靠拢的最大步长（度）。
     * 必须<b>小于</b> {@link #TURN_STEP}，转身时头才会落后于身体、转完再甩上来——这就是需求里
     * 「原有扭头未生效」要恢复的那个按<b>现有方向</b>进行的扭头；不做索敌，头只跟身体朝向走。
     */
    private static final float HEAD_FOLLOW_STEP = 8.0F;
    /** 测试命令的生效半径：把命令执行者周围的两位首领全部拉来跳。 */
    private static final double COMMAND_RADIUS = 48.0D;
    /** {@link BossDanceKeyframes#sampleMove} 的取样缓冲（服务端单线程，复用即可）。 */
    private static final float[] MOVE_FROM = new float[3];
    private static final float[] MOVE_TO = new float[3];

    private BossTauntLogic() {
    }

    /**
     * 允许跳「扒臀长舞」的名单：「女祭司」普瑞赛斯、「预言家」博士，
     * 以及联动彩蛋生物<b>哈基玖</b>——用户要求哈基玖的跳舞机制与首领等同：
     * 同一支舞曲、同一套队列规则（无人在播则起整曲，有人播则跟剩余时长），
     * 舞期内免疫一切伤害并弹开一切弹射物。
     *
     * <p>装有深蓝之树时召唤产出的<b>本尊</b>（外部实体，不是 {@link CalamityMob}）不在
     * 本名单口径内，由 {@link NativeApocataTauntLogic} 以内存会话驱动同一套规则，
     * 弹反、舞程与测试命令共用本类的实现。</p>
     */
    public static boolean canTaunt(CalamityMob mob) {
        return mob instanceof Prophet || mob instanceof Priestess || mob instanceof Apocata;
    }

    public static boolean isActive(CalamityMob mob) {
        return mob.getTauntTicks() > 0;
    }

    public static void start(CalamityMob mob) {
        start(mob, DEFAULT_TICKS);
    }

    /** 开跳：写入总程与倒计时（客户端据此分阶段播放姿势）。重复调用以最后一次为准。 */
    public static void start(CalamityMob mob, int ticks) {
        start(mob, ticks, null);
    }

    /**
     * 开跳并指定「伤害施加者」：舞蹈期间背对其、并以每秒 2 格向其平移。
     * target 传 null 表示沿用当前已记录的目标（无目标则原地跳）。
     */
    public static void start(CalamityMob mob, int ticks, LivingEntity target) {
        if (!canTaunt(mob) || !mob.isAlive() || mob.level().isClientSide) return;
        // 上限放到 5 分钟：跟歌时长以整曲 1900 tick 为基准，原版 1200 的钳制会提前掐断长舞。
        int clamped = Mth.clamp(ticks, 30, 6000);
        if (target != null) mob.setTauntTargetId(target.getUUID());
        mob.setTauntTotalTicks(clamped);
        mob.setTauntTicks(clamped);
    }

    /**
     * 受击触发入口（仅服务端，{@code CommonEvents#onLivingAttack} 调用）。
     *
     * @return true 表示本次伤害应被免疫取消：包含舞期内的任意受击，以及首触/概率触发成功的那一击。
     */
    public static boolean handleIncomingHit(CalamityMob victim, DamageSource source, ServerLevel level) {
        if (!canTaunt(victim) || !victim.isAlive()) return false;
        // 舞期免疫：跳舞中吞掉一切伤害来源（枪械、魔法、近战、爆炸皆然）。
        if (isActive(victim)) return true;
        boolean firearm = WeaponCompat.isFirearmDamage(source)
                // 深蓝之树的远程攻击按「枪械」接入：同一个跳舞开关、同一个复触发概率，
                // 与 TaCZ 等模组完全等同（识别口径见 WeaponCompat#isCaerulaRangedDamage）。
                || WeaponCompat.isCaerulaRangedDamage(source);
        boolean magic = !firearm && WeaponCompat.isMagicDamage(source);
        if (!firearm && !magic) return false;
        // 舞蹈目标 = 造成这一击的伤害施加者（谁开枪/施法就跟着谁），而非玩家。
        LivingEntity attacker = source.getEntity() instanceof LivingEntity living && living != victim
                ? living : null;
        // 首次：枪械或魔法打中即起跳并放曲，免疫该击；之后只剩枪械的 0.325% 复触发。
        if (!victim.isWeaponTauntFirstDone()) {
            victim.setWeaponTauntFirstDone(true);
            beginDance(victim, level, attacker);
            return true;
        }
        if (firearm && level.getRandom().nextFloat() < RETRIGGER_CHANCE) {
            beginDance(victim, level, attacker);
            return true;
        }
        return false;
    }

    /** 起舞：无人在播则起播整曲并跳满；已有舞曲在播则跟随当前曲目剩余时长。 */
    private static void beginDance(CalamityMob mob, ServerLevel level, LivingEntity attacker) {
        boolean joining = TauntSongMusic.playOrJoin(level);
        int ticks = joining ? TauntSongMusic.remainingTicks() : TauntSongMusic.songTicks();
        // 曲尾不足最短舞程（30 tick）时按最短舞程跳完，动作不会演一半掐断。
        start(mob, Math.max(ticks, 30), attacker);
    }

    /**
     * 舞期内弹飞一切弹射物：把半径内的活弹体向远离舞者的方向加速弹出。
     *
     * <p>两路查询：① 一切 {@code Projectile} 子类（含 TaCZ/铁魔法/诡厄巫法多数弹体的常规做法）；
     * ② 不继承 {@code Projectile} 但注册名命中兼容模组弹体特征的实体（TaCZ 部分弹型自管位移，
     * 类型查询抓不到，识别见 {@link WeaponCompat#isCompatProjectile}）。</p>
     *
     * <p>package 可见：深蓝之树本尊（外部实体）的舞蹈驱动复用同一套弹反
     * （见 {@link NativeApocataTauntLogic#tick}）。</p>
     */
    static void deflectAround(ServerLevel level, Entity anchor) {
        AABB box = anchor.getBoundingBox().inflate(DEFLECT_RADIUS);
        List<Projectile> projectiles = level.getEntitiesOfClass(Projectile.class, box,
                projectile -> projectile.getOwner() != anchor
                        // 插地/落定的弹体（箭等）速度归零，不算「来袭弹体」，否则每 tick 拔箭很滑稽。
                        && projectile.getDeltaMovement().lengthSqr() > 1.0E-5D);
        Vec3 center = anchor.position().add(0.0D, anchor.getBbHeight() * 0.5D, 0.0D);
        for (Projectile projectile : projectiles) {
            deflect(level, projectile, center);
        }
        List<Entity> foreign = level.getEntities(anchor, box,
                entity -> !(entity instanceof Projectile)
                        && WeaponCompat.isCompatProjectile(entity)
                        && entity.getDeltaMovement().lengthSqr() > 1.0E-5D);
        for (Entity entity : foreign) {
            deflect(level, entity, center);
        }
    }

    /** 单个弹体的弹出：沿「弹体−首领中心」射线反向加速并同步到客户端。 */
    private static void deflect(ServerLevel level, Entity projectile, Vec3 center) {
        Vec3 away = projectile.position().subtract(center);
        if (away.lengthSqr() < 1.0E-4D) {
            double angle = level.getRandom().nextDouble() * Math.PI * 2.0D;
            away = new Vec3(Math.cos(angle), 0.0D, Math.sin(angle));
        }
        away = away.normalize();
        projectile.setDeltaMovement(away.scale(2.4D).add(0.0D, 0.4D, 0.0D));
        // 同步速度到客户端，弹体才会真的「弹飞」而不是服务端瞬移。
        projectile.hurtMarked = true;
        level.addParticle(ParticleTypes.CRIT, projectile.getX(), projectile.getY(), projectile.getZ(),
                0.0D, 0.1D, 0.0D);
    }

    /** 每个服务端 tick 调用：处理所有正在跳舞的首领（转向锁定 + 背向贴近 + 弹射物防御）。 */
    public static void tick(ServerLevel level) {
        tickMobs(level, EntityTrackers.prophets(level));
        tickMobs(level, EntityTrackers.priestesses(level));
        // 哈基玖与首领共用同一支舞曲与同一套队列：弹开弹射物、转身、贴近伤害施加者。
        tickMobs(level, EntityTrackers.apocatas(level));
    }

    private static void tickMobs(ServerLevel level, List<? extends CalamityMob> mobs) {
        for (CalamityMob mob : mobs) {
            if (mob.getTauntTicks() <= 0 || !mob.isAlive()) continue;
            // 舞蹈期间放弃攻击目标与寻路：位移全部由下面的贴地平移接管。
            mob.setTarget(null);
            mob.setAggressive(false);
            mob.getNavigation().stop();
            // 舞曲持续期间全程弹飞靠近的弹射物（伤害免疫由受击事件入口负责）。
            deflectAround(level, mob);
            // 按「现有方向」扭头：头（yHeadRot）限步长追当前身体朝向，转身时落后、
            // 转完甩上——恢复原版/史诗战斗那条帧末前置叠加头朝向的可见摆动（需求 4）。
            // 不做任何索敌：头跟的是身体，不是任何个体。
            float headStep = Mth.clamp(Mth.wrapDegrees(mob.getYRot() - mob.getYHeadRot()),
                    -HEAD_FOLLOW_STEP, HEAD_FOLLOW_STEP);
            mob.setYHeadRot(mob.getYHeadRot() + headStep);
            LivingEntity target = resolveTarget(level, mob);
            if (target == null) {
                // 没有可跟随的伤害施加者：原地定身，保持入场时的朝向。
                mob.setDeltaMovement(0.0D, mob.getDeltaMovement().y, 0.0D);
                continue;
            }
            double dx = target.getX() - mob.getX();
            double dz = target.getZ() - mob.getZ();
            double planarDistance = Math.sqrt(dx * dx + dz * dz);
            if (planarDistance < 1.0E-4D) {
                mob.setDeltaMovement(0.0D, mob.getDeltaMovement().y, 0.0D);
                continue;
            }
            // 「背对方向为施加者方向」：面向 = 指向施加者的反方向。
            // 面向施加者的 yaw = degrees(atan2(dz, dx)) - 90，故背对施加者 +180 即 +90。
            float awayYaw = (float) (Math.toDegrees(Mth.atan2(dz, dx)) + 90.0D);
            float step = Mth.clamp(Mth.wrapDegrees(awayYaw - mob.getYRot()), -TURN_STEP, TURN_STEP);
            mob.setYRot(mob.getYRot() + step);
            mob.setXRot(0.0F);
            // 每秒 2 格向施加者平移（背向滑步）。本钩子跑在实体 tick 之后，走 move()
            // 直推位移——若借道 setDeltaMovement 会被下 tick 的地面摩擦（×0.6）拖慢，
            // 实际只剩 0.6 倍；move() 自带碰撞与上台阶判定，速度分毫不差。
            mob.setDeltaMovement(0.0D, mob.getDeltaMovement().y, 0.0D);
            double stepX = 0.0D;
            double stepZ = 0.0D;
            if (planarDistance > DANCE_MIN_GAP) {
                double scale = DANCE_SPEED / planarDistance;
                stepX += dx * scale;
                stepZ += dz * scale;
            }
            // 再把动作本身的地面位移（「交替后退」那两段）叠加上去：这段是角色自己在
            // 后退，与追踪速度互不抵消，方向按当前朝向从模型本地系转到世界系。
            int elapsed = Math.max(mob.getTauntTotalTicks() - mob.getTauntTicks(), 0);
            int tickNow = elapsed % BossDanceKeyframes.TICKS;
            // 整段动作循环回起点的那一 tick 不补差值，否则每轮都会向前瞬移一格。
            int tickPrev = tickNow > 0 ? tickNow - 1 : 0;
            BossDanceKeyframes.sampleMove(tickPrev, MOVE_FROM);
            BossDanceKeyframes.sampleMove(tickNow, MOVE_TO);
            double moveX = (MOVE_TO[0] - MOVE_FROM[0]) / 16.0D;
            double moveZ = (MOVE_TO[2] - MOVE_FROM[2]) / 16.0D;
            if (moveX != 0.0D || moveZ != 0.0D) {
                double yaw = Math.toRadians(mob.getYRot());
                double cos = Math.cos(yaw);
                double sin = Math.sin(yaw);
                stepX += moveX * cos + moveZ * sin;
                stepZ += moveX * sin - moveZ * cos;
            }
            if (stepX != 0.0D || stepZ != 0.0D) {
                mob.move(MoverType.SELF, new Vec3(stepX, 0.0D, stepZ));
            }
        }
    }

    /**
     * 解析本次舞蹈要跟随的伤害施加者：只认开跳那一击的凶手（枪械/魔法持有者），
     * 不再退回「最近玩家」。目标死亡、离场或超出 {@link #FACE_RANGE} 后清空并原地续跳。
     */
    private static LivingEntity resolveTarget(ServerLevel level, CalamityMob mob) {
        UUID id = mob.getTauntTargetId();
        if (id == null) return null;
        Entity entity = level.getEntity(id);
        if (entity instanceof LivingEntity living && living.isAlive()
                && living.distanceToSqr(mob) <= FACE_RANGE * FACE_RANGE) {
            return living;
        }
        mob.setTauntTargetId(null);
        return null;
    }

    // ---------------- 测试命令 ----------------

    /** {@code /ofctaunt [ticks]}：让执行者 48 格内的普瑞赛斯/博士集体跳「扒臀舞」。 */
    public static void registerCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("ofctaunt")
                .requires(src -> src.hasPermission(2))
                .executes(ctx -> tauntNearby(ctx, DEFAULT_TICKS))
                .then(Commands.argument("ticks", IntegerArgumentType.integer(30, 6000))
                        .executes(ctx -> tauntNearby(ctx, IntegerArgumentType.getInteger(ctx, "ticks")))));
    }

    private static int tauntNearby(CommandContext<CommandSourceStack> ctx, int ticks) {
        CommandSourceStack src = ctx.getSource();
        if (!(src.getEntity() instanceof LivingEntity anchor)) {
            src.sendFailure(Component.literal("/ofctaunt 需要由玩家执行"));
            return 0;
        }
        ServerLevel level = src.getLevel();
        int count = 0;
        double rangeSq = COMMAND_RADIUS * COMMAND_RADIUS;
        for (Prophet prophet : EntityTrackers.prophets(level)) {
            if (prophet.isAlive() && prophet.distanceToSqr(anchor) <= rangeSq) {
                start(prophet, ticks, anchor);
                count++;
            }
        }
        for (Priestess priestess : EntityTrackers.priestesses(level)) {
            if (priestess.isAlive() && priestess.distanceToSqr(anchor) <= rangeSq) {
                start(priestess, ticks, anchor);
                count++;
            }
        }
        for (Apocata apocata : EntityTrackers.apocatas(level)) {
            if (apocata.isAlive() && apocata.distanceToSqr(anchor) <= rangeSq) {
                start(apocata, ticks, anchor);
                count++;
            }
        }
        // 深蓝之树本尊哈基玖（外部实体）同跳：舞步驱动见 NativeApocataTauntLogic。
        for (LivingEntity nativeApocata : level.getEntitiesOfClass(LivingEntity.class,
                anchor.getBoundingBox().inflate(COMMAND_RADIUS),
                entity -> entity.isAlive() && CaerulaArborCompat.isNativeApocataEntity(entity))) {
            NativeApocataTauntLogic.start(nativeApocata, ticks, anchor);
            count++;
        }
        if (count == 0) {
            src.sendSuccess(() -> Component.literal("48 格内没有「女祭司」普瑞赛斯、「预言家」博士或哈基玖"), false);
            return 0;
        }
        int dancers = count;
        src.sendSuccess(() -> Component.literal(dancers + " 位转身背对你，开始「扒臀舞」（" + ticks + " tick）"), true);
        return dancers;
    }
}
