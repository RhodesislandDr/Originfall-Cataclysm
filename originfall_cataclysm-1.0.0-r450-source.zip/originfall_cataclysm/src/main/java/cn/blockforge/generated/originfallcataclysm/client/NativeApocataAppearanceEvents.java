package cn.blockforge.generated.originfallcataclysm.client;

import cn.blockforge.generated.originfallcataclysm.CaerulaArborCompat;
import cn.blockforge.generated.originfallcataclysm.ClientEvents;
import cn.blockforge.generated.originfallcataclysm.GeneratedMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 哈基玖的外观统一（本模组在场即生效）：深蓝之树本尊（外部实体
 * {@code caerula_arbor:apocata}）的渲染<b>全程</b>由本模组接管，画成替身同款外观
 * （{@link CalamityRenderer}：玩家骨架 + 蕾缪安贴图，与 {@code originfall_cataclysm:apocata}
 * 替身逐像素同一套模型层与贴图）。
 *
 * <p>「扒臀长舞」的舞步顺带走同一通道：有舞蹈会话时 {@code BossTauntPose} 的
 * 本尊通道按 {@link NativeApocataDanceState} 的倒计时叠加关键帧姿势，无会话时
 * 自行复位、走原版走路/攻击/扭头动画——接管渲染与舞蹈从此共用一条管线，
 * 不存在「平时是本尊脸、跳舞才换替身脸」的割裂。</p>
 *
 * <p><b>只动外观，不动能力</b>：这里接管的是客户端像素层，本尊的实体定义、AI、
 * 技能、掉落与潮曦奇美拉钩子全部原样留在深蓝之树——召唤侧本就优先产出本尊
 * （见 {@code CommonEvents#trySummonApocata}），服务端机制（舞蹈受击入口、
 * 中立口径、共同索敌联动）也都按外部实体钩接、不改写其任何数据。
 * 「在深蓝之树模组存在时赋予本体所有能力」由这套让位+钩接结构天然满足。</p>
 *
 * <p><b>为什么走 {@code RenderLivingEvent.Pre} 而不是抢注渲染器</b>：本尊的
 * {@code EntityRenderer} 由对方模组注册，跨模组覆盖要赌模组事件顺序与对方
 * 注册时机；Pre 接管是渲染入口的最后一道闸，无论对方注册了什么渲染器都生效，
 * 且与既有代跳共用重入与史诗战斗分流逻辑，链路已经过实战验证。</p>
 *
 * <p><b>史诗战斗在场时按接管情况分流</b>：</p>
 * <ul>
 *   <li>本尊<b>没有</b>史诗战斗补丁渲染时，史诗战斗不会绘制它、也不会取消事件——
 *       这里照常取消并代画替身外观，装了史诗战斗一样统一；</li>
 *   <li>本尊<b>有</b>史诗战斗补丁渲染时（对方模组自带给史诗战斗的兼容），史诗战斗已在本帧
 *       用自己的骨架画了它（事件被取消）——这里不再叠第二层，避免双影；舞蹈动作由
 *       {@code OriginfallEpicFightClientCompat} 把本模组登记的舞曲动画注入本尊自己的
 *       动画器驱动。替身与本尊同肤同骨架，该分支下观感一致。</li>
 * </ul>
 *
 * <p><b>重入保护</b>：{@code RenderLivingEvent.Pre} 在 {@code LivingEntityRenderer#render}
 * 的字节码 0 号位派发——代画渲染器的 {@code render} 同样会再次触发 Pre；无深度守卫时
 * 会自调用无限递归爆栈（历史版本「没有舞蹈动作」的成因之一）。</p>
 */
@Mod.EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT)
public final class NativeApocataAppearanceEvents {

    /**
     * 代画重入深度：{@code >0} 表示当前正处在代画渲染器自身的 {@code render} 调用里
     * （它同样会派发 Pre），此时直接放行让模型正常绘制，绝不能再取消自套娃。
     */
    private static int proxyRenderDepth;

    /** 代画渲染器：Context 即时构建（见 {@link #context()}），首次用到才建。 */
    private static CalamityRenderer<Mob> appearanceRenderer;

    private NativeApocataAppearanceEvents() {
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRenderLivingPre(RenderLivingEvent.Pre event) {
        if (proxyRenderDepth > 0) return;
        // LOWEST 排在史诗战斗（默认优先级）之后：事件已被取消说明这一帧它已由
        // 史诗战斗（或其他接管者）画过，再叠替身就是双重绘制。
        if (event.isCanceled()) return;
        LivingEntity entity = event.getEntity();
        // 归属判定走 EntityType 缓存（ConcurrentHashMap 一次取键），非本尊零成本。
        if (!CaerulaArborCompat.isNativeApocataEntity(entity)) return;
        // 代画渲染器按 Mob 上界构建（MobRenderer 的固有约束）；本尊正常就是带 AI 的 Mob，
        // 万一对方版本给了非 Mob 的实体类，跳过接管，维持对方自己的渲染。
        if (!(entity instanceof Mob nativeMob)) return;
        CalamityRenderer<Mob> renderer = appearanceRenderer();
        if (renderer == null) return;
        // Pre 的插桩点在 pushPose 之前：姿势栈此刻只有渲染分发器摆好的实体世界坐标，
        // 用同一栈调代画渲染器即可走完与原版一致的 push/setupRotations/模型/装甲层管线
        // ——含眨眼眼睑、持械姿势、死亡倒下与名牌渲染。
        event.setCanceled(true);
        float yaw = Mth.rotLerp(event.getPartialTick(), entity.yHeadRotO, entity.yHeadRot);
        proxyRenderDepth++;
        try {
            renderer.render(nativeMob, yaw, event.getPartialTick(), event.getPoseStack(),
                    event.getMultiBufferSource(), event.getPackedLight());
        } finally {
            proxyRenderDepth--;
        }
    }

    /** 玩家退出/断线：清掉全部舞蹈会话，防止实体 id 在新存档里对到旧截止点。 */
    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        NativeApocataDanceState.clear();
    }

    private static CalamityRenderer<Mob> appearanceRenderer() {
        if (appearanceRenderer == null) {
            EntityRendererProvider.Context context = context();
            if (context == null) return null;
            ResourceLocation id = ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "apocata");
            appearanceRenderer = new CalamityRenderer<>(context,
                    ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "textures/entity/apocata.png"),
                    new ModelLayerLocation(id, "main"),
                    new ModelLayerLocation(id, "inner_armor"),
                    new ModelLayerLocation(id, "outer_armor"));
        }
        return appearanceRenderer;
    }

    /**
     * 可用的渲染上下文。<b>不能</b>只依赖注册渲染器时惰性截获的 Context：深蓝之树在场时
     * 仪式产出的只有本尊、本模组替身可能永不出场，截获点就永远不触发。这里直接用
     * {@code Minecraft} 单例现建一份同构 Context；注册期恰好截获到过就优先复用。
     */
    private static EntityRendererProvider.Context context() {
        if (ClientEvents.apocataRenderContext != null) return ClientEvents.apocataRenderContext;
        try {
            Minecraft minecraft = Minecraft.getInstance();
            EntityRenderDispatcher dispatcher = minecraft.getEntityRenderDispatcher();
            return new EntityRendererProvider.Context(dispatcher,
                    minecraft.getItemRenderer(), minecraft.getBlockRenderer(),
                    dispatcher.getItemInHandRenderer(), minecraft.getResourceManager(),
                    minecraft.getEntityModels(), minecraft.font);
        } catch (RuntimeException | LinkageError ignored) {
            // 表现层兜底：拿不到上下文只是本帧维持对方原渲染，服务端机制照常。
            return null;
        }
    }
}
