package cn.blockforge.generated.originfallcataclysm;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * 如我所见的全部能力定义：
 * 1. 两段伤害：第一段为使用者最大生命值25%的真实伤害；第二段为原有攻击数值，
 *    仍走原版受击链（护甲、盾牌、附魔、击退全部有效）。
 * 2. 极•源石权柄•阳：攻击造成伤害按45%回复自身；自身半径16格内生物的攻击伤害
 *    按65%回复自身；满血时溢出治疗转化为最大生命上限。仅在携带本武器时生效，
 *    丢弃/掉落后清除加成。最大血量削减不计为伤害；时光之末溅射伤害同样适用该效果。
 * 3. 锚定现实：每次攻击基础3.25%概率锚定目标——每次未触发攻击概率提高0.5%，触发后回到基础概率。
 *    锚定后停滞移动与空间位置，并<b>打断正在释放的技能、期间持续沉默</b>（领域、剑气、锁定陨石、
 *    召唤等主动技能全部无法发动），但<b>不再停止攻击与索敌</b>——被锚定者可照常普攻、远程射击与
 *    维持目标。时长10~30秒等概率随机，同一施术者（每只生物独立计时）对同一目标间隔60秒；触发时对
 *    目标施加“阳”标记，随60秒内置间隔到期消失（阳标记自此来源于本武器）。锚定时对主目标触发
 *    时光之末溅射判定，被溅射单位携带同等锚定效果（无需重复判定，等控制时长）。
 *    停滞只作用于被锚定的目标：施加者本人不受影响，「预言家」博士在该次锚定的执行窗口内
 *    （被内化宇宙推迟兑现时含 10 秒虚空停留）索敌、追击与攻击照常进行。
 *    每次攻击另有16.25%概率施加“阳火”：每秒削减1%×层数的当前最大生命值
 *    （单次最低3点），每层持续32.5秒、可叠至32层并逐层衰减；削减不计为伤害但
 *    可触发时光之末；带火单位碰撞箱碰到无火单位时传染同等层数；对文明存续阵营
 *    无效；目标为玩家且削减超过现有生命值时立刻击杀（无视复活与锁血），
 *    复活后最大生命值强制锁定为1，期间武器生命加成视为0。
 * 4. 时光之末：本武器造成的伤害100%溅射至半径8格内所有敌方单位；被溅射单位
 *    再以50%、25%……逐级衰减概率向周围8格继续溅射，伤害均为100%原有伤害。
 * 5. 昔时我见：携带者受到致死伤害（计算后伤害 > 目标当前剩余生命值）时拒绝死亡、
 *    无视此次伤害，并把生命锚定在现有最大生命值32.5%；15秒内任何时刻超过锚定线，
 *    则2秒后扣除超出部分生命值和50%当前最大生命值，扣除时生命值不够则死亡；
 *    本效果可循环使用。所有走受击链的致死来源（含自身/环境伤害）都会触发，
 *    如我所见自身的真伤/时光之末溅射这类不经受击事件、直接压血结算的路径也会在
 *    结算前先判一次，避免「伤害溢出」绕过保命。越线扣除后直接解除判定窗口，
 *    可立即再次发动；若越线扣血致死，则照常触发未在 CD 的「巴别塔回忆」。
 *    本效果优先于「预言家」博士的「巴别塔回忆」：携带如我所见时博士不会真死，
 *    巴别塔等不到死亡登记、主动让位；只有本效果不可用（未携带 / 被流放，或已处于
 *    15秒保命窗口内，或越线扣血死亡）时，博士才真正死亡并由巴别塔献祭复活，
 *    两个保命不再互相吞掉。
 * 6. 无下限•内化宇宙•阳：自身持有“阴”标记且成功对目标施加“阳”标记（锚定现实）时，
 *    附近所有带阴/阳标记的存活生物被拉入虚空并在原地留下空间锚点，10秒后归来。
 *    期间每秒判定：5%即死；其余95%在+3250、+325、+3.25%、+32.5%、-3250、-325、
 *    -3.25%、-32.5%（上限与当前血量同步）八档中平分。虚空内无法移动、无法攻击，
 *    复活与免死效果无效（复用天堂支点的虚空结算）。
 *    锚定现实触发内化宇宙时，原本的锚定停滞推迟到10秒判定归来后兑现；效果造成者
 *    死亡则不再触发，目标在虚空内死亡则无法复活。
 * 7. 无下限•内化宇宙•开放：与阳独立判定——同一生物同时持有“阴”“阳”两枚印记即可触发，
 *    判定与光点表现完全复用天堂支点的内化宇宙。
 *
 * 阴/阳标记与“处刑锁定”的存储复用 {@link TiantangzhidianLogic}：
 * “阴”仍由天堂支点的流放虚空施加，“阳”则只来源于本武器的锚定现实。
 */
public final class RuwosuojianLogic {

    // ---------------- Persistent data 键 ----------------
    private static final String EXTRA_HEALTH = "OfcRwsExtraHealth";
    private static final String FIRE_LAYERS = "OfcRwsFireLayers";
    private static final String FIRE_NEXT = "OfcRwsFireNext";
    private static final String ANCHOR_UNTIL = "OfcRwsAnchorUntil";
    /** 「锚定现实」对同一目标的内置冷却：只记在施术者身上，按目标 UUID 分开，同种生物不共用。 */
    private static final String ANCHOR_CD_ABILITY = "ruwosuojian_anchor_reality";
    private static final String ANCHOR_X = "OfcRwsAnchorX";
    private static final String ANCHOR_Y = "OfcRwsAnchorY";
    private static final String ANCHOR_Z = "OfcRwsAnchorZ";
    private static final String XS_UNTIL = "OfcRwsXsUntil";
    private static final String XS_PENALTY_AT = "OfcRwsXsPenaltyAt";
    private static final String XS_EXCESS = "OfcRwsXsExcess";
    private static final String XS_STACKS = "OfcRwsXsStacks";
    /** 持械者连续未触发锚定现实的攻击次数（用于概率递增；触发后归零）。 */
    private static final String ANCHOR_STREAK = "OfcRwsAnchorAtkStreak";

    // ---------------- 属性修饰符 UUID ----------------
    private static final UUID EXTRA_UUID = UUID.fromString("b83e64c2-1a55-4d37-9f1b-4e7d2c881710");
    private static final UUID XS_UUID = UUID.fromString("b83e64c2-1a55-4d37-9f1b-4e7d2c881711");
    private static final UUID FLOOR_UUID = UUID.fromString("b83e64c2-1a55-4d37-9f1b-4e7d2c881712");

    // ---------------- 数值常量 ----------------
    private static final double FIRST_STAGE_RATIO = 0.25D;
    private static final double LIFESTEAL_RATIO = 1.0D;
    private static final double LOCAL_LIFESTEAL_RATIO = 1.0D;
    private static final double LOCAL_LIFESTEAL_RADIUS = 32.0D;
    private static final double ANCHOR_CHANCE = 0.0325D;
    /** 锚定现实概率递增步长：每次未触发攻击 +0.5%。 */
    private static final double ANCHOR_CHANCE_STEP = 0.005D;
    private static final long ANCHOR_MIN_TICKS = 200L;
    private static final int ANCHOR_SPAN_TICKS = 401;
    private static final long ANCHOR_CD_TICKS = 1200L;
    private static final long YANG_MARK_TICKS = 1200L;
    /** 内化宇宙的虚空停留时长（tick）：被推迟兑现的锚定，其执行窗口要顺延这段时间。 */
    private static final long UNIVERSE_DEFER_TICKS = 200L;
    private static final double FIRE_CHANCE = 0.1625D;
    private static final int FIRE_LAYER_TICKS = 650;
    private static final int FIRE_MAX_LAYERS = 32;
    private static final double FIRE_CUT_PER_LAYER = 0.01D;
    private static final double FIRE_MIN_CUT = 3.0D;
    private static final double SPLASH_RADIUS = 8.0D;
    private static final int SPLASH_MAX_DEPTH = 8;
    private static final double SPLASH_MIN_PROB = 0.004D;
    private static final double XS_ANCHOR_RATIO = 0.325D;
    /**
     * 昔时我见的保命判定窗口：15 秒。窗口内只要生命始终不越过锚定线，就成功活下来；
     * 一旦越线，2 秒后结算代价。此前误写成 2 秒窗口且无条件结算，导致「保命」必定
     * 在 2 秒后把自己扣死——这正是保命机制触发异常。
     */
    private static final long XS_WINDOW_TICKS = 300L;
    /** 越过锚定线后到结算代价的延迟：2 秒。 */
    private static final long XS_DELAY_TICKS = 40L;
    /** 结算代价：扣除超出锚定线的那部分生命值，再扣 50% 当前最大生命值。 */
    private static final double XS_PENALTY_RATIO = 0.50D;
    /** 旧版「昔时代价」每层削减的上限比例：仅用于还原旧存档已叠加的层数。 */
    private static final double XS_STACK_CAP_RATIO = 0.325D;
    /** 生命与锚定线比较时的浮点容差，避免「设到锚定线」本身被误判为越线。 */
    private static final double XS_ANCHOR_EPSILON = 1.0E-4D;

    private RuwosuojianLogic() {
    }

    // ---------------- 持有判定 ----------------

    public static boolean isSwordHeld(LivingEntity entity) {
        if (entity == null) return false;
        return entity.getMainHandItem().is(GeneratedMod.RUWOSUOJIAN.get())
                || entity.getOffhandItem().is(GeneratedMod.RUWOSUOJIAN.get());
    }

    /** 携带判定：主手、副手或背包中的任意一格。 */
    public static boolean hasAccess(LivingEntity entity) {
        if (entity == null) return false;
        if (isSwordHeld(entity)) return true;
        if (entity instanceof Player player) {
            for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
                if (player.getInventory().getItem(i).is(GeneratedMod.RUWOSUOJIAN.get())) return true;
            }
        }
        return false;
    }

    /**
     * 如我所见的普通近战命中入口；月牙形剑气作为近战武器延伸同样计入。
     * 只认主手：近战伤害永远由主手武器打出，副手再拿着如我所见时，
     * 用影霄等别的武器攻击不得再蹭出如我所见的阳火等命中附加（修复影霄可挂阳火）。
     */
    private static boolean isSwordAttackSource(DamageSource source) {
        return source != null && source.getEntity() instanceof LivingEntity attacker
                && attacker.getMainHandItem().is(GeneratedMod.RUWOSUOJIAN.get())
                && (source.getDirectEntity() == attacker
                    || source.getDirectEntity() instanceof SwordQiEntity qi && qi.getOwner() == attacker);
    }

    // ---------------- 状态查询 ----------------

    public static boolean isAnchored(LivingEntity entity) {
        return entity != null && entity.getPersistentData().getLong(ANCHOR_UNTIL)
                > entity.level().getGameTime();
    }

    /**
     * 沉默判定：被锚定（锚定现实的附加效果）、被流放虚空或进入无 AI 状态视为“沉默”——
     * 正在释放的技能被打断，沉默期间一切主动技能（领域、剑气、锁定陨石、召唤等）无法发动；
     * 普通攻击、索敌与受击反馈照常，不受沉默限制。
     */
    public static boolean isSilenced(LivingEntity entity) {
        if (entity == null) return false;
        if (isAnchored(entity)) return true;
        if (TiantangzhidianLogic.isExiled(entity)) return true;
        return entity instanceof Mob mob && mob.isNoAi();
    }

    public static int fireLayers(LivingEntity entity) {
        if (entity == null) return 0;
        return entity.getPersistentData().getIntArray(FIRE_LAYERS).length;
    }

    /** 创造栏「阳火」物品右键生物时的入口：对目标附加满层阳火效果（服务端调用）。 */
    public static void applyYangFire(LivingEntity target) {
        if (target == null || target.level().isClientSide) return;
        grantFire(target, FIRE_MAX_LAYERS, target.level().getGameTime());
    }

    // ---------------- 回复与上限 ----------------

    /** 回复携带者；满血时溢出部分转化为最大生命上限（仅在携带本武器时）。 */
    private static void healHolder(LivingEntity holder, double amount) {
        if (holder == null || !holder.isAlive() || amount <= 0.0D || !hasAccess(holder)) return;
        CompoundTag d = holder.getPersistentData();
        float before = holder.getHealth();
        holder.heal((float) amount);
        double overflow = amount - (holder.getHealth() - before);
        if (overflow > 0.0D) {
            d.putDouble(EXTRA_HEALTH, Math.max(0.0D, d.getDouble(EXTRA_HEALTH)) + overflow);
            syncModifiers(holder);
            holder.heal((float) overflow);
        }
    }

    /**
     * 最大生命值加成/昔时代价修饰符同步；处刑锁定期间武器加成全部视为0
     * （由天堂支点的锁定逻辑把上限钉为1）。
     * 同步入口挂在受击事件、治疗回调与周期 tick 上，必须先清除再添加：
     * 同一 UUID 被重复添加时原版会抛
     * “Modifier is already applied on this attribute!” 并直接崩服。
     */
    public static void syncModifiers(LivingEntity entity) {
        if (entity == null || entity.level().isClientSide) return;
        AttributeInstance maxHealth = entity.getAttribute(Attributes.MAX_HEALTH);
        if (maxHealth == null) return;
        CompoundTag d = entity.getPersistentData();
        clearHealthModifiers(maxHealth);
        if (TiantangzhidianLogic.isExecutionLocked(entity)) return;
        boolean hasSword = hasAccess(entity);
        if (!hasSword) {
            // “丢弃或掉落后清除加成”：武器离开携带范围时，源石权柄的溢出生命立即消失。
            d.remove(EXTRA_HEALTH);
        }
        double extra = hasSword ? Math.max(0.0D, d.getDouble(EXTRA_HEALTH)) : 0.0D;
        OfcAttributes.set(maxHealth, EXTRA_UUID, "如我所见•源石权柄", extra,
                AttributeModifier.Operation.ADDITION);
        int stacks = d.getInt(XS_STACKS);
        // 旧版「昔时代价」每层削减32.5%当前最大生命值，上限按剩余67.5%累计。
        // 新结算改为按窗口越线扣血，不再叠加此层数；这里只保留对旧存档数据的兼容还原。
        OfcAttributes.set(maxHealth, XS_UUID, "如我所见•昔时代价",
                Math.pow(1.0D - XS_STACK_CAP_RATIO, stacks) - 1.0D,
                AttributeModifier.Operation.MULTIPLY_TOTAL, stacks > 0);
        // 不再设“生存下限”：原始上限总值被削到 0 视为正常死亡（见 MaxHealthZeroLogic）；
        // 归零死亡的玩家复活后上限为 1（由原版 1.0 下限钉住），不再重复归零处死。
        if (entity.getHealth() > entity.getMaxHealth()) {
            entity.setHealth(entity.getMaxHealth());
        }
        // 削减在此处生效后立即结算：原始上限总值归零的实体当场按正常死亡处理。
        MaxHealthZeroLogic.settleIfZeroCap(entity);
    }

    /** 清除本类写入最大生命值上的全部修饰符。 */
    private static void clearHealthModifiers(AttributeInstance maxHealth) {
        OfcAttributes.clear(maxHealth, EXTRA_UUID);
        OfcAttributes.clear(maxHealth, XS_UUID);
        OfcAttributes.clear(maxHealth, FLOOR_UUID);
    }

    // ---------------- 真实伤害 ----------------

    private static DamageSource attributionSource(LivingEntity holder, Level level) {
        return holder instanceof Player player
                ? level.damageSources().playerAttack(player)
                : level.damageSources().mobAttack(holder);
    }

    /**
     * 真实伤害：直接压血并结算死亡，不经事件链（免死无效）。
     * derived=true 表示该击杀属于溅射（时光之末），非近战直接击杀；
     * 仅会影响“女祭司”普瑞赛斯的击杀学习判定（详见 LearnedTraitLogic.canLearnFromKill），
     * 「预言家」博士的近战与溅射击杀均正常学习。
     */
    private static float applyTrueDamage(LivingEntity source, LivingEntity victim, double amount, boolean derived) {
        if (victim == null || !victim.isAlive() || amount <= 0.0D) return 0.0F;
        // 昔时我见：真伤路径（第一段 / 时光之末溅射）是直接压低生命值、不经过受击事件的，
        // 原本会绕过昔时我见的「受到致死伤害时保命」，导致伤害溢出（该次伤害达到并超过
        // 目标当前剩余生命值）时昔时我见未触发、目标直接死亡。这里在结算前先按致死判定规则
        // （计算后伤害 > 目标当前剩余生命值）判一次，可保命则优先保命，伤害视为已被无视。
        if (amount >= victim.getHealth() && xishiAvailable(victim)) {
            activateXishi(victim, victim.level().getGameTime());
            return 0.0F;
        }
        float dealt = (float) Math.min(Math.max(0.0D, amount), (double) victim.getHealth());
        if (dealt <= 0.0F) return 0.0F;
        victim.setHealth(Math.max(0.0F, victim.getHealth() - dealt));
        // setHealth 不会自动进入 LivingEntity 的死亡流程；目标压到零血后必须显式 die()，
        // 否则目标停留在零生命状态，死亡登记（含巴别塔回忆的死亡快照）等一律等不到。
        // die() 内部会对「已移除 / 已死亡」再判一次，重复调用也是安全空操作。
        if (victim.getHealth() <= 0.0F) {
            if (derived) LearnedTraitLogic.markDerivedKill(victim);
            victim.die(attributionSource(source, victim.level()));
        }
        return dealt;
    }

    // ---------------- 锚定现实 ----------------

    private static boolean isCreativeLike(LivingEntity entity) {
        return entity instanceof ServerPlayer player && (player.isCreative() || player.isSpectator());
    }

    /**
     * 锚定可行判定：施术者对该目标不在CD、目标不在锚定中、不在虚空流放中，创作/旁观免疫。
     *
     * <p>冷却记在施术者（{@code holder}）身上并按目标 UUID 分开，因此两只「博士」或两只
     * 同种生物各自独立计时，不会因为攻击了同一个目标而共用一份冷却。</p>
     */
    private static boolean canBeAnchored(LivingEntity holder, LivingEntity victim, long now) {
        if (victim == null || !victim.isAlive() || isCreativeLike(victim)) return false;
        if (TiantangzhidianLogic.isExiled(victim) || isAnchored(victim)) return false;
        return AbilityCooldowns.readyFor(holder, victim, now, ANCHOR_CD_ABILITY);
    }

    /**
     * 施加锚定现实：停滞移动/空间位置并附加打断现有技能（沉默），不再停攻击与索敌，
     * 同时施加“阳”标记（阳标记的唯一来源）。
     * 停滞只作用于目标本身，施加者不受任何影响——「预言家」博士在本次锚定的执行窗口内
     * 索敌照常（窗口登记见 {@link ProphetSkillLogic#markAnchorExecution}）。
     * 成功施加时返回锚定到期时刻，失败返回0。
     */
    private static long applyAnchor(LivingEntity holder, LivingEntity victim, long until, long now) {
        if (!canBeAnchored(holder, victim, now)) return 0L;
        boolean hadYin = TiantangzhidianLogic.hasYin(victim);
        TiantangzhidianLogic.setYangMark(victim, YANG_MARK_TICKS);
        // 无下限•内化宇宙•阳：施术者持有“阴”标记（来源于天堂支点），对目标施加反向印记“阳”。
        // 无下限•内化宇宙•开放：同一生物同时持有阴阳两枚印记。阳与开放独立判定，去重交给 triggerUniverse。
        boolean wielderHasYin = holder != null && holder.isAlive()
                && TiantangzhidianLogic.hasYin(holder);
        boolean deferred = false;
        if (wielderHasYin) {
            // 阳之机制：原本的锚定停滞推迟到10秒判定归来后兑现。
            TiantangzhidianLogic.deferOriginalEffect(victim, holder,
                    TiantangzhidianLogic.DEFER_MODE_ANCHOR, until - now);
            TiantangzhidianLogic.triggerUniverse(holder, victim, "无下限•内化宇宙•阳");
            deferred = true;
        } else if (hadYin && holder != null && holder.isAlive()) {
            // 开放之机制：目标同时持有阴阳两枚印记，原本的锚定停滞推迟到归来后兑现。
            TiantangzhidianLogic.deferOriginalEffect(victim, holder,
                    TiantangzhidianLogic.DEFER_MODE_ANCHOR, until - now);
            TiantangzhidianLogic.triggerUniverse(holder, victim, "无下限•内化宇宙•开放");
            deferred = true;
        } else {
            startAnchor(holder, victim, until, now);
        }
        // 执行窗口：被内化宇宙推迟兑现的锚定，顺延虚空停留的 10 秒；其余以停滞到期时刻为准。
        ProphetSkillLogic.markAnchorExecution(holder, deferred ? until + UNIVERSE_DEFER_TICKS : until);
        return until;
    }

    /** 施加锚定停滞状态（含阳标记、位置钉固、禁重力、减速与技能沉默打断；不再停攻击与索敌）。 */
    private static void startAnchor(LivingEntity holder, LivingEntity victim, long until, long now) {
        CompoundTag d = victim.getPersistentData();
        d.putLong(ANCHOR_UNTIL, until);
        // 内置冷却记在施术者身上、按目标分开：同种生物各记各的，绝不共用。
        AbilityCooldowns.armFor(holder, victim, now, ANCHOR_CD_TICKS, ANCHOR_CD_ABILITY);
        d.putDouble(ANCHOR_X, victim.getX());
        d.putDouble(ANCHOR_Y, victim.getY());
        d.putDouble(ANCHOR_Z, victim.getZ());
        // 锁定效果触发时施加“阳”标记，随60秒内置间隔一起到期消失。
        TiantangzhidianLogic.setYangMark(victim, YANG_MARK_TICKS);
        // 打断现有技能（沉默）：终止正在进行的物品使用/寻路，进行中的动作演出交给
        // 兼容层打断（史诗战斗存在时把当前动画强制转成受击硬直）；此后的技能再发动
        // 由各发动入口按 {@link #isSilenced} 拦截，攻击与索敌不受影响、照常进行。
        victim.stopUsingItem();
        if (victim instanceof Mob mob) mob.getNavigation().stop();
        SilenceHooks.interruptSkills(victim);
        victim.setDeltaMovement(Vec3.ZERO);
        victim.setNoGravity(true);
        victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,
                (int) (until - now) + 40, 255, false, false));
        if (victim.level() instanceof ServerLevel serverLevel) {
            serverLevel.playSound(null, victim.getX(), victim.getY(), victim.getZ(),
                    SoundEvents.SHULKER_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.6F);
            serverLevel.sendParticles(ParticleTypes.END_ROD, victim.getX(), victim.getY() + 1.2D,
                    victim.getZ(), 24, 0.35D, 0.9D, 0.35D, 0.02D);
        }
        if (victim instanceof Player target) {
            target.displayClientMessage(Component.literal("锚定现实：停滞于此，所有技能被沉默")
                    .withStyle(ChatFormatting.LIGHT_PURPLE), true);
        }
    }

    /**
     * 内化宇宙归来后兑现“锚定现实”原本效果：重新施加停滞与阳标记（不再触发内化宇宙）。
     * {@code holder} 为本次锚定的施术者，冷却同样按这只生物自己计算。
     */
    public static void applyDeferredAnchor(LivingEntity holder, LivingEntity victim, long durationTicks, long now) {
        if (victim == null || victim.level().isClientSide || !victim.isAlive()) return;
        startAnchor(holder, victim, now + durationTicks, now);
    }

    private static void endAnchor(LivingEntity entity) {
        CompoundTag d = entity.getPersistentData();
        d.remove(ANCHOR_UNTIL);
        d.remove(ANCHOR_X);
        d.remove(ANCHOR_Y);
        d.remove(ANCHOR_Z);
        // 锚定结束（原本的锚定现实兑现完成）：解除内化宇宙的“不可复活”标记。
        TiantangzhidianLogic.clearNoRevive(entity);
        // 沉默只随锚定标记自然解除；不再触碰 AI 开关（锚定早已不停索敌，无需恢复）。
        if (entity.isAlive() && !TiantangzhidianLogic.isExiled(entity)) {
            entity.setNoGravity(false);
            entity.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
        }
    }

    /** 锚定期间：位置逐tick钉回（移动/空间停滞保留）；攻击与索敌不再被停止，沉默只拦技能发动。 */
    private static void tickAnchor(LivingEntity entity, CompoundTag d, long now) {
        long until = d.getLong(ANCHOR_UNTIL);
        if (until <= 0L) return;
        if (now >= until) {
            endAnchor(entity);
            return;
        }
        // 被流放至虚空时由天堂支点接管位置，避免双端钉位互相拉扯。
        if (TiantangzhidianLogic.isExiled(entity)) return;
        // 旧版本存档迁移：此前锚定会把生物置为无 AI，取消“停止攻击/索敌”后须当场恢复。
        if (entity instanceof Mob mob && mob.isNoAi()) mob.setNoAi(false);
        entity.setDeltaMovement(Vec3.ZERO);
        if (!entity.isNoGravity()) entity.setNoGravity(true);
        entity.fallDistance = 0.0F;
        double ax = d.getDouble(ANCHOR_X);
        double ay = d.getDouble(ANCHOR_Y);
        double az = d.getDouble(ANCHOR_Z);
        if (Math.abs(entity.getX() - ax) > 0.08D || Math.abs(entity.getY() - ay) > 0.08D
                || Math.abs(entity.getZ() - az) > 0.08D) {
            entity.teleportTo(ax, ay, az);
        }
        if (entity.tickCount % 5 == 0 && entity.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.REVERSE_PORTAL, entity.getX(),
                    entity.getY() + 1.0D, entity.getZ(), 3, 0.3D, 0.7D, 0.3D, 0.01D);
        }
    }

    // ---------------- 阳火 ----------------

    /** 阳火免疫：文明存续阵营单位与创作/旁观玩家不受“阳火”影响。 */
    private static boolean canBeBurned(LivingEntity entity) {
        if (entity == null || !entity.isAlive()) return false;
        if (isCreativeLike(entity)) return false;
        return !CalamityLogic.isContinuanceFactionMember(entity);
    }

    /** 授予阳火层：每层独立记32.5秒余量，总层数封顶32；逐层衰减即单层各自到期。 */
    private static void grantFire(LivingEntity entity, int layers, long now) {
        if (layers <= 0 || !canBeBurned(entity)) return;
        CompoundTag d = entity.getPersistentData();
        int[] cur = d.getIntArray(FIRE_LAYERS);
        int space = FIRE_MAX_LAYERS - cur.length;
        int add = Math.min(layers, space);
        if (add <= 0) {
            if (cur.length == 0) return;
            // 已满32层：整体刷新各层余量，避免完全无效。
            int[] refreshed = Arrays.stream(cur).map(v -> FIRE_LAYER_TICKS).toArray();
            d.putIntArray(FIRE_LAYERS, refreshed);
        } else {
            int[] merged = Arrays.copyOf(cur, cur.length + add);
            Arrays.fill(merged, cur.length, merged.length, FIRE_LAYER_TICKS);
            d.putIntArray(FIRE_LAYERS, merged);
        }
        if (d.getLong(FIRE_NEXT) <= now) {
            d.putLong(FIRE_NEXT, now + 20L);
        }
        // 层数变化即时同步给追踪客户端，驱动阳火独立模型的渲染。
        YangFireNetworking.syncToTrackers(entity);
    }

    /** 每秒燃烧：削减 layers×1% 当前最大生命值（最低3点，不计为伤害），并触发时光之末。 */
    private static void tickFire(LivingEntity entity, CompoundTag d, long now) {
        int[] layers = d.getIntArray(FIRE_LAYERS);
        if (layers.length == 0) {
            d.remove(FIRE_LAYERS);
            d.remove(FIRE_NEXT);
            return;
        }
        if (entity.tickCount % 4 == 0 && entity.level() instanceof ServerLevel serverLevel) {
            // 阳火特效：改用岩浆上方的原版粒子（LAVA），由生物身体向外喷发（取消原自定义白金火焰）。
            double cx = entity.getX();
            double cy = entity.getY() + entity.getBbHeight() * 0.5D;
            double cz = entity.getZ();
            double spread = Math.max(0.15D, entity.getBbWidth() * 0.5D);
            serverLevel.sendParticles(ParticleTypes.LAVA, cx, cy, cz, 6,
                    spread, entity.getBbHeight() * 0.5D, spread, 0.08D);
        }
        if (entity.tickCount % 40 == 0) {
            // 周期性重播层数：覆盖中途开始追踪该实体的玩家。
            YangFireNetworking.syncToTrackers(entity);
        }
        if (now < d.getLong(FIRE_NEXT) || !entity.isAlive()) return;
        d.putLong(FIRE_NEXT, now + 20L);
        int[] decayed = Arrays.stream(layers).map(v -> v - 20).filter(v -> v > 0).toArray();
        if (decayed.length == 0) {
            d.remove(FIRE_LAYERS);
            d.remove(FIRE_NEXT);
            YangFireNetworking.syncToTrackers(entity);
            return;
        }
        d.putIntArray(FIRE_LAYERS, decayed);
        YangFireNetworking.syncToTrackers(entity);
        double cut = Math.max(FIRE_MIN_CUT, decayed.length * FIRE_CUT_PER_LAYER * entity.getMaxHealth());
        // 最大血量削减不计算为伤害：直接走上限削减通道（玩家超限即处刑）。
        TiantangzhidianLogic.applyMaxHpCut(entity, entity, cut);
        if (entity.isAlive() && entity.level() instanceof ServerLevel serverLevel) {
            Set<UUID> visited = new HashSet<>();
            visited.add(entity.getUUID());
            endOfTime(serverLevel, entity, entity, cut, 1.0D, 0, visited, 0L, 0, true, now);
        }
    }

    /** 碰撞箱接触传染：带火单位碰到无火单位时，对方感染同等层数。 */
    private static void spreadFire(LivingEntity entity, long now) {
        int layers = fireLayers(entity);
        if (layers <= 0 || !(entity.level() instanceof ServerLevel serverLevel)) return;
        List<LivingEntity> touching = serverLevel.getEntitiesOfClass(LivingEntity.class,
                entity.getBoundingBox().inflate(0.125D),
                other -> other != entity && other.isAlive() && fireLayers(other) == 0 && canBeBurned(other));
        for (LivingEntity other : touching) {
            grantFire(other, layers, now);
        }
    }

    // ---------------- 时光之末 ----------------

    /** 溅射候选敌意判定：除使用者本人、创作/旁观玩家与同阵营友军外皆为目标。 */
    private static boolean isSplashTarget(LivingEntity source, LivingEntity candidate, boolean fromFire) {
        if (candidate == source || !candidate.isAlive() || isCreativeLike(candidate)) return false;
        if (TiantangzhidianLogic.isExiled(candidate)) return false;
        if (CalamityLogic.isFactionAlly(source, candidate)) return false;
        // 阳火引燃的溅射属于“阳火可触发时光之末”，同样不触碰文明存续阵营。
        return !fromFire || !CalamityLogic.isContinuanceFactionMember(candidate);
    }

    /**
     * 时光之末溅射链：从 origin 出发对半径8格内的敌方单位造成100%原有伤害，
     * 被溅射单位再按 50%、25%……逐级衰减概率继续溅射；已命中单位不重复判定。
     * carryAnchor/carryFire 为主目标本轮触发的附加效果，随整条溅射链携带（等控制时长）。
     */
    private static void endOfTime(ServerLevel level, LivingEntity source, LivingEntity origin,
                                  double damage, double prob, int depth, Set<UUID> visited,
                                  long carryAnchorUntil, int carryFireLayers, boolean fromFire, long now) {
        if (depth > SPLASH_MAX_DEPTH || prob < SPLASH_MIN_PROB || damage <= 0.0D) return;
        // origin 允许刚被第一段伤害击杀：碰撞箱仍在，溅射照常向外传播。
        if (origin == null) return;
        List<LivingEntity> candidates = level.getEntitiesOfClass(LivingEntity.class,
                origin.getBoundingBox().inflate(ProphetSkillLogic.amplifiedRange(source, SPLASH_RADIUS)),
                entity -> isSplashTarget(source, entity, fromFire)
                        && !visited.contains(entity.getUUID()));
        List<LivingEntity> hitList = new ArrayList<>();
        for (LivingEntity candidate : candidates) {
            if (!candidate.isAlive()) continue;
            if (prob < 1.0D && level.getRandom().nextDouble() >= prob) continue;
            // 概率判定通过后才登记已命中；若该实体已在同一条溅射链中被命中过
            // （例如位于多个半径重叠的溅射源范围内），跳过，避免一次溅射对同一目标重复结算。
            if (!visited.add(candidate.getUUID())) continue;
            float dealt = applyTrueDamage(source, candidate, damage, true);
            // 溅射伤害同样适用极•源石权柄•阳的回复。
            if (dealt > 0.0D) healHolder(source, dealt * LIFESTEAL_RATIO);
            if (candidate.isAlive()) {
                if (carryAnchorUntil > 0L) {
                    applyAnchor(source, candidate, carryAnchorUntil, now);
                }
                if (carryFireLayers > 0) {
                    grantFire(candidate, carryFireLayers, now);
                }
            }
            hitList.add(candidate);
        }
        // 先在本层把所有目标结算完，再逐目标触发下一层溅射，保证“本层满概率命中、下一层才逐级衰减”：
        // 否则同一目标若同时落在两个半径重叠的溅射源内，会被先到的那一跳按衰减后的概率提前命中，
        // 导致本该 100% 命中的一环被记为低概率命中，伤害判定异常。
        for (LivingEntity candidate : hitList) {
            endOfTime(level, source, candidate, damage, prob * 0.5D, depth + 1, visited,
                    carryAnchorUntil, carryFireLayers, fromFire, now);
        }
    }

    // ---------------- 昔时我见 ----------------

    /**
     * 昔时我见的可用判定：携带如我所见、不在虚空流放中，且未处于 15 秒保命窗口内。
     *
     * <p>这是让位的方向所在：昔时我见可用时优先保命，博士不会真死，「巴别塔回忆」的死亡复活
     * 因此等不到死亡登记、主动让位；只有本效果不可用（未携带如我所见 / 被流放，或已处于窗口内）
     * 时，博士才真正死亡并由巴别塔献祭复活——两个保命机制不再互相吞掉对方。</p>
     */
    public static boolean xishiAvailable(LivingEntity entity) {
        if (entity == null || !entity.isAlive()) return false;
        if (!hasAccess(entity)) return false;
        if (TiantangzhidianLogic.isExiled(entity)) return false;
        return entity.getPersistentData().getLong(XS_UNTIL) <= entity.level().getGameTime();
    }

    /** 致命伤害判定：生命锚定在最大生命值32.5%，开启15秒保命窗口（不越线则免罚）。 */
    private static void activateXishi(LivingEntity victim, long now) {
        double anchor = victim.getMaxHealth() * XS_ANCHOR_RATIO;
        // 只在生命低于锚定线时上抬；生命本就更高时不反向压低。
        if (victim.getHealth() < anchor) victim.setHealth((float) anchor);
        CompoundTag d = victim.getPersistentData();
        d.putLong(XS_UNTIL, now + XS_WINDOW_TICKS);
        // 代价只在越线时才排期；窗口内不越线即保命成功。
        d.putLong(XS_PENALTY_AT, 0L);
        d.remove(XS_EXCESS);
        if (victim.level() instanceof ServerLevel level) {
            level.playSound(null, victim.getX(), victim.getY(), victim.getZ(),
                    SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 1.0F, 1.2F);
            level.sendParticles(ParticleTypes.ENCHANT, victim.getX(), victim.getY() + 1.0D,
                    victim.getZ(), 40, 0.6D, 0.9D, 0.6D, 0.12D);
        }
        if (victim instanceof Player player) {
            player.displayClientMessage(Component.literal("昔时我见：生命锚定于最大生命值的32.5%，15秒内不得超过锚定线")
                    .withStyle(ChatFormatting.LIGHT_PURPLE), false);
        }
    }

    /**
     * 昔时我见的窗口结算：
     * 窗口内生命越过锚定线，则 2 秒后扣除「超出部分 + 50% 当前最大生命值」，不够扣则死亡；
     * 15 秒内始终不越线，则保命成功、窗口正常结束，本效果可在下次濒死时再次发动。
     * 越线扣除结算后直接解除判定窗口（移除 XS_UNTIL），因此扣除后若仍存活，
     * 昔时我见可立即再次发动；若扣除致死，则照常走完整死亡流程（die()），
     * 使巴别塔回忆等登记者能接到尚未在 CD 的死亡登记。
     */
    private static void tickXishi(LivingEntity entity, CompoundTag d, long now) {
        long until = d.getLong(XS_UNTIL);
        if (until <= 0L) return;
        long penaltyAt = d.getLong(XS_PENALTY_AT);
        if (penaltyAt > 0L) {
            if (now < penaltyAt) return;
            // 已越线：2 秒结算。即使窗口同时到期也照常兑现（「15秒内任意时刻越线」）。
            d.putLong(XS_PENALTY_AT, 0L);
            d.remove(XS_UNTIL);
            double excess = d.getDouble(XS_EXCESS);
            d.remove(XS_EXCESS);
            double deduct = excess + entity.getMaxHealth() * XS_PENALTY_RATIO;
            float after = (float) (entity.getHealth() - deduct);
            if (after > 0.0F) {
                entity.setHealth(after);
            } else {
                // 扣除时生命值不够：直接死亡，免死无效。setHealth(0) 后 isAlive() 已为 false，
                // 「if (entity.isAlive()) entity.die(...)」会被跳过，导致巴别塔回忆等登记者
                // 永远等不到死亡登记——越过锚定线却扣血死亡时，必须照常触发未在 CD 的巴别塔回忆，
                // 故这里直接走完整死亡流程（die() 内部会对已死/已移除再判一次，安全）。
                entity.setHealth(0.0F);
                entity.die(entity.level().damageSources().magic());
                return;
            }
            if (entity instanceof Player player) {
                player.displayClientMessage(Component.literal("昔时我见：越过锚定线，判定结束，扣除超出生命与50%当前最大生命值")
                        .withStyle(ChatFormatting.RED), false);
            }
            return;
        }
        double anchor = entity.getMaxHealth() * XS_ANCHOR_RATIO;
        if (entity.getHealth() > anchor + XS_ANCHOR_EPSILON) {
            // 越线：记下超出部分，排期 2 秒后的代价结算。
            d.putDouble(XS_EXCESS, entity.getHealth() - anchor);
            d.putLong(XS_PENALTY_AT, now + XS_DELAY_TICKS);
            return;
        }
        if (now >= until) {
            // 15 秒内始终未越线：保命成功。
            d.remove(XS_UNTIL);
            d.remove(XS_PENALTY_AT);
            d.remove(XS_EXCESS);
            if (entity instanceof Player player) {
                player.displayClientMessage(Component.literal("昔时我见：锚定解除，保命成功")
                        .withStyle(ChatFormatting.LIGHT_PURPLE), false);
            }
        }
    }

    // ---------------- 事件入口 ----------------

    // 注意：嵌套类简单名必须全局唯一。Forge eventbus 为处理器生成的动态调用类
    // 名为 "__<声明类简单名>_<方法名>_<事件简单名>"，与 TiantangzhidianLogic 里
    // 同名的 Events 会撞车，触发 ClassCastException（实体 tick 时崩溃）。
    public static final class RuwosuojianEvents {

        public RuwosuojianEvents() {
        }

        @SubscribeEvent
        public void onLivingAttack(LivingAttackEvent event) {
            LivingEntity victim = event.getEntity();
            Level level = victim.level();
            if (level.isClientSide || event.isCanceled()) return;
            long now = level.getGameTime();
            DamageSource source = event.getSource();
            LivingEntity attacker = source.getEntity() instanceof LivingEntity living ? living : null;
            // 锚定现实不再停止被锚定者的攻击（取消“停滞攻击”）；攻击与索敌照常，
            // 沉默只体现在技能发动入口的拦截与施加瞬间的打断上。
            // 被放逐至虚空者的攻击同样被打断（与天堂支点的放逐拦截保持一致）。
            if (attacker != null && TiantangzhidianLogic.isExiled(attacker)) {
                event.setCanceled(true);
                return;
            }
            float incoming = event.getAmount();
            // 极•源石权柄•阳：自身半径16格内生物的攻击伤害按65%回复自身。
            if (attacker != null && attacker != victim && incoming > 0.0F
                    && attacker.isAlive() && !attacker.isSpectator()) {
                for (LivingEntity carrier : level.getEntitiesOfClass(LivingEntity.class,
                        attacker.getBoundingBox().inflate(ProphetSkillLogic.amplifiedRange(attacker, LOCAL_LIFESTEAL_RADIUS)),
                        entity -> entity != attacker && entity.isAlive() && hasAccess(entity))) {
                    healHolder(carrier, incoming * LOCAL_LIFESTEAL_RATIO);
                }
            }
            if (attacker != null && attacker != victim && isSwordAttackSource(source)) {
                // 第一段：使用者最大生命值25%的真实伤害；第二段仍交给原版伤害链结算。
                double first = attacker.getMaxHealth() * FIRST_STAGE_RATIO;
                if (first + incoming >= victim.getHealth() && xishiAvailable(victim)) {
                    event.setCanceled(true);
                    activateXishi(victim, now);
                    return;
                }
                if (first + incoming >= victim.getHealth()
                        && TiantangzhidianLogic.canLethalBeRefused(victim, now)) {
                    event.setCanceled(true);
                    TiantangzhidianLogic.grantLethalRefusal(victim, now);
                    return;
                }
                float dealt = applyTrueDamage(attacker, victim, first, false);
                if (dealt > 0.0D) {
                    healHolder(attacker, dealt * LIFESTEAL_RATIO);
                }
                long carryAnchor = 0L;
                int carryFire = 0;
                if (victim.isAlive()) {
                    // 第二段的“造成伤害”按面板数值参与吸血与附加判定。
                    healHolder(attacker, incoming * LIFESTEAL_RATIO);
                    if (canBeAnchored(attacker, victim, now)) {
                        CompoundTag ad = attacker.getPersistentData();
                        int streak = ad.getInt(ANCHOR_STREAK);
                        double anchorChance = ANCHOR_CHANCE + streak * ANCHOR_CHANCE_STEP;
                        if (level.getRandom().nextDouble() < anchorChance) {
                            long until = now + ANCHOR_MIN_TICKS + level.getRandom().nextInt(ANCHOR_SPAN_TICKS);
                            carryAnchor = applyAnchor(attacker, victim, until, now);
                            if (carryAnchor > 0L) {
                                // 锚定成功触发：回到基础概率。
                                ad.putInt(ANCHOR_STREAK, 0);
                            } else {
                                // 因故未真正生效：视为未触发，继续递增。
                                ad.putInt(ANCHOR_STREAK, streak + 1);
                            }
                        } else {
                            // 未触发：连续计数 +1，下一次概率提高 0.5%。
                            ad.putInt(ANCHOR_STREAK, streak + 1);
                        }
                    }
                    if (canBeBurned(victim) && level.getRandom().nextDouble() < FIRE_CHANCE) {
                        grantFire(victim, 1, now);
                        carryFire = fireLayers(victim);
                    }
                }
                // 时光之末：本次伤害100%溅射至半径8格内所有敌方单位。
                if (level instanceof ServerLevel serverLevel && attacker.isAlive()) {
                    Set<UUID> visited = new HashSet<>();
                    visited.add(attacker.getUUID());
                    visited.add(victim.getUUID());
                    endOfTime(serverLevel, attacker, victim, incoming, 1.0D, 0, visited,
                            carryAnchor, carryFire, false, now);
                }
                // 不取消事件：原版本段伤害（第二段）照常走护甲、盾牌与附魔链。
                return;
            }
            // 昔时我见：首次受到致死伤害时立即触发；判定期间不得再次触发。
            // 让位方向：昔时我见可用即优先保命，巴别塔回忆等不到死亡登记、主动让位；
            // 唯有昔时我见不可用（未携带如我所见 / 被流放，或已处于窗口内）时，博士才真正
            // 死亡并交由巴别塔献祭复活——保命不再吞掉本该触发的死亡复活。
            // 致死伤害判定：该次伤害（计算后）大于目标当前剩余生命值即视为致死伤害；不限来源，
            // 自身/环境等走受击链的伤害同样触发，避免伤害溢出绕过昔时我见、让博士莫名死亡。
            if (incoming >= victim.getHealth() && xishiAvailable(victim)) {
                event.setCanceled(true);
                activateXishi(victim, now);
            }
        }

        @SubscribeEvent
        public void onLivingDeath(LivingDeathEvent event) {
            LivingEntity victim = event.getEntity();
            if (victim.level().isClientSide) return;
            CompoundTag d = victim.getPersistentData();
            if (isAnchored(victim)) {
                d.remove(ANCHOR_UNTIL);
                d.remove(ANCHOR_X);
                d.remove(ANCHOR_Y);
                d.remove(ANCHOR_Z);
            }
            boolean hadFire = d.getIntArray(FIRE_LAYERS).length > 0;
            d.remove(FIRE_LAYERS);
            d.remove(FIRE_NEXT);
            if (hadFire) {
                // 死亡清空阳火时同步熄灭客户端的阳火模型（死亡动画期间不再带火）。
                YangFireNetworking.syncToTrackers(victim);
            }
            d.remove(XS_UNTIL);
            d.remove(XS_PENALTY_AT);
            d.remove(XS_EXCESS);
        }

        @SubscribeEvent
        public void onLivingTick(LivingEvent.LivingTickEvent event) {
            LivingEntity entity = event.getEntity();
            Level level = entity.level();
            if (level.isClientSide) return;
            CompoundTag d = entity.getPersistentData();
            long now = level.getGameTime();
            tickAnchor(entity, d, now);
            tickFire(entity, d, now);
            tickXishi(entity, d, now);
            if (entity.tickCount % 10 == 0) {
                spreadFire(entity, now);
            }
            // 周期性重同步：处理武器丢弃/拾取导致的加成清除与恢复、处刑锁定期满。
            if (entity.tickCount % 10 == 0
                    && (entity instanceof Player || d.contains(EXTRA_HEALTH) || d.getInt(XS_STACKS) > 0)) {
                syncModifiers(entity);
            }
        }

        @SubscribeEvent
        public void onPlayerClone(PlayerEvent.Clone event) {
            if (!event.isWasDeath()) return;
            CompoundTag original = event.getOriginal().getPersistentData();
            CompoundTag copy = event.getEntity().getPersistentData();
            // 昔时代价的层数衰减跨死亡保留；锚定、阳火与昔时窗口在死亡时清空。
            copy.putInt(XS_STACKS, original.getInt(XS_STACKS));
        }
    }
}
