package cn.blockforge.generated.originfallcataclysm;

import cn.blockforge.generated.originfallcataclysm.client.NativeApocataDanceState;
import cn.blockforge.generated.originfallcataclysm.client.YangFireClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/**
 * 服务端→客户端的轻量同步通道（同模组共用一条，按报文类型分发）：
 * <ul>
 *   <li><b>阳火层数</b>：客户端渲染器据此决定给哪些实体叠加阳火模型。
 *       persistent data 不上网，这里用最小报文（实体id+层数）随实体追踪范围广播；</li>
 *   <li><b>本尊舞蹈</b>：深蓝之树本尊哈基玖（外部实体）开跳/补同步时广播舞程，
 *       客户端据此用本模组骨架走舞步通道（见 {@code NativeApocataAppearanceEvents}）。</li>
 * </ul>
 */
public final class YangFireNetworking {

    private static final String PROTOCOL = "1.0";
    public static final SimpleChannel INSTANCE = NetworkRegistry.newSimpleChannel(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "yang_fire"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private YangFireNetworking() {
    }

    /** 在模组构造阶段调用，触发通道与消息注册的静态初始化。 */
    public static void init() {
    }

    static {
        INSTANCE.registerMessage(0, Sync.class, Sync::encode, Sync::decode, (msg, ctx) -> {
            NetworkEvent.Context context = ctx.get();
            context.enqueueWork(() -> YangFireClientState.apply(msg.entityId(), msg.layers()));
            context.setPacketHandled(true);
        });
        INSTANCE.registerMessage(1, NativeDanceSync.class, NativeDanceSync::encode, NativeDanceSync::decode,
                (msg, ctx) -> {
                    NetworkEvent.Context context = ctx.get();
                    context.enqueueWork(() -> NativeApocataDanceState.onSync(
                            msg.entityId(), msg.totalTicks(), msg.remainingTicks()));
                    context.setPacketHandled(true);
                });
    }

    /** 把实体当前的阳火层数广播给所有追踪该实体的客户端（仅服务端调用）。 */
    public static void syncToTrackers(LivingEntity entity) {
        if (entity.level().isClientSide) return;
        INSTANCE.send(PacketDistributor.TRACKING_ENTITY.with(() -> entity),
                new Sync(entity.getId(), RuwosuojianLogic.fireLayers(entity)));
    }

    /** 本尊开跳广播（仅服务端调用）：追踪它的所有客户端按本地时间起一个 remaining 倒计时代跳。 */
    public static void syncNativeDance(Entity entity, int totalTicks, int remainingTicks) {
        if (entity.level().isClientSide) return;
        INSTANCE.send(PacketDistributor.TRACKING_ENTITY.with(() -> entity),
                new NativeDanceSync(entity.getId(), totalTicks, remainingTicks));
    }

    /** 给单个玩家定向补发本尊舞程（开始追踪正在跳舞的本尊时，补上错过的开跳广播）。 */
    public static void sendNativeDanceTo(ServerPlayer player, int entityId, int totalTicks, int remainingTicks) {
        INSTANCE.send(PacketDistributor.PLAYER.with(() -> player),
                new NativeDanceSync(entityId, totalTicks, remainingTicks));
    }

    public record Sync(int entityId, int layers) {

        void encode(FriendlyByteBuf buf) {
            buf.writeVarInt(entityId);
            buf.writeVarInt(layers);
        }

        static Sync decode(FriendlyByteBuf buf) {
            return new Sync(buf.readVarInt(), buf.readVarInt());
        }
    }

    /** 本尊舞蹈同步：{@code totalTicks} 供客户端姿势分相（elapsed = total − remaining），{@code remainingTicks} 为本地倒计时起点。 */
    public record NativeDanceSync(int entityId, int totalTicks, int remainingTicks) {

        void encode(FriendlyByteBuf buf) {
            buf.writeVarInt(entityId);
            buf.writeVarInt(totalTicks);
            buf.writeVarInt(remainingTicks);
        }

        static NativeDanceSync decode(FriendlyByteBuf buf) {
            return new NativeDanceSync(buf.readVarInt(), buf.readVarInt(), buf.readVarInt());
        }
    }
}
