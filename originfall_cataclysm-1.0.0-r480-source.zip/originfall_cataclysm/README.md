# 源石天灾（OriginFall Cataclysm）模组源代码

- Minecraft 版本：**1.20.1**
- 加载器：**Forge 47.4.0**（ForgeGradle [6.0, 6.2)）
- 模组版本：**1.0.0-r480**
- 模组 ID：`originfall_cataclysm`
- Java 版本：17（toolchain 已在 `build.gradle` 中声明）

## 目录结构

```
originfall_cataclysm/
├── build.gradle              ForgeGradle 构建脚本（含多源码集接线）
├── settings.gradle
├── gradle.properties
├── libs/                     编译期依赖（第三方模组 jar，仅 compileOnly，不打开发布包）
│   ├── epic-fight-20-6.14.17-mc1.20.1-forge.jar
│   ├── l2hostility-2-14.5.19.jar
│   └── l2library-2-8.5.3.jar
└── src/
    ├── main/                 主源码集
    │   ├── java/cn/blockforge/generated/originfallcataclysm/
    │   │   ├── *.java        游戏逻辑：天灾 Boss（普瑞塞斯 / 博士 / 阿波卡塔等）、
    │   │   │                 邪魔（Calamity）体系、坍缩效果、邪魔之约档位、源石感染、
    │   │   │                 陨石、决战音乐（FinalBattleMusic / PlayerPriestessBattleMusic）、
    │   │   │                 决战禁舞（PriestessDoctorDuel）、客户端/服务端事件等
    │   │   ├── client/       渲染器、粒子、客户端事件、舞蹈动作状态
    │   │   └── mixin/        LivingEntity 效果免疫 Mixin
    │   └── resources/
    │       ├── META-INF/mods.toml
    │       ├── pack.mcmeta / originfall_cataclysm.mixins.json
    │       ├── assets/originfall_cataclysm/   贴图、模型、音效（7 首内置曲目 ogg）、
    │       │                                  粒子、中英双语语言文件
    │       └── data/                          配方、战利品表、标签等数据
    ├── epicfight/            史诗战斗（Epic Fight）兼容层，仅在装有 Epic Fight 时加载
    └── l2compat/             莱特兰-恶意（L2Hostility）兼容层，仅在装有该模组时加载
```

## 构建方法

环境要求：JDK 17、Gradle 8.x（无需 wrapper，工程未附带；也可用你 IDE 自带的 Gradle）。

```bash
cd originfall_cataclysm
gradle build
```

产物位于 `build/libs/originfall_cataclysm-1.0.0-r480.jar`，放进 `.minecraft/mods` 即可。

说明：

1. `libs/` 下三个 jar 只参与 `epicfight` / `l2compat` 源码集的编译期类路径，
   不会打进成品 jar。运行时兼容层由主代码检测已装模组（ModList / 反射入口）后按需加载，
   因此模组在装有 / 未装这些第三方模组的环境中都能正常工作。
2. 首次构建 ForgeGradle 需要联网下载 Minecraft 与映射数据，属正常现象。
3. 音效为纯 Vorbis（ogg）码流，无视频/封面混流，游戏内可直接播放。

## r480 相对早期版本的关键逻辑

- **决战音乐自动切换**（`FinalBattleMusic`，由 `CommonEvents` 的 LevelTick 驱动）：
  - 普瑞塞斯出现（同维度存在存活的她）即播放「玩家 × 普瑞塞斯」决战曲《火与灰》
    （`player_priestess_battle_music.ogg`）；
  - 博士出现后自动切换为「博士 × 普瑞塞斯」决战曲《焰烬曙明》
    （`final_battle_music.ogg`）；
  - 博士离场且普瑞塞斯仍在场时再切回《火与灰》。
- **决战局面禁止起舞**（`PriestessDoctorDuel`）：
  - 只要场上同时存在普瑞塞斯与博士，即视为决战局面；
  - 「多索雷斯假日」舞蹈（`BossTauntLogic` / `NativeApocataTauntLogic`）不再触发，
    已开跳的会被强制收舞；即使被枪械 / 魔法等外部伤害击中也不会起舞。
- **音频清理**：所有旧版音频已删除，`sounds/` 下仅保留 `sounds.json` 引用的 7 首现行曲目，
  中英双语字幕条目与之一一对应。
